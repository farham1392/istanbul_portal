<?php
session_start();

$conn = new mysqli("localhost", "root", "", "medicine_manager");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (!isset($_SESSION['user_id'])) {
    die("لطفاً وارد حساب کاربری خود شوید.");
}

$user_id = $_SESSION['user_id'];

$medicines = $conn->query("SELECT * FROM medicines WHERE user_id='$user_id'");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['action']) && $_POST['action'] == 'add') {
        $name = $_POST["name"];
        $dosage = $_POST["dosage"];
        $time = $_POST["time"];
        $details = $_POST["details"];
        
        $sql = "INSERT INTO medicines (user_id, name, dosage, time, details) 
                VALUES ('$user_id', '$name', '$dosage', '$time', '$details')";
        if ($conn->query($sql) === TRUE) {
            echo "دارو با موفقیت ثبت شد.";
            header("Location: " . $_SERVER['PHP_SELF']);
            exit;
        } else {
            echo "Error: " . $conn->error;
        }
    }

    // ویرایش دارو
    if (isset($_POST['action']) && $_POST['action'] == 'edit') {
        $id = $_POST["id"];
        $name = $_POST["name"];
        $dosage = $_POST["dosage"];
        $time = $_POST["time"];
        $details = $_POST["details"];
        
        $sql = "UPDATE medicines SET name='$name', dosage='$dosage', time='$time', details='$details' WHERE id='$id' AND user_id='$user_id'";
        if ($conn->query($sql) === TRUE) {
            echo "دارو با موفقیت ویرایش شد.";
            header("Location: " . $_SERVER['PHP_SELF']);
            exit;
        } else {
            echo "Error: " . $conn->error;
        }
    }

    // حذف دارو
    if (isset($_POST['action']) && $_POST['action'] == 'delete') {
        $id = $_POST["id"];
        $sql = "DELETE FROM medicines WHERE id='$id' AND user_id='$user_id'";
        if ($conn->query($sql) === TRUE) {
            echo "دارو با موفقیت حذف شد.";
            header("Location: " . $_SERVER['PHP_SELF']);
            exit;
        } else {
            echo "Error: " . $conn->error;
        }
    }
}
?>

<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>مدیریت داروها</title>
    <style>
        * {
            font-family: pinar;
        }
        body {
            background-color: #242424;
            color: #fff;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            flex-direction: column;
        }
        h2 {
            text-align: center;
            color: #fff;
            margin-top: 20px;
        }
        .cards-container {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            gap: 20px;
            padding: 20px;
            width: 100%;
            max-width: 1200px;
        }
        .card {
            background-color: #333;
            border-radius: 8px;
            margin: 10px;
            padding: 15px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.3);
            transition: transform 0.3s ease;
            width: 250px;
            text-align: center;
        }
        .card:hover {
            transform: scale(1.05);
        }
        .card h3 {
            font-size: 1.5em;
            color: #00d2d2;
        }
        .card p {
            margin: 5px 0;
            color: #ddd;
        }
        button {
            background-color: #00d2d2;
            color: #fff;
            border: none;
            padding: 10px 20px;
            font-size: 1em;
            cursor: pointer;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }
        button:hover {
            background-color: #008f8f;
        }
        #popup {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.7);
            justify-content: center;
            align-items: center;
        }
        #popup form {
            background-color: #333;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.5);
            width: 300px;
        }
        #popup input, #popup textarea {
            width: 100%;
            padding: 4px;
            margin: 10px 0;
            border: 1px solid #555;
            border-radius: 5px;
            background-color: #444;
            color: #fff;
        }
        #popup textarea {
            height: 100px;
            resize: none;
        }
        #popup button {
            width: 100%;
            background-color: #00d2d2;
            padding: 12px;
            border-radius: 5px;
        }
        #popup button:hover {
            background-color: #008f8f;
        }
    </style>
</head>
<body>

<button onclick="document.getElementById('popup').style.display='flex'">+ ثبت دارو</button>

<div id="popup">
    <form method="post">
        <input type="text" name="name" placeholder="نام دارو" required>
        <input type="text" name="dosage" placeholder="دوز دارو" required>
        <input type="text" name="time" placeholder="ساعت مصرف" required>
        <textarea name="details" placeholder="جزئیات"></textarea>
        <input type="hidden" name="action" value="add">
        <input type="hidden" name="id" value="">
        <button type="submit">ثبت</button>
    </form>
</div>

<h2>داروهای شما</h2>

<div class="cards-container">
    <?php if ($medicines->num_rows > 0): ?>
        <?php while ($row = $medicines->fetch_assoc()): ?>
            <div class="card">
                <h3><?= $row["name"] ?></h3>
                <p>دوز: <?= $row["dosage"] ?></p>
                <p>زمان: <?= $row["time"] ?></p>
                <p>جزئیات: <?= $row["details"] ?></p>

                <!-- دکمه ویرایش -->
                <button onclick="editMedicine(<?= $row['id'] ?>, '<?= $row['name'] ?>', '<?= $row['dosage'] ?>', '<?= $row['time'] ?>', '<?= $row['details'] ?>')">ویرایش</button>
                <!-- دکمه حذف -->
                <form method="post" style="display:inline;">
                    <input type="hidden" name="action" value="delete">
                    <input type="hidden" name="id" value="<?= $row['id'] ?>">
                    <button type="submit">حذف</button>
                </form>
            </div>
        <?php endwhile; ?>
    <?php else: ?>
        <p>هیچ دارویی ثبت نشده است.</p>
    <?php endif; ?>
</div>

<script>
    function editMedicine(id, name, dosage, time, details) {
        document.querySelector("#popup input[name='id']").value = id;
        document.querySelector("#popup input[name='name']").value = name;
        document.querySelector("#popup input[name='dosage']").value = dosage;
        document.querySelector("#popup input[name='time']").value = time;
        document.querySelector("#popup textarea[name='details']").value = details;
        document.querySelector("#popup input[name='action']").value = "edit";
        document.getElementById('popup').style.display = 'flex';
    }
</script>

</body>
</html>

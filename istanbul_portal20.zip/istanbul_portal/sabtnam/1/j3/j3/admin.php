<?php
session_start();
$conn = new mysqli("localhost", "root", "", "medicine_manager");

if (!isset($_SESSION["user_id"]) || $_SESSION["role"] != "admin") {
    header("Location: login.php");
}

$medicines = $conn->query("SELECT * FROM medicines");

if (isset($_GET["delete"])) {
    $id = $_GET["delete"];
    $conn->query("DELETE FROM medicines WHERE id='$id'");
    header("Location: admin.php");
}

if (isset($_GET["edit"])) {
    $id = $_GET["edit"];
    $medicine = $conn->query("SELECT * FROM medicines WHERE id='$id'")->fetch_assoc();
}

if (isset($_POST["update"])) {
    $id = $_POST["id"];
    $name = $_POST["name"];
    $dosage = $_POST["dosage"];
    $time = $_POST["time"];
    $details = $_POST["details"];
    $conn->query("UPDATE medicines SET name='$name', dosage='$dosage', time='$time', details='$details' WHERE id='$id'");
    header("Location: admin.php");
}
?>

<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>مدیریت داروها</title>
    <style>
                * {
            @font-face {
                font-family: pinar;
                src: url('PINAR-LIGHT.TTF');
            }
            font-family:pinar;  
        }
        
        body {
            @font-face {
                font-family: pinar;
                src: url('PINAR-LIGHT.TTF');
            }
            font-family: 'Tahoma', sans-serif;
            background-color: #242424;
            color: #fff;
            margin: 0;
            padding: 0;
            /* display: flex; */
            justify-content: center;
            align-items: flex-start;
            flex-direction: column;
            height: 100vh;
            padding-top: 50px;
            font-family: pinar;
        }

        h2 {
            color: #00d2d2;
            text-align: center;
            margin-bottom: 30px;
            font-size: 2em;
        }

        .card-container {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            gap: 20px;
            margin-top: 20px;
            width: 80%;
        }

        .card {
            background-color: #333;
            border-radius: 8px;
            padding: 20px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.5);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            width: 250px;
            text-align: center;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
        }

        .card:hover {
            transform: translateY(-5px);
            box-shadow: 0 6px 15px rgba(0, 0, 0, 0.7);
        }

        .card h3 {
            color: #00d2d2;
            font-size: 1.6em;
            margin-bottom: 10px;
        }

        .card p {
            margin: 5px 0;
            color: #ddd;
            font-size: 1em;
        }

        .card a {
            color: #ff4d4d;
            font-size: 1.2em;
            margin-top: 15px;
            text-decoration: none;
            transition: color 0.3s ease;
        }

        .card a:hover {
            color: #ff1a1a;
        }

        /* Edit Form */
        .edit-form-overlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.7);
            display: flex;
            justify-content: center;
            align-items: center;
            z-index: 999;
        }

        .edit-form {
            background-color: #333;
            padding: 20px;
            width: 400px;
            border-radius: 8px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.5);
            position: relative;
        }

        .edit-form input, .edit-form textarea, .edit-form button {
            width: 100%;
            padding: 4px;
            margin: 10px 0;
            border-radius: 5px;
            border: 1px solid #ddd;
            background-color: #444;
            color: #fff;
        }

        .edit-form button {
            background-color: #00d2d2;
            border: none;
            cursor: pointer;
            font-size: 1.2em;
        }

        .edit-form button:hover {
            background-color: #00b8b8;
        }

        .edit-form .close {
            position: absolute;
            top: 10px;
            right: 10px;
            font-size: 1.5em;
            color: #fff;
            cursor: pointer;
        }
    </style>
</head>
<body>

<h2>مدیریت داروها</h2>

<div class="card-container">
    <?php while ($row = $medicines->fetch_assoc()): ?>
        <div class="card">
            <h3><?= $row["name"] ?></h3>
            <p>دوز: <?= $row["dosage"] ?></p>
            <p>زمان: <?= $row["time"] ?></p>
            <p>جزئیات: <?= $row["details"] ?></p>
            <a href="admin.php?delete=<?= $row['id'] ?>">حذف</a>
            <a href="admin.php?edit=<?= $row['id'] ?>">ویرایش</a>
        </div>
    <?php endwhile; ?>
</div>

<?php if (isset($medicine)): ?>
    <div class="edit-form-overlay">
        <div class="edit-form">
            <span class="close" onclick="window.location.href='admin.php'">&times;</span>
            <h3>ویرایش دارو</h3>
            <form method="POST">
                <input type="hidden" name="id" value="<?= $medicine['id'] ?>">
                <input type="text" name="name" value="<?= $medicine['name'] ?>" placeholder="نام دارو" required>
                <input type="text" name="dosage" value="<?= $medicine['dosage'] ?>" placeholder="دوز دارو" required>
                <input type="text" name="time" value="<?= $medicine['time'] ?>" placeholder="زمان مصرف" required>
                <textarea name="details" placeholder="جزئیات دارو" required><?= $medicine['details'] ?></textarea>
                <button type="submit" name="update">بروزرسانی</button>
            </form>
        </div>
    </div>
<?php endif; ?>

</body>
</html>

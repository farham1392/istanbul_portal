<?php
session_start();
$conn = new mysqli("localhost", "root", "", "medicine_manager");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST["username"];
    $password = password_hash($_POST["password"], PASSWORD_BCRYPT);
    $role = $_POST["role"];

    $sql = "INSERT INTO users (username, password, role) VALUES ('$username', '$password', '$role')";
    if ($conn->query($sql) === TRUE) {
        if ($role == "admin") {
            header("Location: admin.php");
        } else {
            header("Location: login.php");
        }
    }
}
?>

<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>صفحه ثبت نام</title>
    <style>

* {
            @font-face {
                font-family: pinar;
                src: url('PINAR-LIGHT.TTF');
            }
            font-family:pinar;  
        }
        
        body {
            font-family: 'Tahoma', sans-serif;
            background-color: #242424;
            color: #fff;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background-image: linear-gradient(45deg, #333, #444);
        }

        .form-container {
            background-color: #333;
            padding: 40px 60px;
            border-radius: 10px;
            box-shadow: 0 6px 15px rgba(0, 0, 0, 0.3);
            width: 100%;
            max-width: 400px;
        }

        h2 {
            text-align: center;
            color: #00d2d2;
            margin-bottom: 20px;
            font-size: 1.8em;
        }

        input, select {
            width: 100%;
            padding: 12px;
            margin: 10px 0;
            border: 1px solid #555;
            border-radius: 5px;
            background-color: #444;
            color: #fff;
            font-size: 1em;
        }

        input::placeholder, select {
            color: #bbb;
        }

        button {
            background-color: #00d2d2;
            color: #fff;
            border: none;
            padding: 12px 20px;
            font-size: 1.1em;
            cursor: pointer;
            border-radius: 5px;
            width: 100%;
            transition: background-color 0.3s ease;
        }

        button:hover {
            background-color: #008f8f;
        }

        .form-container select {
            background-color: #444;
        }

        .form-container input:focus, .form-container select:focus {
            border-color: #00d2d2;
            outline: none;
        }
    </style>
</head>
<body>

<div class="form-container">
    <h2>ثبت‌نام</h2>
    <form method="post">
        <input type="text" name="username" placeholder="نام کاربری" required>
        <input type="password" name="password" placeholder="رمز عبور" required>
        <select name="role">
            <option value="user">کاربر</option>
            <option value="admin">ادمین</option>
        </select>
        <button type="submit">ثبت‌نام</button>
    </form>
</div>

</body>
</html>

<?php
// اتصال به پایگاه داده
$db = mysqli_connect('localhost', 'root', '', 'yadavari');
if (!$db) {
    die("Connection failed: " . mysqli_connect_error());
}

// حذف کاربر
if (isset($_POST['del_id'])) {
    $daro_del_id = $_POST['del_id'];
    mysqli_query($db, "DELETE FROM user WHERE id = '$daro_del_id'");
}

// ویرایش کاربر
if (isset($_POST['edit_id'])) {
    $edit_id = $_POST['edit_id'];
    $edit_namekarbar = $_POST['namekarbar'];  // نام کاربری جدید
    $edit_name = $_POST['namefull'];
    $edit_mobil = $_POST['inputmobil'];
    $edit_pass = $_POST['inputPassword5'];

    // حذف کاراکترهای غیر عددی از موبایل
    $edit_mobil = preg_replace('/\D/', '', $edit_mobil);  // حذف کاراکترهای غیر عددی

    // بررسی اطلاعات وارد شده
    if (strlen($edit_namekarbar) < 3 || strlen($edit_namekarbar) > 50) {
        $error = 'نام کاربری باید بین 3 تا 50 کاراکتر باشد';
    }

    if (strlen($edit_name) < 3 || strlen($edit_name) > 50) {
        $error = 'نام خانوادگی اشتباه است';
    }

    // بررسی موبایل
    if (strlen($edit_mobil) != 11) {
        $error = 'موبایل باید دقیقاً 11 رقم باشد';
    } elseif (substr($edit_mobil, 0, 2) != '09') {
        $error = 'موبایل باید با 09 شروع شود';
    }

    if (strlen($edit_pass) < 6 || strlen($edit_pass) > 11) {
        $error = 'رمز باید بین 6 تا 11 کاراکتر باشد';
    }

    if ($error == '-') {
        mysqli_query($db, "UPDATE user SET namekarbar = '$edit_namekarbar', family = '$edit_name', tel = '$edit_mobil', pass = '$edit_pass' WHERE id = '$edit_id'");
        echo "<div class='alert alert-success text-center'>ویرایش با موفقیت انجام شد!</div>";
        echo "<meta http-equiv='refresh' content='1; url='#'>";
    } else {
        echo "<div class='alert alert-danger text-center'>{$error}</div>";
    }
}
?>

<html dir="rtl">
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        body {
            background-color: #f7f7f7;
            font-family: 'Iran Sans', sans-serif;
        }

        .table-container {
            margin-top: 50px;
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        }

        table {
            width: 100%;
            border-radius: 8px;
            overflow: hidden;
        }

        th, td {
            text-align: center;
            padding: 12px;
        }

        th {
            background-color: #4CAF50;
            color: white;
            border-bottom: 2px solid #ddd;
        }

        td {
            background-color: #f9f9f9;
            border-bottom: 1px solid #ddd;
        }

        .btn-warning {
            background-color: #f39c12;
            border-color: #f39c12;
            color: white;
        }

        .btn-warning:hover {
            background-color: #e67e22;
            border-color: #e67e22;
        }

        .btn-danger {
            background-color: #e74c3c;
            border-color: #e74c3c;
            color: white;
        }

        .btn-danger:hover {
            background-color: #c0392b;
            border-color: #c0392b;
        }

        .btn-success {
            background-color: #2ecc71;
            border-color: #2ecc71;
            color: white;
        }

        .btn-success:hover {
            background-color: #27ae60;
            border-color: #27ae60;
        }

        /* برای صفحه‌های کوچک‌تر (مثل موبایل‌ها) */
        @media (max-width: 767px) {
            .table-container {
                padding: 10px;
            }

            .btn-warning, .btn-danger, .btn-success {
                font-size: 12px;
                padding: 5px;
            }

            table {
                font-size: 14px;
            }

            th, td {
                padding: 8px;
            }
        }
    </style>
</head>

<body>

    <h1 class="text-center mt-5">لیست کاربران</h1>

    <div class="table-container">
        <table class="table table-striped table-bordered">
            <thead>
                <tr>
                    <th>ردیف</th>
                    <th>نام کاربری</th>
                    <th>نام خانوادگی</th>
                    <th>موبایل</th>
                    <th>عملیات</th>
                </tr>
            </thead>
            <tbody>
                <?php
                // نمایش لیست کاربران
                $result = mysqli_query($db, "SELECT * FROM user");
                $i = 1;
                while ($row = mysqli_fetch_assoc($result)) {
                    echo "
                    <tr>
                        <td>{$i}</td>
                        <td>{$row['namekarbar']}</td>
                        <td>{$row['family']}</td>
                        <td>{$row['tel']}</td>
                        <td>
                            <button class='btn btn-warning' data-bs-toggle='modal' data-bs-target='#editModal{$row['id']}'>
                                <i class='bi bi-pencil-square'></i> ویرایش
                            </button>
                            <button class='btn btn-danger' data-bs-toggle='modal' data-bs-target='#deleteModal{$row['id']}'>
                                <i class='bi bi-trash'></i> حذف
                            </button>
                        </td>
                    </tr>
                    ";
                    $i++;
                }
                ?>
            </tbody>
        </table>
    </div>

    <!-- Modal Edit -->
    <?php
    $result = mysqli_query($db, "SELECT * FROM user");
    while ($row = mysqli_fetch_assoc($result)) {
        echo "
        <div class='modal fade' id='editModal{$row['id']}' tabindex='-1' aria-labelledby='editModalLabel' aria-hidden='true'>
            <div class='modal-dialog'>
                <div class='modal-content'>
                    <div class='modal-header'>
                        <h5 class='modal-title' id='editModalLabel'>ویرایش اطلاعات کاربر</h5>
                        <button type='button' class='btn-close' data-bs-dismiss='modal' aria-label='Close'></button>
                    </div>
                    <div class='modal-body'>
                        <form action='' method='POST'>
                            <input type='hidden' name='edit_id' value='{$row['id']}'>
                            <label for='namekarbar'>نام کاربری</label>
                            <input type='text' name='namekarbar' class='form-control' value='{$row['namekarbar']}' required><br>
                            <label for='namefull'>نام خانوادگی</label>
                            <input type='text' name='namefull' class='form-control' value='{$row['family']}' required><br>
                            <label for='inputmobil'>موبایل</label>
                            <input type='tel' name='inputmobil' class='form-control' value='{$row['tel']}' required><br>
                            <label for='inputPassword5'>رمز</label>
                            <input type='password' name='inputPassword5' class='form-control' value='{$row['pass']}' required><br>
                            <button type='submit' class='btn btn-success'>ذخیره تغییرات</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        ";
    }
    ?>

    <!-- Modal Delete -->
    <?php
    $result = mysqli_query($db, "SELECT * FROM user");
    while ($row = mysqli_fetch_assoc($result)) {
        echo "
        <div class='modal fade' id='deleteModal{$row['id']}' tabindex='-1' aria-labelledby='deleteModalLabel' aria-hidden='true'>
            <div class='modal-dialog'>
                <div class='modal-content'>
                    <div class='modal-header'>
                        <h5 class='modal-title' id='deleteModalLabel'>حذف کاربر</h5>
                        <button type='button' class='btn-close' data-bs-dismiss='modal' aria-label='Close'></button>
                    </div>
                    <div class='modal-body'>
                        <p>آیا از حذف این کاربر مطمئن هستید؟</p>
                    </div>
                    <div class='modal-footer'>
                        <form action='' method='POST'>
                            <input type='hidden' name='del_id' value='{$row['id']}'>
                            <button type='submit' class='btn btn-danger'>حذف</button>
                            <button type='button' class='btn btn-secondary' data-bs-dismiss='modal'>انصراف</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        ";
    }
    ?>
</body>
</html>

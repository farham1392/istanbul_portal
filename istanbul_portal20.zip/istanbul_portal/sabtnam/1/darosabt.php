<?php

$db = mysqli_connect('localhost', 'root', '', 'yadavari');

$ok = false;
$error = '-';

if (isset($_GET["namedaro"])) {

    $daro = $_GET["namedaro"];
    $date = $_GET["date"];
    $time = $_GET["time"];
    $meghdar = $_GET["meghdar"];
    $day = $_GET["day"];

    mysqli_query($db, " INSERT INTO daro (named, dated, tim, dosage, numberdate) 
    values ('$daro', '$date', '$time', '$meghdar', '$day')");
}

if (isset($_GET['del'])) {
    $daro_del_id = $_GET['del'];
    $sql = mysqli_query($db, " DELETE FROM `daro` WHERE  id='$daro_del_id'");
}

?>

<html dir="rtl">

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    
    <!-- اضافه کردن لینک فونت Vazir -->
    <link href="https://cdn.jsdelivr.net/npm/@fontsource/vazir/latin.css" rel="stylesheet">
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    <link href="css1.css" rel="stylesheet">

    <style>
        /* استفاده از فونت Vazir در کل صفحه */
        body {
            font-family: 'Vazir', sans-serif;
            background-color: #f8f9fa;
            padding: 20px;
        }

        h1 {
            color: #2c3e50;
            text-align: center;
            font-size: 36px;
            font-weight: bold;
            margin-bottom: 40px;
        }

        .formdaro {
            background-color: #ffffff;
            border-radius: 10px;
            box-shadow: 0px 4px 12px rgba(0, 0, 0, 0.1);
            padding: 30px;
            width: 100%;
            max-width: 600px;
            margin: 0 auto;
        }

        .formdaro span {
            font-size: 16px;
            margin-bottom: 5px;
            display: block;
            color: #4a4a4a;
        }

        .formdaro input {
            width: 100%;
            padding: 12px;
            margin-bottom: 20px;
            border-radius: 8px;
            border: 1px solid #ddd;
            font-size: 16px;
            color: #555;
        }

        .formdaro input:focus {
            outline: none;
            border-color: #007bff;
            box-shadow: 0 0 5px rgba(0, 123, 255, 0.2);
        }

        .formdaro button {
            width: 100%;
            padding: 14px;
            background-color: #007bff;
            border: none;
            border-radius: 8px;
            color: white;
            font-size: 18px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .formdaro button:hover {
            background-color: #0056b3;
        }

        .formdaro button:active {
            background-color: #004085;
        }

        .formdaro button:focus {
            outline: none;
        }

        /* For small screens */
        @media (max-width: 767px) {
            .formdaro {
                padding: 20px;
            }
        }

        /* Animations for inputs */
        .formdaro input,
        .formdaro button {
            transition: all 0.3s ease;
        }

        .formdaro input:focus {
            border-color: #007bff;
            transform: translateY(-2px);
        }

        .formdaro button:hover {
            transform: translateY(-2px);
        }

        /* Custom icon for the input fields */
        .formdaro .input-icon {
            position: absolute;
            left: 10px;
            top: 12px;
            font-size: 18px;
            color: #007bff;
        }

        .input-container {
            position: relative;
        }

        .formdaro input {
            padding-left: 30px;
        }
    </style>
</head>

<body>

    <h1>فرم ثبت دارو</h1>

    <!-- Form -->
    <form class="formdaro" method="get" action="darosabt.php">

        <div class="input-container">
            <span>نام دارو</span>
            <input name="namedaro" type="text" class="form-control" required>
            <i class="bi bi-pill input-icon"></i>
        </div>

        <div class="input-container">
            <span>تاریخ شروع</span>
            <input name="date" type="date" class="form-control" required>
            <i class="bi bi-calendar input-icon"></i>
        </div>

        <div class="input-container">
            <span>ساعت مصرف</span>
            <input name="time" type="time" class="form-control" required>
            <i class="bi bi-clock input-icon"></i>
        </div>

        <div class="input-container">
            <span>مقدار دز مصرف</span>
            <input name="meghdar" type="text" class="form-control" required>
            <i class="bi bi-capsule input-icon"></i>
        </div>

        <div class="input-container">
            <span>تعداد روزهای مصرف</span>
            <input name="day" type="text" class="form-control" required>
            <i class="bi bi-calendar-day input-icon"></i>
        </div>

        <button type="submit" id="btn_send">ثبت دارو</button>
    </form>

</body>

</html>

<?php
require_once 'jdf.php'; // Include JDF library for Jalali date conversion

// Function to convert Gregorian date to Jalali date
function jdate_gregorian_to_jalali($g_y, $g_m, $g_d) {
    $g_days_in_month = array(31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31);
    $j_days_in_month = array(31, 31, 31, 31, 31, 31, 30, 30, 30, 30, 30, 29);

    $gy = $g_y - 1600;
    $gm = $g_m - 1;
    $gd = $g_d - 1;

    $g_day_no = 365 * $gy + intval(($gy + 3) / 4) - intval(($gy + 99) / 100) + intval(($gy + 399) / 400);

    for ($i = 0; $i < $gm; ++$i)
        $g_day_no += $g_days_in_month[$i];

    if ($gm > 1 && (($gy % 4 == 0 && $gy % 100 != 0) || ($gy % 400 == 0)))
        $g_day_no++; // leap and after Feb

    $g_day_no += $gd;

    $j_day_no = $g_day_no - 79;

    $j_np = intval($j_day_no / 12053); // 12053 = 365*33 + 32/4
    $j_day_no %= 12053;

    $jy = 979 + 33 * $j_np + 4 * intval($j_day_no / 1461); // 1461 = 365*4 + 4/4
    $j_day_no %= 1461;

    if ($j_day_no >= 366) {
        $jy += intval(($j_day_no - 1) / 365);
        $j_day_no = ($j_day_no - 1) % 365;
    }

    for ($i = 0; $i < 11 && $j_day_no >= $j_days_in_month[$i]; ++$i)
        $j_day_no -= $j_days_in_month[$i];
    $jm = $i + 1;
    $jd = $j_day_no + 1;

    return array($jy, $jm, $jd);
}

// Database connection
try {
    $db = new PDO('mysql:host=localhost;dbname=yadavari', 'root', '');
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Database connection error: " . $e->getMessage());
}

// Handle POST requests
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['add'])) {
        $named = $_POST['named'];
        $dated = $_POST['dated'];
        $tim = $_POST['tim'];
        $stmt = $db->prepare("INSERT INTO daro (named, dated, tim, del) VALUES (?, ?, ?, 0)");
        $stmt->execute([$named, $dated, $tim]);
    } elseif (isset($_POST['update'])) {
        $daro_id = $_POST['daro_id'];
        $named = $_POST['named'];
        $dated = $_POST['dated'];
        $tim = $_POST['tim'];
        $stmt = $db->prepare("UPDATE daro SET named = ?, dated = ?, tim = ? WHERE idd = ?");
        $stmt->execute([$named, $dated, $tim, $daro_id]);
    } elseif (isset($_POST['delete'])) {
        $daro_id = $_POST['daro_id'];
        $stmt = $db->prepare("UPDATE daro SET del = 1 WHERE idd = ?");
        $stmt->execute([$daro_id]);
    }
    header("Location: " . $_SERVER['PHP_SELF']);
    exit;
}

// Fetch data for display
$query = "SELECT idd, named, dated, tim FROM daro WHERE del = 0";
$data = $db->query($query)->fetchAll(PDO::FETCH_ASSOC);

// Current reminders
$currentDate = date('Y-m-d');
$currentTime = date('H:i');
$reminderQuery = $db->prepare(
    "SELECT named, dated, tim FROM daro WHERE del = 0 AND dated = ? AND tim BETWEEN ? AND ADDTIME(?, '01:00')"
);
$reminderQuery->execute([$currentDate, $currentTime, $currentTime]);
$upcomingReminders = $reminderQuery->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <title>مدیریت داروها</title>
    <style>
        body {
            font-family: 'Iran Sans', sans-serif;
            background-color: #f5f5f5;
        }
        .table-responsive {
            overflow-x: auto;
        }
    </style>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-light bg-light">
    <div class="container-fluid">
        <a class="navbar-brand" href="#">مدیریت داروها</a>
    </div>
</nav>

<div class="container mt-5">
    <h2 class="text-center">مدیریت داروها</h2>

    <!-- Reminders -->
    <?php if (!empty($upcomingReminders)): ?>
        <div class="alert alert-info">
            <?php foreach ($upcomingReminders as $reminder): ?>
                یادآوری: مصرف داروی <strong><?= htmlspecialchars($reminder['named']) ?></strong> در ساعت <?= htmlspecialchars(substr($reminder['tim'], 0, 5)) ?>.<br>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>

    <!-- Table -->
    <div class="table-responsive">
        <table class="table table-bordered table-striped mt-4">
            <thead class="table-primary">
            <tr>
                <th>ردیف</th>
                <th>نام دارو</th>
                <th>تاریخ مصرف</th>
                <th>ساعت مصرف</th>
                <th>عملیات</th>
            </tr>
            </thead>
            <tbody>
            <?php
            $i = 1;
            foreach ($data as $row):
                list($jy, $jm, $jd) = jdate_gregorian_to_jalali(
                    intval(substr($row['dated'], 0, 4)),
                    intval(substr($row['dated'], 5, 2)),
                    intval(substr($row['dated'], 8, 2))
                );
                $jalaliDate = "$jy/$jm/$jd";
            ?>
            <tr>
                <td><?= $i++ ?></td>
                <td><?= htmlspecialchars($row['named']) ?></td>
                <td><?= $jalaliDate ?></td>
                <td><?= htmlspecialchars(substr($row['tim'], 0, 5)) ?></td>
                <td>
                    <form method="post" style="display:inline-block;">
                        <input type="hidden" name="daro_id" value="<?= $row['idd'] ?>">
                        <button type="button" class="btn btn-warning btn-sm" data-bs-toggle="modal" data-bs-target="#editModal<?= $row['idd'] ?>">ویرایش</button>
                        <button type="submit" name="delete" class="btn btn-danger btn-sm">حذف</button>
                    </form>
                </td>
            </tr>

            <!-- Edit Modal -->
            <div class="modal fade" id="editModal<?= $row['idd'] ?>" tabindex="-1" aria-labelledby="editModalLabel<?= $row['idd'] ?>" aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <form method="post">
                            <div class="modal-header">
                                <h5 class="modal-title" id="editModalLabel<?= $row['idd'] ?>">ویرایش دارو</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="بستن"></button>
                            </div>
                            <div class="modal-body">
                                <input type="hidden" name="daro_id" value="<?= $row['idd'] ?>">
                                <div class="mb-3">
                                    <label for="named" class="form-label">نام دارو</label>
                                    <input type="text" name="named" class="form-control" id="named" value="<?= htmlspecialchars($row['named']) ?>" required>
                                </div>
                                <div class="mb-3">
                                    <label for="dated" class="form-label">تاریخ مصرف</label>
                                    <input type="date" name="dated" class="form-control" id="dated" value="<?= $row['dated'] ?>" required>
                                </div>
                                <div class="mb-3">
                                    <label for="tim" class="form-label">ساعت مصرف</label>
                                    <input type="time" name="tim" class="form-control" id="tim" value="<?= htmlspecialchars(substr($row['tim'], 0, 5)) ?>" required>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="submit" name="update" class="btn btn-primary">ذخیره تغییرات</button>
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">لغو</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <!-- Add Button -->
    <button class="btn btn-success" data-bs-toggle="modal" data-bs-target="#addModal">افزودن داروی جدید</button>
    <button class="btn btn-danger"><a href="logout.php" style="color:white;">خروج</a></button>

    <!-- Add Modal -->
    <div class="modal fade" id="addModal" tabindex="-1" aria-labelledby="addModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <form method="post">
                    <div class="modal-header">
                        <h5 class="modal-title" id="addModalLabel">افزودن داروی جدید</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="بستن"></button>
                    </div>
                    <div class="modal-body">
                        <div class="mb-3">
                            <label for="named" class="form-label">نام دارو</label>
                            <input type="text" name="named" class="form-control" id="named" required>
                        </div>
                        <div class="mb-3">
                            <label for="dated" class="form-label">تاریخ مصرف</label>
                            <input type="date" name="dated" class="form-control" id="dated" required>
                        </div>
                        <div class="mb-3">
                            <label for="tim" class="form-label">ساعت مصرف</label>
                            <input type="time" name="tim" class="form-control" id="tim" required>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="submit" name="add" class="btn btn-primary">افزودن</button>
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">لغو</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>








<?php
$db = new mysqli('localhost', 'root', '', 'yadavari');
if ($db->connect_error) {
    die("خطا در اتصال به دیتابیس: " . $db->connect_error);
}

if (isset($_GET['id'])) {
    $id = intval($_GET['id']);

    // بازیابی اطلاعات رکورد
    $result = $db->query("SELECT * FROM daro WHERE idd = $id");
    if ($result && $result->num_rows > 0) {
        $row = $result->fetch_assoc();
    } else {
        die("رکورد پیدا نشد.");
    }

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $name_daro = $_POST['named'];
        $d_date = $_POST['dated'];
        $d_tim = $_POST['tim'];

        // به‌روزرسانی اطلاعات رکورد
        $stmt = $db->prepare("UPDATE daro SET named = ?, dated = ?, tim = ? WHERE idd = ?");
        $stmt->bind_param("sssi", $name_daro, $d_date, $d_tim, $id);
        if ($stmt->execute()) {
            echo "اطلاعات با موفقیت به‌روزرسانی شد.";
        } else {
            echo "خطا در به‌روزرسانی: " . $stmt->error;
        }
    }
} else {
    die("هیچ ID ارسال نشده است.");
}
?>
<!DOCTYPE html>
<html dir="rtl">
<head>

<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
</head>
<body>

<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="exampleModalLabel">ویرایش دارو</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
     
<form method="POST">
    <label>نام دارو:</label>
    <input type="text" name="named" value="<?php echo $row['named']; ?>" required>
    <label>تاریخ مصرف:</label>
    <input type="date" name="dated" value="<?php echo $row['dated']; ?>" required>
    <label>ساعت مصرف:</label>
    <input type="time" name="tim" value="<?php echo $row['tim']; ?>" required>
    <button type="submit">ذخیره</button>
</form>

  </div>
</div>
</body>
</html>
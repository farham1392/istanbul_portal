<?php
$db = mysqli_connect('localhost', 'root', '', 'yadavari');

$ok = false;
$error = '-';

if (isset($_GET["namedaro"])) {
    $daro = $_GET["namedaro"];
    $date = $_GET["date"];
    $time = $_GET["time"];
    $meghdar = $_GET["meghdar"];
    $day = $_GET["day"];
}

if (isset($_GET['del'])) {
    $daro_del_id = $_GET['del'];
    $sql = mysqli_query($db, " DELETE FROM `daro` WHERE  id='$daro_del_id'");
}
?>

<html dir="rtl">

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    <link href="css1.css" rel="stylesheet">
    <style>
        body {
            background-color: #f4f6f9;
            font-family: 'Vazir', sans-serif;
        }

        /* Sidebar styles */
        .sidebar {
            background-color: #2c3e50;
            color: white;
            height: 100vh;
            position: fixed;
            top: 0;
            left: 0;
            width: 250px;
            padding-top: 30px;
            border-radius: 10px;
        }

        .sidebar a {
            color: white;
            padding: 10px 15px;
            text-decoration: none;
            display: block;
            font-weight: bold;
            border-radius: 5px;
            margin: 5px 0;
        }

        .sidebar a:hover {
            background-color: #34495e;
        }

        .content {
            margin-left: 260px;
            padding: 20px;
        }

        .card {
            background-color: #ffffff;
            border-radius: 10px;
            box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1);
            padding: 20px;
            margin: 10px 0;
        }

        .table thead {
            background-color: #007bff;
            color: white;
        }

        .table tbody tr {
            background-color: #ffffff;
        }

        .table tbody tr:hover {
            background-color: #f1f1f1;
        }

        .table th,
        .table td {
            vertical-align: middle;
        }

        .btn-danger,
        .btn-primary {
            font-weight: bold;
        }

        .navbar {
            display: none;
        }
    </style>
    <h1 class="headh1"> </h1>

</head>

<body>

    <!-- Sidebar -->
    <div class="sidebar">
        <h3 class="text-center text-white">پنل مدیریت</h3>
        <a href="admin.php">داشبورد</a>
        <a href="darosabt.php">ثبت دارو</a>
        <a href="verayeshd.php">تغییرات دارو</a>
        <a href="vrayeshuser.php">مدیریت کاربران</a>
        
    </div>

    <!-- Main Content -->
    <div class="content">
        <h1 class="text-success text-center font-weight-bold" style="font-size: 40px;">داشبورد مدیریت داروخانه</h1>

        <!-- User Statistics and Quick Links -->
        <div class="row">
            <div class="col-md-4">
                <div class="card">
                    <h5>تعداد داروها</h5>
                    <p>تعداد داروهای موجود در سیستم: <strong>
                        <?php 
                            $result = mysqli_query($db, "SELECT COUNT(*) AS total FROM daro WHERE del = 0");
                            $row = mysqli_fetch_assoc($result);
                            echo $row['total'];
                        ?></strong></p>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card">
                    <h5>تعداد کاربران</h5>
                    <p>تعداد کاربران فعال: <strong>
                        <?php 
                            $result = mysqli_query($db, "SELECT COUNT(*) AS total FROM users WHERE status = 'active'");
                            $row = mysqli_fetch_assoc($result);
                            echo $row['total'];
                        ?></strong></p>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card">
                    <h5>تعداد داروهای حذف شده</h5>
                    <p>تعداد داروهای حذف شده: <strong>
                        <?php 
                            $result = mysqli_query($db, "SELECT COUNT(*) AS total FROM daro WHERE del = 1");
                            $row = mysqli_fetch_assoc($result);
                            echo $row['total'];
                        ?></strong></p>
                </div>
            </div>
        </div>

      
    </div>

</body>

</html>

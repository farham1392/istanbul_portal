
<?php


$db=mysqli_connect('localhost','root','','yadavari');
$ok=false; 
   if(isset($_GET["user"])){
     

$user=$_GET["user"];
$pass=$_GET["pass"];

$sql=mysqli_query($db,"select * from user where namekarbar='$user' and pass='$pass'");

      

if( $row=mysqli_fetch_assoc($sql)){
    

$mobil=$row['tel'];
$name=$row['namekarbar'];
         setcookie('mobil',$mobil,time()+(86400*30),"/");
         setcookie('namefull',$name,time()+(86400*30),"/");


  
         $_COOKIE['name']=$mobil[3];
        
         $_COOKIE['tell']=$name[1];
 


      

        $ok=true;


        }
       
        if ( $ok == true){
         echo '1';
        }
       else{
      
            echo '0';  
         
        }
      
        }

?>
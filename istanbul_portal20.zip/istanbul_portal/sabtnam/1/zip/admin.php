<?php
// اطلاعات پایگاه داده
$host = 'localhost';  
$username = 'heydarpo_narges';      
$password = 'Nn0918545634';   
$dbname = 'heydarpo_yadavari';

// اتصال به پایگاه داده
$db = mysqli_connect($host, $username, $password, $dbname);

// بررسی اتصال
if (!$db) {
    die("Database connection failed: " . mysqli_connect_error());
}

// تابعی برای تبدیل تاریخ میلادی به شمسی
function jdate_gregorian_to_jalali($g_y, $g_m, $g_d) {
    // عملکرد تبدیل میلادی به شمسی
    return [1399, 12, 30];  // فرض کنید برای تست یک تاریخ شمسی برمی‌گرداند
}

// بررسی متد POST برای عملیات‌های مختلف (افزودن، بروزرسانی، حذف)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['add'])) {
        // اضافه کردن دارو
        $named = $_POST['named'];
        $dated = $_POST['dated']; // تاریخ میلادی
        $tim = $_POST['tim'];

        // تبدیل تاریخ میلادی به شمسی
        list($g_y, $g_m, $g_d) = explode('-', $dated);
        list($jy, $jm, $jd) = jdate_gregorian_to_jalali($g_y, $g_m, $g_d);
        $jalaliDate = "$jy/$jm/$jd"; // ذخیره تاریخ به فرمت شمسی

        // درج دارو در پایگاه داده
        $stmt = mysqli_prepare($db, "INSERT INTO daro (named, dated, tim, del) VALUES (?, ?, ?, 0)");
        mysqli_stmt_bind_param($stmt, 'sss', $named, $jalaliDate, $tim);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);
    } elseif (isset($_POST['update'])) {
        // بروزرسانی دارو
        $daro_id = $_POST['daro_id'];
        $named = $_POST['named'];
        $dated = $_POST['dated']; // تاریخ میلادی
        $tim = $_POST['tim'];

        // تبدیل تاریخ میلادی به شمسی
        list($g_y, $g_m, $g_d) = explode('-', $dated);
        list($jy, $jm, $jd) = jdate_gregorian_to_jalali($g_y, $g_m, $g_d);
        $jalaliDate = "$jy/$jm/$jd"; // ذخیره تاریخ به فرمت شمسی

        // بروزرسانی دارو در پایگاه داده
        $stmt = mysqli_prepare($db, "UPDATE daro SET named = ?, dated = ?, tim = ? WHERE idd = ?");
        mysqli_stmt_bind_param($stmt, 'sssi', $named, $jalaliDate, $tim, $daro_id);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);
    } elseif (isset($_POST['delete'])) {
        // حذف دارو
        $daro_id = $_POST['daro_id'];
        $stmt = mysqli_prepare($db, "UPDATE daro SET del = 1 WHERE idd = ?");
        mysqli_stmt_bind_param($stmt, 'i', $daro_id);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);
    }
    header("Location: " . $_SERVER['PHP_SELF']);
    exit;
}

// دریافت داده‌ها برای نمایش
$query = "SELECT idd, named, dated, tim FROM daro WHERE del = 0";
$data = mysqli_query($db, $query);

// تاریخ و زمان کنونی
$currentDate = date('Y-m-d');
$currentTime = date('H:i');

// دریافت یادآوری‌ها
$reminderQuery = mysqli_prepare($db, "SELECT named, dated, tim FROM daro WHERE del = 0 AND dated = ? AND tim BETWEEN ? AND ADDTIME(?, '01:00')");
mysqli_stmt_bind_param($reminderQuery, 'sss', $currentDate, $currentTime, $currentTime);
mysqli_stmt_execute($reminderQuery);
$upcomingReminders = mysqli_stmt_get_result($reminderQuery);

?>

<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <title>مدیریت داروها</title>
    <style>
        body {
            font-family: 'Iran Sans', sans-serif;
            background-color: #f5f5f5;
        }
        .table-responsive {
            overflow-x: auto;
        }
    </style>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-light bg-light">
    <div class="container-fluid">
        <a class="navbar-brand" href="#">مدیریت داروها</a>
    </div>
</nav>

<div class="container mt-5">
    <h2 class="text-center">مدیریت داروها</h2>

    <!-- نمایش یادآوری‌ها -->
    <?php if (mysqli_num_rows($upcomingReminders) > 0): ?>
        <div class="alert alert-info">
            <?php while ($reminder = mysqli_fetch_assoc($upcomingReminders)): ?>
                یادآوری: مصرف داروی <strong><?= htmlspecialchars($reminder['named']) ?></strong> در ساعت <?= htmlspecialchars(substr($reminder['tim'], 0, 5)) ?>.<br>
            <?php endwhile; ?>
        </div>
    <?php endif; ?>

    <!-- جدول داروها -->
    <div class="table-responsive">
        <table class="table table-bordered table-striped mt-4">
            <thead class="table-primary">
            <tr>
                <th>ردیف</th>
                <th>نام دارو</th>
                <th>تاریخ مصرف</th>
                <th>ساعت مصرف</th>
                <th>عملیات</th>
            </tr>
            </thead>
            <tbody>
            <?php
            $i = 1;
            while ($row = mysqli_fetch_assoc($data)):
                list($jy, $jm, $jd) = jdate_gregorian_to_jalali(
                    intval(substr($row['dated'], 0, 4)),
                    intval(substr($row['dated'], 5, 2)),
                    intval(substr($row['dated'], 8, 2))
                );
                $jalaliDate = "$jy/$jm/$jd";
            ?>
            <tr>
                <td><?= $i++ ?></td>
                <td><?= htmlspecialchars($row['named']) ?></td>
                <td><?= $jalaliDate ?></td>
                <td><?= htmlspecialchars(substr($row['tim'], 0, 5)) ?></td>
                <td>
                    <form method="post" style="display:inline-block;">
                        <input type="hidden" name="daro_id" value="<?= $row['idd'] ?>">
                        <button type="button" class="btn btn-warning btn-sm" data-bs-toggle="modal" data-bs-target="#editModal<?= $row['idd'] ?>">ویرایش</button>
                        <button type="submit" name="delete" class="btn btn-danger btn-sm">حذف</button>
                    </form>
                </td>
            </tr>

            <!-- ویرایش دارو -->
            <div class="modal fade" id="editModal<?= $row['idd'] ?>" tabindex="-1" aria-labelledby="editModalLabel<?= $row['idd'] ?>" aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <form method="post">
                            <div class="modal-header">
                                <h5 class="modal-title" id="editModalLabel<?= $row['idd'] ?>">ویرایش دارو</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="بستن"></button>
                            </div>
                            <div class="modal-body">
                                <input type="hidden" name="daro_id" value="<?= $row['idd'] ?>">
                                <div class="mb-3">
                                    <label for="named" class="form-label">نام دارو</label>
                                    <input type="text" name="named" class="form-control" id="named" value="<?= htmlspecialchars($row['named']) ?>" required>
                                </div>
                                <div class="mb-3">
                                    <label for="dated" class="form-label">تاریخ مصرف</label>
                                    <input type="date" name="dated" class="form-control" id="dated" value="<?= $row['dated'] ?>" required>
                                </div>
                                <div class="mb-3">
                                    <label for="tim" class="form-label">ساعت مصرف</label>
                                    <input type="time" name="tim" class="form-control" id="tim" value="<?= htmlspecialchars(substr($row['tim'], 0, 5)) ?>" required>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="submit" name="update" class="btn btn-primary">ذخیره تغییرات</button>
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">لغو</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <?php endwhile; ?>
            </tbody>
        </table>
    </div>

    <!-- افزودن دارو -->
    <button class="btn btn-success" data-bs-toggle="modal" data-bs-target="#addModal">افزودن داروی جدید</button> </br>
    <button class="btn btn-danger"> <a href="logout.php">خروج</a></button>

    <!-- Modal افزودن دارو -->
    <div class="modal fade" id="addModal" tabindex="-1" aria-labelledby="addModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <form method="post">
                    <div class="modal-header">
                        <h5 class="modal-title" id="addModalLabel">افزودن داروی جدید</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="بستن"></button>
                    </div>
                    <div class="modal-body">
                        <div class="mb-3">
                            <label for="named" class="form-label">نام دارو</label>
                            <input type="text" name="named" class="form-control" id="named" required>
                        </div>
                        <div class="mb-3">
                            <label for="dated" class="form-label">تاریخ مصرف</label>
                            <input type="date" name="dated" class="form-control" id="dated" required>
                        </div>
                        <div class="mb-3">
                            <label for="tim" class="form-label">ساعت مصرف</label>
                            <input type="time" name="tim" class="form-control" id="tim" required>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="submit" name="add" class="btn btn-primary">افزودن</button>
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">لغو</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

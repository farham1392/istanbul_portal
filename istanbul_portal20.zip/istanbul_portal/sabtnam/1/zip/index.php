<?php
$COOKIE_user = "user";
$COOKIE_value = "1";

date_default_timezone_set("Asia/Tehran");
$date = date("Y/m/d H:i:s");  // فرمت تاریخ و ساعت به‌صورت سال/ماه/روز ساعت:دقیقه:ثانیه
$ok = false;

$_COOKIE['a'] = 2;

if (isset($_COOKIE['mobil'])) {
    echo '<meta http-equiv="refresh" content="0; url=verayeshd.php">';
    die();
} else {
    $_COOKIE['namefullul'] = '';
    $_COOKIE['tell'] = '';
}

if (isset($_GET["user"])) {
    $user = $_GET["user"];
    $pass = $_GET["pass"];
}
?>

<html dir="rtl">
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

    <!-- اضافه کردن Font Awesome برای استفاده از آیکون‌ها -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">

    <!-- اضافه کردن بوت‌استرپ -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>

    <!-- اضافه کردن فونت Vazir -->
    <link href="https://cdn.jsdelivr.net/npm/@fontsource/vazir/latin.css" rel="stylesheet">

    <style>
        body {
            background-color: #f4f8f9;
            font-family: 'Vazir', sans-serif;
            margin: 0;
            padding: 0;
        }

        .nav {
            background-color: #007bff;
            padding: 10px;
        }

        .nav-link {
            color: white;
            font-size: 16px;
        }

        .nav-link:hover {
            background-color: #0056b3;
        }

        .form-container {
            display: flex;
            justify-content: center;
            flex-wrap: wrap;
            margin: 20px auto;
        }

        .form {
            max-width: 400px;
            padding: 20px;
            border: 1px solid #ddd;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            background-color: white;
        }

        .form label {
            font-weight: bold;
        }

        .btn {
            font-size: 16px;
        }

        .img-fluid {
            max-width: 100%;
            height: auto;
        }

        @media (max-width: 576px) {
            .nav-link {
                font-size: 14px;
            }

            .form {
                width: 90%;
                padding: 15px;
            }
        }
    </style>
</head>

<body>

<!-- Navbar -->
<ul class="nav nav-pills">
    <li class="nav-item">
        <a class="nav-link active" href="#">
            <i class="fas fa-calendar"></i> <?php echo $date ?>
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="sabtnam.php">
            <i class="fas fa-edit"></i> ثبت نام  در داروخانه
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="index.php">
            <i class="fas fa-home"></i> صفحه اصلی
        </a>
    </li>
</ul>

<div class="form-container">
    <!-- Image Section -->
    <div>
        <img src="maghz6.png" alt="Image" class="img-fluid">
    </div> 

    <!-- Login Form Section -->
    <div class="form">
        <h4 class="text-center mb-3">ورود به سیستم</h4>
        <div class="mb-3">
            <label for="inputnamekarbari" class="form-label"><i class="fas fa-user"></i> نام کاربری</label>
            <input type="text" name="user" id="user" class="form-control" aria-describedby="passwordHelpBlock">
        </div>
        <div class="mb-3">
            <label for="inputPassword5" class="form-label"><i class="fas fa-key"></i> رمز ورود</label>
            <div class="input-group">
                <input type="password" id="pass" name="pass" class="form-control">
                <button type="button" class="btn btn-outline-secondary" id="togglePassword" onclick="togglePassword()">
                    <i class="fas fa-eye"></i>
                </button>
            </div>
        </div>

        <div class="mb-3">
            <button id="btn_send" onclick="send();" class="btn btn-success w-100">
                <i class="fas fa-paper-plane"></i> ارسال
            </button>
        </div>
        <div class="mb-3">
            <button type="button" class="btn btn-primary w-100">
                <a href="sabtnam.php" style="color: white; text-decoration: none;">
                    <i class="fas fa-user-plus"></i> ثبت نام
                </a>
            </button>
        </div>

        <div id='error1' style="display:none; color: red; text-align: center;">
            <i class="fas fa-exclamation-circle"></i> خطاااااااا
        </div>
        <div id='ok1' style="display:none; color: green; text-align: center;">
            <i class="fas fa-check-circle"></i> شما وارد شدید
        </div>
    </div>
</div>

<script>
    function send(){
        user = document.getElementById('user').value;
        pass = document.getElementById('pass').value;
        document.getElementById("error1").style.display = "none";
        document.getElementById("btn_send").disabled = true;
        document.getElementById("btn_send").textContent = "در حال ارسال";
        
        var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                console.log(this.responseText);
                let ok = this.responseText;
                document.getElementById("btn_send").disabled = false;
                document.getElementById("btn_send").textContent = "دریافت شد";
                if (ok == true) {
                    document.getElementById("error1").style.display = "none";
                    document.getElementById("ok1").style.display = "block";
                    window.location.assign('verayeshd.php');
                } else {
                    document.getElementById("error1").style.display = "block";
                    document.getElementById("ok1").style.display = "none";
                }
            }
        };
        xmlhttp.open("GET", "ajax.php?user=" + user + "&pass=" + pass, true);
        xmlhttp.send();
    }

    function togglePassword() {
        var passwordField = document.getElementById('pass');
        var eyeIcon = document.getElementById('togglePassword').querySelector('i');
        
        if (passwordField.type === "password") {
            passwordField.type = "text"; // نمایش رمز
            eyeIcon.classList.remove('fa-eye');
            eyeIcon.classList.add('fa-eye-slash');
        } else {
            passwordField.type = "password"; // مخفی کردن رمز
            eyeIcon.classList.remove('fa-eye-slash');
            eyeIcon.classList.add('fa-eye');
        }
    }
</script>

</body>
</html>
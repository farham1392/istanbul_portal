<?php
// اتصال به دیتابیس
$db = mysqli_connect('localhost', 'root', '', 'istanbul');
$ok = false;
$error = '-';

// بررسی ارسال فرم با متد POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // دریافت مقادیر از فرم
    $user = trim($_POST["user"]);
    $namefull = trim($_POST["namefull"]);
    $mobail = trim($_POST["inputmobil"]);
    $password = trim($_POST["inputPassword5"]);

    // بررسی صحت نام خانوادگی
    if (strlen($namefull) < 3 || strlen($namefull) > 50) {
        $error = 'نام خانوادگی اشتباه است';
    }

    // بررسی صحت شماره موبایل
    if (strlen($mobail) != 11) {
        $error = 'موبایل باید 11 رقم باشد';
    }

    if (substr($mobail, 0, 2) != '09') {
        $error = 'موبایل باید با 09 شروع شود';
    }

    // بررسی صحت رمز عبور
    if (strlen($password) < 6 || strlen($password) > 11) {
        $error = 'رمز عبور باید بین 6 تا 11 کاراکتر باشد';
    }

    // اگر خطا وجود نداشته باشد، اطلاعات ذخیره می‌شوند
    if ($error == '-') {
        $ok = true;

        // آماده سازی کوئری
        $stmt = $db->prepare("INSERT INTO user (family, tel, pass, namekarbar) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("ssss", $namefull, $mobail, $password, $user);
        
        // اجرای کوئری
        if ($stmt->execute()) {
            $ok = true;
        } else {
            $error = 'خطا در ثبت نام، لطفاً دوباره تلاش کنید';
        }

        $stmt->close();
    }
}
?>

<html dir="rtl">

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    
    <!-- اضافه کردن FontAwesome از CDN برای آیکن چشم -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" />

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>

    <style>
        body {
            background-color: #f5f5f5;
            font-family: 'Arial', sans-serif;
        }

        .form-container {
            max-width: 500px;
            margin: 50px auto;
            padding: 20px;
            background-color: #ffffff;
            border-radius: 10px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
            background-color: #e9f7ef; /* رنگ پس زمینه جدول فرم */
        }

        h1 {
            font-size: 32px;
            color: #4CAF50;
            text-align: center;
        }

        .form-group label {
            font-weight: bold;
        }

        .form-group input {
            border-radius: 5px;
            border: 1px solid #ccc;
            padding: 10px;
            width: 100%;
            font-size: 16px;
        }

        .btn {
            width: 100%;
            padding: 10px;
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 5px;
            font-size: 16px;
        }

        .btn:hover {
            background-color: #45a049;
        }

        .alert {
            margin-top: 20px;
            text-align: center;
        }

        .form-group .input-icon {
            position: absolute;
            top: 50%;
            right: 10px;
            transform: translateY(-50%);
            color: #888;
            cursor: pointer;
            font-size: 20px; /* بزرگتر کردن آیکن چشم */
        }

        .form-group {
            position: relative;
        }

        .form-group input[type="password"] {
            padding-right: 40px; /* برای آیکن */
        }

        .form-control:focus {
            border-color: #4CAF50;
            box-shadow: 0 0 5px rgba(76, 175, 80, 0.5);
        }
    </style>
</head>

<body>

    <div class="form-container">
        <h1>ثبت نام کاربر</h1>
        <form action="sabtnam.php" method="post">

            <div class="form-group">
                <label for="inputname">نام کاربری</label>
                <input type="text" id="inputname" name="user" class="form-control" autocomplete="off" required />
            </div>

            <div class="form-group">
                <label for="inputfamily">نام خانوادگی</label>
                <input type="text" id="inputfamily" name="namefull" class="form-control" autocomplete="off" required />
            </div>

            <div class="form-group">
                <label for="inputmobil">موبایل</label>
                <input type="tel" id="inputmobil" name="inputmobil" class="form-control" autocomplete="off" required />
            </div>

            <div class="form-group">
                <label for="inputPassword5">رمز عبور</label>
                <input type="password" id="inputPassword5" name="inputPassword5" class="form-control" autocomplete="off" required />
                <i class="fas fa-eye input-icon" id="togglePassword"></i>
            </div>

            <button type="submit" class="btn">ثبت نام</button>

            <div class="alert alert-danger mt-3" role="alert">
                <?php echo ($error != '-' ? $error : ''); ?>
            </div>
        </form>

        <?php
        if ($ok == true) {
            echo '<div class="alert alert-success">ثبت نام با موفقیت انجام شد!</div>';
            echo '<meta http-equiv="refresh" content="1; url=verayeshd.php">';
        }
        ?>
    </div>

    <script>
        // نمایش یا مخفی کردن رمز عبور
        const togglePassword = document.getElementById("togglePassword");
        const passwordField = document.getElementById("inputPassword5");

        togglePassword.addEventListener("click", function () {
            // اگر نوع رمز عبور password باشد، آن را به text تغییر دهیم تا نمایش داده شود
            const type = passwordField.getAttribute("type") === "password" ? "text" : "password";
            passwordField.setAttribute("type", type);

            // تغییر آیکن چشم
            this.classList.toggle("fa-eye-slash");
        });
    </script>

</body>

</html>
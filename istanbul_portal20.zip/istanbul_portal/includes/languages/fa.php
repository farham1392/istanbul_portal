<?php
return [
    'page_title' => 'راهنمای جامع استانبول | شهر دو قاره',
    'page_description' => 'راهنمای کامل سفر به استانبول با اطلاعات جاذبه‌های تاریخی، هتل‌ها، رستوران‌ها و برنامه‌ریز سفر',
    
    'nav_home' => 'خانه',
    'nav_discover' => 'کشف‌کنید',
    'nav_hotels' => 'اقامت',
    'nav_experiences' => 'تجربه‌ها',
    'nav_itinerary' => 'برنامه سفر',
    'nav_about' => 'درباره پروژه',
    
    'hero_title' => 'جادوی بی‌پایان استانبول 🇹🇷',
    'hero_subtitle' => 'جایی که شرق و غرب در هم می‌آمیزند',
    'hero_cta' => 'کشف استانبول',
    
    'stats_historical' => 'جاذبه تاریخی',
    'stats_hotels' => 'هتل و اقامتگاه',
    'stats_restaurants' => 'رستوران و کافه',
    'stats_undiscovered' => 'منطقه کشف‌نشده',
    
    'section_top_attractions' => 'جاذبه‌های برتر استانبول',
    'section_top_desc' => 'معروف‌ترین و دیدنی‌ترین مکان‌های شهر را کشف کنید',
    'section_view_all' => 'مشاهده همه',
    
    'section_categories' => 'بر اساس علاقه‌تان کشف کنید',
    'section_categories_desc' => 'دسته‌بندی‌های محبوب برای سفر شما',
    
    'category_historical' => 'تاریخی',
    'category_photography' => 'عکاسی',
    'category_food' => 'غذا',
    'category_shopping' => 'خرید',
    'category_sea' => 'دریایی',
    'category_nightlife' => 'شب‌زنده‌داری',
    
    'section_hotels' => 'اقامت‌گاه‌های منتخب',
    'section_hotels_desc' => 'بهترین هتل‌ها، ویلاها و اقامتگاه‌های محلی',
    
    'section_experiences' => 'تجربه‌های ویژه استانبول',
    'section_experiences_desc' => 'کارهایی که فقط در استانبول می‌توانید انجام دهید',
    
    'section_virtual' => 'تور مجازی ۳۶۰ درجه',
    'section_virtual_desc' => 'قبل از سفر از خانه دیدن کنید',
    
    'section_planner' => 'برنامه‌ریز سفر هوشمند',
    'section_planner_desc' => 'برنامه سفری شخصی‌سازی شده بر اساس علاقه شما',
    
    'planner_step1' => 'مدت سفر',
    'planner_step2' => 'علاقه‌مندی‌ها',
    'planner_step3' => 'بودجه',
    'planner_step4' => 'برنامه نهایی',
    
    'newsletter_title' => 'آماده کشف استانبول هستید؟ 🇹🇷',
    'newsletter_desc' => 'با خبرنامه ما، جدیدترین راهنمای سفر، تخفیف‌ها و تجربه‌های خاص را دریافت کنید',
    'newsletter_placeholder' => 'ایمیل خود را وارد کنید',
    'newsletter_button' => 'عضویت',
    
    'ai_assistant_title' => 'دستیار هوشمند استانبول 🇹🇷',
    'ai_assistant_status' => 'آنلاین • پاسخ بر اساس اطلاعات سایت',
    
    'footer_description' => 'راهنمای کامل و جامع برای کشف استانبول، شهر روی دو قاره. ما بهترین تجربه سفر را برای شما فراهم می‌کنیم.',
    
    'copyright' => 'تمامی حقوق محفوظ است.',
    'copyright_note' => 'این پروژه یک پروژه نمایشی است و با استانبول‌گردی واقعی مرتبط نمی‌باشد.',
];
?>
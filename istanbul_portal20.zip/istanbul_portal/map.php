<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>نقشه 3D استانبول - ماهواره‌ای + آب‌وهوا + مسیریاب هوشمند</title>
    
    <!-- Leaflet & Plugins -->
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
    <link rel="stylesheet" href="https://unpkg.com/leaflet-control-geocoder/dist/Control.Geocoder.css" />
    <link rel="stylesheet" href="https://unpkg.com/leaflet-routing-machine@3.2.12/dist/leaflet-routing-machine.css" />
    
    <!-- Font Awesome 6 -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <style>
        /* ===== استایل‌های کامل ===== */
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Vazirmatn', Tahoma, sans-serif;
            background: linear-gradient(135deg, #0c2461, #1e3799);
            color: white;
            min-height: 100vh;
            overflow-x: hidden;
        }
        .super-map-container {
            position: relative;
            width: 100%;
            height: 100vh;
            border-radius: 20px;
            overflow: hidden;
            box-shadow: 0 20px 60px rgba(0,0,0,0.5);
            border: 5px solid #ff6b6b;
        }
        #superMap { width: 100%; height: 100%; }

        /* ===== هدر سه‌زبانه و دکمه خانه ===== */
        .top-bar {
            position: absolute;
            top: 15px;
            left: 50%;
            transform: translateX(-50%);
            z-index: 2000;
            display: flex;
            gap: 20px;
            background: rgba(0, 0, 0, 0.7);
            backdrop-filter: blur(12px);
            padding: 12px 25px;
            border-radius: 50px;
            border: 1px solid rgba(255,255,255,0.3);
            box-shadow: 0 10px 30px rgba(0,0,0,0.5);
            align-items: center;
        }
        .home-btn {
            background: #ff6b6b;
            color: white;
            border: none;
            width: 45px;
            height: 45px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.3rem;
            cursor: pointer;
            transition: 0.2s;
            border: 2px solid white;
        }
        .home-btn:hover {
            transform: scale(1.1);
            background: #ff8e53;
        }
        .language-selector {
            display: flex;
            gap: 10px;
        }
        .lang-btn {
            background: rgba(255,255,255,0.15);
            border: 1px solid rgba(255,255,255,0.4);
            color: white;
            padding: 8px 16px;
            border-radius: 30px;
            font-size: 14px;
            font-weight: bold;
            cursor: pointer;
            transition: 0.2s;
            display: flex;
            align-items: center;
            gap: 6px;
        }
        .lang-btn.active {
            background: #4ecdc4;
            color: black;
            border-color: white;
        }
        .lang-btn i {
            font-size: 1rem;
        }

        /* پنل کنترل اصلی */
        .main-control-panel {
            position: absolute; top: 20px; right: 20px; z-index: 1000;
            background: rgba(25,25,35,0.95); backdrop-filter: blur(20px);
            border-radius: 20px; padding: 25px; width: 380px;
            box-shadow: 0 15px 40px rgba(0,0,0,0.4); border: 2px solid #4ecdc4;
        }
        .panel-header {
            display: flex; align-items: center; gap: 15px;
            margin-bottom: 25px; padding-bottom: 15px; border-bottom: 2px solid #4ecdc4;
        }
        .panel-header h2 {
            font-size: 1.8rem;
            background: linear-gradient(45deg, #4ecdc4, #44a08d);
            -webkit-background-clip: text; -webkit-text-fill-color: transparent;
            font-weight: 800;
        }
        /* جستجوی هوشمند */
        .smart-search-container { margin-bottom: 25px; }
        .search-box { position: relative; width: 100%; }
        .search-input {
            width: 100%; padding: 15px 50px 15px 20px; border-radius: 15px;
            border: 2px solid #4ecdc4; background: rgba(255,255,255,0.1);
            color: white; font-family: 'Vazirmatn'; font-size: 1rem;
            transition: 0.3s;
        }
        .search-input:focus {
            outline: none; border-color: #ff6b6b; box-shadow: 0 0 20px rgba(255,107,107,0.3);
        }
        .search-btn {
            position: absolute; left: 15px; top: 50%; transform: translateY(-50%);
            background: transparent; border: none; color: #4ecdc4; font-size: 1.2rem; cursor: pointer;
        }
        .search-results {
            position: absolute; width: 100%; background: rgba(25,25,35,0.98);
            border-radius: 15px; margin-top: 10px; max-height: 300px; overflow-y: auto;
            display: none; z-index: 1001; border: 2px solid #4ecdc4;
        }
        .search-result-item {
            padding: 15px; border-bottom: 1px solid rgba(255,255,255,0.1);
            cursor: pointer; transition: 0.3s;
        }
        .search-result-item:hover { background: rgba(78,205,196,0.2); }

        /* سیستم مسیریابی */
        .route-system {
            background: linear-gradient(135deg, rgba(30,60,114,0.9), rgba(42,82,152,0.9));
            padding: 20px; border-radius: 15px; margin-top: 20px;
            border: 1px solid rgba(78,205,196,0.5);
        }
        .route-inputs { display: grid; gap: 15px; margin-bottom: 15px; }
        .route-input-group {
            display: flex; align-items: center; gap: 10px;
        }
        .route-input-group i { color: #4ecdc4; font-size: 1.2rem; min-width: 25px; }
        .route-input {
            flex: 1; padding: 12px 15px; border-radius: 10px; border: 2px solid #4ecdc4;
            background: rgba(255,255,255,0.1); color: white; font-family: 'Vazirmatn';
        }
        .route-actions {
            display: grid; grid-template-columns: repeat(3, 1fr); gap: 10px; margin-top: 15px;
        }
        .route-action-btn {
            padding: 12px; border-radius: 10px; border: none;
            background: linear-gradient(135deg, #2d3436, #636e72);
            color: white; font-family: 'Vazirmatn'; cursor: pointer; transition: 0.3s;
            display: flex; align-items: center; justify-content: center; gap: 8px;
        }
        .route-action-btn:hover { transform: translateY(-3px); box-shadow: 0 5px 15px rgba(0,0,0,0.3); }
        .route-action-btn.calculate { background: linear-gradient(135deg, #4ecdc4, #44a08d); }
        .route-action-btn.clear { background: linear-gradient(135deg, #ff6b6b, #ff8e53); }
        
        .route-info-display {
            margin-top: 20px; padding: 15px; background: rgba(0,0,0,0.3);
            border-radius: 10px; display: none;
        }
        .route-stats {
            display: grid; grid-template-columns: repeat(2, 1fr); gap: 15px; margin-top: 10px;
        }
        .route-stat { text-align: center; padding: 10px; background: rgba(255,255,255,0.1); border-radius: 8px; }

        /* کنترل‌های نقشه */
        .map-controls {
            position: absolute; top: 100px; left: 20px; z-index: 1000;
            display: flex; flex-direction: column; gap: 10px;
        }
        .control-btn {
            width: 50px; height: 50px; border-radius: 12px;
            background: rgba(25,25,35,0.95); border: 2px solid #4ecdc4;
            color: white; font-size: 1.2rem; cursor: pointer;
            display: flex; align-items: center; justify-content: center;
            transition: 0.3s; backdrop-filter: blur(10px);
        }
        .control-btn:hover { transform: scale(1.1); border-color: #ff6b6b; }
        .control-btn.active { background: linear-gradient(135deg, #ff6b6b, #ff8e53); border-color: #ff6b6b; }

        /* پنل آب‌وهوا */
        .weather-info {
            background: linear-gradient(135deg, rgba(30,60,114,0.9), rgba(42,82,152,0.9));
            padding: 20px; border-radius: 15px; margin-top: 20px;
            border: 1px solid rgba(78,205,196,0.5);
        }
        .weather-details {
            display: grid; grid-template-columns: repeat(2, 1fr); gap: 12px; margin-top: 15px;
        }
        .weather-item { text-align: center; }
        .weather-item i { color: #ffd166; font-size: 1.5rem; }
        .weather-item div { font-size: 1.4rem; font-weight: bold; margin: 5px 0; }
        .weather-item small { color: rgba(255,255,255,0.8); }

        /* کنترل لایه آب‌وهوا (دکمه‌های باران، ابر، دما، باد) */
        .weather-layer-selector {
            display: flex; gap: 8px; margin-top: 15px; flex-wrap: wrap;
        }
        .weather-type-btn {
            flex: 1; min-width: 70px; padding: 8px; border-radius: 20px;
            border: 1px solid #4ecdc4; background: rgba(0,0,0,0.3);
            color: white; font-size: 12px; cursor: pointer; transition: 0.2s;
            display: flex; flex-direction: column; align-items: center; gap: 4px;
        }
        .weather-type-btn.active {
            background: #4ecdc4; color: black; border-color: white;
        }
        .weather-type-btn i { font-size: 1.2rem; }

        /* نوار وضعیت */
        .status-bar {
            position: absolute; bottom: 0; left: 0; right: 0;
            background: rgba(25,25,35,0.9); backdrop-filter: blur(20px);
            padding: 15px 30px; display: flex; justify-content: space-between;
            align-items: center; z-index: 1000; border-top: 3px solid #ff6b6b;
        }
        @media (max-width: 1200px) { .main-control-panel { width: 350px; } }
        @media (max-width: 768px) {
            .main-control-panel { width: 95%; right: 2.5%; left: 2.5%; top: 10px; max-height: 80vh; overflow-y: auto; }
            .map-controls { top: auto; bottom: 100px; flex-direction: row; }
            .status-bar { flex-direction: column; gap: 10px; text-align: center; }
            .route-actions { grid-template-columns: repeat(2,1fr); }
            .top-bar { width: 90%; padding: 10px 15px; }
            .lang-btn span { display: none; } /* فقط آیکون روی موبایل */
            .lang-btn i { margin: 0; }
        }
        @media (max-width: 480px) {
            .main-control-panel { padding: 15px; }
            .route-actions { grid-template-columns: 1fr; }
            .weather-details { grid-template-columns: 1fr; }
        }
        @keyframes pulse {
            0% { box-shadow: 0 0 0 0 rgba(78,205,196,0.7); }
            70% { box-shadow: 0 0 0 15px rgba(78,205,196,0); }
            100% { box-shadow: 0 0 0 0 rgba(78,205,196,0); }
        }
        .pulse-animation { animation: pulse 2s infinite; }
        @keyframes slideIn {
            from { transform: translateY(-20px); opacity: 0; }
            to { transform: translateY(0); opacity: 1; }
        }
        .slide-in { animation: slideIn 0.3s ease-out; }
    </style>
</head>
<body>
<div class="super-map-container">
    <div id="superMap"></div>

    <!-- ===== هدر سه‌زبانه + دکمه خانه ===== -->
    <div class="top-bar">
        <!-- دکمه بازگشت به صفحه اصلی (index.php) -->
        <button class="home-btn" onclick="window.location.href='index.php'" title="بازگشت به صفحه اصلی / Ana Sayfa / Home">
            <i class="fas fa-home"></i>
        </button>
        <!-- انتخابگر زبان -->
        <div class="language-selector">
            <button class="lang-btn active" onclick="setLanguage('fa')" id="langFa">
                <i class="fas fa-flag"></i> <span>فارسی</span>
            </button>
            <button class="lang-btn" onclick="setLanguage('tr')" id="langTr">
                <i class="fas fa-flag"></i> <span>Türkçe</span>
            </button>
            <button class="lang-btn" onclick="setLanguage('en')" id="langEn">
                <i class="fas fa-flag"></i> <span>English</span>
            </button>
        </div>
    </div>

    <!-- کنترل‌های نقشه -->
    <div class="map-controls">
        <button class="control-btn" onclick="toggleSatellite()" title="ماهواره‌ای / Uydu / Satellite"><i class="fas fa-satellite"></i></button>
        <button class="control-btn" onclick="toggle3D()" title="نمایش 3D / 3D Görünüm / 3D View"><i class="fas fa-cube"></i></button>
        <!-- دکمه آب‌وهوا – با کلیک لینک OpenWeatherMap در تب جدید باز می‌شود -->
        <button class="control-btn" onclick="window.open('https://openweathermap.org/weathermap', '_blank')" title="نقشه آب‌وهوا / Hava Durumu / Weather Map" id="weatherToggleBtn"><i class="fas fa-cloud-sun"></i></button>
        <button class="control-btn" onclick="locateMe()" title="موقعیت من / Konumum / My Location"><i class="fas fa-location-arrow"></i></button>
        <button class="control-btn" onclick="resetView()" title="بازنشانی / Sıfırla / Reset"><i class="fas fa-sync-alt"></i></button>
    </div>

    <!-- پنل کنترل اصلی -->
    <!--<div class="main-control-panel">-->
    <!--    <div class="panel-header">-->
    <!--        <div style="width:50px; height:50px; background:linear-gradient(135deg,#ff6b6b,#ffd166); border-radius:12px; display:flex; align-items:center; justify-content:center; font-size:1.5rem;">🗺️</div>-->
    <!--        <h2 id="panelTitle">نقشه هوشمند استانبول</h2>-->
    <!--    </div>-->

        <!-- جستجوی هوشمند -->
    <!--    <div class="smart-search-container">-->
    <!--        <div class="search-box">-->
    <!--            <input type="text" class="search-input" id="searchInput" placeholder="جستجوی آدرس، مکان، یا نقطه مورد نظر..." onkeyup="searchLocation(event)">-->
    <!--            <button class="search-btn" onclick="searchLocation()"><i class="fas fa-search"></i></button>-->
    <!--            <div class="search-results" id="searchResults"></div>-->
    <!--        </div>-->
    <!--    </div>-->

        <!-- سیستم مسیریابی -->
    <!--    <div class="route-system">-->
    <!--        <h3 id="routeSystemTitle"><i class="fas fa-route"></i> سیستم مسیریابی</h3>-->
    <!--        <div class="route-inputs">-->
    <!--            <div class="route-input-group">-->
    <!--                <i class="fas fa-map-marker-alt"></i>-->
    <!--                <input type="text" class="route-input" id="routeFrom" placeholder="مبدا (کلیک روی نقشه یا جستجو)" readonly>-->
    <!--            </div>-->
    <!--            <div class="route-input-group">-->
    <!--                <i class="fas fa-flag-checkered"></i>-->
    <!--                <input type="text" class="route-input" id="routeTo" placeholder="مقصد (کلیک روی نقشه یا جستجو)" readonly>-->
    <!--            </div>-->
    <!--        </div>-->
    <!--        <div class="route-actions">-->
    <!--            <button class="route-action-btn" onclick="setFromMode()" id="btnFrom"><i class="fas fa-dot-circle"></i> مبدا</button>-->
    <!--            <button class="route-action-btn" onclick="setToMode()" id="btnTo"><i class="fas fa-flag"></i> مقصد</button>-->
    <!--            <button class="route-action-btn calculate" onclick="calculateRoute()" id="btnCalculate"><i class="fas fa-calculator"></i> محاسبه</button>-->
    <!--            <button class="route-action-btn" onclick="swapRoute()" id="btnSwap"><i class="fas fa-exchange-alt"></i> جابجا</button>-->
    <!--            <button class="route-action-btn clear" onclick="clearRoute()" id="btnClear"><i class="fas fa-times"></i> پاک کردن</button>-->
    <!--        </div>-->
    <!--        <div class="route-info-display" id="routeInfo">-->
    <!--            <h4 id="routeInfoTitle"><i class="fas fa-info-circle"></i> اطلاعات مسیر</h4>-->
    <!--            <div class="route-stats">-->
    <!--                <div class="route-stat"><div class="stat-value" id="routeDistance">-- کیلومتر</div><div class="stat-label" id="routeDistanceLabel">مسافت</div></div>-->
    <!--                <div class="route-stat"><div class="stat-value" id="routeDuration">-- دقیقه</div><div class="stat-label" id="routeDurationLabel">زمان</div></div>-->
    <!--                <div class="route-stat"><div class="stat-value" id="routeType">--</div><div class="stat-label" id="routeTypeLabel">نوع مسیر</div></div>-->
    <!--                <div class="route-stat"><div class="stat-value" id="routeInstructions">--</div><div class="stat-label" id="routeInstructionsLabel">مراحل</div></div>-->
    <!--            </div>-->
    <!--        </div>-->
    <!--    </div>-->

        <!-- اطلاعات آب‌وهوا + لایه‌های راداری -->
    <!--    <div class="weather-info" id="weatherInfo">-->
    <!--        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:15px;">-->
    <!--            <h3 id="weatherTitle"><i class="fas fa-cloud-sun"></i> آب‌وهوا و رادار</h3>-->
    <!--            <span id="weatherTime">در حال بارگذاری...</span>-->
    <!--        </div>-->
    <!--        <div class="weather-details">-->
    <!--            <div class="weather-item">-->
    <!--                <i class="fas fa-thermometer-half"></i>-->
    <!--                <div id="currentTemp">--°C</div>-->
    <!--                <small id="tempLabel">دمای فعلی</small>-->
    <!--            </div>-->
    <!--            <div class="weather-item">-->
    <!--                <i class="fas fa-tint"></i>-->
    <!--                <div id="currentHumidity">--%</div>-->
    <!--                <small id="humidityLabel">رطوبت</small>-->
    <!--            </div>-->
    <!--            <div class="weather-item">-->
    <!--                <i class="fas fa-wind"></i>-->
    <!--                <div id="currentWind">-- km/h</div>-->
    <!--                <small id="windLabel">سرعت باد</small>-->
    <!--            </div>-->
    <!--            <div class="weather-item">-->
    <!--                <i class="fas fa-cloud"></i>-->
    <!--                <div id="currentCondition">--</div>-->
    <!--                <small id="conditionLabel">شرایط</small>-->
    <!--            </div>-->
    <!--        </div>-->
            <!-- انتخاب نوع لایه آب‌وهوا (رادار) -->
    <!--        <div class="weather-layer-selector">-->
    <!--            <button class="weather-type-btn" onclick="setWeatherLayerType('precipitation')" id="btnPrecip">-->
    <!--                <i class="fas fa-cloud-rain"></i> <span id="precipLabel">باران</span>-->
    <!--            </button>-->
    <!--            <button class="weather-type-btn" onclick="setWeatherLayerType('clouds')" id="btnClouds">-->
    <!--                <i class="fas fa-cloud"></i> <span id="cloudsLabel">ابر</span>-->
    <!--            </button>-->
    <!--            <button class="weather-type-btn" onclick="setWeatherLayerType('temp')" id="btnTemp">-->
    <!--                <i class="fas fa-temperature-high"></i> <span id="tempLayerLabel">دما</span>-->
    <!--            </button>-->
    <!--            <button class="weather-type-btn" onclick="setWeatherLayerType('wind')" id="btnWind">-->
    <!--                <i class="fas fa-wind"></i> <span id="windLayerLabel">باد</span>-->
    <!--            </button>-->
    <!--        </div>-->
    <!--        <p style="font-size:12px; color:rgba(255,255,255,0.6); margin-top:10px; text-align:center;" id="weatherAttribution">-->
    <!--            ⚡ لایه‌های آب‌وهوا توسط OpenWeatherMap ارائه می‌شود.-->
    <!--        </p>-->
    <!--    </div>-->
    <!--</div>-->

    <!-- نوار وضعیت -->
    <div class="status-bar">
        <div class="coordinates" id="currentCoords"><i class="fas fa-crosshairs"></i> <span></span></div>
        <div id="routeModeStatus" style="color:#4ecdc4; font-weight:bold;"><i class="fas fa-mouse-pointer"></i> <span>حالت: انتخاب مبدا</span></div>
        <div><span id="mapScale">مقیاس: 1:5000</span> | <span id="altitude">ارتفاع: 40m</span></div>
    </div>
</div>

<!-- کتابخانه‌ها -->
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
<script src="https://unpkg.com/leaflet-control-geocoder/dist/Control.Geocoder.min.js"></script>
<script src="https://unpkg.com/leaflet-routing-machine@3.2.12/dist/leaflet-routing-machine.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/js/all.min.js"></script>

<script>
// =============================================
//   نقشه فوق‌پیشرفته استانبول + چندزبانه + دکمه خانه
// =============================================

// ========== متغیرهای سراسری ==========
let map;
let routingControl = null;
let currentRoute = null;
let fromMarker = null, toMarker = null;
let clickMode = 'from';
let currentWeatherData = null;
let searchMarker = null;
let weatherLayer = null;
let currentWeatherLayerType = 'precipitation';
let currentLanguage = 'fa'; // زبان پیش‌فرض: فارسی

// ========== تنظیمات API (کاملاً رایگان) ==========
const CONFIG = {
    osmTile: 'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',
    // 🔴 کلید API خود را در اینجا وارد کنید
    weatherKey: '44b8b93077913560d5b35756d52a74ec', // ⚠️ کلید خود را اینجا وارد کنید
    weatherApi: 'https://api.openweathermap.org/data/2.5/weather',
    nominatimApi: 'https://nominatim.openstreetmap.org/search',
    mapStyles: {
        street: 'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',
        satellite: 'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}',
        dark: 'https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}.png',
        topo: 'https://{s}.tile.opentopomap.org/{z}/{x}/{y}.png'
    },
    weatherLayers: {
        precipitation: 'https://tile.openweathermap.org/map/precipitation_new/{z}/{x}/{y}.png?appid=',
        clouds: 'https://tile.openweathermap.org/map/clouds_new/{z}/{x}/{y}.png?appid=',
        temp: 'https://tile.openweathermap.org/map/temp_new/{z}/{x}/{y}.png?appid=',
        wind: 'https://tile.openweathermap.org/map/wind_new/{z}/{x}/{y}.png?appid='
    }
};

// ========== دیکشنری سه‌زبانه ==========
const translations = {
    fa: {
        panelTitle: "نقشه هوشمند استانبول",
        searchPlaceholder: "جستجوی آدرس، مکان، یا نقطه مورد نظر...",
        routeSystemTitle: "سیستم مسیریابی",
        routeFromPlaceholder: "مبدا (کلیک روی نقشه یا جستجو)",
        routeToPlaceholder: "مقصد (کلیک روی نقشه یا جستجو)",
        btnFrom: "مبدا",
        btnTo: "مقصد",
        btnCalculate: "محاسبه",
        btnSwap: "جابجا",
        btnClear: "پاک کردن",
        routeInfoTitle: "اطلاعات مسیر",
        routeDistanceLabel: "مسافت",
        routeDurationLabel: "زمان",
        routeTypeLabel: "نوع مسیر",
        routeInstructionsLabel: "مراحل",
        weatherTitle: "آب‌وهوا و رادار",
        tempLabel: "دمای فعلی",
        humidityLabel: "رطوبت",
        windLabel: "سرعت باد",
        conditionLabel: "شرایط",
        precipLabel: "باران",
        cloudsLabel: "ابر",
        tempLayerLabel: "دما",
        windLayerLabel: "باد",
        weatherAttribution: "⚡ لایه‌های آب‌وهوا توسط OpenWeatherMap ارائه می‌شود.",
        modeFrom: "حالت: انتخاب مبدا",
        modeTo: "حالت: انتخاب مقصد",
        mapScale: "مقیاس",
        altitude: "ارتفاع",
        // نوتیفیکیشن‌ها (اختیاری)
        notificationRouteCalculated: "مسیر محاسبه شد",
        notificationLocationFound: "موقعیت شما پیدا شد!",
        notificationPlaceFound: "مکان یافت شد!"
    },
    tr: {
        panelTitle: "İstanbul Akıllı Harita",
        searchPlaceholder: "Adres, yer veya nokta arayın...",
        routeSystemTitle: "Rota Sistemi",
        routeFromPlaceholder: "Başlangıç (Haritaya tıklayın veya arayın)",
        routeToPlaceholder: "Hedef (Haritaya tıklayın veya arayın)",
        btnFrom: "Başlangıç",
        btnTo: "Hedef",
        btnCalculate: "Hesapla",
        btnSwap: "Değiştir",
        btnClear: "Temizle",
        routeInfoTitle: "Rota Bilgisi",
        routeDistanceLabel: "Mesafe",
        routeDurationLabel: "Süre",
        routeTypeLabel: "Rota Tipi",
        routeInstructionsLabel: "Adımlar",
        weatherTitle: "Hava Durumu ve Radar",
        tempLabel: "Sıcaklık",
        humidityLabel: "Nem",
        windLabel: "Rüzgar Hızı",
        conditionLabel: "Durum",
        precipLabel: "Yağmur",
        cloudsLabel: "Bulut",
        tempLayerLabel: "Sıcaklık",
        windLayerLabel: "Rüzgar",
        weatherAttribution: "⚡ Hava durumu katmanları OpenWeatherMap tarafından sağlanır.",
        modeFrom: "Durum: Başlangıç seçimi",
        modeTo: "Durum: Hedef seçimi",
        mapScale: "Ölçek",
        altitude: "Yükseklik",
        notificationRouteCalculated: "Rota hesaplandı",
        notificationLocationFound: "Konumunuz bulundu!",
        notificationPlaceFound: "Yer bulundu!"
    },
    en: {
        panelTitle: "Istanbul Smart Map",
        searchPlaceholder: "Search for address, place or point...",
        routeSystemTitle: "Routing System",
        routeFromPlaceholder: "Start (Click on map or search)",
        routeToPlaceholder: "Destination (Click on map or search)",
        btnFrom: "Start",
        btnTo: "Destination",
        btnCalculate: "Calculate",
        btnSwap: "Swap",
        btnClear: "Clear",
        routeInfoTitle: "Route Info",
        routeDistanceLabel: "Distance",
        routeDurationLabel: "Duration",
        routeTypeLabel: "Route Type",
        routeInstructionsLabel: "Steps",
        weatherTitle: "Weather & Radar",
        tempLabel: "Temperature",
        humidityLabel: "Humidity",
        windLabel: "Wind Speed",
        conditionLabel: "Condition",
        precipLabel: "Rain",
        cloudsLabel: "Clouds",
        tempLayerLabel: "Temperature",
        windLayerLabel: "Wind",
        weatherAttribution: "⚡ Weather layers provided by OpenWeatherMap.",
        modeFrom: "Mode: Select start point",
        modeTo: "Mode: Select destination",
        mapScale: "Scale",
        altitude: "Altitude",
        notificationRouteCalculated: "Route calculated",
        notificationLocationFound: "Your location found!",
        notificationPlaceFound: "Place found!"
    }
};

// ========== تابع تغییر زبان ==========
function setLanguage(lang) {
    currentLanguage = lang;
    
    // به‌روزرسانی دکمه‌های فعال
    document.getElementById('langFa').classList.toggle('active', lang === 'fa');
    document.getElementById('langTr').classList.toggle('active', lang === 'tr');
    document.getElementById('langEn').classList.toggle('active', lang === 'en');
    
    // تغییر جهت صفحه
    if (lang === 'fa') {
        document.documentElement.setAttribute('dir', 'rtl');
    } else {
        document.documentElement.setAttribute('dir', 'ltr');
    }
    
    const t = translations[lang];
    
    // به‌روزرسانی تمام المان‌های دارای ID
    document.getElementById('panelTitle').textContent = t.panelTitle;
    document.getElementById('searchInput').placeholder = t.searchPlaceholder;
    document.getElementById('routeSystemTitle').innerHTML = `<i class="fas fa-route"></i> ${t.routeSystemTitle}`;
    document.getElementById('routeFrom').placeholder = t.routeFromPlaceholder;
    document.getElementById('routeTo').placeholder = t.routeToPlaceholder;
    document.getElementById('btnFrom').innerHTML = `<i class="fas fa-dot-circle"></i> ${t.btnFrom}`;
    document.getElementById('btnTo').innerHTML = `<i class="fas fa-flag"></i> ${t.btnTo}`;
    document.getElementById('btnCalculate').innerHTML = `<i class="fas fa-calculator"></i> ${t.btnCalculate}`;
    document.getElementById('btnSwap').innerHTML = `<i class="fas fa-exchange-alt"></i> ${t.btnSwap}`;
    document.getElementById('btnClear').innerHTML = `<i class="fas fa-times"></i> ${t.btnClear}`;
    document.getElementById('routeInfoTitle').innerHTML = `<i class="fas fa-info-circle"></i> ${t.routeInfoTitle}`;
    document.getElementById('routeDistanceLabel').textContent = t.routeDistanceLabel;
    document.getElementById('routeDurationLabel').textContent = t.routeDurationLabel;
    document.getElementById('routeTypeLabel').textContent = t.routeTypeLabel;
    document.getElementById('routeInstructionsLabel').textContent = t.routeInstructionsLabel;
    document.getElementById('weatherTitle').innerHTML = `<i class="fas fa-cloud-sun"></i> ${t.weatherTitle}`;
    document.getElementById('tempLabel').textContent = t.tempLabel;
    document.getElementById('humidityLabel').textContent = t.humidityLabel;
    document.getElementById('windLabel').textContent = t.windLabel;
    document.getElementById('conditionLabel').textContent = t.conditionLabel;
    document.getElementById('precipLabel').textContent = t.precipLabel;
    document.getElementById('cloudsLabel').textContent = t.cloudsLabel;
    document.getElementById('tempLayerLabel').textContent = t.tempLayerLabel;
    document.getElementById('windLayerLabel').textContent = t.windLayerLabel;
    document.getElementById('weatherAttribution').textContent = t.weatherAttribution;
    
    // به‌روزرسانی وضعیت حالت مسیریابی
    updateRouteModeStatus();
    
    // به‌روزرسانی مقیاس و ارتفاع
    document.getElementById('mapScale').innerHTML = `${t.mapScale}: 1:${Math.round(591657550 / Math.pow(2, map?.getZoom() || 13 - 1))}`;
    document.getElementById('altitude').innerHTML = `${t.altitude}: 40m`;
}

// ========== مقداردهی اولیه نقشه ==========
function initSuperMap() {
    console.log('🚀 راه‌اندازی نقشه هوشمند استانبول...');
    
    map = L.map('superMap', {
        center: [41.0082, 28.9784],
        zoom: 13,
        zoomControl: true,
        maxZoom: 20,
        minZoom: 3
    });

    // لایه پایه
    L.tileLayer(CONFIG.mapStyles.street, {
        attribution: '© OpenStreetMap contributors',
        maxZoom: 19
    }).addTo(map);

    // کنترل جستجوی Nominatim
    L.Control.geocoder({
        defaultMarkGeocode: false,
        placeholder: translations[currentLanguage].searchPlaceholder,
        geocoder: new L.Control.Geocoder.Nominatim()
    }).on('markgeocode', function(e) {
        handleSearchResult(e.geocode);
    }).addTo(map);

    L.control.scale({ imperial: false }).addTo(map);

    // بارگذاری اولیه
    setTimeout(() => {
        loadWeatherData();
        addTouristPoints();
        setupClickHandlers();
        updateStatusBar();
        map.on('mousemove', updateCoordinates);
        map.on('zoom', updateScale);
        startWeatherUpdates();
    }, 1000);

    showNotification(translations[currentLanguage].notificationPlaceFound || 'نقشه هوشمند استانبول آماده شد!', 'success');
}

// ========== مدیریت کلیک روی نقشه ==========
function setupClickHandlers() {
    map.on('click', function(e) {
        if (clickMode === 'from' || clickMode === 'to') {
            handleMapClick(e.latlng, clickMode);
        }
    });
}

async function handleMapClick(latlng, mode) {
    try {
        const response = await fetch(
            `https://nominatim.openstreetmap.org/reverse?format=json&lat=${latlng.lat}&lon=${latlng.lng}&zoom=18&addressdetails=1`
        );
        if (!response.ok) throw new Error('خطا');
        const data = await response.json();
        const locationName = data.display_name || `موقعیت (${latlng.lat.toFixed(4)}, ${latlng.lng.toFixed(4)})`;
        
        if (mode === 'from') {
            if (fromMarker) map.removeLayer(fromMarker);
            fromMarker = L.marker(latlng, {
                icon: L.divIcon({ html: '<div style="background:#4ecdc4; width:25px; height:25px; border-radius:50%; border:3px solid white; box-shadow:0 0 10px rgba(78,205,196,0.5);"></div>' })
            }).addTo(map);
            document.getElementById('routeFrom').value = locationName;
            document.getElementById('routeFrom').dataset.lat = latlng.lat;
            document.getElementById('routeFrom').dataset.lng = latlng.lng;
            showNotification(`مبدا تنظیم شد`, 'success');
        } else {
            if (toMarker) map.removeLayer(toMarker);
            toMarker = L.marker(latlng, {
                icon: L.divIcon({ html: '<div style="background:#ff6b6b; width:25px; height:25px; border-radius:50%; border:3px solid white; box-shadow:0 0 10px rgba(255,107,107,0.5);"></div>' })
            }).addTo(map);
            document.getElementById('routeTo').value = locationName;
            document.getElementById('routeTo').dataset.lat = latlng.lat;
            document.getElementById('routeTo').dataset.lng = latlng.lng;
            showNotification(`مقصد تنظیم شد`, 'success');
        }
        if (fromMarker && toMarker) showRouteInfo();
    } catch (error) {
        console.error(error);
        showNotification('خطا در دریافت اطلاعات مکان', 'error');
    }
}

// ========== جستجوی مکان ==========
async function searchLocation(e) {
    if (e) e.preventDefault();
    const query = document.getElementById('searchInput').value.trim();
    if (!query) return;
    const resultsDiv = document.getElementById('searchResults');
    resultsDiv.innerHTML = '<div class="search-result-item"><i class="fas fa-spinner fa-spin"></i> در حال جستجو...</div>';
    resultsDiv.style.display = 'block';
    try {
        const response = await fetch(`${CONFIG.nominatimApi}?q=${encodeURIComponent(query)}&format=json&limit=10&viewbox=28.5,40.8,29.5,41.2&bounded=1`);
        if (!response.ok) throw new Error('خطا');
        const results = await response.json();
        if (results.length === 0) {
            resultsDiv.innerHTML = '<div class="search-result-item">نتیجه‌ای یافت نشد</div>';
            return;
        }
        resultsDiv.innerHTML = '';
        results.forEach(result => {
            const item = document.createElement('div');
            item.className = 'search-result-item';
            item.innerHTML = `<div style="font-weight:bold;">${result.display_name.split(',')[0]}</div><div style="font-size:0.9rem; opacity:0.8;">${result.display_name.split(',').slice(1,3).join(',')}</div>`;
            item.onclick = () => {
                handleSearchResult({ center: [result.lat, result.lon], name: result.display_name });
                resultsDiv.style.display = 'none';
            };
            resultsDiv.appendChild(item);
        });
    } catch (error) {
        resultsDiv.innerHTML = '<div class="search-result-item">خطا در جستجو</div>';
    }
}

function handleSearchResult(geocode) {
    const [lat, lng] = geocode.center.map(parseFloat);
    const name = geocode.name;
    map.setView([lat, lng], 16);
    if (searchMarker) map.removeLayer(searchMarker);
    searchMarker = L.marker([lat, lng], {
        icon: L.divIcon({ html: '<div style="background:#ffd166; width:40px; height:40px; border-radius:50%; border:3px solid white; display:flex; align-items:center; justify-content:center; font-size:1.2rem;">📍</div>' })
    }).addTo(map).bindPopup(`<div style="font-family:Vazirmatn; padding:10px;"><h3 style="color:#ff6b6b;">${name.split(',')[0]}</h3><p>${name}</p><div style="margin-top:10px;"><button onclick="setFromHere(${lat}, ${lng}, '${name}')" style="background:#4ecdc4; color:white; border:none; padding:8px 15px; border-radius:10px; cursor:pointer;">${translations[currentLanguage].btnFrom}</button> <button onclick="setToHere(${lat}, ${lng}, '${name}')" style="background:#ff6b6b; color:white; border:none; padding:8px 15px; border-radius:10px; cursor:pointer;">${translations[currentLanguage].btnTo}</button></div></div>`).openPopup();
    document.getElementById('searchInput').value = name.split(',')[0];
    document.getElementById('searchResults').style.display = 'none';
    showNotification(translations[currentLanguage].notificationPlaceFound, 'success');
}

function setFromHere(lat, lng, name) {
    const latlng = L.latLng(lat, lng);
    if (fromMarker) map.removeLayer(fromMarker);
    fromMarker = L.marker(latlng, { icon: L.divIcon({ html: '<div style="background:#4ecdc4; width:25px; height:25px; border-radius:50%; border:3px solid white;"></div>' }) }).addTo(map);
    document.getElementById('routeFrom').value = name;
    document.getElementById('routeFrom').dataset.lat = lat;
    document.getElementById('routeFrom').dataset.lng = lng;
    clickMode = 'from';
    updateRouteModeStatus();
}

function setToHere(lat, lng, name) {
    const latlng = L.latLng(lat, lng);
    if (toMarker) map.removeLayer(toMarker);
    toMarker = L.marker(latlng, { icon: L.divIcon({ html: '<div style="background:#ff6b6b; width:25px; height:25px; border-radius:50%; border:3px solid white;"></div>' }) }).addTo(map);
    document.getElementById('routeTo').value = name;
    document.getElementById('routeTo').dataset.lat = lat;
    document.getElementById('routeTo').dataset.lng = lng;
    clickMode = 'to';
    updateRouteModeStatus();
}

// ========== مسیریابی ==========
function calculateRoute() {
    const from = document.getElementById('routeFrom');
    const to = document.getElementById('routeTo');
    if (!from.dataset.lat || !to.dataset.lat) {
        showNotification('لطفاً مبدا و مقصد را مشخص کنید', 'error');
        return;
    }
    const fromLat = parseFloat(from.dataset.lat), fromLng = parseFloat(from.dataset.lng);
    const toLat = parseFloat(to.dataset.lat), toLng = parseFloat(to.dataset.lng);
    if (routingControl) map.removeControl(routingControl);
    const distance = calculateDistance(fromLat, fromLng, toLat, toLng);
    const duration = calculateDuration(distance, 'car');
    document.getElementById('routeDistance').textContent = `${distance.toFixed(1)} کیلومتر`;
    document.getElementById('routeDuration').textContent = `${duration} دقیقه`;
    document.getElementById('routeType').textContent = 'ماشین';
    document.getElementById('routeInstructions').textContent = 'مسیر مستقیم';
    document.getElementById('routeInfo').style.display = 'block';
    drawSimpleRoute(fromLat, fromLng, toLat, toLng);
    showNotification(`${translations[currentLanguage].notificationRouteCalculated}: ${distance.toFixed(1)} km`, 'success');
}

function calculateDistance(lat1, lon1, lat2, lon2) {
    const R = 6371;
    const dLat = (lat2 - lat1) * Math.PI / 180;
    const dLon = (lon2 - lon1) * Math.PI / 180;
    const a = Math.sin(dLat/2)**2 + Math.cos(lat1 * Math.PI/180) * Math.cos(lat2 * Math.PI/180) * Math.sin(dLon/2)**2;
    return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
}

function calculateDuration(distance, mode) {
    const speed = mode === 'car' ? 40 : 5;
    return Math.round((distance / speed) * 60);
}

function drawSimpleRoute(fromLat, fromLng, toLat, toLng) {
    if (currentRoute) map.removeLayer(currentRoute);
    currentRoute = L.polyline([[fromLat, fromLng], [toLat, toLng]], { color: '#ff6b6b', weight: 5, opacity: 0.7, dashArray: '10,10' }).addTo(map);
    map.fitBounds([[fromLat, fromLng], [toLat, toLng]], { padding: [50,50] });
}

function setFromMode() { clickMode = 'from'; updateRouteModeStatus(); showNotification(translations[currentLanguage].modeFrom, 'info'); }
function setToMode() { clickMode = 'to'; updateRouteModeStatus(); showNotification(translations[currentLanguage].modeTo, 'info'); }
function updateRouteModeStatus() {
    const el = document.getElementById('routeModeStatus');
    if (clickMode === 'from') {
        el.innerHTML = `<i class="fas fa-dot-circle"></i> <span>${translations[currentLanguage].modeFrom}</span>`;
        el.style.color = '#4ecdc4';
    } else {
        el.innerHTML = `<i class="fas fa-flag"></i> <span>${translations[currentLanguage].modeTo}</span>`;
        el.style.color = '#ff6b6b';
    }
}
function swapRoute() {
    const from = document.getElementById('routeFrom'), to = document.getElementById('routeTo');
    [from.value, to.value] = [to.value, from.value];
    [from.dataset.lat, to.dataset.lat] = [to.dataset.lat, from.dataset.lat];
    [from.dataset.lng, to.dataset.lng] = [to.dataset.lng, from.dataset.lng];
    if (fromMarker && toMarker) {
        const fromLatLng = fromMarker.getLatLng();
        const toLatLng = toMarker.getLatLng();
        fromMarker.setLatLng(toLatLng);
        toMarker.setLatLng(fromLatLng);
    }
    showNotification('مبدا و مقصد جابجا شدند', 'success');
}
function clearRoute() {
    if (routingControl) map.removeControl(routingControl);
    if (currentRoute) map.removeLayer(currentRoute);
    if (fromMarker) map.removeLayer(fromMarker);
    if (toMarker) map.removeLayer(toMarker);
    fromMarker = toMarker = null;
    document.getElementById('routeFrom').value = '';
    document.getElementById('routeTo').value = '';
    document.getElementById('routeInfo').style.display = 'none';
    showNotification('مسیر پاک شد', 'info');
}
function showRouteInfo() {
    if (fromMarker && toMarker) {
        const from = fromMarker.getLatLng(), to = toMarker.getLatLng();
        const dist = calculateDistance(from.lat, from.lng, to.lat, to.lng);
        const dur = calculateDuration(dist, 'car');
        document.getElementById('routeDistance').textContent = `${dist.toFixed(1)} کیلومتر`;
        document.getElementById('routeDuration').textContent = `${dur} دقیقه`;
        document.getElementById('routeInfo').style.display = 'block';
    }
}

// ========== لایه آب‌وهوا ==========
function setWeatherLayerType(type) {
    currentWeatherLayerType = type;
    
    ['precipitation', 'clouds', 'temp', 'wind'].forEach(t => {
        const btn = document.getElementById(`btn${t.charAt(0).toUpperCase()+t.slice(1)}`);
        if (btn) btn.classList.remove('active');
    });
    const activeBtn = document.getElementById(`btn${type.charAt(0).toUpperCase()+type.slice(1)}`);
    if (activeBtn) activeBtn.classList.add('active');
    
    if (!CONFIG.weatherKey || CONFIG.weatherKey === 'YOUR_OPENWEATHERMAP_API_KEY') {
        showNotification('⚠️ لطفاً ابتدا یک کلید رایگان از OpenWeatherMap دریافت کنید.', 'error');
        return;
    }
    
    if (!weatherLayer) {
        addWeatherLayerByType(type);
    } else {
        map.removeLayer(weatherLayer);
        addWeatherLayerByType(type);
    }
    showNotification(`لایه ${getWeatherLayerName(type)} فعال شد`, 'success');
}

function addWeatherLayerByType(type) {
    const tileUrl = CONFIG.weatherLayers[type] + CONFIG.weatherKey;
    weatherLayer = L.tileLayer(tileUrl, {
        attribution: '© OpenWeatherMap',
        maxZoom: 18,
        opacity: 0.7
    }).addTo(map);
}

function getWeatherLayerName(type) {
    const names = { precipitation: 'بارش', clouds: 'ابری', temp: 'دما', wind: 'باد' };
    return names[type];
}

// ========== دریافت آب‌وهوای لحظه‌ای ==========
async function loadWeatherData() {
    if (!map) return;
    const center = map.getCenter();
    try {
        if (!CONFIG.weatherKey || CONFIG.weatherKey === 'YOUR_OPENWEATHERMAP_API_KEY') {
            document.getElementById('currentTemp').textContent = '24°C';
            document.getElementById('currentHumidity').textContent = '65%';
            document.getElementById('currentWind').textContent = '12 km/h';
            document.getElementById('currentCondition').textContent = 'آفتابی';
            document.getElementById('weatherTime').textContent = new Date().toLocaleTimeString('fa-IR');
            return;
        }
        const response = await fetch(`${CONFIG.weatherApi}?lat=${center.lat}&lon=${center.lng}&appid=${CONFIG.weatherKey}&units=metric&lang=${currentLanguage === 'fa' ? 'fa' : 'en'}`);
        if (!response.ok) throw new Error();
        const data = await response.json();
        document.getElementById('currentTemp').textContent = `${Math.round(data.main.temp)}°C`;
        document.getElementById('currentHumidity').textContent = `${data.main.humidity}%`;
        document.getElementById('currentWind').textContent = `${Math.round(data.wind.speed * 3.6)} km/h`;
        document.getElementById('currentCondition').textContent = data.weather[0].description;
        document.getElementById('weatherTime').textContent = new Date().toLocaleTimeString(currentLanguage === 'fa' ? 'fa-IR' : (currentLanguage === 'tr' ? 'tr-TR' : 'en-US'));
    } catch (error) {
        console.error('خطا در دریافت آب‌وهوا');
    }
}

function startWeatherUpdates() {
    setInterval(loadWeatherData, 300000);
}

// ========== موقعیت‌یابی ==========
function locateMe() {
    if (!navigator.geolocation) {
        showNotification('مرورگر شما از موقعیت‌یابی پشتیبانی نمی‌کند', 'error');
        return;
    }
    showNotification('در حال یافتن موقعیت شما...', 'info');
    navigator.geolocation.getCurrentPosition(pos => {
        const { latitude, longitude } = pos.coords;
        map.flyTo([latitude, longitude], 16, { duration: 2 });
        L.marker([latitude, longitude], {
            icon: L.divIcon({ html: '<div style="background:linear-gradient(135deg,#00b09b,#96c93d); width:40px; height:40px; border-radius:50%; border:3px solid white; display:flex; align-items:center; justify-content:center; color:white; font-size:1.2rem;"><i class="fas fa-user"></i></div>' })
        }).addTo(map).bindPopup(translations[currentLanguage].notificationLocationFound).openPopup();
        showNotification(translations[currentLanguage].notificationLocationFound, 'success');
    }, () => showNotification('خطا در دریافت موقعیت', 'error'), { enableHighAccuracy: true });
}

// ========== نقاط گردشگری ==========
function addTouristPoints() {
    const attractions = [
        { name: { fa: 'ایاصوفیا', tr: 'Ayasofya', en: 'Hagia Sophia' }, lat: 41.0086, lng: 28.9795, icon: '🕌' },
        { name: { fa: 'مسجد آبی', tr: 'Sultan Ahmet Camii', en: 'Blue Mosque' }, lat: 41.0054, lng: 28.9769, icon: '🕌' },
        { name: { fa: 'کاخ توپکاپی', tr: 'Topkapı Sarayı', en: 'Topkapı Palace' }, lat: 41.0116, lng: 28.9831, icon: '🏰' },
        { name: { fa: 'برج گالاتا', tr: 'Galata Kulesi', en: 'Galata Tower' }, lat: 41.0256, lng: 28.9745, icon: '🗼' },
        { name: { fa: 'بازار بزرگ', tr: 'Kapalıçarşı', en: 'Grand Bazaar' }, lat: 41.0108, lng: 28.9708, icon: '🛍️' },
        { name: { fa: 'کاخ دلما‌باغچه', tr: 'Dolmabahçe Sarayı', en: 'Dolmabahçe Palace' }, lat: 41.0392, lng: 28.9954, icon: '🏛️' }
    ];
    attractions.forEach(att => {
        const displayName = att.name[currentLanguage] || att.name.fa;
        L.marker([att.lat, att.lng], {
            icon: L.divIcon({ html: `<div style="background:linear-gradient(135deg,#ff6b6b,#ffd166); width:50px; height:50px; border-radius:50%; display:flex; align-items:center; justify-content:center; border:3px solid white; font-size:1.5rem; box-shadow:0 5px 20px rgba(0,0,0,0.3);">${att.icon}</div>` })
        }).addTo(map).bindPopup(`
            <div style="font-family:Vazirmatn; padding:10px; min-width:200px;">
                <h3 style="color:#ff6b6b; margin-bottom:10px;">${displayName}</h3>
                <button onclick="setFromHere(${att.lat}, ${att.lng}, '${displayName}')" style="background:#4ecdc4; color:white; border:none; padding:8px 15px; border-radius:10px; cursor:pointer; margin-right:5px;">${translations[currentLanguage].btnFrom}</button>
                <button onclick="setToHere(${att.lat}, ${att.lng}, '${displayName}')" style="background:#ff6b6b; color:white; border:none; padding:8px 15px; border-radius:10px; cursor:pointer;">${translations[currentLanguage].btnTo}</button>
            </div>
        `);
    });
}

// ========== توابع کمکی ==========
function updateCoordinates(e) {
    const { lat, lng } = e.latlng;
    const span = document.querySelector('#currentCoords span');
    if (span) span.innerHTML = `${translations[currentLanguage]?.mapScale === 'مقیاس' ? 'طول' : (currentLanguage === 'tr' ? 'Boylam' : 'Lng')}: ${lng.toFixed(4)}, ${translations[currentLanguage]?.mapScale === 'مقیاس' ? 'عرض' : (currentLanguage === 'tr' ? 'Enlem' : 'Lat')}: ${lat.toFixed(4)}`;
}
function updateScale() {
    const zoom = map.getZoom();
    const scale = Math.round(591657550 / Math.pow(2, zoom - 1));
    document.getElementById('mapScale').textContent = `${translations[currentLanguage].mapScale}: 1:${scale}`;
}
function updateStatusBar() {
    document.getElementById('altitude').textContent = `${translations[currentLanguage].altitude}: ${Math.floor(30 + Math.random()*50)}m`;
}
function toggleSatellite() {
    const btn = event.currentTarget;
    btn.classList.toggle('active');
    map.eachLayer(l => { 
        if (l._url && l._url.includes('tile') && !l._url.includes('openweathermap')) {
            map.removeLayer(l); 
        }
    });
    if (btn.classList.contains('active')) {
        L.tileLayer(CONFIG.mapStyles.satellite, { attribution: 'Esri', maxZoom: 19 }).addTo(map);
        showNotification(translations[currentLanguage]?.panelTitle ? 'لایه ماهواره‌ای فعال شد' : 'Satellite layer activated', 'success');
    } else {
        L.tileLayer(CONFIG.mapStyles.street, { attribution: '© OpenStreetMap', maxZoom: 19 }).addTo(map);
        showNotification(translations[currentLanguage]?.panelTitle ? 'لایه خیابان‌ها فعال شد' : 'Street layer activated', 'success');
    }
    if (weatherLayer) {
        addWeatherLayerByType(currentWeatherLayerType);
    }
}
function toggle3D() { showNotification('حالت 3D در حال توسعه...', 'info'); }
function resetView() { map.setView([41.0082, 28.9784], 13); showNotification('نمایش نقشه بازنشانی شد', 'success'); }

// ========== نوتیفیکیشن ==========
function showNotification(msg, type = 'info') {
    const notif = document.createElement('div');
    notif.style.cssText = `
        position:fixed; top:20px; left:50%; transform:translateX(-50%);
        background:${type === 'success' ? 'linear-gradient(135deg,#00b09b,#96c93d)' : type === 'error' ? 'linear-gradient(135deg,#ff416c,#ff4b2b)' : 'linear-gradient(135deg,#4A00E0,#8E2DE2)'};
        color:white; padding:15px 25px; border-radius:15px; z-index:10000;
        box-shadow:0 10px 30px rgba(0,0,0,0.3); border:2px solid white;
        font-family:Vazirmatn; text-align:center; min-width:300px; max-width:500px;
        animation:slideDown 0.3s ease;
    `;
    notif.innerHTML = `<div style="display:flex; align-items:center; gap:15px;"><div style="font-size:1.5rem;">${type==='success'?'✅':type==='error'?'❌':'ℹ️'}</div><div>${msg}</div></div>`;
    document.body.appendChild(notif);
    setTimeout(() => { 
        notif.style.opacity = '0'; 
        notif.style.transform = 'translateX(-50%) translateY(-20px)'; 
        setTimeout(() => { if (notif.parentNode) notif.remove(); }, 300); 
    }, 3000);
}

// ========== راه‌اندازی اولیه و اعمال زبان پیش‌فرض ==========
document.addEventListener('DOMContentLoaded', function() {
    initSuperMap();
    setLanguage('fa'); // زبان پیش‌فرض فارسی
});

// ========== اضافه کردن استایل انیمیشن ==========
const style = document.createElement('style');
style.textContent = `
    @keyframes slideDown { from { opacity:0; transform:translateX(-50%) translateY(-20px); } to { opacity:1; transform:translateX(-50%) translateY(0); } }
    @keyframes pulse { 0% { box-shadow:0 0 0 0 rgba(78,205,196,0.7); } 70% { box-shadow:0 0 0 15px rgba(78,205,196,0); } 100% { box-shadow:0 0 0 0 rgba(78,205,196,0); } }
`;
document.head.appendChild(style);

// اضافه کردن فونت وزیر
const font = document.createElement('link');
font.href = 'https://fonts.googleapis.com/css2?family=Vazirmatn:wght@300;400;500;600;700;800&display=swap';
font.rel = 'stylesheet';
document.head.appendChild(font);
</script>
</body>
</html>
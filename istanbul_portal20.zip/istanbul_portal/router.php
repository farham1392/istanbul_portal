<!DOCTYPE html>
<html dir="rtl" lang="fa">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
    <title>استانبول · Google Earth 3D · مسیریاب هوشمند</title>
    
    <!-- CesiumJS - آخرین نسخه -->
    <script src="https://cesium.com/downloads/cesiumjs/releases/1.136/Build/Cesium/Cesium.js"></script>
    <link href="https://cesium.com/downloads/cesiumjs/releases/1.136/Build/Cesium/Widgets/widgets.css" rel="stylesheet">
    
    <!-- Font Awesome 6 -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- فونت وزیر -->
    <link href="https://cdn.jsdelivr.net/gh/rastikerdar/vazir-font@v30.1.0/dist/font-face.css" rel="stylesheet">
    
    <style>
        /* ========== استایل شیشهای پیشرفته ========== */
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Vazir', sans-serif; }
        html, body, #cesiumContainer { width: 100%; height: 100%; overflow: hidden; background: #000; }
        
        .glass-header {
            position: absolute; top: 20px; left: 20px; right: 20px; z-index: 1000;
            display: flex; gap: 15px; align-items: center; justify-content: space-between;
            pointer-events: none;
        }
        
        .brand-earth {
            background: rgba(0, 0, 0, 0.7); backdrop-filter: blur(15px);
            padding: 12px 28px; border-radius: 50px; color: white;
            border: 1px solid rgba(255,255,255,0.3); box-shadow: 0 10px 30px rgba(0,0,0,0.5);
            display: flex; align-items: center; gap: 12px; pointer-events: auto;
            font-size: 18px; font-weight: 700;
        }
        
        .search-earth {
            flex: 1; max-width: 600px; margin: 0 auto; display: flex;
            background: rgba(0, 0, 0, 0.7); backdrop-filter: blur(15px);
            border: 1px solid rgba(255,255,255,0.3); border-radius: 50px; padding: 5px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.5); pointer-events: auto;
        }
        
        .search-earth i {
            color: #8ab4f8; font-size: 20px; margin: 0 15px; align-self: center;
        }
        
        .search-earth input {
            flex: 1; background: transparent; border: none; outline: none;
            color: white; font-size: 16px; padding: 14px 0;
            font-family: 'Vazir', sans-serif;
        }
        
        .search-earth input::placeholder {
            color: rgba(255,255,255,0.7);
        }
        
        .search-earth button {
            background: #8ab4f8; border: none; border-radius: 50px;
            padding: 12px 28px; color: black; font-weight: 700;
            display: flex; align-items: center; gap: 10px; cursor: pointer;
            transition: 0.2s; border: 1px solid rgba(255,255,255,0.5);
        }
        
        .search-earth button:hover {
            background: #aecbfa; transform: scale(1.02);
        }
        
        /* ========== پنل مسیریابی شبیه Google Earth ========== */
        .earth-routing {
            position: absolute; bottom: 30px; left: 30px; right: 30px;
            background: rgba(0, 0, 0, 0.7); backdrop-filter: blur(15px);
            border-radius: 60px; border: 1px solid rgba(255,255,255,0.2);
            padding: 16px 28px; display: flex; align-items: center;
            justify-content: space-between; color: white; z-index: 1000;
            box-shadow: 0 10px 40px rgba(0,0,0,0.6); pointer-events: auto;
            flex-wrap: wrap;
        }
        
        .route-group {
            display: flex; gap: 20px; flex: 2; align-items: center;
        }
        
        .route-box {
            display: flex; align-items: center; background: rgba(255,255,255,0.1);
            border-radius: 40px; padding: 8px 20px; flex: 1;
            border: 1px solid rgba(255,255,255,0.2);
        }
        
        .route-box i {
            color: #8ab4f8; margin-left: 12px; font-size: 18px;
        }
        
        .route-box input {
            background: transparent; border: none; color: white; font-size: 15px;
            width: 100%; outline: none; font-family: 'Vazir', sans-serif;
        }
        
        .mode-earth {
            display: flex; gap: 12px; margin: 0 20px;
        }
        
        .mode-btn {
            background: rgba(255,255,255,0.1); border: none; color: white;
            padding: 12px 20px; border-radius: 40px; font-size: 15px;
            display: flex; align-items: center; gap: 8px; cursor: pointer;
            transition: 0.2s; border: 1px solid transparent;
        }
        
        .mode-btn.active {
            background: #8ab4f8; color: black; border-color: white;
        }
        
        .btn-calc {
            background: #8ab4f8; border: none; color: black; font-weight: 700;
            padding: 14px 30px; border-radius: 40px; display: flex;
            align-items: center; gap: 12px; cursor: pointer; transition: 0.2s;
        }
        
        .btn-calc:hover {
            background: #aecbfa; transform: scale(1.02);
        }
        
        /* ========== پنل ناوبری ========== */
        .nav-panel-earth {
            position: absolute; bottom: 30px; left: 50%; transform: translateX(-50%);
            width: 700px; max-width: 95%; background: rgba(0,0,0,0.8);
            backdrop-filter: blur(20px); border-radius: 80px;
            border: 2px solid #8ab4f8; padding: 18px 28px; display: none;
            align-items: center; justify-content: space-between; color: white;
            z-index: 1100; box-shadow: 0 0 40px rgba(138,180,248,0.5);
            pointer-events: auto;
        }
        
        .nav-panel-earth.active { display: flex; animation: floatUp 0.4s; }
        
        @keyframes floatUp {
            from { opacity: 0; transform: translate(-50%, 30px); }
            to { opacity: 1; transform: translate(-50%, 0); }
        }
        
        .nav-instruc {
            font-size: 22px; font-weight: 700; margin-bottom: 6px;
            color: #8ab4f8; display: flex; align-items: center; gap: 12px;
        }
        
        .nav-dist {
            font-size: 15px; opacity: 0.9; display: flex; align-items: center; gap: 10px;
        }
        
        .nav-actions {
            display: flex; gap: 12px;
        }
        
        .nav-btn {
            background: rgba(255,255,255,0.1); border: 1px solid rgba(255,255,255,0.2);
            color: white; width: 52px; height: 52px; border-radius: 50%;
            display: flex; align-items: center; justify-content: center;
            cursor: pointer; transition: 0.2s; font-size: 22px;
        }
        
        .nav-btn:hover {
            background: #8ab4f8; color: black; transform: scale(1.1);
        }
        
        /* ========== کنترل‌های سه‌بعدی ========== */
        .compass-earth {
            position: absolute; bottom: 30px; right: 30px; width: 70px; height: 70px;
            background: rgba(0,0,0,0.7); backdrop-filter: blur(10px); border-radius: 50%;
            display: flex; align-items: center; justify-content: center;
            border: 2px solid #8ab4f8; color: white; font-size: 32px;
            box-shadow: 0 0 30px rgba(138,180,248,0.4); z-index: 1000;
            cursor: pointer; pointer-events: auto; transition: 0.2s;
        }
        
        .compass-earth:hover {
            transform: rotate(15deg); border-color: white;
        }
        
        .attribution-earth {
            position: absolute; bottom: 30px; left: 30px; z-index: 1000;
            background: rgba(0,0,0,0.5); backdrop-filter: blur(5px);
            padding: 8px 16px; border-radius: 30px; color: rgba(255,255,255,0.8);
            font-size: 12px; pointer-events: none;
        }
        
        /* ========== Cesium تنظیمات ========== */
        .cesium-viewer-bottom, .cesium-viewer-toolbar { display: none !important; }
        .cesium-viewer { background: #03050a !important; }
        .cesium-label { font-family: 'Vazir', sans-serif !important; }
    </style>
</head>
<body>
    <div id="cesiumContainer"></div>
    
    <!-- ========== هدر شبیه Google Earth ========== -->
    <div class="glass-header">
        <div class="brand-earth">
            <i class="fas fa-globe-asia" style="color: #8ab4f8;"></i> استانبول ۳D · Google Earth
        </div>
        <div class="search-earth">
            <i class="fas fa-search"></i>
            <input type="text" id="searchBox" placeholder="جستجوی مکان، جاذبه، خیابان...">
            <button id="searchBtn"><i class="fas fa-arrow-left"></i> جستجو</button>
        </div>
        <div style="width: 180px;"></div>
    </div>
    
    <!-- ========== پنل مسیریابی ========== -->
    <div class="earth-routing">
        <div class="route-group">
            <div class="route-box">
                <i class="fas fa-circle-dot"></i>
                <input type="text" id="routeStart" placeholder="مبدأ">
            </div>
            <div class="route-box">
                <i class="fas fa-flag-checkered"></i>
                <input type="text" id="routeEnd" placeholder="مقصد">
            </div>
        </div>
        <div class="mode-earth">
            <button id="modeDriving" class="mode-btn active"><i class="fas fa-car"></i> ماشین</button>
            <button id="modeWalking" class="mode-btn"><i class="fas fa-walking"></i> پیاده</button>
        </div>
        <div>
            <button id="calcRouteBtn" class="btn-calc"><i class="fas fa-route"></i> مسیریابی</button>
        </div>
    </div>
    
    <!-- ========== پنل ناوبری هوشمند ========== -->
    <div id="navigationPanel" class="nav-panel-earth">
        <div style="flex: 1;">
            <div class="nav-instruc" id="navInstruction">
                <i class="fas fa-arrow-up"></i> مستقیم، خیابان استقلال
            </div>
            <div class="nav-dist" id="navDistance">
                <i class="fas fa-flag"></i> ۲۵۰ متر تا مقصد
            </div>
        </div>
        <div class="nav-actions">
            <button class="nav-btn" id="prevStepBtn"><i class="fas fa-arrow-right"></i></button>
            <button class="nav-btn" id="voiceToggleBtn"><i class="fas fa-volume-up"></i></button>
            <button class="nav-btn" id="nextStepBtn"><i class="fas fa-arrow-left"></i></button>
            <button class="nav-btn" id="exitNavBtn"><i class="fas fa-times"></i></button>
        </div>
    </div>
    
    <!-- ========== کنترل‌های سه‌بعدی ========== -->
    <div class="compass-earth" id="compassBtn">
        <i class="fas fa-compass"></i>
    </div>
    
    <div class="attribution-earth">
        <span>Google Photorealistic 3D Tiles | Bing Aerial | CesiumJS</span>
    </div>
    
    <script type="module">
        (async function() {
            // ========== 1. توکن Cesium Ion (اجباری برای Google 3D Tiles) ==========
            // از این لینک توکن رایگان بگیر: https://cesium.com/ion/tokens
            Cesium.Ion.defaultAccessToken = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJqdGkiOiIzZjE2ZTg4OS02ODY3LTQyMTMtOTY1OC1mZWEzODQ4MmQ5NTEiLCJpZCI6Mzg5NTc0LCJpYXQiOjE3NzA4MDg5NTh9.TGGr4UPduaMp2bQOQxNTfEOLB8lsiPQE8Ntcb4BA2-0"; // ← اینو عوض کن
            
            // ========== 2. ایجاد Viewer با تنظیمات Google Earth ==========
            const viewer = new Cesium.Viewer('cesiumContainer', {
                // زمین سه‌بعدی واقعی با نورپردازی
                terrain: Cesium.Terrain.fromWorldTerrain({
                    requestVertexNormals: true,  // نورپردازی realistic
                    requestWaterMask: true       // افکت آب
                }),
                // عکس ماهواره‌ای Bing با کیفیت 15cm
                imageryProvider: await Cesium.IonImageryProvider.fromAssetId(2), // Bing Maps Aerial
                baseLayerPicker: false,
                geocoder: false,
                homeButton: false,
                sceneModePicker: false,
                navigationHelpButton: false,
                animation: false,
                timeline: false,
                fullscreenButton: false,
                vrButton: false,
                infoBox: false,
                selectionIndicator: false,
                shadows: true,
                contextOptions: {
                    webgl: {
                        antialias: true,
                        preserveDrawingBuffer: true,
                        powerPreference: "high-performance"
                    }
                }
            });
            
            // فعال‌سازی نور خورشید و سایه
            viewer.scene.globe.enableLighting = true;
            viewer.scene.globe.depthTestAgainstTerrain = true;
            viewer.scene.skyAtmosphere.show = true;
            viewer.scene.fog.density = 0.001;
            viewer.scene.highDynamicRange = true;
            
            // ========== 3. اضافه کردن Google Photorealistic 3D Tiles ==========
            // این مهمترین بخشه! ساختمان‌های واقعی با بافت عکس
            try {
                const google3DTiles = await Cesium.Cesium3DTileset.fromIonAssetId(2272797); // Asset ID رسمی Google 3D Tiles
                viewer.scene.primitives.add(google3DTiles);
                console.log("✅ Google Photorealistic 3D Tiles loaded");
            } catch(e) {
                console.error("❌ Failed to load Google 3D Tiles:", e);
                alert("⚠️ برای نمایش ساختمان‌های واقعی، توکن Cesium Ion معتبر لازم است. از https://cesium.com/ion/tokens توکن رایگان بگیر.");
            }
            
            // ========== 4. اضافه کردن برچسب شهرها (مثل Google Earth) ==========
            // Cesium به صورت پیش‌فرض برچسب نداره - این راه‌حل از [citation:10]
            async function addCityLabels() {
                // استفاده از asset مخصوص برچسب‌ها (در صورت وجود در حساب کاربری)
                // یا ایجاد وکتور تایل با متد [citation:10]
                try {
                    // این asset شامل برچسب شهرهای ترکیه است (شما باید خودتون بسازید یا از سرویس‌های جایگزین استفاده کنید)
                    // راه‌حل موقت: استفاده از Cesium ion's built-in vector tiles (در صورت فعال بودن)
                    const labelsTileset = await Cesium.Cesium3DTileset.fromIonAssetId(96188); // نمونه - ممکنه نیاز به آپلود داشته باشه
                    viewer.scene.primitives.add(labelsTileset);
                } catch(e) {
                    console.warn("⚠️ برچسب شهرها بارگذاری نشد. برای فعال‌سازی، وکتور تایل بسازید.");
                }
            }
            addCityLabels();
            
            // ========== 5. حرکت دوربین به استانبول ==========
            viewer.camera.flyTo({
                destination: Cesium.Cartesian3.fromDegrees(28.9784, 41.0082, 2000),
                orientation: {
                    heading: Cesium.Math.toRadians(-30),
                    pitch: Cesium.Math.toRadians(-35),
                    roll: 0
                },
                duration: 3
            });
            
            // ========== 6. متغیرهای سراسری ==========
            let currentRouteEntity = null;
            let startMarker = null;
            let endMarker = null;
            let currentMode = 'driving';
            let navigationSteps = [];
            let currentStepIndex = 0;
            let isVoiceEnabled = true;
            
            // ========== 7. جاذبه‌های گردشگری با نشانگر ==========
            const attractions = [
                { name: 'ایاصوفیه', lat: 41.0086, lon: 28.9802, icon: '🕌' },
                { name: 'برج گالاتا', lat: 41.0255, lon: 28.9742, icon: '🗼' },
                { name: 'کاخ توپکاپی', lat: 41.0117, lon: 28.9831, icon: '🏰' },
                { name: 'مسجد آبی', lat: 41.0054, lon: 28.9768, icon: '🕌' },
                { name: 'بازار بزرگ', lat: 41.0108, lon: 28.9684, icon: '🛍️' },
                { name: 'کاخ دلمه‌باغچه', lat: 41.0390, lon: 29.0004, icon: '🏛️' }
            ];
            
            // اضافه کردن نشانگر
            attractions.forEach(att => {
                viewer.entities.add({
                    position: Cesium.Cartesian3.fromDegrees(att.lon, att.lat, 100),
                    billboard: {
                        image: `data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" width="50" height="70"><circle cx="25" cy="25" r="20" fill="%238ab4f8" stroke="white" stroke-width="3"/><text x="25" y="45" font-size="24" text-anchor="middle" fill="white">${att.icon}</text></svg>`,
                        verticalOrigin: Cesium.VerticalOrigin.BOTTOM,
                        scale: 0.9,
                        disableDepthTestDistance: Number.POSITIVE_INFINITY
                    },
                    label: {
                        text: att.name,
                        font: '18px Vazir',
                        fillColor: Cesium.Color.WHITE,
                        outlineColor: Cesium.Color.BLACK,
                        outlineWidth: 2,
                        pixelOffset: new Cesium.Cartesian2(0, -50),
                        disableDepthTestDistance: Number.POSITIVE_INFINITY
                    }
                });
            });
            
            // ========== 8. جستجوی مکان ==========
            window.searchLocation = async function(query) {
                if (!query) return;
                const url = `https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(query + ' Istanbul')}&limit=1`;
                try {
                    const res = await fetch(url);
                    const data = await res.json();
                    if (data[0]) {
                        viewer.camera.flyTo({
                            destination: Cesium.Cartesian3.fromDegrees(
                                parseFloat(data[0].lon),
                                parseFloat(data[0].lat),
                                800
                            ),
                            duration: 2
                        });
                    }
                } catch(e) { console.error(e); }
            };
            
            // ========== 9. مسیریابی با OSRM ==========
            window.calculateRoute = async function(startCoords, endCoords) {
                if (!startCoords || !endCoords) return;
                
                if (currentRouteEntity) viewer.entities.remove(currentRouteEntity);
                if (startMarker) viewer.entities.remove(startMarker);
                if (endMarker) viewer.entities.remove(endMarker);
                
                const profile = currentMode === 'driving' ? 'driving' : 'foot';
                const url = `https://router.project-osrm.org/route/v1/${profile}/${startCoords.lon},${startCoords.lat};${endCoords.lon},${endCoords.lat}?overview=full&geometries=geojson&steps=true`;
                
                try {
                    const res = await fetch(url);
                    const data = await res.json();
                    if (data.routes?.[0]) {
                        const route = data.routes[0];
                        navigationSteps = route.legs.flatMap(l => l.steps);
                        
                        const positions = route.geometry.coordinates.map(coord => 
                            Cesium.Cartesian3.fromDegrees(coord[0], coord[1], 30)
                        );
                        
                        currentRouteEntity = viewer.entities.add({
                            polyline: {
                                positions: positions,
                                width: 8,
                                material: new Cesium.PolylineGlowMaterialProperty({
                                    glowPower: 0.3,
                                    color: Cesium.Color.fromCssColorString('#8ab4f8')
                                })
                            }
                        });
                        
                        startMarker = viewer.entities.add({
                            position: Cesium.Cartesian3.fromDegrees(startCoords.lon, startCoords.lat, 50),
                            billboard: { image: 'https://cesium.com/public/cesiumjs/Assets/Images/pin_mark.png', scale: 0.8 }
                        });
                        
                        endMarker = viewer.entities.add({
                            position: Cesium.Cartesian3.fromDegrees(endCoords.lon, endCoords.lat, 50),
                            billboard: { image: 'https://cesium.com/public/cesiumjs/Assets/Images/pin_mark.png', scale: 0.8 }
                        });
                        
                        // فعال‌سازی پنل ناوبری
                        document.getElementById('navigationPanel').classList.add('active');
                        currentStepIndex = 0;
                        updateNavigationStep();
                    }
                } catch(e) { console.error(e); }
            };
            
            // ========== 10. راهنمای صوتی ==========
            function speak(text) {
                if (!isVoiceEnabled || !window.speechSynthesis) return;
                window.speechSynthesis.cancel();
                const utterance = new SpeechSynthesisUtterance(text);
                utterance.lang = 'fa-IR';
                utterance.rate = 1.0;
                window.speechSynthesis.speak(utterance);
            }
            
            function updateNavigationStep() {
                if (!navigationSteps.length) return;
                const step = navigationSteps[currentStepIndex];
                const modifier = step.maneuver.modifier || 'straight';
                const streetName = step.name || 'خیابان';
                const distance = step.distance;
                
                let turnText = '', icon = 'fa-arrow-up';
                if (modifier.includes('left')) { turnText = 'چپ'; icon = 'fa-arrow-left'; }
                else if (modifier.includes('right')) { turnText = 'راست'; icon = 'fa-arrow-right'; }
                else if (modifier.includes('straight')) { turnText = 'مستقیم'; icon = 'fa-arrow-up'; }
                else if (modifier.includes('uturn')) { turnText = 'دور برگردان'; icon = 'fa-rotate-left'; }
                
                const distanceText = distance >= 1000 ? `${(distance/1000).toFixed(1)} کیلومتر` : `${Math.round(distance)} متر`;
                
                document.getElementById('navInstruction').innerHTML = `<i class="fas ${icon}"></i> ${turnText}، ${streetName}`;
                document.getElementById('navDistance').innerHTML = `<i class="fas fa-flag"></i> ${distanceText} تا مقصد`;
                
                speak(`در ${distanceText} به ${turnText} بپیچید، ${streetName}`);
            }
            
            // ========== 11. رویدادها ==========
            document.getElementById('searchBtn').addEventListener('click', () => {
                window.searchLocation(document.getElementById('searchBox').value);
            });
            
            document.getElementById('calcRouteBtn').addEventListener('click', async () => {
                async function geocode(text) {
                    const res = await fetch(`https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(text + ' Istanbul')}&limit=1`);
                    const data = await res.json();
                    return data[0] ? { lat: parseFloat(data[0].lat), lon: parseFloat(data[0].lon) } : null;
                }
                
                const start = await geocode(document.getElementById('routeStart').value);
                const end = await geocode(document.getElementById('routeEnd').value);
                if (start && end) window.calculateRoute(start, end);
            });
            
            document.getElementById('modeDriving').addEventListener('click', () => {
                currentMode = 'driving';
                document.getElementById('modeDriving').classList.add('active');
                document.getElementById('modeWalking').classList.remove('active');
            });
            
            document.getElementById('modeWalking').addEventListener('click', () => {
                currentMode = 'walking';
                document.getElementById('modeWalking').classList.add('active');
                document.getElementById('modeDriving').classList.remove('active');
            });
            
            document.getElementById('compassBtn').addEventListener('click', () => {
                viewer.camera.flyTo({
                    destination: viewer.camera.position,
                    orientation: { heading: 0, pitch: Cesium.Math.toRadians(-35), roll: 0 },
                    duration: 0.8
                });
            });
            
            document.getElementById('nextStepBtn').addEventListener('click', () => {
                if (currentStepIndex < navigationSteps.length - 1) {
                    currentStepIndex++;
                    updateNavigationStep();
                } else {
                    speak('شما به مقصد رسیدید');
                    document.getElementById('navigationPanel').classList.remove('active');
                }
            });
            
            document.getElementById('prevStepBtn').addEventListener('click', () => {
                if (currentStepIndex > 0) {
                    currentStepIndex--;
                    updateNavigationStep();
                }
            });
            
            document.getElementById('exitNavBtn').addEventListener('click', () => {
                document.getElementById('navigationPanel').classList.remove('active');
                window.speechSynthesis.cancel();
            });
            
            document.getElementById('voiceToggleBtn').addEventListener('click', function() {
                isVoiceEnabled = !isVoiceEnabled;
                this.innerHTML = isVoiceEnabled ? '<i class="fas fa-volume-up"></i>' : '<i class="fas fa-volume-mute"></i>';
            });
            
            // مقدار پیش‌فرض
            document.getElementById('routeStart').value = 'ایاصوفیه';
            document.getElementById('routeEnd').value = 'برج گالاتا';
        })();
    </script>
</body>
</html>
<?php
// config.php

// تنظیمات خطا
error_reporting(E_ALL);
ini_set('display_errors', 1);

// تنظیمات تاریخ و زمان
date_default_timezone_set('Asia/Tehran');

// تنظیمات امنیتی
define('SECRET_KEY', 'istanbul-guide-2024-secret-key');
define('JWT_SECRET', 'jwt-secret-key-for-auth-2024');
define('CSRF_TOKEN_NAME', 'csrf_token');

// تنظیمات دیتابیس
define('DB_HOST', 'localhost');
define('DB_NAME', 'istanbul_guide');
define('DB_USER', 'root');
define('DB_PASS', '');

// تنظیمات API
define('API_BASE_URL', 'https://farhamzamani.com/istanbul_guide/api');
define('FRONTEND_URL', 'https://farhamzamani.com/istanbul_guide');

// تنظیمات آپلود
define('UPLOAD_MAX_SIZE', 5242880); // 5MB
define('ALLOWED_IMAGE_TYPES', ['jpg', 'jpeg', 'png', 'gif', 'webp']);
define('UPLOAD_PATH', dirname(__DIR__) . '/uploads/');

// تنظیمات کش
define('CACHE_ENABLED', true);
define('CACHE_TIME', 3600); // 1 ساعت

// شروع سشن
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// تنظیم هدرهای CORS
header('Access-Control-Allow-Origin: ' . FRONTEND_URL);
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With');
header('Access-Control-Allow-Credentials: true');

// اگر درخواست OPTIONS باشد
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// تنظیم کدینگ و نوع محتوا
header('Content-Type: application/json; charset=utf-8');

// تابع برای خروجی JSON
function json_response($data, $status_code = 200) {
    http_response_code($status_code);
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    exit();
}

// تابع برای گرفتن بدنه درخواست
function get_request_body() {
    $input = file_get_contents('php://input');
    return json_decode($input, true);
}

// تابع برای سانیتایز ورودی
function sanitize_input($data) {
    if (is_array($data)) {
        return array_map('sanitize_input', $data);
    }
    return htmlspecialchars(strip_tags(trim($data)), ENT_QUOTES, 'UTF-8');
}

// تابع برای تولید CSRF Token
function generate_csrf_token() {
    if (!isset($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

// تابع برای اعتبارسنجی CSRF Token
function validate_csrf_token($token) {
    return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
}

// تنظیم متغیرهای گلوبال
$config = [
    'site_name' => 'Istanbul Guide',
    'site_description' => 'راهنمای کامل سفر به استانبول',
    'default_language' => 'fa',
    'supported_languages' => ['fa', 'en', 'tr', 'ar'],
    'default_theme' => 'light',
    'contact_email' => 'info@istanbulguide.com',
    'version' => '1.0.0',
    'debug' => true
];

// لود اتوماتیک کلاس‌ها
spl_autoload_register(function ($class_name) {
    $file = __DIR__ . '/includes/' . $class_name . '.php';
    if (file_exists($file)) {
        require_once $file;
    }
});


$pdo = new PDO(
    "mysql:host=www.farhamzamani.com;dbname=farhamza_istanbul_guide;charset=utf8",
    "farhamza_farham3",
    "fzfz13139292##"
);

$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

$OPENAI_API_KEY = "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";
?>
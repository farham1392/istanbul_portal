<?php

function getUserProfile($pdo, $session_id) {
    $stmt = $pdo->prepare(
        "SELECT preferences FROM user_profile WHERE session_id=?"
    );
    $stmt->execute([$session_id]);
    $res = $stmt->fetchColumn();
    return $res ? json_decode($res, true) : [];
}

function saveUserProfile($pdo, $session_id, $prefs) {
    $stmt = $pdo->prepare("
        INSERT INTO user_profile (session_id, preferences)
        VALUES (?,?)
        ON DUPLICATE KEY UPDATE preferences=?
    ");
    $json = json_encode($prefs, JSON_UNESCAPED_UNICODE);
    $stmt->execute([$session_id, $json, $json]);
}

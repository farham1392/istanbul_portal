  <?php
// require_once __DIR__ . '/../config.php'; 


// function getUserMemory($userId) {
//     global $pdo;

//     $stmt = $pdo->prepare("
//         SELECT * FROM isto_user_memory
//         WHERE user_id = ?
//         LIMIT 1
//     ");
//     $stmt->execute([$userId]);

//     $memory = $stmt->fetch(PDO::FETCH_ASSOC);

   
//     if (!$memory) {
//         return [
//             'language' => 'fa',
//             'travel_style' => 'balanced',
//             'food_preference' => 'normal',
//             'budget_level' => 'medium',
//             'mood' => 'neutral',
//             'notes' => ''
//         ];
//     }

//     return $memory;
// }



// function getTripContext($userId) {
//     global $pdo;

//     $stmt = $pdo->prepare("
//         SELECT * FROM isto_trip_context
//         WHERE user_id = ?
//         ORDER BY id DESC
//         LIMIT 1
//     ");
//     $stmt->execute([$userId]);

//     $context = $stmt->fetch(PDO::FETCH_ASSOC);

//     if (!$context) {
//         return [
//             'day_number' => 1,
//             'time_of_day' => 'morning',
//             'location' => 'Istanbul',
//             'weather' => 'unknown'
//         ];
//     }

//     return $context;
// }


// function updateUserMemory($userId, $userMessage) {
//     global $pdo;

//     $updates = [];

//     if (str_contains($userMessage, 'غذای تند')) {
//         $updates['food_preference'] = 'no_spicy';
//     }

//     if (str_contains($userMessage, 'آرام')) {
//         $updates['travel_style'] = 'calm';
//     }

//     if (str_contains($userMessage, 'ارزون')) {
//         $updates['budget_level'] = 'low';
//     }

//     if (empty($updates)) return;

//     $setPart = [];
//     $values = [];

//     foreach ($updates as $key => $value) {
//         $setPart[] = "$key = ?";
//         $values[] = $value;
//     }

//     $values[] = $userId;

//     $sql = "UPDATE isto_user_memory SET " . implode(', ', $setPart) . " WHERE user_id = ?";
//     $stmt = $pdo->prepare($sql);
//     $stmt->execute($values);
// }





function saveMessage($pdo, $session_id, $role, $content) {
    $stmt = $pdo->prepare(
        "INSERT INTO chat_memory (session_id, role, content) VALUES (?,?,?)"
    );
    $stmt->execute([$session_id, $role, $content]);
}

function loadMemory($pdo, $session_id, $limit = 10) {
    $stmt = $pdo->prepare(
        "SELECT role, content FROM chat_memory 
         WHERE session_id=? 
         ORDER BY id DESC LIMIT ?"
    );
    $stmt->execute([$session_id, $limit]);
    return array_reverse($stmt->fetchAll(PDO::FETCH_ASSOC));
}

<?php
session_start();
header('Content-Type: application/json');

require '../config/database.php';
require 'isto_memory.php';

if (!isset($_SESSION['isto_id'])) {
    $_SESSION['isto_id'] = uniqid('isto_', true);
}
$session_id = $_SESSION['isto_id'];

$userMessage = trim($_POST['message'] ?? '');
if (!$userMessage) {
    echo json_encode(['error'=>'Empty message']);
    exit;
}

// ===== SYSTEM PROMPT =====
require 'isto_prompt.php';

// ===== MEMORY =====
saveMessage($pdo, $session_id, 'user', $userMessage);
$memory = loadMemory($pdo, $session_id);

// ===== BUILD CHAT =====
require 'isto_profile.php';
require 'isto_pref_prompt.php';

$profile = getUserProfile($pdo, $session_id);

if (!empty($profile)) {
    $messages[] = [
        'role'=>'system',
        'content'=>'User preferences: '.json_encode($profile, JSON_UNESCAPED_UNICODE)
    ];
}


// ===== Preference Extraction Call =====
$prefMessages = [
    ['role'=>'system','content'=>$PREFERENCE_PROMPT],
    ['role'=>'user','content'=>$userMessage]
];

$prefPayload = [
    'model' => 'gpt-3.5-turbo',
    'messages' => $prefMessages,
    'temperature' => 0
];

$ch = curl_init('https://api.openai.com/v1/chat/completions');
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POST => true,
    CURLOPT_HTTPHEADER => [
        'Content-Type: application/json',
        'Authorization: Bearer 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'
    ],
    CURLOPT_POSTFIELDS => json_encode($prefPayload)
]);

$prefResponse = curl_exec($ch);
curl_close($ch);

$prefData = json_decode($prefResponse, true);
$prefJson = $prefData['choices'][0]['message']['content'] ?? '{}';

$newPrefs = json_decode($prefJson, true);

// Merge with existing profile
if (is_array($newPrefs)) {
    $merged = array_merge($profile, $newPrefs);
    saveUserProfile($pdo, $session_id, $merged);
}


file_put_contents('debug_openai.txt', $prefResponse);

<?php
require 'isto_prompt.php';
require 'isto_memory.php';
require 'openai_client.php';

function istoHandleMessage($userId, $userMessage) {

    $userProfile = getUserMemory($userId);
    $tripContext = getTripContext($userId);

    $dynamicPrompt = buildDynamicPrompt(
        $userProfile,
        $tripContext,
        $userMessage
    );

    $reply = callOpenAI($dynamicPrompt);

    updateUserMemory($userId, $userMessage);

    return $reply;
}

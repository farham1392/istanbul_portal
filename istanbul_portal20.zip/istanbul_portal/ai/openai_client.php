<?php

function callOpenAI($finalPrompt) {
    global $OPENAI_API_KEY;

    $url = "https://api.openai.com/v1/chat/completions";

    $data = [
        "model" => "gpt-4o-mini", 
        "messages" => [
            [
                "role" => "system",
                "content" => "You are ISTO, a smart local travel companion from Istanbul."
            ],
            [
                "role" => "user",
                "content" => $finalPrompt
            ]
        ],
        "temperature" => 0.7,
        "max_tokens" => 400
    ];

    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST => true,
        CURLOPT_HTTPHEADER => [
            "Content-Type: application/json",
            "Authorization: Bearer {$OPENAI_API_KEY}"
        ],
        CURLOPT_POSTFIELDS => json_encode($data),
        CURLOPT_TIMEOUT => 20
    ]);

    $response = curl_exec($ch);

    if (curl_errno($ch)) {
        return "الان ذهنم یه لحظه شلوغ شد 😅 دوباره امتحان کن.";
    }

    curl_close($ch);

    $result = json_decode($response, true);

    return $result['choices'][0]['message']['content'] 
           ?? "الان نمی‌تونم جواب دقیقی بدم، ولی باهم درستش می‌کنیم 😉";
}

<?php
$PREFERENCE_PROMPT = <<<PROMPT
Extract user travel preferences from the message.

Return ONLY valid JSON.
No explanation.
No text.

Possible keys:
- travel_type (solo, couple, family, friends)
- budget (low, medium, high)
- interests (food, history, shopping, nature, nightlife)
- crowd_preference (low, medium, high)
- trip_days (number if mentioned)

If information is missing, ignore it.

Example output:
{
  "travel_type":"couple",
  "interests":["food","history"],
  "budget":"medium"
}
PROMPT;

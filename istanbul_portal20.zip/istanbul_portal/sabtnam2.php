<?php
// ================= اتصال به دیتابیس =================
$db = mysqli_connect('localhost', 'root', '', 'istanbul');
mysqli_set_charset($db, "utf8");

if (!$db) {
    die("خطا در اتصال به دیتابیس");
}

$error = '';
$success = false;

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $username  = trim($_POST['username']);
    $email     = trim($_POST['email']);
    $password  = trim($_POST['password']);
    $full_name = trim($_POST['full_name']);
    $phone     = trim($_POST['phone']);

    if (strlen($username) < 3) {
        $error = "نام کاربری حداقل 3 کاراکتر باشد";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "ایمیل نامعتبر است";
    } elseif (strlen($password) < 6 || strlen($password) > 11) {
        $error = "رمز عبور باید بین 6 تا 11 کاراکتر باشد";
    } elseif (strlen($phone) != 11 || substr($phone, 0, 2) != '09') {
        $error = "شماره موبایل معتبر نیست";
    }

    if ($error == '') {
        $password_hash = password_hash($password, PASSWORD_DEFAULT);

        $stmt = mysqli_prepare(
            $db,
            "INSERT INTO users
            (username, email, password_hash, full_name, phone, avatar_url, language, theme, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())"
        );

        $avatar_url = '';
        $language = 'fa';
        $theme = 'light';

        mysqli_stmt_bind_param(
            $stmt,
            "ssssssss",
            $username,
            $email,
            $password_hash,
            $full_name,
            $phone,
            $avatar_url,
            $language,
            $theme
        );

        if (mysqli_stmt_execute($stmt)) {
            $success = true;
        } else {
            $error = "خطا در ثبت اطلاعات";
        }

        mysqli_stmt_close($stmt);
    }
}
?>

<!DOCTYPE html>
<html dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>ثبت نام کاربر - گردشگری استانبول</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- FontAwesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

    <style>
        body {
            background: linear-gradient(to right, #4facfe, #00f2fe);
            font-family: 'Arial', sans-serif;
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
        }

        .form-container {
            background-color: #ffffff;
            padding: 30px 25px;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
            width: 100%;
            max-width: 450px;
            position: relative;
        }

        .form-container h2 {
            text-align: center;
            color: #007bff;
            margin-bottom: 25px;
            font-weight: 700;
            font-size: 28px;
        }

        .form-control {
            border-radius: 10px;
            padding: 12px 15px;
            font-size: 16px;
        }

        .form-group {
            position: relative;
        }

        .input-icon {
            position: absolute;
            top: 50%;
            left: 15px;
            transform: translateY(-50%);
            color: #aaa;
            cursor: pointer;
        }

        .form-control:focus {
            border-color: #007bff;
            box-shadow: 0 0 5px rgba(0,123,255,0.5);
        }

        .btn-submit {
            width: 100%;
            background: #007bff;
            color: white;
            font-size: 18px;
            border-radius: 10px;
            padding: 12px;
            font-weight: 600;
            transition: 0.3s;
        }

        .btn-submit:hover {
            background: #0056b3;
        }

        .alert {
            margin-top: 15px;
            text-align: center;
        }

        /* ریسپانسیو */
        @media (max-width: 480px) {
            .form-container {
                padding: 20px 15px;
            }
        }
    </style>
</head>

<body>
<div class="form-container">
    <h2>ثبت نام گردشگری استانبول</h2>

    <?php if ($error): ?>
        <div class="alert alert-danger"><?php echo $error; ?></div>
    <?php endif; ?>

    <?php if ($success): ?>
        <div class="alert alert-success">
            ثبت نام با موفقیت انجام شد
        </div>
        <meta http-equiv="refresh" content="1; url=index.php">
    <?php endif; ?>

    <form method="post">

        <div class="mb-3 form-group">
            <label>نام کاربری</label>
            <input type="text" name="username" class="form-control" placeholder="مثال: tourist123" required>
            <i class="fas fa-user input-icon"></i>
        </div>

        <div class="mb-3 form-group">
            <label>ایمیل</label>
            <input type="email" name="email" class="form-control" placeholder="مثال: example@gmail.com" required>
            <i class="fas fa-envelope input-icon"></i>
        </div>

        <div class="mb-3 form-group">
            <label>رمز عبور</label>
            <input type="password" name="password" id="password" class="form-control" placeholder="رمز عبور" required>
            <i class="fas fa-eye input-icon" onclick="togglePassword()"></i>
        </div>

        <div class="mb-3 form-group">
            <label>نام کامل</label>
            <input type="text" name="full_name" class="form-control" placeholder="مثال: علی رضایی">
            <i class="fas fa-id-card input-icon"></i>
        </div>

        <div class="mb-3 form-group">
            <label>شماره موبایل</label>
            <input type="tel" name="phone" class="form-control" placeholder="09xxxxxxxxx" required>
            <i class="fas fa-phone input-icon"></i>
        </div>

        <button type="submit" class="btn btn-submit">
            ثبت نام
        </button>
    </form>
</div>

<script>
function togglePassword() {
    let p = document.getElementById("password");
    p.type = (p.type === "password") ? "text" : "password";
}
</script>
</body>
</html>

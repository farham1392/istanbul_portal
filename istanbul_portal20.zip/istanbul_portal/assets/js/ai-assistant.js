class IstanbulAI {
    constructor() {
        this.baseUrl = window.PHP_CONFIG?.apiBase || 'api/';
        this.sessionId = this.generateSessionId();
        this.conversationHistory = [];
        this.isTyping = false;
        this.maxHistory = 20; // حداکثر تعداد پیام‌های ذخیره شده
        this.typingSpeed = 20; // میلی‌ثانیه برای هر حرف
    }
    
    generateSessionId() {
        return 'session_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
    }
    
    async sendMessage(message) {
        if (!message.trim()) return null;
        
        const chatInput = document.getElementById('chatInput');
        const sendBtn = document.getElementById('sendMessage');
        
        // غیرفعال کردن ورودی هنگام ارسال
        chatInput.disabled = true;
        sendBtn.disabled = true;
        
        // نمایش پیام کاربر
        this.addMessage(message, 'user');
        
        // نمایش نشانگر تایپ
        this.showTypingIndicator();
        
        try {
            // آماده کردن تاریخچه مکالمه
            const context = {
                current_page: window.location.pathname.split('/').pop() || 'index',
                history: this.conversationHistory.slice(-5), // فقط ۵ پیام آخر
                language: document.documentElement.getAttribute('data-lang') || 'fa'
            };
            
            // ارسال درخواست
            const response = await fetch(this.baseUrl + 'api/ai/chat.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    message: message,
                    context: context,
                    session_id: this.sessionId,
                    analyze_sentiment: true
                })
            });
            
            const data = await response.json();
            
           
            
            // پنهان کردن نشانگر تایپ
            this.hideTypingIndicator();
            
            if (data.success) {
                // نمایش پاسخ با انیمیشن تایپ
                await this.typeMessage(data.response, 'ai');
                
                // ذخیره در تاریخچه
                this.saveToHistory('user', message);
                this.saveToHistory('ai', data.response);
                
                // تحلیل احساسات (اگر وجود دارد)
                if (data.sentiment) {
                    this.handleSentiment(data.sentiment);
                }
                
                // آپدیت آمار استفاده
                this.updateUsageStats(data.tokens_used || 0, data.response_time || 0);
                
                return data;
            } else {
                this.addMessage('خطا در ارتباط با سرور: ' + (data.error || 'ناشناخته'), 'ai', true);
                throw new Error(data.error || 'Unknown error');
            }
            
        } catch (error) {
            console.error('AI Error:', error);
            this.hideTypingIndicator();
            this.addMessage('متأسفانه در حال حاضر دستیار در دسترس نیست. لطفاً دوباره تلاش کنید.', 'ai', true);
            return null;
        } finally {
            // فعال کردن مجدد ورودی
            chatInput.disabled = false;
            sendBtn.disabled = false;
            chatInput.focus();
        }
    }
    
    async typeMessage(message, sender) {
        this.isTyping = true;
        
        // ایجاد عنصر پیام
        const messageDiv = this.createMessageElement('', sender);
        const contentDiv = messageDiv.querySelector('.message-content');
        
        // انیمیشن تایپ
        let i = 0;
        const typingInterval = setInterval(() => {
            if (i < message.length) {
                contentDiv.textContent += message.charAt(i);
                i++;
                
                // اسکرول به پایین
                const chatMessages = document.getElementById('chatMessages');
                chatMessages.scrollTop = chatMessages.scrollHeight;
            } else {
                clearInterval(typingInterval);
                this.isTyping = false;
                
                // فرمت‌نویسی Markdown ساده
                this.formatMessage(contentDiv);
                
                // اضافه کردن دکمه‌های عملی
                this.addActionButtons(messageDiv, message);
            }
        }, this.typingSpeed);
        
        // توقف خودکار اگر طولانی شد
        setTimeout(() => {
            if (this.isTyping) {
                clearInterval(typingInterval);
                contentDiv.textContent = message;
                this.isTyping = false;
                this.formatMessage(contentDiv);
                this.addActionButtons(messageDiv, message);
            }
        }, 10000); // حداکثر ۱۰ ثانیه
    }
    
    addMessage(text, sender = 'user', isError = false) {
        const messageDiv = this.createMessageElement(text, sender, isError);
        
        // فرمت‌نویسی برای پیام‌های کامل
        if (!this.isTyping) {
            this.formatMessage(messageDiv.querySelector('.message-content'));
        }
        
        // اسکرول به پایین
        const chatMessages = document.getElementById('chatMessages');
        chatMessages.scrollTop = chatMessages.scrollHeight;
        
        return messageDiv;
    }
    
    createMessageElement(text, sender, isError = false) {
        const chatMessages = document.getElementById('chatMessages');
        
        const messageDiv = document.createElement('div');
        messageDiv.className = `message ${sender}${isError ? ' error' : ''}`;
        messageDiv.dataset.timestamp = new Date().toISOString();
        
        const avatar = document.createElement('div');
        avatar.className = 'message-avatar';
        
        if (sender === 'user') {
            avatar.innerHTML = '<i class="fas fa-user"></i>';
        } else {
            avatar.innerHTML = '<i class="fas fa-robot"></i>';
        }
        
        const contentDiv = document.createElement('div');
        contentDiv.className = 'message-content';
        contentDiv.textContent = text;
        
        const timeDiv = document.createElement('div');
        timeDiv.className = 'message-time';
        timeDiv.textContent = this.formatTime(new Date());
        
        messageDiv.appendChild(avatar);
        messageDiv.appendChild(contentDiv);
        messageDiv.appendChild(timeDiv);
        
        chatMessages.appendChild(messageDiv);
        
        return messageDiv;
    }
    
    showTypingIndicator() {
        const chatMessages = document.getElementById('chatMessages');
        
        const typingDiv = document.createElement('div');
        typingDiv.className = 'message ai typing';
        typingDiv.id = 'typingIndicator';
        
        const avatar = document.createElement('div');
        avatar.className = 'message-avatar';
        avatar.innerHTML = '<i class="fas fa-robot"></i>';
        
        const contentDiv = document.createElement('div');
        contentDiv.className = 'typing-indicator';
        for (let i = 0; i < 3; i++) {
            const dot = document.createElement('span');
            dot.className = 'typing-dot';
            contentDiv.appendChild(dot);
        }
        
        typingDiv.appendChild(avatar);
        typingDiv.appendChild(contentDiv);
        
        chatMessages.appendChild(typingDiv);
        chatMessages.scrollTop = chatMessages.scrollHeight;
    }
    
    hideTypingIndicator() {
        const typingIndicator = document.getElementById('typingIndicator');
        if (typingIndicator) {
            typingIndicator.remove();
        }
    }
    
    formatMessage(contentDiv) {
        let text = contentDiv.textContent;
        
        // فرمت‌نویسی Markdown ساده
        text = text.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
        text = text.replace(/\*(.*?)\*/g, '<em>$1</em>');
        text = text.replace(/`(.*?)`/g, '<code>$1</code>');
        
        // لیست‌ها
        text = text.replace(/^\s*[-*]\s+(.+)$/gm, '<li>$1</li>');
        text = text.replace(/(<li>.*<\/li>)/s, '<ul>$1</ul>');
        
        // لینک‌ها
        text = text.replace(/\[([^\]]+)\]\(([^)]+)\)/g, '<a href="$2" target="_blank">$1</a>');
        
        // ایموجی‌ها
        const emojiMap = {
            '🎯': '<i class="fas fa-bullseye"></i>',
            '🏨': '<i class="fas fa-hotel"></i>',
            '🍽️': '<i class="fas fa-utensils"></i>',
            '🗺️': '<i class="fas fa-map"></i>',
            '💰': '<i class="fas fa-money-bill-wave"></i>',
            '⏰': '<i class="fas fa-clock"></i>',
            '📍': '<i class="fas fa-map-marker-alt"></i>',
            '⭐': '<i class="fas fa-star"></i>'
        };
        
        Object.keys(emojiMap).forEach(emoji => {
            text = text.replace(new RegExp(emoji, 'g'), emojiMap[emoji]);
        });
        
        contentDiv.innerHTML = text;
    }
    
    addActionButtons(messageDiv, message) {
        const actionsDiv = document.createElement('div');
        actionsDiv.className = 'message-actions';
        
        // دکمه کپی
        const copyBtn = document.createElement('button');
        copyBtn.className = 'action-btn copy-btn';
        copyBtn.innerHTML = '<i class="fas fa-copy"></i> کپی';
        copyBtn.onclick = () => this.copyToClipboard(message);
        
        // دکمه خواندن متن
        const speakBtn = document.createElement('button');
        speakBtn.className = 'action-btn speak-btn';
        speakBtn.innerHTML = '<i class="fas fa-volume-up"></i> خواندن';
        speakBtn.onclick = () => this.speakText(message);
        
        // دکمه اشتراک‌گذاری
        const shareBtn = document.createElement('button');
        shareBtn.className = 'action-btn share-btn';
        shareBtn.innerHTML = '<i class="fas fa-share-alt"></i> اشتراک';
        shareBtn.onclick = () => this.shareMessage(message);
        
        actionsDiv.appendChild(copyBtn);
        actionsDiv.appendChild(speakBtn);
        actionsDiv.appendChild(shareBtn);
        
        messageDiv.appendChild(actionsDiv);
    }
    
    copyToClipboard(text) {
        navigator.clipboard.writeText(text).then(() => {
            this.showToast('متن کپی شد!', 'success');
        }).catch(err => {
            console.error('Failed to copy:', err);
            this.showToast('خطا در کپی متن', 'error');
        });
    }
    
    speakText(text) {
        if ('speechSynthesis' in window) {
            const utterance = new SpeechSynthesisUtterance(text);
            utterance.lang = 'fa-IR';
            utterance.rate = 0.9;
            window.speechSynthesis.speak(utterance);
        } else {
            this.showToast('مرورگر شما از قابلیت خواندن متن پشتیبانی نمی‌کند', 'warning');
        }
    }
    
    shareMessage(text) {
        if (navigator.share) {
            navigator.share({
                title: 'Istanbul Guide AI',
                text: text.substring(0, 100) + '...',
                url: window.location.href
            });
        } else {
            this.copyToClipboard(text);
            this.showToast('لینک کپی شد، می‌توانید در شبکه‌های اجتماعی به اشتراک بگذارید', 'info');
        }
    }
    
    saveToHistory(role, content) {
        this.conversationHistory.push({
            role: role,
            content: content,
            timestamp: new Date().toISOString()
        });
        
        // حفظ حداکثر تعداد پیام
        if (this.conversationHistory.length > this.maxHistory) {
            this.conversationHistory.shift();
        }
        
        // ذخیره در localStorage
        localStorage.setItem('istanbul_ai_history', JSON.stringify(this.conversationHistory));
    }
    
    loadHistory() {
        const saved = localStorage.getItem('istanbul_ai_history');
        if (saved) {
            this.conversationHistory = JSON.parse(saved);
            
            // نمایش تاریخچه
            const chatMessages = document.getElementById('chatMessages');
            chatMessages.innerHTML = '';
            
            this.conversationHistory.forEach(msg => {
                this.addMessage(msg.content, msg.role);
            });
        }
    }
    
    clearHistory() {
        this.conversationHistory = [];
        localStorage.removeItem('istanbul_ai_history');
        document.getElementById('chatMessages').innerHTML = '';
        this.showToast('تاریخچه مکالمات پاک شد', 'success');
    }
    
    handleSentiment(sentiment) {
        if (sentiment && sentiment.sentiment === 'negative') {
            // اگر احساسات منفی بود، پیام ویژه نشان دهیم
            setTimeout(() => {
                this.addMessage(
                    'به نظر می‌رسد کمی نگران هستید. اگر نیاز به کمک بیشتری دارید، خوشحال می‌شوم کمک کنم! 😊',
                    'ai'
                );
            }, 1000);
        }
    }
    
    updateUsageStats(tokens, responseTime) {
        const stats = JSON.parse(localStorage.getItem('ai_usage_stats') || '{"tokens": 0, "requests": 0}');
        
        stats.tokens += tokens;
        stats.requests++;
        stats.lastUsed = new Date().toISOString();
        
        localStorage.setItem('ai_usage_stats', JSON.stringify(stats));
        
        // نمایش در کنسول برای دیباگ
        console.log(`Tokens used: ${tokens}, Response time: ${responseTime}s`);
    }
    
    formatTime(date) {
        return date.toLocaleTimeString('fa-IR', {
            hour: '2-digit',
            minute: '2-digit'
        });
    }
    
    showToast(message, type = 'info') {
        // ایجاد toast
        const toast = document.createElement('div');
        toast.className = `toast toast-${type}`;
        toast.textContent = message;
        
        document.body.appendChild(toast);
        
        // پنهان شدن خودکار
        setTimeout(() => {
            toast.remove();
        }, 3000);
    }
}

// ایجاد نمونه دستیار هوشمند
const istanbulAI = new IstanbulAI();

// راه‌اندازی دستیار هوشمند
document.addEventListener('DOMContentLoaded', function() {
    // بارگذاری تاریخچه
    istanbulAI.loadHistory();
    
    // تنظیم رویدادها
    setupAIEvents();
});

function setupAIEvents() {
    const chatInput = document.getElementById('chatInput');
    const sendBtn = document.getElementById('sendMessage');
    
    // ارسال با Enter
    chatInput.addEventListener('keypress', function(e) {
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            sendMessage();
        }
    });
    
    // ارسال با دکمه
    sendBtn.addEventListener('click', sendMessage);
    
    // سوالات سریع
    document.querySelectorAll('.quick-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            const question = this.dataset.question;
            if (question) {
                chatInput.value = question;
                sendMessage();
            }
        });
    });
    
    // تغییر سایز دستیار
    const minimizeBtn = document.querySelector('.minimize-btn');
    const closeBtn = document.querySelector('.close-btn');
    
    if (minimizeBtn) {
        minimizeBtn.addEventListener('click', function() {
            const assistant = document.getElementById('aiAssistant');
            assistant.classList.toggle('minimized');
            this.querySelector('i').classList.toggle('fa-minus');
            this.querySelector('i').classList.toggle('fa-plus');
        });
    }
    
    if (closeBtn) {
        closeBtn.addEventListener('click', function() {
            document.getElementById('aiAssistant').style.display = 'none';
            localStorage.setItem('ai_assistant_closed', 'true');
        });
    }
    
    // نمایش مجدد اگر بسته بود
    if (localStorage.getItem('ai_assistant_closed') === 'true') {
        setTimeout(() => {
            document.getElementById('aiAssistant').style.display = 'flex';
            localStorage.removeItem('ai_assistant_closed');
        }, 30000); // بعد از ۳۰ ثانیه
    }
}

function sendMessage() {
    const chatInput = document.getElementById('chatInput');
    const message = chatInput.value.trim();
    
    if (message) {
        istanbulAI.sendMessage(message);
        chatInput.value = '';
    }
}
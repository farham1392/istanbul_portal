// ==========================
// PLACES DATA
// ==========================
const placesData = [
    {
        id: 1,
        name: {
            fa: "ایاصوفیه",
            en: "Hagia Sophia",
            tr: "Ayasofya",
            ar: "آيا صوفيا"
        },
        description: {
            fa: "ایاصوفیه یک شاهکار معماری بیزانس و یکی از بزرگ‌ترین کلیساهای جهان است که بعداً به مسجد تبدیل شد و اکنون موزه است. این بنا به دلیل گنبد عظیم و موزائیک‌های طلایی خود مشهور است.",
            en: "Hagia Sophia is a masterpiece of Byzantine architecture and one of the world's largest churches, later converted into a mosque and now a museum. Famous for its massive dome and golden mosaics.",
            tr: "Ayasofya, Bizans mimarisinin bir şaheseri ve dünyanın en büyük kiliselerinden biri olup daha sonra camiye çevrilmiş ve şu anda müzedir. Devasa kubbesi ve altın mozaikleriyle ünlüdür.",
            ar: "آيا صوفيا هي تحفة معمارية بيزنطية وواحدة من أكبر الكنائس في العالم، تم تحويلها لاحقًا إلى مسجد وهي الآن متحف. تشتهر بقبتها الضخمة وفسيفسائها الذهبية."
        },
        category: ["historical", "museum"],
        district: {
            fa: "سلطان احمد",
            en: "Sultanahmet",
            tr: "Sultanahmet",
            ar: "سلطان أحمد"
        },
        address: {
            fa: "سلطان احمد، استانبول",
            en: "Sultanahmet, Istanbul",
            tr: "Sultanahmet, İstanbul",
            ar: "سلطان أحمد، إسطنبول"
        },
        coordinates: {
            lat: 41.0086,
            lng: 28.9802
        },
        rating: 4.8,
        price: "medium",
        icon: "fas fa-mosque",
        image: "assets/visit-hagia-sophia-museum.jpg",
        openingHours: {
            fa: "۹:۰۰ صبح تا ۷:۰۰ عصر (سه‌شنبه‌ها تعطیل)",
            en: "9:00 AM - 7:00 PM (Closed Tuesdays)",
            tr: "09:00 - 19:00 (Salı günleri kapalı)",
            ar: "٩:٠٠ صباحًا - ٧:٠٠ مساءً (مغلق أيام الثلاثاء)"
        },
        bestTime: {
            fa: "صبح زود برای جلوگیری از شلوغی",
            en: "Early morning to avoid crowds",
            tr: "Kalabalıktan kaçınmak için sabah erken",
            ar: "الصباح الباكر لتجنب الازدحام"
        },
        duration: {
            fa: "۲-۳ ساعت",
            en: "2-3 hours",
            tr: "2-3 saat",
            ar: "٢-٣ ساعات"
        },
        tags: {
            fa: ["تاریخی", "معماری", "بیزانس", "عثمانی"],
            en: ["historical", "architecture", "byzantine", "ottoman"],
            tr: ["tarihi", "mimari", "bizans", "osmanlı"],
            ar: ["تاريخي", "عمارة", "بيزنطي", "عثماني"]
        },
        reviewCount: 12500,
        website: "https://muze.gen.tr/hagia-sophia"
    },
    {
        id: 2,
        name: {
            fa: "کاخ توپکاپی",
            en: "Topkapi Palace",
            tr: "Topkapı Sarayı",
            ar: "قصر توبكابي"
        },
        description: {
            fa: "کاخ توپکاپی اقامتگاه اصلی سلاطین عثمانی برای بیش از ۴۰۰ سال بوده است. این مجموعه وسیع شامل حیاط‌های متعدد، حرمسرا، خزانه‌ی جواهرات و نمایشگاه‌های مختلف است.",
            en: "Topkapi Palace was the main residence of Ottoman sultans for over 400 years. The vast complex includes numerous courtyards, harem, treasury of jewels, and various exhibitions.",
            tr: "Topkapı Sarayı, 400 yılı aşkın süre Osmanlı sultanlarının ana ikametgahı olmuştur. Geniş kompleks, çok sayıda avlu, harem, mücevher hazinesi ve çeşitli sergileri içerir.",
            ar: "كان قصر توبكابي المقر الرئيسي لسلاطين العثمانيين لأكثر من ٤٠٠ عام. يشمل المجمع الواسع العديد من الأفنية والحرملك وخزانة المجوهرات ومعارض متنوعة."
        },
        category: ["historical", "palace"],
        district: {
            fa: "سلطان احمد",
            en: "Sultanahmet",
            tr: "Sultanahmet",
            ar: "سلطان أحمد"
        },
        coordinates: {
            lat: 41.0138,
            lng: 28.9856
        },
        rating: 4.7,
        price: "medium",
        icon: "fas fa-crown",
        image: "assets/download (4).jpg",
        openingHours: {
            fa: "۹:۰۰ صبح تا ۶:۰۰ عصر (سه‌شنبه‌ها تعطیل)",
            en: "9:00 AM - 6:00 PM (Closed Tuesdays)",
            tr: "09:00 - 18:00 (Salı günleri kapalı)",
            ar: "٩:٠٠ صباحًا - ٦:٠٠ مساءً (مغلق أيام الثلاثاء)"
        },
        bestTime: {
            fa: "روزهای هفته برای جمعیت کمتر",
            en: "Weekdays for fewer crowds",
            tr: "Daha az kalabalık için hafta içi",
            ar: "أيام الأسبوع لازدحام أقل"
        },
        duration: {
            fa: "۳-۴ ساعت",
            en: "3-4 hours",
            tr: "3-4 saat",
            ar: "٣-٤ ساعات"
        },
        tags: {
            fa: ["کاخ", "عثمانی", "تاریخی", "موزه"],
            en: ["palace", "ottoman", "historical", "museum"],
            tr: ["saray", "osmanlı", "tarihi", "müze"],
            ar: ["قصر", "عثماني", "تاريخي", "متحف"]
        },
        reviewCount: 9800
    },
    {
        id: 3,
        name: {
            fa: "مسجد سلطان احمد (مسجد آبی)",
            en: "Sultan Ahmed Mosque (Blue Mosque)",
            tr: "Sultanahmet Camii (Mavi Camii)",
            ar: "مسجد السلطان أحمد (المسجد الأزرق)"
        },
        description: {
            fa: "مسجد سلطان احمد که به مسجد آبی معروف است، به دلیل کاشی‌کاری‌های آبی رنگ داخلی خود مشهور می‌باشد. این مسجد در قرن ۱۷ ساخته شد و هنوز هم به عنوان عبادتگاه فعال استفاده می‌شود.",
            en: "Sultan Ahmed Mosque, known as the Blue Mosque, is famous for its blue tile interior. Built in the 17th century, it is still used as an active place of worship.",
            tr: "Sultanahmet Camii, Mavi Camii olarak bilinir ve mavi çini iç mekanıyla ünlüdür. 17. yüzyılda inşa edilmiş olup hala aktif bir ibadet yeri olarak kullanılmaktadır.",
            ar: "يشتهر مسجد السلطان أحمد، المعروف بالمسجد الأزرق، ببلاطه الداخلي الأزرق. تم بناؤه في القرن السابع عشر ولا يزال يستخدم كمكان عبادة نشط."
        },
        category: ["mosque", "historical"],
        district: {
            fa: "سلطان احمد",
            en: "Sultanahmet",
            tr: "Sultanahmet",
            ar: "سلطان أحمد"
        },
        coordinates: {
            lat: 41.0054,
            lng: 28.9768
        },
        rating: 4.6,
        price: "free",
        icon: "fas fa-mosque",
        image: "assets/b0.webp",
        openingHours: {
            fa: "پنج نوبت نماز (در زمان نماز برای گردشگران بسته است)",
            en: "Five prayer times (Closed to tourists during prayers)",
            tr: "Beş vakit namaz (Namaz sırasında turistlere kapalı)",
            ar: "خمس أوقات صلاة (مغلق أمام السياح أثناء الصلاة)"
        },
        bestTime: {
            fa: "بین نمازها",
            en: "Between prayer times",
            tr: "Namaz saatleri arasında",
            ar: "بين أوقات الصلاة"
        },
        duration: {
            fa: "۱-۲ ساعت",
            en: "1-2 hours",
            tr: "1-2 saat",
            ar: "١-٢ ساعات"
        },
        tags: {
            fa: ["مسجد", "معماری اسلامی", "تاریخی"],
            en: ["mosque", "islamic architecture", "historical"],
            tr: ["cami", "islam mimarisi", "tarihi"],
            ar: ["مسجد", "العمارة الإسلامية", "تاريخي"]
        },
        reviewCount: 11200
    },
    {
        id: 4,
        name: {
            fa: "بازار بزرگ",
            en: "Grand Bazaar",
            tr: "Kapalı Çarşı",
            ar: "السوق الكبير"
        },
        description: {
            fa: "بازار بزرگ یکی از قدیمی‌ترین و بزرگ‌ترین بازارهای سرپوشیده جهان با بیش از ۴۰۰۰ مغازه است. این بازار مکان مناسبی برای خرید سوغاتی، فرش، جواهرات و صنایع دستی ترکی است.",
            en: "The Grand Bazaar is one of the oldest and largest covered markets in the world with over 4,000 shops. It's perfect for buying souvenirs, carpets, jewelry, and Turkish handicrafts.",
            tr: "Kapalı Çarşı, 4.000'den fazla dükkanı ile dünyanın en eski ve en büyük kapalı çarşılarından biridir. Hediyelik eşya, halı, mücevher ve Türk el sanatları satın almak için mükemmeldir.",
            ar: "السوق الكبير هو أحد أقدم وأكبر الأسواق المسقوفة في جهان مع أكثر من ٤٠٠٠ متجر. إنه مثالي لشراء الهدايا التذكارية والسجاد والمجوهرات والحرف اليدوية التركية."
        },
        category: ["bazaar", "shopping"],
        district: {
            fa: "بی‌اوغلو",
            en: "Beyoglu",
            tr: "Beyoğlu",
            ar: "بي أوغلو"
        },
        coordinates: {
            lat: 41.0108,
            lng: 28.9682
        },
        rating: 4.4,
        price: "low",
        icon: "fas fa-shopping-bag",
        image: "assets/Thumbnail-min.jpg",
        openingHours: {
            fa: "۹:۰۰ صبح تا ۷:۰۰ عصر (یکشنبه‌ها تعطیل)",
            en: "9:00 AM - 7:00 PM (Closed Sundays)",
            tr: "09:00 - 19:00 (Pazar günleri kapalı)",
            ar: "٩:٠٠ صباحًا - ٧:٠٠ مساءً (مغلق أيام الأحد)"
        },
        bestTime: {
            fa: "صبح‌ها برای جمعیت کمتر",
            en: "Mornings for fewer crowds",
            tr: "Daha az kalabalık için sabahları",
            ar: "الصباح لازدحام أقل"
        },
        duration: {
            fa: "۲-۴ ساعت",
            en: "2-4 hours",
            tr: "2-4 saat",
            ar: "٢-٤ ساعات"
        },
        tags: {
            fa: ["بازار", "خرید", "سوغاتی", "صنایع دستی"],
            en: ["market", "shopping", "souvenirs", "handicrafts"],
            tr: ["çarşı", "alışveriş", "hediyelik", "el sanatları"],
            ar: ["سوق", "تسوق", "هدايا تذكارية", "حرف يدوية"]
        },
        reviewCount: 15600
    },
    {
        id: 5,
        name: {
            fa: "برج گالاتا",
            en: "Galata Tower",
            tr: "Galata Kulesi",
            ar: "برج غلطة"
        },
        description: {
            fa: "برج گالاتا یک برج تاریخی قرون وسطایی است که چشم‌اندازی پانوراما از استانبول ارائه می‌دهد. این برج در قرن ۱۴ ساخته شد و یکی از نمادهای شهر است.",
            en: "Galata Tower is a medieval stone tower that offers panoramic views of Istanbul. Built in the 14th century, it's one of the city's icons.",
            tr: "Galata Kulesi, İstanbul'a panoramik manzara sunan ortaçağ taş kulesidir. 14. yüzyılda inşa edilmiş olup şehrin simgelerinden biridir.",
            ar: "برج غلطة هو برج حجري من العصور الوسطى يوفر إطلالة بانورامية على إسطنبول. تم بناؤه في القرن الرابع عشر وهو أحد رموز المدينة."
        },
        category: ["historical"],
        district: {
            fa: "بی‌اوغلو",
            en: "Beyoglu",
            tr: "Beyoğlu",
            ar: "بي أوغلو"
        },
        coordinates: {
            lat: 41.0256,
            lng: 28.9744
        },
        rating: 4.5,
        price: "medium",
        icon: "fas fa-tower",
        image: "assets/گالاتا.jpg",
        openingHours: {
            fa: "۹:۰۰ صبح تا ۸:۰۰ عصر",
            en: "9:00 AM - 8:00 PM",
            tr: "09:00 - 20:00",
            ar: "٩:٠٠ صباحًا - ٨:٠٠ مساءً"
        },
        bestTime: {
            fa: "غروب آفتاب برای بهترین منظره",
            en: "Sunset for the best view",
            tr: "En iyi manzara için gün batımı",
            ar: "غروب الشمس لأفضل إطلالة"
        },
        duration: {
            fa: "۱-۲ ساعت",
            en: "1-2 hours",
            tr: "1-2 saat",
            ar: "١-٢ ساعات"
        },
        tags: {
            fa: ["برج", "منظره", "تاریخی", "عکس‌برداری"],
            en: ["tower", "view", "historical", "photography"],
            tr: ["kule", "manzara", "tarihi", "fotoğraf"],
            ar: ["برج", "إطلالة", "تاريخي", "تصوير"]
        },
        reviewCount: 8900
    },
    {
        id: 6,
        name: {
            fa: "کاخ دلما‌باغچه",
            en: "Dolmabahçe Palace",
            tr: "Dolmabahçe Sarayı",
            ar: "قصر طولمة باغجة"
        },
        description: {
            fa: "کاخ دلما‌باغچه کاخی مجلل از دوره عثمانی متأخر است که ترکیبی از معماری عثمانی و اروپایی را نشان می‌دهد. این کاخ دارای بزرگترین چلچراغ کریستالی بوهم در جهان است.",
            en: "Dolmabahçe Palace is an opulent Ottoman-era palace showcasing a blend of Ottoman and European architecture. It houses the world's largest Bohemian crystal chandelier.",
            tr: "Dolmabahçe Sarayı, Osmanlı ve Avrupa mimarisinin bir karışımını sergileyen görkemli bir Osmanlı dönemi sarayıdır. Dünyanın en büyük Bohemya kristal avizesini barındırır.",
            ar: "قصر طولمة باغجة هو قصر فخم من العصر العثماني يعرض مزيجًا من العمارة العثمانية والأوروبية. يضم أكبر ثريا كريستال بوهيمية في العالم."
        },
        category: ["palace", "historical"],
        district: {
            fa: "بشیکتاش",
            en: "Besiktas",
            tr: "Beşiktaş",
            ar: "بشكتاش"
        },
        coordinates: {
            lat: 41.0392,
            lng: 29.0000
        },
        rating: 4.6,
        price: "medium",
        icon: "fas fa-landmark",
        image: "assets/download (6).jpg",
        openingHours: {
            fa: "۹:۰۰ صبح تا ۴:۰۰ عصر (دوشنبه و پنجشنبه تعطیل)",
            en: "9:00 AM - 4:00 PM (Closed Monday & Thursday)",
            tr: "09:00 - 16:00 (Pazartesi ve Perşembe kapalı)",
            ar: "٩:٠٠ صباحًا - ٤:٠٠ مساءً (مغلق الإثنين والخميس)"
        },
        bestTime: {
            fa: "اول وقت بازدید",
            en: "First thing in the morning",
            tr: "Sabah ilk iş",
            ar: "أول شيء في الصباح"
        },
        duration: {
            fa: "۲-۳ ساعت",
            en: "2-3 hours",
            tr: "2-3 saat",
            ar: "٢-٣ ساعات"
        },
        tags: {
            fa: ["کاخ", "عثمانی", "لوکس", "معماری"],
            en: ["palace", "ottoman", "luxury", "architecture"],
            tr: ["saray", "osmanlı", "lüks", "mimari"],
            ar: ["قصر", "عثماني", "فاخر", "عمارة"]
        },
        reviewCount: 7600
    },
    {
        id: 7,
        name: {
            fa: "موزه باستان‌شناسی استانبول",
            en: "Istanbul Archaeology Museums",
            tr: "İstanbul Arkeoloji Müzeleri",
            ar: "متحف الآثار في إسطنبول"
        },
        description: {
            fa: "این موزه مجموعه‌ای از سه موزه است که آثار باستان‌شناسی از تمدن‌های مختلف از جمله تابوت اسکندر را در خود جای داده است. یکی از مهم‌ترین موزه‌های باستان‌شناسی در جهان.",
            en: "This museum is a complex of three museums housing archaeological artifacts from various civilizations including the Alexander Sarcophagus. One of the world's most important archaeology museums.",
            tr: "Bu müze, İskender Lahdi de dahil olmak üzere çeşitli medeniyetlerden arkeolojik eserleri barındıran üç müzeden oluşan bir komplekstir. Dünyanın en önemli arkeoloji müzelerinden biri.",
            ar: "هذا المتحف هو مجمع من ثلاثة متاحف تضم قطعًا أثرية من حضارات مختلفة بما في ذلك تابوت الإسكندر. أحد أهم متاحف الآثار في العالم."
        },
        category: ["museum"],
        district: {
            fa: "سلطان احمد",
            en: "Sultanahmet",
            tr: "Sultanahmet",
            ar: "سلطان أحمد"
        },
        coordinates: {
            lat: 41.0115,
            lng: 28.9815
        },
        rating: 4.4,
        price: "low",
        icon: "fas fa-history",
        image: "assets/unnamed.jpg",
        openingHours: {
            fa: "۹:۰۰ صبح تا ۵:۰۰ عصر (دوشنبه‌ها تعطیل)",
            en: "9:00 AM - 5:00 PM (Closed Mondays)",
            tr: "09:00 - 17:00 (Pazartesi kapalı)",
            ar: "٩:٠٠ صباحًا - ٥:٠٠ مساءً (مغلق أيام الاثنين)"
        },
        bestTime: {
            fa: "بعدازظهرها معمولاً خلوت‌تر است",
            en: "Afternoons are usually less crowded",
            tr: "Öğleden sonraları genellikle daha az kalabalık",
            ar: "عادة ما تكون بعد الظهر أقل ازدحامًا"
        },
        duration: {
            fa: "۲-۳ ساعت",
            en: "2-3 hours",
            tr: "2-3 saat",
            ar: "٢-٣ ساعات"
        },
        tags: {
            fa: ["موزه", "باستان‌شناسی", "تاریخ", "آثار"],
            en: ["museum", "archaeology", "history", "artifacts"],
            tr: ["müze", "arkeoloji", "tarih", "eserler"],
            ar: ["متحف", "آثار", "تاريخ", "قطع أثرية"]
        },
        reviewCount: 5400
    },
    {
        id: 8,
        name: {
            fa: "پارک گولهانه",
            en: "Gülhane Park",
            tr: "Gülhane Parkı",
            ar: "حديقة غولهانة"
        },
        description: {
            fa: "پارک گولهانه یکی از قدیمی‌ترین و زیباترین پارک‌های عمومی استانبول است که در نزدیکی کاخ توپکاپی واقع شده. این پارک مکان مناسبی برای قدم زدن و استراحت در میان طبیعت است.",
            en: "Gülhane Park is one of Istanbul's oldest and most beautiful public parks, located near Topkapi Palace. Perfect for walking and relaxing amidst nature.",
            tr: "Gülhane Parkı, Topkapı Sarayı yakınında bulunan İstanbul'un en eski ve en güzel parklarından biridir. Doğa içinde yürüyüş و dinlenme için mükemmeldir.",
            ar: "حديقة غولهانة هي واحدة من أقدم وأجمل الحدائق العامة في إسطنبول، وتقع بالقرب من قصر توبكابي. مثالية للمشي والاسترخاء وسط الطبيعة."
        },
        category: ["park"],
        district: {
            fa: "سلطان احمد",
            en: "Sultanahmet",
            tr: "Sultanahmet",
            ar: "سلطان أحمد"
        },
        coordinates: {
            lat: 41.0136,
            lng: 28.9819
        },
        rating: 4.3,
        price: "free",
        icon: "fas fa-tree",
        image: "assets/download (7).jpg",
        openingHours: {
            fa: "۶:۰۰ صبح تا ۱۰:۰۰ عصر",
            en: "6:00 AM - 10:00 PM",
            tr: "06:00 - 22:00",
            ar: "٦:٠٠ صباحًا - ١٠:٠٠ مساءً"
        },
        bestTime: {
            fa: "بهار برای دیدن شکوفه‌های گیلاس",
            en: "Spring to see cherry blossoms",
            tr: "Kiraz çiçeklerini görmek için bahar",
            ar: "الربيع لرؤية أزهار الكرز"
        },
        duration: {
            fa: "۱-۲ ساعت",
            en: "1-2 hours",
            tr: "1-2 saat",
            ar: "١-٢ ساعات"
        },
        tags: {
            fa: ["پارک", "طبیعت", "قدم‌زدن", "آرامش"],
            en: ["park", "nature", "walking", "relaxation"],
            tr: ["park", "doğa", "yürüyüş", "dinlenme"],
            ar: ["حديقة", "طبيعة", "مشي", "استرخاء"]
        },
        reviewCount: 6800
    },
    {
        id: 9,
        name: {
            fa: "مسجد سلیمانیه",
            en: "Suleymaniye Mosque",
            tr: "Süleymaniye Camii",
            ar: "مسجد السليمانية"
        },
        description: {
            fa: "مسجد سلیمانیه یکی از بزرگترین و زیباترین مساجد استانبول است که توسط معمار سینان در قرن ۱۶ ساخته شد. این مسجد مجموعه‌ای از مدارس، کتابخانه، حمام و بیمارستان را نیز شامل می‌شود.",
            en: "Suleymaniye Mosque is one of Istanbul's largest and most beautiful mosques, built by architect Sinan in the 16th century. The complex also includes schools, a library, baths, and a hospital.",
            tr: "Süleymaniye Camii, 16. yüzyılda Mimar Sinan tarafından inşa edilen İstanbul'un en büyük ve en güzel camilerinden biridir. Kompleks ayrıca okullar, kütüphane, hamam ve hastane içerir.",
            ar: "مسجد السليمانية هو أحد أكبر وأجمل مساجد إسطنبول، بناه المعماري سنان في القرن السادس عشر. يشمل المجمع مدارس ومكتبة وحمامات ومستشفى."
        },
        category: ["mosque", "historical"],
        district: {
            fa: "فاتح",
            en: "Fatih",
            tr: "Fatih",
            ar: "الفاتح"
        },
        coordinates: {
            lat: 41.0160,
            lng: 28.9639
        },
        rating: 4.7,
        price: "free",
        icon: "fas fa-mosque",
        image: "assets/download (8).jpg",
        openingHours: {
            fa: "۹:۰۰ صبح تا ۶:۰۰ عصر (بین نمازها)",
            en: "9:00 AM - 6:00 PM (Between prayers)",
            tr: "09:00 - 18:00 (Namaz saatleri arasında)",
            ar: "٩:٠٠ صباحًا - ٦:٠٠ مساءً (بين الصلوات)"
        },
        bestTime: {
            fa: "بعدازظهر برای نور عالی عکاسی",
            en: "Afternoon for great photography light",
            tr: "Fotoğraf için mükemmel ışık için öğleden sonra",
            ar: "بعد الظهر للضوء الرائع للتصوير"
        },
        duration: {
            fa: "۱-۲ ساعت",
            en: "1-2 hours",
            tr: "1-2 saat",
            ar: "١-٢ ساعات"
        },
        tags: {
            fa: ["مسجد", "معماری عثمانی", "معمار سینان", "تاریخی"],
            en: ["mosque", "ottoman architecture", "mimar sinan", "historical"],
            tr: ["cami", "osmanlı mimarisi", "mimar sinan", "tarihi"],
            ar: ["مسجد", "العمارة العثمانية", "معمار سنان", "تاريخي"]
        },
        reviewCount: 8400
    },
    {
        id: 10,
        name: {
            fa: "آب انبار باسیلیکا",
            en: "Basilica Cistern",
            tr: "Yerebatan Sarnıcı",
            ar: "خزان البازيليك"
        },
        description: {
            fa: "آب انبار زیرزمینی وسیع از دوره بیزانس با ۳۳۶ ستون مرمری. این مکان به دلیل ستون‌های معروف مدوسا و محیط مرموز و سرد خود مشهور است.",
            en: "Vast underground cistern from the Byzantine period with 336 marble columns. Famous for its Medusa columns and mysterious, cool atmosphere.",
            tr: "336 mermer sütunlu Bizans döneminden geniş yeraltı sarnıcı. Medusa sütunları ve gizemli, serin atmosferi ile ünlüdür.",
            ar: "خزان تحت الأرض واسع من العصر البيزنطي مع ٣٣٦ عمود رخامي. تشتهر بأعمدة ميدوسا وأجوائها الغامضة والباردة."
        },
        category: ["historical"],
        district: {
            fa: "سلطان احمد",
            en: "Sultanahmet",
            tr: "Sultanahmet",
            ar: "سلطان أحمد"
        },
        coordinates: {
            lat: 41.0083,
            lng: 28.9778
        },
        rating: 4.5,
        price: "medium",
        icon: "fas fa-water",
        image: "assets/download (9).jpg",
        openingHours: {
            fa: "۹:۰۰ صبح تا ۷:۰۰ عصر",
            en: "9:00 AM - 7:00 PM",
            tr: "09:00 - 19:00",
            ar: "٩:٠٠ صباحًا - ٧:٠٠ مساءً"
        },
        bestTime: {
            fa: "هنگام شلوغی روز برای فرار از گرما",
            en: "During the day's heat to escape the heat",
            tr: "Sıcaktan kaçmak için günün sıcağında",
            ar: "أثناء حرارة النهار للهروب من الحرارة"
        },
        duration: {
            fa: "۱ ساعت",
            en: "1 hour",
            tr: "1 saat",
            ar: "١ ساعة"
        },
        tags: {
            fa: ["بیزانس", "آب انبار", "زیرزمینی", "معماری"],
            en: ["byzantine", "cistern", "underground", "architecture"],
            tr: ["bizans", "sarnıç", "yeraltı", "mimari"],
            ar: ["بيزنطي", "خزان", "تحت الأرض", "عمارة"]
        },
        reviewCount: 6200
    },
    {
        id: 11,
        name: {
            fa: "موزه هنرهای اسلامی و ترکی",
            en: "Museum of Turkish and Islamic Arts",
            tr: "Türk ve İslam Eserleri Müzesi",
            ar: "متحف الفنون التركية والإسلامية"
        },
        description: {
            fa: "موزه‌ای غنی از هنرهای اسلامی و ترکی از دوره سلجوقی تا عثمانی. این موزه در کاخ ابراهیم پاشا واقع شده و مجموعه‌ای از فرش‌های نفیس، خوشنویسی و آثار فلزی را نمایش می‌دهد.",
            en: "Museum rich in Turkish and Islamic arts from the Seljuk to Ottoman periods. Located in the Ibrahim Pasha Palace, it displays a collection of exquisite carpets, calligraphy, and metalwork.",
            tr: "Selçuklu'dan Osmanlı'ya Türk ve İslam sanatları açısından zengin bir müze. İbrahim Paşa Sarayı'nda yer alır ve muhteşem halılar, hat sanatı ve metal işçiliği koleksiyonu sergiler.",
            ar: "متحف غني بالفنون التركية والإسلامية من العصر السلجوقي إلى العثماني. يقع في قصر إبراهيم باشا ويعرض مجموعة من السجاد الفاخر والخط والأعمال المعدنية."
        },
        category: ["museum"],
        district: {
            fa: "سلطان احمد",
            en: "Sultanahmet",
            tr: "Sultanahmet",
            ar: "سلطان أحمد"
        },
        coordinates: {
            lat: 41.0061,
            lng: 28.9714
        },
        rating: 4.4,
        price: "low",
        icon: "fas fa-palette",
        image: "assets/download (10).jpg",
        openingHours: {
            fa: "۹:۰۰ صبح تا ۵:۰۰ عصر (دوشنبه‌ها تعطیل)",
            en: "9:00 AM - 5:00 PM (Closed Mondays)",
            tr: "09:00 - 17:00 (Pazartesi kapalı)",
            ar: "٩:٠٠ صباحًا - ٥:٠٠ مساءً (مغلق الاثنين)"
        },
        bestTime: {
            fa: "صبح‌ها برای بازدید آرام",
            en: "Mornings for a quiet visit",
            tr: "Sessiz bir ziyaret için sabahları",
            ar: "الصباح لزيارة هادئة"
        },
        duration: {
            fa: "۲ ساعت",
            en: "2 hours",
            tr: "2 saat",
            ar: "٢ ساعات"
        },
        tags: {
            fa: ["موزه", "هنر اسلامی", "فرش", "خوشنویسی"],
            en: ["museum", "islamic art", "carpets", "calligraphy"],
            tr: ["müze", "islam sanatı", "halı", "hat"],
            ar: ["متحف", "الفن الإسلامي", "سجاد", "خط"]
        },
        reviewCount: 3800
    }
];
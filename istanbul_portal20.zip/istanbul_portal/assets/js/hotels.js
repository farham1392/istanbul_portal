// ==========================
// HOTELS DATA
// ==========================
const hotelsData = [
    {
        id: 101,
        name: {
            fa: "هیلتون استانبول بوسفروس",
            en: "Hilton Istanbul Bosphorus",
            tr: "Hilton İstanbul Boğaziçi",
            ar: "هيلتون إسطنبول البوسفور"
        },
        address: {
            fa: "بی‌اوغلو، استانبول",
            en: "Beyoglu, Istanbul",
            tr: "Beyoğlu, İstanbul",
            ar: "بي أوغلو، إسطنبول"
        },
        coordinates: {
            lat: 41.0450,
            lng: 29.0075
        },
        stars: 5,
        pricePerNight: 2500,
        amenities: ["استخر", "اسپا", "رستوران", "سالن ورزش", "وای‌فای رایگان", "پارکینگ"],
        rating: 4.7,
        reviewCount: 3200,
        description: {
            fa: "هتل لوکس ۵ ستاره با چشم‌انداز بی‌نظیر از بسفر",
            en: "Luxury 5-star hotel with stunning Bosphorus views",
            tr: "Boğaz manzaralı lüks 5 yıldızlı otel",
            ar: "فندق فاخر ٥ نجوم بإطلالة خلابة على البوسفور"
        }
    },
    {
        id: 102,
        name: {
            fa: "فورسیزن استانبول",
            en: "Four Seasons Istanbul",
            tr: "Four Seasons İstanbul",
            ar: "فور سيزونز إسطنبول"
        },
        address: {
            fa: "سلطان احمد، استانبول",
            en: "Sultanahmet, Istanbul",
            tr: "Sultanahmet, İstanbul",
            ar: "سلطان أحمد، إسطنبول"
        },
        coordinates: {
            lat: 41.0080,
            lng: 28.9775
        },
        stars: 5,
        pricePerNight: 3500,
        amenities: ["استخر", "اسپا", "رستوران میشلن", "سالن ورزش", "خدمات کونسیرژ"],
        rating: 4.9,
        reviewCount: 2800,
        description: {
            fa: "هتل لوکس در قلب منطقه تاریخی استانبول",
            en: "Luxury hotel in the heart of Istanbul's historic district",
            tr: "İstanbul'un tarihi bölgesinin kalbinde lüks otel",
            ar: "فندق فاخر في قلب المنطقة التاريخية في إسطنبول"
        }
    },
    {
        id: 103,
        name: {
            fa: "رادیسون بلو استانبول",
            en: "Radisson Blu Istanbul",
            tr: "Radisson Blu İstanbul",
            ar: "راديسون بلو إسطنبول"
        },
        address: {
            fa: "شیشلی، استانبول",
            en: "Sisli, Istanbul",
            tr: "Şişli, İstanbul",
            ar: "شيشلي، إسطنبول"
        },
        coordinates: {
            lat: 41.0600,
            lng: 28.9900
        },
        stars: 4,
        pricePerNight: 1200,
        amenities: ["رستوران", "سالن ورزش", "وای‌فای رایگان", "صبحانه رایگان"],
        rating: 4.3,
        reviewCount: 2100,
        description: {
            fa: "هتل ۴ ستاره مدرن در مرکز خرید استانبول",
            en: "Modern 4-star hotel in Istanbul's shopping district",
            tr: "İstanbul'un alışveriş bölgesinde modern 4 yıldızlı otel",
            ar: "فندق ٤ نجوم حديث في منطقة التسوق في إسطنبول"
        }
    },
    {
        id: 104,
        name: {
            fa: "ایرا هتل",
            en: "Ira Hotel",
            tr: "Ira Hotel",
            ar: "فندق إيرا"
        },
        address: {
            fa: "سلطان احمد، استانبول",
            en: "Sultanahmet, Istanbul",
            tr: "Sultanahmet, İstanbul",
            ar: "سلطان أحمد، إسطنبول"
        },
        coordinates: {
            lat: 41.0065,
            lng: 28.9750
        },
        stars: 3,
        pricePerNight: 600,
        amenities: ["تراس روف", "صبحانه", "وای‌فای رایگان"],
        rating: 4.5,
        reviewCount: 1800,
        description: {
            fa: "هتل بوتیک با معماری عثمانی و منظره‌ای از مسجد آبی",
            en: "Boutique hotel with Ottoman architecture and Blue Mosque views",
            tr: "Osmanlı mimarili butik otel ve Mavi Camii manzarası",
            ar: "فندق بوتيك بعمارة عثمانية وإطلالة على المسجد الأزرق"
        }
    },
    {
        id: 105,
        name: {
            fa: "دابل‌تری استانبول",
            en: "DoubleTree Istanbul",
            tr: "DoubleTree İstanbul",
            ar: "دابل تري إسطنبول"
        },
        address: {
            fa: "بشیکتاش، استانبول",
            en: "Besiktas, Istanbul",
            tr: "Beşiktaş, İstanbul",
            ar: "بشكتاش، إسطنبول"
        },
        coordinates: {
            lat: 41.0420,
            lng: 29.0100
        },
        stars: 4,
        pricePerNight: 1500,
        amenities: ["استخر", "رستوران", "سالن ورزش", "کلوپ کودکان"],
        rating: 4.4,
        reviewCount: 1900,
        description: {
            fa: "هتل خانوادگی نزدیک به کاخ دلما‌باغچه",
            en: "Family-friendly hotel near Dolmabahçe Palace",
            tr: "Dolmabahçe Sarayı yakınında aile dostu otel",
            ar: "فندق ملائم للعائلات بالقرب من قصر طولمة باغجة"
        }
    }
];
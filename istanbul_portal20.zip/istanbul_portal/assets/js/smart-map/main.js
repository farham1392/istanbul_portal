// assets/js/smart-map/main.js
/**
 * فایل اصلی برای ادغام تمام سیستم‌های نقشه هوشمند
 */

// تابع راه‌اندازی کامل نقشه هوشمند
function initializeSmartMap() {
    console.log('🚀 راه‌اندازی نقشه هوشمند استانبول...');
    
    // بررسی وجود المان نقشه
    if (!document.getElementById('smart-map')) {
        console.error('❌ المان #smart-map پیدا نشد');
        return;
    }
    
    // بارگذاری Mapbox
    if (typeof mapboxgl === 'undefined') {
        console.error('❌ Mapbox GL JS بارگذاری نشده است');
        return;
    }
    
    // راه‌اندازی سیستم‌ها
    try {
        // 1. راه‌اندازی موتور اصلی نقشه
        window.smartMap = new SmartMap();
        smartMap.init();
        
        // 2. راه‌اندازی سیستم فیلتر هوشمند
        setTimeout(() => {
            if (document.getElementById('smart-filters')) {
                window.smartFilters = new SmartFilters(smartMap);
                smartFilters.init();
            }
        }, 1000);
        
        // 3. راه‌اندازی سیستم مسیریابی
        setTimeout(() => {
            window.smartRouting = new SmartRouting(smartMap);
            smartRouting.init();
        }, 1500);
        
        // 4. راه‌اندازی سیستم گیمیفیکیشن
        setTimeout(() => {
            window.gameEngine = new GamificationEngine(smartMap);
        }, 2000);
        
        console.log('✅ نقشه هوشمند با موفقیت راه‌اندازی شد');
        
    } catch (error) {
        console.error('❌ خطا در راه‌اندازی نقشه هوشمند:', error);
        showErrorFallback();
    }
}

// تابع نمایش حالت جایگزین در صورت خطا
function showErrorFallback() {
    const mapContainer = document.getElementById('smart-map');
    if (mapContainer) {
        mapContainer.innerHTML = `
            <div style="
                height: 100%;
                display: flex;
                flex-direction: column;
                align-items: center;
                justify-content: center;
                background: linear-gradient(135deg, #667eea, #764ba2);
                color: white;
                border-radius: 20px;
                padding: 30px;
                text-align: center;
                font-family: 'Vazirmatn', sans-serif;
            ">
                <div style="font-size: 48px; margin-bottom: 20px;">🗺️</div>
                <h3 style="margin: 0 0 15px 0;">نقشه هوشمند استانبول</h3>
                <p style="margin: 0 0 25px 0; opacity: 0.9;">
                    در حال حاضر نقشه در دسترس نیست، اما می‌توانید از سایر بخش‌های راهنما استفاده کنید.
                </p>
                <div style="display: flex; gap: 15px; flex-wrap: wrap; justify-content: center;">
                    <button onclick="showDistrictInfo('sultanahmet')" style="
                        background: rgba(255,255,255,0.2);
                        border: 1px solid rgba(255,255,255,0.3);
                        color: white;
                        padding: 10px 20px;
                        border-radius: 10px;
                        cursor: pointer;
                        font-family: 'Vazirmatn', sans-serif;
                    ">
                        🏛️ سلطان احمد
                    </button>
                    <button onclick="showDistrictInfo('beyoglu')" style="
                        background: rgba(255,255,255,0.2);
                        border: 1px solid rgba(255,255,255,0.3);
                        color: white;
                        padding: 10px 20px;
                        border-radius: 10px;
                        cursor: pointer;
                        font-family: 'Vazirmatn', sans-serif;
                    ">
                        🏙️ بی‌اوغلو
                    </button>
                    <button onclick="showDistrictInfo('balat')" style="
                        background: rgba(255,255,255,0.2);
                        border: 1px solid rgba(255,255,255,0.3);
                        color: white;
                        padding: 10px 20px;
                        border-radius: 10px;
                        cursor: pointer;
                        font-family: 'Vazirmatn', sans-serif;
                    ">
                        🎨 بالات
                    </button>
                </div>
            </div>
        `;
    }
}

// تابع نمایش اطلاعات محله (در حالت جایگزین)
function showDistrictInfo(districtId) {
    const districts = {
        sultanahmet: {
            name: 'سلطان احمد',
            description: 'قلب تاریخی استانبول',
            attractions: 'ایاصوفیه، کاخ توپکاپی، مسجد آبی',
            food: 'کباب ترکی'
        },
        beyoglu: {
            name: 'بی‌اوغلو',
            description: 'شهر مدرن استانبول',
            attractions: 'برج گالاتا، خیابان استقلال',
            food: 'سیب‌زمینی گوشت‌دار'
        },
        balat: {
            name: 'بالات',
            description: 'محله رنگارنگ و هنری',
            attractions: 'خانه‌های رنگارنگ، کلیسای بلغاری',
            food: 'چای ترکی'
        }
    };
    
    const district = districts[districtId];
    if (district) {
        alert(`
            🏛️ ${district.name}
            
            ${district.description}
            
            🏆 جاذبه‌ها:
            ${district.attractions}
            
            🍽️ غذای معروف:
            ${district.food}
        `);
    }
}

// تابع برای دریافت پارامترهای URL
function getUrlParams() {
    const params = new URLSearchParams(window.location.search);
    const mapParam = params.get('map');
    
    if (mapParam) {
        const [lng, lat, zoom, pitch, bearing] = mapParam.split(',').map(Number);
        return { lng, lat, zoom, pitch, bearing };
    }
    
    return null;
}

// تابع به‌روزرسانی عنوان صفحه بر اساس محله انتخاب شده
function updatePageTitle(districtName) {
    document.title = `${districtName} - نقشه هوشمند استانبول`;
    
    // به‌روزرسانی meta tags برای SEO
    const metaDescription = document.querySelector('meta[name="description"]');
    if (metaDescription) {
        metaDescription.content = `کشف ${districtName} در استانبول. نقشه هوشمند، راهنمای گردشگری و برنامه‌ریز سفر`;
    }
}

// تابع اشتراک‌گذاری موقعیت
function shareLocation(districtName, coordinates) {
    if (navigator.share) {
        navigator.share({
            title: `${districtName} در استانبول`,
            text: `به ${districtName} در نقشه هوشمند استانبول نگاه کنید!`,
            url: `${window.location.origin}${window.location.pathname}?map=${coordinates[0]},${coordinates[1]},14`
        });
    } else {
        // کپی لینک به کلیپ‌برد
        const shareUrl = `${window.location.origin}${window.location.pathname}?map=${coordinates[0]},${coordinates[1]},14`;
        navigator.clipboard.writeText(shareUrl).then(() => {
            alert('لینک موقعیت در حافظه کلیپ‌برد کپی شد');
        });
    }
}

// تابع گزارش مشکل
function reportIssue(type, details) {
    const issues = {
        'map_error': 'خطای نقشه',
        'data_error': 'خطای اطلاعات',
        'ui_error': 'خطای رابط کاربری',
        'other': 'سایر'
    };
    
    console.log(`گزارش مشکل: ${issues[type] || type}`, details);
    
    // در واقعیت، این اطلاعات به سرور ارسال می‌شود
    alert('گزارش شما ثبت شد. با تشکر از بازخورد شما!');
}

// راه‌اندازی وقتی DOM کاملاً بارگذاری شد
document.addEventListener('DOMContentLoaded', () => {
    // اضافه کردن استایل‌های اضافی
    const extraStyles = document.createElement('style');
    extraStyles.textContent = `
        /* انیمیشن‌های اضافی */
        @keyframes shimmer {
            0% { background-position: -200% center; }
            100% { background-position: 200% center; }
        }
        
        .loading-shimmer {
            background: linear-gradient(90deg, #f0f0f0 25%, #e0e0e0 50%, #f0f0f0 75%);
            background-size: 200% 100%;
            animation: shimmer 1.5s infinite;
        }
        
        /* افکت‌های ویژه */
        .glow-effect {
            filter: drop-shadow(0 0 10px rgba(251, 191, 36, 0.5));
        }
        
        .pulse-border {
            border: 2px solid transparent;
            animation: pulse-border 2s infinite;
        }
        
        @keyframes pulse-border {
            0%, 100% { border-color: transparent; }
            50% { border-color: #FBBF24; }
        }
        
        /* استایل‌های ریسپانسیو */
        @media (max-width: 768px) {
            #smart-map {
                height: 400px !important;
            }
            
            .smart-filters {
                top: 10px !important;
                right: 10px !important;
                left: 10px !important;
                max-width: none !important;
            }
            
            #routing-panel,
            #gamification-stats-panel,
            #gamification-missions-panel {
                position: fixed !important;
                top: 50% !important;
                left: 50% !important;
                transform: translate(-50%, -50%) !important;
                width: 90% !important;
                max-width: 400px !important;
                max-height: 80vh !important;
                overflow-y: auto !important;
            }
            
            .map-controls {
                bottom: 10px !important;
                right: 10px !important;
            }
            
            #open-routing-panel,
            #open-stats-panel {
                width: 40px !important;
                height: 40px !important;
                font-size: 16px !important;
            }
        }
        
        @media (max-width: 480px) {
            #smart-map {
                height: 350px !important;
            }
            
            .filter-btn {
                padding: 6px 12px !important;
                font-size: 12px !important;
            }
        }
        
        /* حالت تاریک */
        @media (prefers-color-scheme: dark) {
            .district-card {
                background: #1F2937 !important;
                color: white !important;
            }
            
            .card-body {
                background: #1F2937 !important;
            }
            
            .suitable-tag {
                background: #374151 !important;
                color: #D1D5DB !important;
            }
            
            .highlights,
            .famous-food,
            .smart-tip {
                background: #374151 !important;
            }
            
            .missions-panel,
            .ai-panel,
            #routing-panel,
            #gamification-stats-panel,
            #gamification-missions-panel {
                background: #1F2937 !important;
                color: white !important;
            }
        }
    `;
    document.head.appendChild(extraStyles);
    
    // بارگذاری نقشه هوشمند
    initializeSmartMap();
    
    // اضافه کردن event listener برای گزارش مشکلات
    document.addEventListener('keydown', (e) => {
        // Ctrl + Shift + R برای گزارش مشکل
        if (e.ctrlKey && e.shiftKey && e.key === 'R') {
            const details = {
                url: window.location.href,
                userAgent: navigator.userAgent,
                timestamp: new Date().toISOString(),
                mapState: window.smartMap ? {
                    center: smartMap.map?.getCenter(),
                    zoom: smartMap.map?.getZoom()
                } : null
            };
            
            reportIssue('other', details);
        }
    });
    
    // اضافه کردن متا تگ‌های SEO دینامیک
    const seoMetaTags = `
        <meta property="og:title" content="نقشه هوشمند استانبول - راهنمای گردشگری تعاملی">
        <meta property="og:description" content="کشف استانبول با نقشه هوشمند، فیلترهای پیشرفته، مسیریابی و سیستم گیمیفیکیشن">
        <meta property="og:image" content="${window.location.origin}/assets/social-preview.jpg">
        <meta property="og:url" content="${window.location.href}">
        <meta name="twitter:card" content="summary_large_image">
    `;
    
    document.head.insertAdjacentHTML('beforeend', seoMetaTags);
    
    console.log('✨ نقشه هوشمند استانبول آماده است!');
});

// Global error handler
window.addEventListener('error', function(e) {
    console.error('خطای全局:', e.error);
    
    // ارسال گزارش خطا به سرور (در حالت تولید)
    if (window.location.hostname !== 'localhost') {
        const errorData = {
            message: e.error?.message,
            stack: e.error?.stack,
            url: window.location.href,
            timestamp: new Date().toISOString()
        };
        
        // در واقعیت، این داده‌ها به سرور ارسال می‌شوند
        console.log('گزارش خطا:', errorData);
    }
});

// اضافه کردن توابع global برای دسترسی آسان
window.shareMapLocation = shareLocation;
window.updateMapTitle = updatePageTitle;
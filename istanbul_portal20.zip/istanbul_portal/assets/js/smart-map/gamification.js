// assets/js/smart-map/gamification-engine.js
/**
 * سیستم گیمیفیکیشن و بازی‌گونه برای نقشه استانبول
 */

class GamificationEngine {
    constructor(smartMap) {
        this.smartMap = smartMap;
        this.userStats = {
            points: 0,
            level: 1,
            badges: [],
            discoveries: [],
            missionsCompleted: 0,
            totalDistance: 0,
            districtsVisited: new Set()
        };
        
        this.badges = [
            { id: 'explorer', name: 'کاشف', icon: '🗺️', description: '۵ محله مختلف را کشف کنید', requirement: 5 },
            { id: 'photographer', name: 'عکاس', icon: '📸', description: '۱۰ عکس ثبت کنید', requirement: 10 },
            { id: 'foodie', name: 'خوشمزه‌شناس', icon: '🍽️', description: '۵ غذای محلی را امتحان کنید', requirement: 5 },
            { id: 'historian', name: 'تاریخ‌دان', icon: '🏛️', description: '۱۰ مکان تاریخی ببینید', requirement: 10 },
            { id: 'collector', name: 'کلکسیونر', icon: '🏆', description: 'تمام مدال‌ها را جمع کنید', requirement: 8 }
        ];
        
        this.currentMissions = [];
        this.hiddenGems = [];
        this.easterEggs = [];
        
        this.init();
    }
    
    init() {
        this.loadUserStats();
        this.setupMissions();
        this.setupHiddenGems();
        this.setupEasterEggs();
        this.createGamificationUI();
        
        console.log('✅ سیستم گیمیفیکیشن راه‌اندازی شد');
    }
    
    loadUserStats() {
        try {
            const savedStats = localStorage.getItem('istanbul_gamification_stats');
            if (savedStats) {
                const parsed = JSON.parse(savedStats);
                this.userStats = {
                    ...this.userStats,
                    ...parsed,
                    districtsVisited: new Set(parsed.districtsVisited || [])
                };
            }
        } catch (e) {
            console.error('خطا در بارگیری آمار کاربر:', e);
        }
    }
    
    saveUserStats() {
        try {
            localStorage.setItem('istanbul_gamification_stats', JSON.stringify({
                ...this.userStats,
                districtsVisited: Array.from(this.userStats.districtsVisited)
            }));
        } catch (e) {
            console.error('خطا در ذخیره آمار کاربر:', e);
        }
    }
    
    setupMissions() {
        this.currentMissions = [
            {
                id: 'explore_3_districts',
                title: '۳ محله مختلف را کشف کن',
                description: 'کارت اطلاعات ۳ محله مختلف را باز کن',
                type: 'exploration',
                target: 3,
                progress: 0,
                reward: { points: 100, badge: 'explorer' },
                completed: false
            },
            {
                id: 'find_hidden_gems',
                title: 'گنجینه‌های مخفی را پیدا کن',
                description: '۳ نقطه مخفی روی نقشه را پیدا کن',
                type: 'discovery',
                target: 3,
                progress: 0,
                reward: { points: 150 },
                completed: false
            },
            {
                id: 'create_route',
                title: 'یک مسیر سفارشی بساز',
                description: 'مسیری با حداقل ۳ ایستگاه ایجاد کن',
                type: 'route',
                target: 3,
                progress: 0,
                reward: { points: 200 },
                completed: false
            },
            {
                id: 'use_filters',
                title: 'فیلترهای هوشمند را امتحان کن',
                description: 'از ۵ فیلتر مختلف استفاده کن',
                type: 'interaction',
                target: 5,
                progress: 0,
                reward: { points: 80 },
                completed: false
            }
        ];
        
        // بارگیری پیشرفت مأموریت‌ها
        this.loadMissionProgress();
    }
    
    setupHiddenGems() {
        this.hiddenGems = [
            {
                id: 'gem_1',
                name: 'کافه مخفی بالات',
                coordinates: [28.9490, 41.0310],
                clue: 'پشت سومین خانه آبی رنگ',
                description: 'کافه‌ای دنج با قهوه دست‌ساز',
                reward: { points: 50 },
                discovered: false
            },
            {
                id: 'gem_2',
                name: 'منظره مخفی گالاتا',
                coordinates: [28.9739, 41.0255],
                clue: 'از پله‌های مارپیچ برج بالا بروید',
                description: 'نمای پانوراما از استانبول',
                reward: { points: 75 },
                discovered: false
            },
            {
                id: 'gem_3',
                name: 'باغ مخفی فاتح',
                coordinates: [28.9470, 41.0220],
                clue: 'در پشت مسجد تاریخی',
                description: 'باغی آرام در قلب شهر شلوغ',
                reward: { points: 60 },
                discovered: false
            },
            {
                id: 'gem_4',
                name: 'فروشگاه دست‌ساز',
                coordinates: [28.9760, 41.0270],
                clue: 'در کوچه فرعی کاراکوی',
                description: 'صنایع دستی سنتی ترکی',
                reward: { points: 40 },
                discovered: false
            }
        ];
        
        this.loadHiddenGemsProgress();
        this.addHiddenGemsToMap();
    }
    
    setupEasterEggs() {
        this.easterEggs = [
            {
                id: 'secret_button',
                selector: '#map',
                trigger: 'triple-click',
                action: () => this.showSecretMessage()
            },
            {
                id: 'konami_code',
                code: ['ArrowUp', 'ArrowUp', 'ArrowDown', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'ArrowLeft', 'ArrowRight', 'b', 'a'],
                progress: [],
                action: () => this.unlockSecretMode()
            }
        ];
        
        this.setupEasterEggListeners();
    }
    
    createGamificationUI() {
        // ایجاد پنل آمار کاربر
        const statsPanel = document.createElement('div');
        statsPanel.id = 'gamification-stats-panel';
        statsPanel.style.cssText = `
            position: absolute;
            top: 120px;
            right: 20px;
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            padding: 15px;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.15);
            z-index: 1000;
            width: 280px;
            font-family: 'Vazirmatn', sans-serif;
            display: none;
            border: 2px solid #FBBF24;
        `;
        
        this.updateStatsPanel(statsPanel);
        document.getElementById('smart-map')?.parentElement?.appendChild(statsPanel);
        
        // دکمه باز کردن پنل آمار
        const statsButton = document.createElement('button');
        statsButton.id = 'open-stats-panel';
        statsButton.style.cssText = `
            position: absolute;
            top: 70px;
            right: 20px;
            background: linear-gradient(135deg, #F59E0B, #D97706);
            color: white;
            border: none;
            width: 50px;
            height: 50px;
            border-radius: 50%;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 20px;
            box-shadow: 0 5px 15px rgba(245, 158, 11, 0.3);
            z-index: 999;
        `;
        statsButton.innerHTML = '🏆';
        statsButton.title = 'آمار و دستاوردها';
        statsButton.addEventListener('click', () => {
            const panel = document.getElementById('gamification-stats-panel');
            panel.style.display = panel.style.display === 'none' ? 'block' : 'none';
        });
        
        document.getElementById('smart-map')?.parentElement?.appendChild(statsButton);
        
        // ایجاد پنل مأموریت‌ها
        this.createMissionsPanel();
    }
    
    updateStatsPanel(panel) {
        if (!panel) return;
        
        panel.innerHTML = `
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 15px;">
                <h4 style="margin: 0; color: #1F2937; display: flex; align-items: center; gap: 8px;">
                    🏆 دستاوردهای شما
                </h4>
                <button onclick="document.getElementById('gamification-stats-panel').style.display='none'" 
                        style="background: none; border: none; font-size: 20px; cursor: pointer; color: #6B7280;">
                    ×
                </button>
            </div>
            
            <div style="margin-bottom: 15px;">
                <div style="display: flex; align-items: center; gap: 10px; margin-bottom: 10px;">
                    <div style="
                        background: linear-gradient(135deg, #FBBF24, #F59E0B);
                        width: 60px;
                        height: 60px;
                        border-radius: 50%;
                        display: flex;
                        align-items: center;
                        justify-content: center;
                        font-size: 24px;
                        font-weight: bold;
                        color: white;
                    ">
                        ${this.userStats.level}
                    </div>
                    <div>
                        <div style="font-size: 14px; color: #6B7280;">سطح</div>
                        <div style="font-weight: bold; font-size: 18px; color: #1F2937;">کاشف استانبول</div>
                    </div>
                </div>
                
                <div style="background: #F3F4F6; height: 8px; border-radius: 4px; overflow: hidden; margin-bottom: 20px;">
                    <div style="
                        background: linear-gradient(90deg, #F59E0B, #FBBF24);
                        height: 100%;
                        width: ${(this.userStats.points % 1000) / 10}%;
                        border-radius: 4px;
                    "></div>
                </div>
            </div>
            
            <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 10px; margin-bottom: 20px;">
                <div style="text-align: center;">
                    <div style="font-size: 20px; font-weight: bold; color: #4F46E5;">${this.userStats.points}</div>
                    <div style="font-size: 12px; color: #6B7280;">امتیاز</div>
                </div>
                <div style="text-align: center;">
                    <div style="font-size: 20px; font-weight: bold; color: #10B981;">${this.userStats.districtsVisited.size}</div>
                    <div style="font-size: 12px; color: #6B7280;">محله</div>
                </div>
                <div style="text-align: center;">
                    <div style="font-size: 20px; font-weight: bold; color: #8B5CF6;">${this.userStats.missionsCompleted}</div>
                    <div style="font-size: 12px; color: #6B7280;">ماموریت</div>
                </div>
            </div>
            
            <div style="margin-bottom: 15px;">
                <h5 style="margin: 0 0 10px 0; color: #374151; font-size: 14px;">مدال‌ها:</h5>
                <div style="display: flex; flex-wrap: wrap; gap: 8px;">
                    ${this.badges.map(badge => `
                        <div style="
                            background: ${this.userStats.badges.includes(badge.id) ? '#ECFDF5' : '#F9FAFB'};
                            border: 1px solid ${this.userStats.badges.includes(badge.id) ? '#10B981' : '#E5E7EB'};
                            padding: 8px;
                            border-radius: 8px;
                            text-align: center;
                            flex: 1;
                            min-width: 70px;
                            opacity: ${this.userStats.badges.includes(badge.id) ? '1' : '0.5'};
                        ">
                            <div style="font-size: 20px; margin-bottom: 5px;">${badge.icon}</div>
                            <div style="font-size: 11px; color: #6B7280;">${badge.name}</div>
                        </div>
                    `).join('')}
                </div>
            </div>
            
            <button onclick="gameEngine.showAchievements()" style="
                width: 100%;
                background: #4F46E5;
                color: white;
                border: none;
                padding: 10px;
                border-radius: 8px;
                cursor: pointer;
                font-family: 'Vazirmatn', sans-serif;
                font-weight: 600;
            ">
                مشاهده تمام دستاوردها
            </button>
        `;
    }
    
    createMissionsPanel() {
        const missionsPanel = document.createElement('div');
        missionsPanel.id = 'gamification-missions-panel';
        missionsPanel.style.cssText = `
            position: absolute;
            bottom: 80px;
            left: 20px;
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            padding: 15px;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.15);
            z-index: 1000;
            width: 300px;
            font-family: 'Vazirmatn', sans-serif;
            border: 2px solid #10B981;
        `;
        
        this.updateMissionsPanel(missionsPanel);
        document.getElementById('smart-map')?.parentElement?.appendChild(missionsPanel);
    }
    
    updateMissionsPanel(panel) {
        if (!panel) return;
        
        const activeMissions = this.currentMissions.filter(m => !m.completed);
        
        panel.innerHTML = `
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 15px;">
                <h4 style="margin: 0; color: #1F2937; display: flex; align-items: center; gap: 8px;">
                    🎯 مأموریت‌های فعال
                </h4>
                <span style="font-size: 12px; color: #6B7280;">${activeMissions.length}/${this.currentMissions.length}</span>
            </div>
            
            ${activeMissions.length > 0 ? activeMissions.map(mission => `
                <div class="mission-item" style="
                    background: #F9FAFB;
                    padding: 12px;
                    border-radius: 10px;
                    margin-bottom: 10px;
                    border: 1px solid #E5E7EB;
                ">
                    <div style="display: flex; justify-content: space-between; align-items: start; margin-bottom: 8px;">
                        <div style="font-weight: 600; color: #374151;">${mission.title}</div>
                        <div style="font-size: 12px; color: #6B7280;">${mission.progress}/${mission.target}</div>
                    </div>
                    
                    <div style="font-size: 12px; color: #6B7280; margin-bottom: 8px;">
                        ${mission.description}
                    </div>
                    
                    <div style="background: #E5E7EB; height: 6px; border-radius: 3px; overflow: hidden;">
                        <div style="
                            background: linear-gradient(90deg, #10B981, #34D399);
                            height: 100%;
                            width: ${(mission.progress / mission.target) * 100}%;
                            border-radius: 3px;
                        "></div>
                    </div>
                    
                    <div style="display: flex; justify-content: space-between; margin-top: 8px; font-size: 11px;">
                        <span style="color: #059669;">جایزه: ${mission.reward.points} امتیاز</span>
                        ${mission.reward.badge ? `<span style="color: #8B5CF6;">+ مدال</span>` : ''}
                    </div>
                </div>
            `).join('') : `
                <div style="text-align: center; padding: 20px; color: #9CA3AF;">
                    🎉 همه مأموریت‌ها تکمیل شدند!
                </div>
            `}
            
            <button onclick="gameEngine.showAllMissions()" style="
                width: 100%;
                background: #10B981;
                color: white;
                border: none;
                padding: 10px;
                border-radius: 8px;
                cursor: pointer;
                font-family: 'Vazirmatn', sans-serif;
                font-weight: 600;
                margin-top: 10px;
            ">
                مشاهده همه مأموریت‌ها
            </button>
        `;
    }
    
    addHiddenGemsToMap() {
        if (!this.smartMap || !this.smartMap.map) return;
        
        this.hiddenGems.forEach(gem => {
            if (!gem.discovered) {
                const el = document.createElement('div');
                el.className = 'hidden-gem-marker';
                el.innerHTML = '💎';
                el.style.cssText = `
                    font-size: 24px;
                    cursor: pointer;
                    animation: pulse 2s infinite, float 3s ease-in-out infinite;
                    filter: drop-shadow(0 0 8px rgba(245, 158, 11, 0.5));
                `;
                el.title = 'گنجینه مخفی - کلیک کنید';
                
                el.addEventListener('click', () => this.discoverHiddenGem(gem.id));
                
                const marker = new mapboxgl.Marker(el)
                    .setLngLat(gem.coordinates)
                    .setPopup(new mapboxgl.Popup().setHTML(`
                        <div style="padding: 10px; font-family: 'Vazirmatn', sans-serif; max-width: 250px;">
                            <h4 style="margin: 0 0 10px 0; color: #D97706;">${gem.name}</h4>
                            <p style="margin: 0 0 10px 0; color: #6B7280; font-size: 14px;">
                                <strong>سرنخ:</strong> ${gem.clue}
                            </p>
                            <p style="margin: 0 0 15px 0; color: #6B7280; font-size: 14px;">
                                ${gem.description}
                            </p>
                            <button onclick="gameEngine.discoverHiddenGem('${gem.id}')" style="
                                background: linear-gradient(135deg, #F59E0B, #D97706);
                                color: white;
                                border: none;
                                padding: 8px 16px;
                                border-radius: 6px;
                                cursor: pointer;
                                font-family: 'Vazirmatn', sans-serif;
                                font-weight: 600;
                                width: 100%;
                            ">
                                کشف کن! 🔍
                            </button>
                        </div>
                    `))
                    .addTo(this.smartMap.map);
                
                gem.marker = marker;
            }
        });
    }
    
    discoverHiddenGem(gemId) {
        const gem = this.hiddenGems.find(g => g.id === gemId);
        if (!gem || gem.discovered) return;
        
        gem.discovered = true;
        gem.marker?.remove();
        
        // اضافه کردن امتیاز
        this.addPoints(gem.reward.points);
        
        // آپدیت مأموریت
        this.updateMissionProgress('find_hidden_gems', 1);
        
        // آپدیت آمار
        this.userStats.discoveries.push(gemId);
        this.saveUserStats();
        
        // نمایش انیمیشن
        this.showDiscoveryAnimation(gem);
        
        console.log(`✅ گنجینه کشف شد: ${gem.name}`);
    }
    
    showDiscoveryAnimation(gem) {
        // ایجاد انیمیشن کشف
        const animationDiv = document.createElement('div');
        animationDiv.style.cssText = `
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            z-index: 9999;
            text-align: center;
        `;
        
        animationDiv.innerHTML = `
            <div style="
                background: rgba(0, 0, 0, 0.8);
                color: white;
                padding: 30px 40px;
                border-radius: 20px;
                backdrop-filter: blur(10px);
                animation: popIn 0.5s ease;
                max-width: 400px;
            ">
                <div style="font-size: 48px; margin-bottom: 20px;">🎉</div>
                <h3 style="margin: 0 0 10px 0; color: #FBBF24;">گنجینه کشف شد!</h3>
                <h4 style="margin: 0 0 15px 0;">${gem.name}</h4>
                <p style="margin: 0 0 20px 0; opacity: 0.9;">${gem.description}</p>
                <div style="
                    background: rgba(245, 158, 11, 0.2);
                    padding: 15px;
                    border-radius: 10px;
                    margin-bottom: 20px;
                ">
                    <div style="font-size: 24px; font-weight: bold; color: #FBBF24;">
                        +${gem.reward.points} امتیاز
                    </div>
                    <div style="font-size: 14px; opacity: 0.8;">به دستاوردهای شما اضافه شد</div>
                </div>
                <button onclick="this.parentElement.parentElement.remove()" style="
                    background: #F59E0B;
                    color: white;
                    border: none;
                    padding: 12px 30px;
                    border-radius: 25px;
                    cursor: pointer;
                    font-family: 'Vazirmatn', sans-serif;
                    font-weight: 600;
                ">
                    ادامـه ماجراجویی
                </button>
            </div>
        `;
        
        document.body.appendChild(animationDiv);
        
        // پخش صدا (اختیاری)
        if (typeof Audio !== 'undefined') {
            const audio = new Audio('https://assets.mixkit.co/sfx/preview/mixkit-winning-chimes-2015.mp3');
            audio.volume = 0.3;
            audio.play().catch(e => console.log('Audio play failed:', e));
        }
        
        // حذف خودکار بعد از 5 ثانیه
        setTimeout(() => {
            if (animationDiv.parentElement) {
                animationDiv.remove();
            }
        }, 5000);
    }
    
    setupEasterEggListeners() {
        // Easter Egg: triple-click on map
        document.getElementById('smart-map')?.addEventListener('click', (e) => {
            if (e.detail === 3) {
                this.showSecretMessage();
            }
        });
        
        // Easter Egg: Konami code
        let konamiProgress = [];
        document.addEventListener('keydown', (e) => {
            konamiProgress.push(e.key);
            
            // فقط ۱۰ کلید آخر را نگه دار
            if (konamiProgress.length > 10) {
                konamiProgress.shift();
            }
            
            // بررسی کد
            const easterEgg = this.easterEggs.find(ee => ee.code);
            if (easterEgg && this.arraysEqual(konamiProgress.slice(-10), easterEgg.code)) {
                this.unlockSecretMode();
                konamiProgress = []; // ریست
            }
        });
    }
    
    arraysEqual(a, b) {
        if (a.length !== b.length) return false;
        for (let i = 0; i < a.length; i++) {
            if (a[i] !== b[i]) return false;
        }
        return true;
    }
    
    showSecretMessage() {
        const messages = [
            "🤫 شما یک راز کشف کردید!",
            "🎮 حالا شما یک بازیکن حرفه‌ای هستید!",
            "💎 راز استانبول در دستان شماست...",
            "🔑 این فقط شروع ماجراست!"
        ];
        
        const randomMessage = messages[Math.floor(Math.random() * messages.length)];
        this.showFloatingMessage(randomMessage, '#8B5CF6');
        this.addPoints(50);
    }
    
    unlockSecretMode() {
        this.showFloatingMessage('🎮 حالت مخفی فعال شد!', '#EC4899');
        this.addPoints(100);
        
        // تغییرات ویژه در حالت مخفی
        document.body.style.filter = 'hue-rotate(90deg)';
        setTimeout(() => {
            document.body.style.filter = '';
        }, 5000);
    }
    
    showFloatingMessage(message, color = '#4F46E5') {
        const floatingDiv = document.createElement('div');
        floatingDiv.style.cssText = `
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background: ${color};
            color: white;
            padding: 15px 25px;
            border-radius: 15px;
            z-index: 9999;
            font-family: 'Vazirmatn', sans-serif;
            font-weight: 600;
            box-shadow: 0 10px 30px rgba(0,0,0,0.3);
            animation: floatMessage 2s ease forwards;
        `;
        
        floatingDiv.textContent = message;
        document.body.appendChild(floatingDiv);
        
        // حذف خودکار
        setTimeout(() => {
            floatingDiv.remove();
        }, 2000);
    }
    
    // توابع کمکی
    addPoints(points) {
        const oldPoints = this.userStats.points;
        this.userStats.points += points;
        
        // بررسی ارتقای سطح
        const oldLevel = this.userStats.level;
        this.userStats.level = Math.floor(this.userStats.points / 1000) + 1;
        
        if (this.userStats.level > oldLevel) {
            this.showLevelUpAnimation(oldLevel, this.userStats.level);
        }
        
        this.saveUserStats();
        this.updateStatsPanel(document.getElementById('gamification-stats-panel'));
        
        // نمایش انیمیشن امتیاز
        this.showPointsAnimation(points);
    }
    
    showPointsAnimation(points) {
        const pointsDiv = document.createElement('div');
        pointsDiv.style.cssText = `
            position: fixed;
            bottom: 100px;
            right: 20px;
            background: linear-gradient(135deg, #FBBF24, #F59E0B);
            color: white;
            padding: 10px 20px;
            border-radius: 25px;
            z-index: 9998;
            font-family: 'Vazirmatn', sans-serif;
            font-weight: bold;
            box-shadow: 0 5px 15px rgba(245, 158, 11, 0.3);
            animation: slideInLeft 0.5s ease, slideOutRight 0.5s ease 2s forwards;
        `;
        
        pointsDiv.innerHTML = `+${points} 🏆`;
        document.body.appendChild(pointsDiv);
        
        setTimeout(() => {
            if (pointsDiv.parentElement) {
                pointsDiv.remove();
            }
        }, 2500);
    }
    
    showLevelUpAnimation(oldLevel, newLevel) {
        const levelDiv = document.createElement('div');
        levelDiv.style.cssText = `
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background: linear-gradient(135deg, #8B5CF6, #7C3AED);
            color: white;
            padding: 30px 40px;
            border-radius: 20px;
            z-index: 9999;
            text-align: center;
            font-family: 'Vazirmatn', sans-serif;
            animation: popIn 0.5s ease;
            box-shadow: 0 20px 60px rgba(139, 92, 246, 0.4);
        `;
        
        levelDiv.innerHTML = `
            <div style="font-size: 48px; margin-bottom: 20px;">🎉</div>
            <h2 style="margin: 0 0 10px 0;">تبریک!</h2>
            <p style="margin: 0 0 20px 0; font-size: 18px;">شما ارتقا سطح یافتید</p>
            <div style="
                display: flex;
                justify-content: center;
                align-items: center;
                gap: 20px;
                margin-bottom: 25px;
            ">
                <div style="
                    background: rgba(255,255,255,0.2);
                    padding: 15px;
                    border-radius: 50%;
                    font-size: 24px;
                    font-weight: bold;
                ">
                    ${oldLevel}
                </div>
                <div style="font-size: 24px;">→</div>
                <div style="
                    background: white;
                    color: #8B5CF6;
                    padding: 20px;
                    border-radius: 50%;
                    font-size: 32px;
                    font-weight: bold;
                ">
                    ${newLevel}
                </div>
            </div>
            <button onclick="this.parentElement.parentElement.remove()" style="
                background: white;
                color: #8B5CF6;
                border: none;
                padding: 12px 30px;
                border-radius: 25px;
                cursor: pointer;
                font-family: 'Vazirmatn', sans-serif;
                font-weight: 600;
            ">
                ادامـه ماجراجویی
            </button>
        `;
        
        document.body.appendChild(levelDiv);
        
        // پخش صدا
        if (typeof Audio !== 'undefined') {
            const audio = new Audio('https://assets.mixkit.co/sfx/preview/mixkit-game-level-completed-2059.mp3');
            audio.volume = 0.3;
            audio.play().catch(e => console.log('Audio play failed:', e));
        }
        
        // حذف خودکار
        setTimeout(() => {
            if (levelDiv.parentElement) {
                levelDiv.remove();
            }
        }, 5000);
    }
    
    updateMissionProgress(missionId, increment = 1) {
        const mission = this.currentMissions.find(m => m.id === missionId);
        if (!mission || mission.completed) return;
        
        mission.progress += increment;
        
        if (mission.progress >= mission.target) {
            mission.completed = true;
            mission.progress = mission.target;
            
            // اعطای پاداش
            this.addPoints(mission.reward.points);
            
            if (mission.reward.badge) {
                this.awardBadge(mission.reward.badge);
            }
            
            this.userStats.missionsCompleted++;
            this.saveUserStats();
            
            // نمایش اعلان تکمیل مأموریت
            this.showMissionCompleteNotification(mission);
        }
        
        this.updateMissionsPanel(document.getElementById('gamification-missions-panel'));
        this.saveMissionProgress();
    }
    
    awardBadge(badgeId) {
        if (!this.userStats.badges.includes(badgeId)) {
            this.userStats.badges.push(badgeId);
            this.saveUserStats();
            
            // نمایش انیمیشن مدال
            this.showBadgeAnimation(badgeId);
        }
    }
    
    showBadgeAnimation(badgeId) {
        const badge = this.badges.find(b => b.id === badgeId);
        if (!badge) return;
        
        const badgeDiv = document.createElement('div');
        badgeDiv.style.cssText = `
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background: linear-gradient(135deg, #FBBF24, #F59E0B);
            color: white;
            padding: 25px;
            border-radius: 20px;
            z-index: 9999;
            text-align: center;
            font-family: 'Vazirmatn', sans-serif;
            animation: popIn 0.5s ease;
            box-shadow: 0 20px 60px rgba(245, 158, 11, 0.4);
            width: 300px;
        `;
        
        badgeDiv.innerHTML = `
            <div style="font-size: 48px; margin-bottom: 15px;">${badge.icon}</div>
            <h3 style="margin: 0 0 10px 0; color: white;">مدال جدید!</h3>
            <h4 style="margin: 0 0 15px 0;">${badge.name}</h4>
            <p style="margin: 0 0 20px 0; opacity: 0.9; font-size: 14px;">${badge.description}</p>
            <button onclick="this.parentElement.parentElement.remove()" style="
                background: white;
                color: #F59E0B;
                border: none;
                padding: 10px 25px;
                border-radius: 20px;
                cursor: pointer;
                font-family: 'Vazirmatn', sans-serif;
                font-weight: 600;
            ">
                باشه!
            </button>
        `;
        
        document.body.appendChild(badgeDiv);
        
        setTimeout(() => {
            if (badgeDiv.parentElement) {
                badgeDiv.remove();
            }
        }, 4000);
    }
    
    showMissionCompleteNotification(mission) {
        const notificationDiv = document.createElement('div');
        notificationDiv.style.cssText = `
            position: fixed;
            bottom: 20px;
            right: 20px;
            background: linear-gradient(135deg, #10B981, #059669);
            color: white;
            padding: 15px 20px;
            border-radius: 15px;
            z-index: 9997;
            font-family: 'Vazirmatn', sans-serif;
            box-shadow: 0 10px 30px rgba(16, 185, 129, 0.3);
            animation: slideInLeft 0.5s ease;
            max-width: 300px;
        `;
        
        notificationDiv.innerHTML = `
            <div style="display: flex; align-items: center; gap: 10px; margin-bottom: 10px;">
                <div style="font-size: 24px;">🎯</div>
                <div style="font-weight: bold; font-size: 16px;">ماموریت تکمیل شد!</div>
            </div>
            <div style="font-size: 14px; opacity: 0.9; margin-bottom: 10px;">
                ${mission.title}
            </div>
            <div style="display: flex; justify-content: space-between; align-items: center; font-size: 12px;">
                <span>+${mission.reward.points} امتیاز</span>
                <button onclick="this.parentElement.parentElement.remove()" style="
                    background: rgba(255,255,255,0.2);
                    color: white;
                    border: none;
                    padding: 5px 15px;
                    border-radius: 12px;
                    cursor: pointer;
                    font-family: 'Vazirmatn', sans-serif;
                ">
                    بستن
                </button>
            </div>
        `;
        
        document.body.appendChild(notificationDiv);
        
        setTimeout(() => {
            if (notificationDiv.parentElement) {
                notificationDiv.remove();
            }
        }, 5000);
    }
    
    loadMissionProgress() {
        try {
            const saved = localStorage.getItem('istanbul_missions_progress');
            if (saved) {
                const progress = JSON.parse(saved);
                this.currentMissions = progress;
            }
        } catch (e) {
            console.error('خطا در بارگیری پیشرفت مأموریت‌ها:', e);
        }
    }
    
    saveMissionProgress() {
        try {
            localStorage.setItem('istanbul_missions_progress', JSON.stringify(this.currentMissions));
        } catch (e) {
            console.error('خطا در ذخیره پیشرفت مأموریت‌ها:', e);
        }
    }
    
    loadHiddenGemsProgress() {
        try {
            const saved = localStorage.getItem('istanbul_hidden_gems');
            if (saved) {
                const gems = JSON.parse(saved);
                this.hiddenGems = gems;
            }
        } catch (e) {
            console.error('خطا در بارگیری گنجینه‌ها:', e);
        }
    }
    
    saveHiddenGemsProgress() {
        try {
            localStorage.setItem('istanbul_hidden_gems', JSON.stringify(this.hiddenGems));
        } catch (e) {
            console.error('خطا در ذخیره گنجینه‌ها:', e);
        }
    }
    
    // توابع عمومی برای استفاده خارجی
    recordDistrictVisit(districtId) {
        if (!this.userStats.districtsVisited.has(districtId)) {
            this.userStats.districtsVisited.add(districtId);
            this.addPoints(25);
            
            // آپدیت مأموریت
            this.updateMissionProgress('explore_3_districts', 1);
            
            this.saveUserStats();
        }
    }
    
    recordRouteCreation(stopCount) {
        if (stopCount >= 3) {
            this.updateMissionProgress('create_route', 1);
        }
    }
    
    recordFilterUse(filterId) {
        this.updateMissionProgress('use_filters', 1);
    }
    
    showAchievements() {
        alert('صفحه دستاوردها به زودی اضافه خواهد شد!');
    }
    
    showAllMissions() {
        alert('صفحه همه مأموریت‌ها به زودی اضافه خواهد شد!');
    }
}

// اضافه کردن استایل‌های انیمیشن
const gamificationStyles = document.createElement('style');
gamificationStyles.textContent = `
    @keyframes floatMessage {
        0% { transform: translate(-50%, -50%) scale(0.8); opacity: 0; }
        20% { transform: translate(-50%, -60%) scale(1); opacity: 1; }
        80% { transform: translate(-50%, -60%) scale(1); opacity: 1; }
        100% { transform: translate(-50%, -80%) scale(0.8); opacity: 0; }
    }
    
    @keyframes slideInLeft {
        from { transform: translateX(100%); opacity: 0; }
        to { transform: translateX(0); opacity: 1; }
    }
    
    @keyframes slideOutRight {
        from { transform: translateX(0); opacity: 1; }
        to { transform: translateX(100%); opacity: 0; }
    }
    
    .hidden-gem-marker {
        animation: pulse 2s infinite, float 3s ease-in-out infinite !important;
    }
    
    @keyframes pulse {
        0% { transform: scale(1); opacity: 0.7; }
        50% { transform: scale(1.1); opacity: 1; }
        100% { transform: scale(1); opacity: 0.7; }
    }
    
    @keyframes float {
        0%, 100% { transform: translateY(0); }
        50% { transform: translateY(-10px); }
    }
`;
document.head.appendChild(gamificationStyles);

// راه‌اندازی سیستم گیمیفیکیشن
document.addEventListener('DOMContentLoaded', () => {
    if (window.smartMap) {
        window.gameEngine = new GamificationEngine(window.smartMap);
        
        // اضافه کردن توابع به smartMap برای ردیابی فعالیت‌ها
        smartMap.showDistrictCard = function(district, coordinates) {
            // فراخوانی تابع اصلی
            const originalShowCard = SmartMap.prototype.showDistrictCard;
            originalShowCard.call(this, district, coordinates);
            
            // ردیابی بازدید از محله
            if (window.gameEngine) {
                window.gameEngine.recordDistrictVisit(district.id);
            }
        };
        
        // ردیابی ایجاد مسیر
        if (window.smartRouting) {
            const originalAddToRoute = smartRouting.addDistrictToRoute;
            smartRouting.addDistrictToRoute = function(districtId) {
                originalAddToRoute.call(this, districtId);
                
                if (window.gameEngine) {
                    window.gameEngine.recordRouteCreation(this.currentRoute.length);
                }
            };
        }
        
        // ردیابی استفاده از فیلترها
        if (window.smartFilters) {
            const originalToggleFilter = smartFilters.toggleFilter;
            smartFilters.toggleFilter = function(filterId) {
                originalToggleFilter.call(this, filterId);
                
                if (window.gameEngine && !this.activeFilters.has(filterId)) {
                    window.gameEngine.recordFilterUse(filterId);
                }
            };
        }
    }
});
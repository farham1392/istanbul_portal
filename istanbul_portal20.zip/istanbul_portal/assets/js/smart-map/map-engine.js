// assets/js/smart-map/map-engine.js
/**
 * موتور اصلی نقشه هوشمند استانبول
 * استفاده از Mapbox GL JS
 */

class SmartMap {
    constructor() {
        this.map = null;
        this.districts = [];
        this.currentFilters = new Set();
        this.userPreferences = {
            budget: 'medium',
            interests: [],
            timeAvailable: 4,
            travelType: 'solo'
        };
        this.hiddenGems = [];
        this.activeRoute = null;
        this.missions = [];
        this.routeLayerId = 'route-line';
        this.districtsLayerId = 'districts-layer';
        this.markersLayerId = 'points-layer';
        
        // توکن Mapbox (در فایل config باید قرار گیرد)
        this.mapboxToken = 'pk.eyJ1IjoiZmFyaGFtemFtYW5pIiwiYSI6ImNsdHdkaHd1czB6cjcya3A5bGRyNWt2dTQifQ.0p93fLulCKX_s7YbPHw7Cg';
    }
    
    init() {
        if (!this.mapboxToken) {
            console.error('Mapbox token is required');
            return;
        }
        
        mapboxgl.accessToken = this.mapboxToken;
        
        // ایجاد نقشه
        this.map = new mapboxgl.Map({
            container: 'smart-map',
            style: 'mapbox://styles/mapbox/streets-v11',
            center: [28.9784, 41.0082], // استانبول
            zoom: 12,
            pitch: 45,
            bearing: -17.6,
            antialias: true
        });
        
        // بارگذاری نقشه
        this.map.on('load', () => {
            this.loadDistrictsData();
            this.setupLayers();
            this.setupInteractions();
            this.addBaseControls();
            this.setupSmartFilters();
            this.setupGamification();
            
            console.log('🗺️ نقشه هوشمند استانبول بارگذاری شد');
        });
        
        // مدیریت خطاها
        this.map.on('error', (e) => {
            console.error('Map error:', e.error);
        });
    }
    
    loadDistrictsData() {
        // داده‌های محله‌ها (می‌توان از API یا فایل JSON بارگیری کرد)
        this.districts = [
            {
                id: 'sultanahmet',
                name: 'سلطان احمد',
                name_en: 'Sultanahmet',
                color: '#FBBF24',
                mood: 'تاریخی',
                icon: '🏛️',
                description: 'قلب تاریخی استانبول با بناهای بی‌نظیر',
                suitableFor: ['تاریخی', 'عکاسی', 'فرهنگی', 'خانوادگی'],
                topPlaces: ['ایاصوفیه', 'کاخ توپکاپی', 'مسجد آبی', 'میدان اسب‌دوانی'],
                famousFood: 'کباب ترکی با نان پیتا',
                categories: ['historical', 'free', 'family', 'photography'],
                budget: 'low',
                vibeScore: 9,
                coordinates: [
                    [28.972, 41.005],
                    [28.980, 41.005],
                    [28.980, 41.012],
                    [28.972, 41.012]
                ],
                center: [28.976, 41.0085],
                timeRecommendation: {
                    morning: 'بهترین زمان برای بازدید از موزه‌ها',
                    afternoon: 'پیاده‌روی در پارک‌های تاریخی',
                    evening: 'تماشای غروب در میدان اسب‌دوانی',
                    night: 'نورپردازی شگفت‌انگیز بناها'
                },
                bestSeason: 'بهار و پاییز',
                crowdLevel: 'high',
                walkingScore: 10
            },
            {
                id: 'beyoglu',
                name: 'بی‌اوغلو',
                name_en: 'Beyoglu',
                color: '#3B82F6',
                mood: 'مدرن',
                icon: '🏙️',
                description: 'شهر مدرن استانبول با برج‌ها و مراکز خرید',
                suitableFor: ['خرید', 'شب‌زنده‌داری', 'کافه', 'هنر'],
                topPlaces: ['برج گالاتا', 'خیابان استقلال', 'میدان تکسیم', 'مرکز خرید زورلو'],
                famousFood: 'سیب‌زمینی گوشت‌دار (Kumpir)',
                categories: ['shopping', 'food', 'nightlife', 'art'],
                budget: 'medium',
                vibeScore: 8,
                coordinates: [
                    [28.970, 41.025],
                    [28.985, 41.025],
                    [28.985, 41.035],
                    [28.970, 41.035]
                ],
                center: [28.9775, 41.03],
                timeRecommendation: {
                    morning: 'صبحانه در کافه‌های دنج',
                    afternoon: 'خرید در خیابان استقلال',
                    evening: 'نمایشگاه‌های هنری',
                    night: 'زندگی شبانه در میدان تکسیم'
                },
                bestSeason: 'همه‌فصل',
                crowdLevel: 'high',
                walkingScore: 8
            },
            {
                id: 'balat',
                name: 'بالات',
                name_en: 'Balat',
                color: '#8B5CF6',
                mood: 'هنری',
                icon: '🎨',
                description: 'محله‌ای رنگارنگ با خانه‌های تاریخی و کافه‌های خلاق',
                suitableFor: ['عکاسی', 'کافه', 'هنر', 'آرامش'],
                topPlaces: ['خانه‌های رنگارنگ', 'کلیسای بلغاری', 'کافه‌های محلی', 'فروشگاه‌های دست‌ساز'],
                famousFood: 'چای ترکی با شیرینی محلی',
                categories: ['art', 'photography', 'cafe', 'relax'],
                budget: 'low',
                vibeScore: 7,
                coordinates: [
                    [28.945, 41.029],
                    [28.955, 41.029],
                    [28.955, 41.035],
                    [28.945, 41.035]
                ],
                center: [28.95, 41.032],
                timeRecommendation: {
                    morning: 'عکاسی از خانه‌های رنگارنگ',
                    afternoon: 'چای در کافه‌های دنج',
                    evening: 'پیاده‌روی در کوچه‌های سنگ‌فرش',
                    night: 'آرام و دنج'
                },
                bestSeason: 'بهار',
                crowdLevel: 'medium',
                walkingScore: 9
            },
            {
                id: 'kadikoy',
                name: 'کادیکوی',
                name_en: 'Kadikoy',
                color: '#10B981',
                mood: 'محلی',
                icon: '🏘️',
                description: 'سمت آسیایی استانبول با بازارهای محلی و غذاخوری‌های معروف',
                suitableFor: ['غذا', 'بازار', 'محلی', 'خانوادگی'],
                topPlaces: ['بازار کادیکوی', 'ساحل مودا', 'خیابان غذا', 'پارک فانبره'],
                famousFood: 'صبحانه ترکی کامل',
                categories: ['food', 'local', 'family', 'market'],
                budget: 'low',
                vibeScore: 8,
                coordinates: [
                    [29.010, 40.985],
                    [29.040, 40.985],
                    [29.040, 41.005],
                    [29.010, 41.005]
                ],
                center: [29.025, 40.995],
                timeRecommendation: {
                    morning: 'صبحانه ترکی در کافه‌های ساحلی',
                    afternoon: 'گشت‌وگذار در بازار',
                    evening: 'غذای دریایی تازه',
                    night: 'پیاده‌روی در ساحل'
                },
                bestSeason: 'تابستان',
                crowdLevel: 'medium',
                walkingScore: 7
            },
            {
                id: 'uskudar',
                name: 'اسکودار',
                name_en: 'Uskudar',
                color: '#EC4899',
                mood: 'آرام',
                icon: '🕌',
                description: 'منطقه‌ای آرام با مناظر زیبا از تنگه بسفر',
                suitableFor: ['طبیعت', 'آرامش', 'تاریخی', 'خانوادگی'],
                topPlaces: ['برج دختر', 'مسجد شکرچی', 'پارک فتحی‌پاشا', 'اسکله اسکودار'],
                famousFood: 'کوفته اسکودار',
                categories: ['nature', 'relax', 'historical', 'family'],
                budget: 'low',
                vibeScore: 6,
                coordinates: [
                    [29.015, 41.015],
                    [29.035, 41.015],
                    [29.035, 41.030],
                    [29.015, 41.030]
                ],
                center: [29.025, 41.0225],
                timeRecommendation: {
                    morning: 'تماشای طلوع آفتاب از برج دختر',
                    afternoon: 'پیاده‌روی در پارک',
                    evening: 'عکاسی از مناظر بسفر',
                    night: 'آرام و رویایی'
                },
                bestSeason: 'بهار و تابستان',
                crowdLevel: 'low',
                walkingScore: 8
            }
        ];
        
        console.log('✅ داده‌های محله‌ها بارگذاری شد:', this.districts.length, 'محله');
    }
    
    setupLayers() {
        // اضافه کردن لایه محله‌ها
        this.map.addSource('districts', {
            'type': 'geojson',
            'data': {
                'type': 'FeatureCollection',
                'features': this.districts.map(district => ({
                    'type': 'Feature',
                    'properties': {
                        'id': district.id,
                        'name': district.name,
                        'color': district.color,
                        'mood': district.mood,
                        'categories': district.categories
                    },
                    'geometry': {
                        'type': 'Polygon',
                        'coordinates': [district.coordinates]
                    }
                }))
            }
        });
        
        this.map.addLayer({
            'id': this.districtsLayerId,
            'type': 'fill',
            'source': 'districts',
            'paint': {
                'fill-color': ['get', 'color'],
                'fill-opacity': 0.6,
                'fill-outline-color': '#ffffff'
            }
        });
        
        // اضافه کردن لایه حاشیه محله‌ها
        this.map.addLayer({
            'id': 'districts-outline',
            'type': 'line',
            'source': 'districts',
            'paint': {
                'line-color': '#ffffff',
                'line-width': 2,
                'line-opacity': 0.8
            }
        });
        
        // اضافه کردن لایه برچسب محله‌ها
        this.map.addLayer({
            'id': 'districts-labels',
            'type': 'symbol',
            'source': 'districts',
            'layout': {
                'text-field': ['get', 'name'],
                'text-font': ['Vazirmatn Regular', 'Arial Unicode MS Regular'],
                'text-size': 14,
                'text-allow-overlap': false
            },
            'paint': {
                'text-color': '#ffffff',
                'text-halo-color': '#000000',
                'text-halo-width': 2
            }
        });
        
        console.log('✅ لایه‌های نقشه تنظیم شدند');
    }
    
    setupInteractions() {
        // کلیک روی محله‌ها
        this.map.on('click', this.districtsLayerId, (e) => {
            const feature = e.features[0];
            if (feature) {
                const districtId = feature.properties.id;
                const district = this.getDistrictById(districtId);
                if (district) {
                    this.showDistrictCard(district, e.lngLat);
                    
                    // حرکت دوربین به مرکز محله
                    this.map.flyTo({
                        center: district.center,
                        zoom: 14,
                        duration: 1000
                    });
                }
            }
        });
        
        // hover effect
        this.map.on('mouseenter', this.districtsLayerId, () => {
            this.map.getCanvas().style.cursor = 'pointer';
        });
        
        this.map.on('mouseleave', this.districtsLayerId, () => {
            this.map.getCanvas().style.cursor = '';
        });
        
        // hover highlight
        this.map.on('mouseenter', this.districtsLayerId, (e) => {
            this.map.setPaintProperty(this.districtsLayerId, 'fill-opacity', 0.8);
        });
        
        this.map.on('mouseleave', this.districtsLayerId, () => {
            this.map.setPaintProperty(this.districtsLayerId, 'fill-opacity', 0.6);
        });
        
        console.log('✅ تعاملات نقشه تنظیم شدند');
    }
    
    getDistrictById(id) {
        return this.districts.find(d => d.id === id);
    }
    
    showDistrictCard(district, coordinates) {
        // ایجاد HTML کارت
        const cardHTML = this.createDistrictCardHTML(district);
        
        // حذف پاپ‌آپ قبلی
        const existingPopup = document.querySelector('.mapboxgl-popup');
        if (existingPopup) {
            existingPopup.remove();
        }
        
        // ایجاد پاپ‌آپ جدید
        const popup = new mapboxgl.Popup({
            closeButton: true,
            closeOnClick: false,
            anchor: 'left',
            offset: 25,
            maxWidth: '350px'
        })
        .setLngLat(coordinates)
        .setHTML(cardHTML)
        .addTo(this.map);
        
        // اضافه کردن event listener به دکمه‌ها
        setTimeout(() => {
            const card = document.querySelector('.district-card');
            if (card) {
                card.querySelector('.btn-add-route')?.addEventListener('click', () => {
                    this.addToRoute(district.id);
                    popup.remove();
                });
                
                card.querySelector('.btn-ask-ai')?.addEventListener('click', () => {
                    this.askAIAboutDistrict(district.id);
                });
                
                card.querySelector('.btn-save')?.addEventListener('click', () => {
                    this.saveDistrict(district.id);
                    this.showNotification(`${district.name} ذخیره شد!`, 'success');
                });
            }
        }, 100);
    }
    
    createDistrictCardHTML(district) {
        const vibeDots = '●'.repeat(district.vibeScore) + '○'.repeat(10 - district.vibeScore);
        const timeOfDay = this.getTimeOfDay();
        const smartTip = this.generateSmartTip(district, timeOfDay);
        
        return `
            <div class="district-card">
                <div class="card-header" style="background: ${district.color}">
                    <div class="district-icon">${district.icon}</div>
                    <div>
                        <h3>${district.name}</h3>
                        <p style="margin: 0; font-size: 12px; opacity: 0.9;">${district.description}</p>
                    </div>
                    <span class="district-mood">${district.mood}</span>
                </div>
                
                <div class="card-body">
                    <div class="vibe-meter">
                        <span>حس و حال:</span>
                        <div class="vibe-dots">
                            <span class="filled">${vibeDots.substring(0, district.vibeScore)}</span>
                            <span class="empty">${vibeDots.substring(district.vibeScore)}</span>
                        </div>
                    </div>
                    
                    <div class="suitable-for">
                        <strong>مناسب برای:</strong>
                        ${district.suitableFor.map(item => 
                            `<span class="suitable-tag">${item}</span>`
                        ).join('')}
                    </div>
                    
                    <div class="highlights">
                        <h4>🏆 نقاط برتر:</h4>
                        <ul>
                            ${district.topPlaces.map(place => `<li>${place}</li>`).join('')}
                        </ul>
                    </div>
                    
                    <div class="famous-food">
                        <h4>🍴 غذای معروف:</h4>
                        <p>${district.famousFood}</p>
                    </div>
                    
                    <div class="smart-tip">
                        <h4>💡 پیشنهاد هوشمند:</h4>
                        <p>${smartTip}</p>
                    </div>
                    
                    <div class="card-actions">
                        <button class="btn-add-route">🗺️ افزودن به مسیر</button>
                        <button class="btn-ask-ai">🤖 از راهنما بپرس</button>
                        <button class="btn-save">💾 ذخیره</button>
                    </div>
                </div>
            </div>
        `;
    }
    
    getTimeOfDay() {
        const hour = new Date().getHours();
        if (hour < 12) return 'morning';
        if (hour < 17) return 'afternoon';
        if (hour < 21) return 'evening';
        return 'night';
    }
    
    generateSmartTip(district, timeOfDay) {
        const tips = {
            morning: [
                `صبح‌ها ${district.name} کمتر شلوغ است`,
                `بهترین زمان برای عکاسی در ${district.name}`,
                `صبحانه‌های محلی ${district.name} را از دست ندهید`
            ],
            afternoon: [
                `بازارهای ${district.name} در بعدازظهر پررونق‌ترند`,
                `برای فرار از گرما به کافه‌های ${district.name} بروید`,
                `تورهای راهنمای محلی ${district.name} در این زمان فعال‌ترند`
            ],
            evening: [
                `غروب ${district.name} منظره‌ای فراموش‌نشدنی دارد`,
                `شام در رستوران‌های سنتی ${district.name} تجربه‌ای خاص است`,
                `نورپردازی بناهای ${district.name} در شب تماشایی است`
            ],
            night: [
                `زندگی شبانه ${district.name} برای ماجراجویان`,
                `پیاده‌روی شبانه در ${district.name} امن و دلپذیر است`,
                `کافه‌های دنج ${district.name} برای استراحت شبانه`
            ]
        };
        
        const randomTip = tips[timeOfDay][Math.floor(Math.random() * tips[timeOfDay].length)];
        return randomTip || district.timeRecommendation[timeOfDay] || 'لحظه‌ای درنگ کنید و از حس این مکان لذت ببرید';
    }
    
    addBaseControls() {
        // اضافه کردن کنترل‌های ناوبری
        this.map.addControl(new mapboxgl.NavigationControl(), 'top-right');
        
        // اضافه کردن کنترل مقیاس
        this.map.addControl(new mapboxgl.ScaleControl({
            maxWidth: 100,
            unit: 'metric'
        }), 'bottom-left');
        
        // کنترل‌های سفارشی
        const customControls = document.createElement('div');
        customControls.className = 'map-controls';
        customControls.innerHTML = `
            <button class="map-control-btn" id="locate-me" title="موقعیت من">📍</button>
            <button class="map-control-btn" id="reset-view" title="بازنشانی نقشه">🏠</button>
            <button class="map-control-btn" id="toggle-3d" title="تغییر نمای ۳D">🏔️</button>
            <button class="map-control-btn" id="share-map" title="اشتراک‌گذاری">📤</button>
        `;
        
        this.map.getContainer().appendChild(customControls);
        
        // اضافه کردن event listeners
        document.getElementById('locate-me').addEventListener('click', () => this.locateUser());
        document.getElementById('reset-view').addEventListener('click', () => this.resetView());
        document.getElementById('toggle-3d').addEventListener('click', () => this.toggle3D());
        document.getElementById('share-map').addEventListener('click', () => this.shareMap());
        
        console.log('✅ کنترل‌های نقشه اضافه شدند');
    }
    
    locateUser() {
        if ('geolocation' in navigator) {
            navigator.geolocation.getCurrentPosition(
                (position) => {
                    const { longitude, latitude } = position.coords;
                    this.map.flyTo({
                        center: [longitude, latitude],
                        zoom: 14,
                        duration: 1500
                    });
                    
                    // اضافه کردن مارکر موقعیت کاربر
                    new mapboxgl.Marker({
                        color: '#3B82F6',
                        scale: 0.8
                    })
                    .setLngLat([longitude, latitude])
                    .setPopup(new mapboxgl.Popup().setHTML('<strong>موقعیت شما</strong>'))
                    .addTo(this.map);
                    
                    this.showNotification('موقعیت شما روی نقشه مشخص شد', 'info');
                },
                (error) => {
                    console.error('Geolocation error:', error);
                    this.showNotification('دسترسی به موقعیت امکان‌پذیر نیست', 'error');
                }
            );
        } else {
            this.showNotification('مرورگر شما از موقعیت‌یابی پشتیبانی نمی‌کند', 'error');
        }
    }
    
    resetView() {
        this.map.flyTo({
            center: [28.9784, 41.0082],
            zoom: 12,
            pitch: 45,
            bearing: -17.6,
            duration: 1000
        });
    }
    
    toggle3D() {
        const currentPitch = this.map.getPitch();
        const newPitch = currentPitch === 0 ? 60 : 0;
        
        this.map.easeTo({
            pitch: newPitch,
            duration: 1000
        });
    }
    
    shareMap() {
        const center = this.map.getCenter();
        const zoom = this.map.getZoom();
        const pitch = this.map.getPitch();
        const bearing = this.map.getBearing();
        
        const shareUrl = `${window.location.origin}${window.location.pathname}?map=${center.lng.toFixed(4)},${center.lat.toFixed(4)},${zoom.toFixed(2)},${pitch.toFixed(2)},${bearing.toFixed(2)}`;
        
        if (navigator.share) {
            navigator.share({
                title: 'نقشه هوشمند استانبول',
                text: 'به نقشه هوشمند استانبول نگاه کنید!',
                url: shareUrl
            });
        } else {
            navigator.clipboard.writeText(shareUrl).then(() => {
                this.showNotification('لینک نقشه در حافظه کلیپ‌برد کپی شد', 'success');
            });
        }
    }
    
    setupSmartFilters() {
        const filters = [
            { id: 'historical', label: 'تاریخی', icon: '🏛️' },
            { id: 'food', label: 'غذا', icon: '🍴' },
            { id: 'nature', label: 'طبیعت', icon: '🌳' },
            { id: 'shopping', label: 'خرید', icon: '🛍️' },
            { id: 'free', label: 'رایگان', icon: '🆓' },
            { id: 'family', label: 'خانوادگی', icon: '👨‍👩‍👧‍👦' },
            { id: 'photography', label: 'عکاسی', icon: '📸' },
            { id: 'art', label: 'هنر', icon: '🎨' },
            { id: 'nightlife', label: 'شب‌زنده‌داری', icon: '🌙' },
            { id: 'cafe', label: 'کافه', icon: '☕' }
        ];
        
        const container = document.getElementById('smart-filters');
        if (!container) {
            console.warn('Container #smart-filters not found');
            return;
        }
        
        filters.forEach(filter => {
            const button = document.createElement('button');
            button.className = 'filter-btn';
            button.innerHTML = `${filter.icon} ${filter.label}`;
            button.dataset.filter = filter.id;
            
            button.addEventListener('click', () => {
                button.classList.toggle('active');
                this.toggleFilter(filter.id);
            });
            
            container.appendChild(button);
        });
        
        console.log('✅ فیلترهای هوشمند تنظیم شدند');
    }
    
    toggleFilter(filterId) {
        if (this.currentFilters.has(filterId)) {
            this.currentFilters.delete(filterId);
        } else {
            this.currentFilters.add(filterId);
        }
        
        this.applyFilters();
    }
    
    applyFilters() {
        if (this.currentFilters.size === 0) {
            // نمایش همه محله‌ها
            this.map.setFilter(this.districtsLayerId, null);
            this.map.setPaintProperty(this.districtsLayerId, 'fill-opacity', 0.6);
        } else {
            // فیلتر کردن بر اساس دسته‌بندی
            const filterConditions = ['any'];
            this.currentFilters.forEach(filterId => {
                filterConditions.push(['in', filterId, ['get', 'categories']]);
            });
            
            this.map.setFilter(this.districtsLayerId, filterConditions);
            this.map.setPaintProperty(this.districtsLayerId, 'fill-opacity', [
                'case',
                ['==', ['feature-state', 'hovered'], true],
                0.8,
                0.6
            ]);
        }
        
        // آپدیت تعداد فیلترهای فعال
        this.updateActiveFiltersCount();
    }
    
    updateActiveFiltersCount() {
        const countElement = document.getElementById('active-filters-count');
        if (countElement) {
            countElement.textContent = this.currentFilters.size;
            countElement.style.display = this.currentFilters.size > 0 ? 'inline' : 'none';
        }
    }
    
    setupGamification() {
        this.hiddenGems = [
            {
                id: 'hidden-cafe-balat',
                name: 'کافه مخفی بالات',
                coordinates: [28.9490, 41.0310],
                clue: 'پشت سومین خانه آبی رنگ',
                reward: 'مدال کاشف 🏅',
                found: false,
                type: 'cafe'
            },
            {
                id: 'secret-viewpoint',
                name: 'منظره مخفی گالاتا',
                coordinates: [28.9739, 41.0255],
                clue: 'از پله‌های مارپیچ برج بالا بروید',
                reward: 'مدال ماجراجو ⛰️',
                found: false,
                type: 'viewpoint'
            },
            {
                id: 'historical-fountain',
                name: 'فواره تاریخی اسکودار',
                coordinates: [29.0265, 41.0210],
                clue: 'در کنار مسجد شکرچی',
                reward: 'مدال تاریخ‌دان 📜',
                found: false,
                type: 'historical'
            }
        ];
        
        this.missions = [
            {
                id: 'find-ottoman-buildings',
                title: 'سه بنای عثمانی پیدا کن',
                targets: ['sultanahmet', 'sultanahmet', 'sultanahmet'],
                progress: 0,
                reward: 'مدال تاریخ‌دان 📜',
                completed: false
            },
            {
                id: 'try-local-foods',
                title: 'سه غذای معروف امتحان کن',
                targets: ['kadikoy', 'beyoglu', 'uskudar'],
                progress: 0,
                reward: 'مدال خوشمزه‌شناسی 🍽️',
                completed: false
            },
            {
                id: 'find-hidden-gems',
                title: 'گنجینه‌های مخفی پیدا کن',
                targets: this.hiddenGems.map(gem => gem.id),
                progress: 0,
                reward: 'مدال گنج‌یاب 🗝️',
                completed: false
            }
        ];
        
        // اضافه کردن مارکرهای مخفی
        this.addHiddenGemsToMap();
        
        // ایجاد پنل مأموریت‌ها
        this.createMissionsPanel();
        
        console.log('✅ سیستم گیمیفیکیشن تنظیم شد');
    }
    
    addHiddenGemsToMap() {
        this.hiddenGems.forEach(gem => {
            if (!gem.found) {
                const el = document.createElement('div');
                el.className = 'hidden-gem-marker';
                el.innerHTML = '💎';
                el.style.fontSize = '24px';
                el.style.cursor = 'pointer';
                el.title = 'نقطه مخفی - کلیک کنید';
                
                el.addEventListener('click', () => this.foundHiddenGem(gem.id));
                
                new mapboxgl.Marker(el)
                    .setLngLat(gem.coordinates)
                    .setPopup(new mapboxgl.Popup().setHTML(`
                        <div style="padding: 10px;">
                            <h3 style="margin: 0 0 10px 0;">${gem.name}</h3>
                            <p><strong>سرنخ:</strong> ${gem.clue}</p>
                            <p><strong>جایزه:</strong> ${gem.reward}</p>
                            <button onclick="smartMap.foundHiddenGem('${gem.id}')" 
                                    style="background: #8B5CF6; color: white; border: none; padding: 8px 16px; border-radius: 5px; cursor: pointer;">
                                پیدا کردم! 🎯
                            </button>
                        </div>
                    `))
                    .addTo(this.map);
            }
        });
    }
    
    foundHiddenGem(gemId) {
        const gem = this.hiddenGems.find(g => g.id === gemId);
        if (gem && !gem.found) {
            gem.found = true;
            
            // آپدیت مأموریت
            const mission = this.missions.find(m => m.id === 'find-hidden-gems');
            if (mission) {
                mission.progress++;
                this.updateMissionProgress(mission);
                
                if (mission.progress >= mission.targets.length) {
                    mission.completed = true;
                    this.showReward(mission.reward);
                }
            }
            
            this.showNotification(`گنجینه پیدا شد! ${gem.reward}`, 'success');
            
            // حذف مارکر
            // در واقعیت باید مارکر را از نقشه حذف کنیم
        }
    }
    
    createMissionsPanel() {
        const container = document.getElementById('missions-panel');
        if (!container) {
            console.warn('Container #missions-panel not found');
            return;
        }
        
        const missionsHTML = this.missions.map(mission => `
            <div class="mission-item" data-mission-id="${mission.id}">
                <div class="mission-title">${mission.title}</div>
                <div class="mission-progress">
                    <div class="mission-progress-bar" style="width: ${(mission.progress / mission.targets.length) * 100}%"></div>
                </div>
                <div class="mission-reward">جایزه: ${mission.reward}</div>
            </div>
        `).join('');
        
        container.innerHTML = `
            <h3>🏆 مأموریت‌های استانبول</h3>
            <div id="missions-list">
                ${missionsHTML}
            </div>
            <div style="text-align: center; margin-top: 15px;">
                <button id="toggle-missions" style="background: none; border: 1px solid #E5E7EB; padding: 5px 15px; border-radius: 15px; cursor: pointer; font-size: 12px;">
                    🔽 مخفی کردن
                </button>
            </div>
        `;
        
        // event listener برای مخفی کردن پنل
        document.getElementById('toggle-missions').addEventListener('click', () => {
            const list = document.getElementById('missions-list');
            const button = document.getElementById('toggle-missions');
            
            if (list.style.display === 'none') {
                list.style.display = 'block';
                button.innerHTML = '🔽 مخفی کردن';
            } else {
                list.style.display = 'none';
                button.innerHTML = '🔼 نمایش مأموریت‌ها';
            }
        });
    }
    
    updateMissionProgress(mission) {
        const missionElement = document.querySelector(`[data-mission-id="${mission.id}"] .mission-progress-bar`);
        if (missionElement) {
            const progressPercent = (mission.progress / mission.targets.length) * 100;
            missionElement.style.width = `${progressPercent}%`;
            
            if (mission.completed) {
                missionElement.parentElement.parentElement.style.opacity = '0.6';
            }
        }
    }
    
    addToRoute(districtId) {
        // در اینجا می‌توان منطق اضافه کردن به مسیر را پیاده‌سازی کرد
        console.log('اضافه به مسیر:', districtId);
        
        // نمایش مسیر روی نقشه
        const district = this.getDistrictById(districtId);
        if (district) {
            // ایجاد یک مسیر ساده (در واقعیت باید از Directions API استفاده کرد)
            if (this.activeRoute) {
                // اضافه کردن نقطه جدید به مسیر موجود
                this.activeRoute.push(district.center);
            } else {
                // ایجاد مسیر جدید
                this.activeRoute = [district.center];
            }
            
            // رسم مسیر
            this.drawRouteOnMap();
            
            this.showNotification(`${district.name} به مسیر شما اضافه شد`, 'info');
        }
    }
    
    drawRouteOnMap() {
        if (!this.activeRoute || this.activeRoute.length < 2) return;
        
        // حذف لایه مسیر قبلی
        if (this.map.getSource(this.routeLayerId)) {
            this.map.removeLayer(this.routeLayerId);
            this.map.removeSource(this.routeLayerId);
        }
        
        // ایجاد لایه مسیر جدید
        this.map.addSource(this.routeLayerId, {
            'type': 'geojson',
            'data': {
                'type': 'Feature',
                'properties': {},
                'geometry': {
                    'type': 'LineString',
                    'coordinates': this.activeRoute
                }
            }
        });
        
        this.map.addLayer({
            'id': this.routeLayerId,
            'type': 'line',
            'source': this.routeLayerId,
            'layout': {
                'line-join': 'round',
                'line-cap': 'round'
            },
            'paint': {
                'line-color': '#FBBF24',
                'line-width': 4,
                'line-opacity': 0.8,
                'line-dasharray': [0, 2]
            }
        });
    }
    
    askAIAboutDistrict(districtId) {
        const district = this.getDistrictById(districtId);
        if (!district) return;
        
        const aiPanel = document.getElementById('ai-panel');
        if (!aiPanel) {
            console.warn('AI panel not found');
            return;
        }
        
        // نمایش پیام در حال بارگذاری
        aiPanel.innerHTML = `
            <div class="ai-response-card">
                <div class="ai-header">
                    <div class="ai-avatar">🤔</div>
                    <h4>در حال پرسیدن از ISTO...</h4>
                </div>
                <div class="ai-content">
                    در حال دریافت پیشنهادات هوشمند برای ${district.name}
                </div>
            </div>
        `;
        
        // شبیه‌سازی پاسخ AI (در واقعیت باید به API متصل شود)
        setTimeout(() => {
            const responses = [
                `منطقه ${district.name} واقعاً خاصه! پیشنهاد می‌کنم اول به ${district.topPlaces[0]} برید و بعد برای ناهار ${district.famousFood} رو امتحان کنید.`,
                `اگر در ${district.name} هستید، حتماً ${district.topPlaces[1]} رو ببینید. بعدازظهرها بهترین زمان برای گشت‌وگذار در این محله است.`,
                `برای تجربه واقعی ${district.name}، پیشنهاد می‌کنم صبح زود برید و با مردم محلی صحبت کنید. ${district.description}`,
                `اینجا چند نکته برای ${district.name}: ۱) کفش راحت بپوشید ۲) دوربین فراموش نشود ۳) نقدی همراه داشته باشید.`
            ];
            
            const randomResponse = responses[Math.floor(Math.random() * responses.length)];
            
            aiPanel.innerHTML = `
                <div class="ai-response-card">
                    <div class="ai-header">
                        <div class="ai-avatar">🤖</div>
                        <h4>پیشنهاد ISTO برای ${district.name}</h4>
                    </div>
                    <div class="ai-content">
                        ${randomResponse}
                        <br><br>
                        <strong>💡 نکته هوشمند:</strong> ${this.generateSmartTip(district, this.getTimeOfDay())}
                    </div>
                    <div class="ai-actions">
                        <button onclick="smartMap.saveTip('${districtId}')">💾 ذخیره نکته</button>
                        <button onclick="smartMap.askFollowUp('${districtId}')">❓ سوال بعدی</button>
                        <button onclick="document.getElementById('ai-panel').innerHTML = ''">✕ بستن</button>
                    </div>
                </div>
            `;
        }, 1500);
    }
    
    saveTip(districtId) {
        // ذخیره نکته در localStorage
        const savedTips = JSON.parse(localStorage.getItem('istanbul_saved_tips') || '[]');
        if (!savedTips.includes(districtId)) {
            savedTips.push(districtId);
            localStorage.setItem('istanbul_saved_tips', JSON.stringify(savedTips));
            this.showNotification('نکته ذخیره شد! می‌توانید در پروفایل خود ببینید.', 'success');
        }
    }
    
    askFollowUp(districtId) {
        const followUpQuestions = [
            `بهترین رستوران ارزان در ${this.getDistrictById(districtId).name} کجاست؟`,
            `چطور می‌تونم از ${this.getDistrictById(districtId).name} به محله دیگر برم؟`,
            `جاذبه‌های رایگان ${this.getDistrictById(districtId).name} چه چیزهایی هستند؟`,
            `برای خانواده با بچه کوچک در ${this.getDistrictById(districtId).name} چه پیشنهادی دارید؟`
        ];
        
        const randomQuestion = followUpQuestions[Math.floor(Math.random() * followUpQuestions.length)];
        
        // شبیه‌سازی پاسخ AI
        this.askAIAboutDistrict(districtId);
    }
    
    saveDistrict(districtId) {
        // ذخیره در favorites
        const favorites = JSON.parse(localStorage.getItem('istanbul_favorites') || '[]');
        if (!favorites.includes(districtId)) {
            favorites.push(districtId);
            localStorage.setItem('istanbul_favorites', JSON.stringify(favorites));
        }
    }
    
    showReward(reward) {
        const rewardDiv = document.createElement('div');
        rewardDiv.style.cssText = `
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background: linear-gradient(135deg, #FBBF24, #F59E0B);
            color: white;
            padding: 30px 50px;
            border-radius: 20px;
            text-align: center;
            z-index: 9999;
            box-shadow: 0 20px 60px rgba(0,0,0,0.4);
            animation: popIn 0.5s ease;
            font-family: 'Vazirmatn', sans-serif;
        `;
        
        rewardDiv.innerHTML = `
            <div style="font-size: 48px; margin-bottom: 20px;">🎉</div>
            <h2 style="margin: 0 0 10px 0;">تبریک!</h2>
            <p style="margin: 0 0 20px 0; font-size: 18px;">شما جایزه گرفتید:</p>
            <div style="font-size: 24px; font-weight: bold;">${reward}</div>
            <button onclick="this.parentElement.remove()" style="
                background: white;
                color: #F59E0B;
                border: none;
                padding: 10px 30px;
                border-radius: 25px;
                margin-top: 20px;
                font-weight: bold;
                cursor: pointer;
                font-family: 'Vazirmatn', sans-serif;
            ">
                ادامه ماجراجویی
            </button>
        `;
        
        document.body.appendChild(rewardDiv);
        
        // پخش صدای جایزه (اختیاری)
        if (typeof Audio !== 'undefined') {
            const audio = new Audio('https://assets.mixkit.co/sfx/preview/mixkit-winning-chimes-2015.mp3');
            audio.play().catch(e => console.log('Audio play failed:', e));
        }
        
        // حذف خودکار بعد از 5 ثانیه
        setTimeout(() => {
            if (rewardDiv.parentElement) {
                rewardDiv.remove();
            }
        }, 5000);
    }
    
    showNotification(message, type = 'info') {
        // ایجاد اعلان
        const notification = document.createElement('div');
        notification.style.cssText = `
            position: fixed;
            bottom: 20px;
            left: 50%;
            transform: translateX(-50%);
            background: ${type === 'success' ? '#10B981' : type === 'error' ? '#EF4444' : '#3B82F6'};
            color: white;
            padding: 15px 25px;
            border-radius: 10px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.2);
            z-index: 9998;
            font-family: 'Vazirmatn', sans-serif;
            animation: slideUp 0.3s ease;
            max-width: 400px;
            text-align: center;
        `;
        
        notification.textContent = message;
        document.body.appendChild(notification);
        
        // حذف خودکار
        setTimeout(() => {
            notification.style.animation = 'slideDown 0.3s ease';
            setTimeout(() => {
                if (notification.parentElement) {
                    notification.remove();
                }
            }, 300);
        }, 3000);
    }
    
    // توابع کمکی
    calculateRoute(districts, timeAvailable) {
        // محاسبه مسیر بهینه
        const maxPoints = Math.min(districts.length, Math.ceil(timeAvailable / 2));
        return districts.slice(0, maxPoints);
    }
    
    optimizeRoute(districts) {
        // ساده‌سازی: برگرداندن همان ترتیب
        return districts;
    }
}

// اضافه کردن استایل‌های انیمیشن
const style = document.createElement('style');
style.textContent = `
    @keyframes popIn {
        from { transform: translate(-50%, -50%) scale(0.5); opacity: 0; }
        to { transform: translate(-50%, -50%) scale(1); opacity: 1; }
    }
    
    @keyframes slideUp {
        from { transform: translate(-50%, 100%); opacity: 0; }
        to { transform: translate(-50%, 0); opacity: 1; }
    }
    
    @keyframes slideDown {
        from { transform: translate(-50%, 0); opacity: 1; }
        to { transform: translate(-50%, 100%); opacity: 0; }
    }
    
    .hidden-gem-marker {
        animation: pulse 2s infinite, float 3s ease-in-out infinite;
    }
`;
document.head.appendChild(style);

// راه‌اندازی نقشه وقتی صفحه لود شد
document.addEventListener('DOMContentLoaded', () => {
    if (document.getElementById('smart-map')) {
        window.smartMap = new SmartMap();
        smartMap.init();
    }
});

console.log('✅ موتور نقشه هوشمند بارگذاری شد');
// ==========================
// RESTAURANTS DATA
// ==========================
const restaurantsData = [
    {
        id: 201,
        name: {
            fa: "رستوران مشتی",
            en: "Mısır Çarşısı Restaurant",
            tr: "Mısır Çarşısı Restaurant",
            ar: "مطعم بازار مصر"
        },
        cuisine: {
            fa: "ترکی، کباب",
            en: "Turkish, Kebabs",
            tr: "Türk, Kebap",
            ar: "تركي، كباب"
        },
        address: {
            fa: "امینونو، استانبول",
            en: "Eminonu, Istanbul",
            tr: "Eminönü, İstanbul",
            ar: "أمينونو، إسطنبول"
        },
        coordinates: {
            lat: 41.0172,
            lng: 28.9705
        },
        priceRange: {
            fa: "متوسط (۸۰-۱۵۰ لیر)",
            en: "Medium (80-150 TL)",
            tr: "Orta (80-150 TL)",
            ar: "متوسط (٨٠-١٥٠ ليرة)"
        },
        openingHours: {
            fa: "۸:۰۰ صبح تا ۱۱:۰۰ عصر",
            en: "8:00 AM - 11:00 PM",
            tr: "08:00 - 23:00",
            ar: "٨:٠٠ صباحًا - ١١:٠٠ مساءً"
        },
        rating: 4.6,
        reviewCount: 4200,
        specialties: {
            fa: ["کباب آدانا", "کوفته", "باقلوا"],
            en: ["Adana Kebab", "Kofte", "Baklava"],
            tr: ["Adana Kebap", "Köfte", "Baklava"],
            ar: ["كباب أضana", "كفتة", "بقلاوة"]
        }
    },
    {
        id: 202,
        name: {
            fa: "رستوران نورتان",
            en: "Nur Restaurant",
            tr: "Nur Restaurant",
            ar: "مطعم النور"
        },
        cuisine: {
            fa: "غذاهای دریایی",
            en: "Seafood",
            tr: "Deniz Ürünleri",
            ar: "مأكولات بحرية"
        },
        address: {
            fa: "کادیکوی، استانبول",
            en: "Kadikoy, Istanbul",
            tr: "Kadıköy, İstanbul",
            ar: "كاديكوي، إسطنبول"
        },
        coordinates: {
            lat: 40.9900,
            lng: 29.0250
        },
        priceRange: {
            fa: "بالا (۲۰۰-۴۰۰ لیر)",
            en: "High (200-400 TL)",
            tr: "Yüksek (200-400 TL)",
            ar: "مرتفع (٢٠٠-٤٠٠ ليرة)"
        },
        openingHours: {
            fa: "۱۲:۰۰ ظهر تا ۱۲:۰۰ شب",
            en: "12:00 PM - 12:00 AM",
            tr: "12:00 - 00:00",
            ar: "١٢:٠٠ ظهرًا - ١٢:٠٠ صباحًا"
        },
        rating: 4.8,
        reviewCount: 3100,
        specialties: {
            fa: ["ماهی سفید", "میگو", "کالاماری"],
            en: ["Sea Bass", "Shrimp", "Calamari"],
            tr: ["Levrek", "Karides", "Kalamar"],
            ar: ["سمك قاروص", "جمبري", "حبار"]
        }
    },
    {
        id: 203,
        name: {
            fa: "کافه پیرلوتا",
            en: "Pierre Loti Cafe",
            tr: "Pierre Loti Kahvesi",
            ar: "مقهى بيير لوتي"
        },
        cuisine: {
            fa: "کافه، چای ترکی",
            en: "Cafe, Turkish Tea",
            tr: "Kafe, Türk Çayı",
            ar: "مقهى، شاي تركي"
        },
        address: {
            fa: "ایوب، استانبول",
            en: "Eyup, Istanbul",
            tr: "Eyüp, İstanbul",
            ar: "أيوب، إسطنبول"
        },
        coordinates: {
            lat: 41.0540,
            lng: 28.9340
        },
        priceRange: {
            fa: "اقتصادی (۲۰-۵۰ لیر)",
            en: "Economical (20-50 TL)",
            tr: "Ekonomik (20-50 TL)",
            ar: "اقتصادي (٢٠-٥٠ ليرة)"
        },
        openingHours: {
            fa: "۷:۰۰ صبح تا ۱۰:۰۰ عصر",
            en: "7:00 AM - 10:00 PM",
            tr: "07:00 - 22:00",
            ar: "٧:٠٠ صباحًا - ١٠:٠٠ مساءً"
        },
        rating: 4.7,
        reviewCount: 5200,
        specialties: {
            fa: ["چای ترکی", "قهوه ترکی", "سیگر بوره"],
            en: ["Turkish Tea", "Turkish Coffee", "Sigara Boregi"],
            tr: ["Türk Çayı", "Türk Kahvesi", "Sigara Böreği"],
            ar: ["شاي تركي", "قهوة تركية", "سيجارا بوريك"]
        }
    },
    {
        id: 204,
        name: {
            fa: "رستوران ۳۶۰",
            en: "360 Istanbul",
            tr: "360 İstanbul",
            ar: "مطعم ٣٦٠ إسطنبول"
        },
        cuisine: {
            fa: "بین المللی، ترکی",
            en: "International, Turkish",
            tr: "Uluslararası, Türk",
            ar: "دولي، تركي"
        },
        address: {
            fa: "بی‌اوغلو، استانبول",
            en: "Beyoglu, Istanbul",
            tr: "Beyoğlu, İstanbul",
            ar: "بي أوغلو، إسطنبول"
        },
        coordinates: {
            lat: 41.0330,
            lng: 28.9850
        },
        priceRange: {
            fa: "گران (۳۰۰-۵۰۰ لیر)",
            en: "Expensive (300-500 TL)",
            tr: "Pahalı (300-500 TL)",
            ar: "مكلف (٣٠٠-٥٠٠ ليرة)"
        },
        openingHours: {
            fa: "۶:۰۰ عصر تا ۲:۰۰ شب",
            en: "6:00 PM - 2:00 AM",
            tr: "18:00 - 02:00",
            ar: "٦:٠٠ مساءً - ٢:٠٠ صباحًا"
        },
        rating: 4.5,
        reviewCount: 2800,
        specialties: {
            fa: ["منظره ۳۶۰ درجه", "کوکتل", "غذاهای بین‌المللی"],
            en: ["360° View", "Cocktails", "International Cuisine"],
            tr: ["360° Manzara", "Kokteyller", "Uluslararası Mutfak"],
            ar: ["إطلالة ٣٦٠ درجة", "كوكتيل", "مأكولات دولية"]
        }
    },
    {
        id: 205,
        name: {
            fa: "دونرچی صابر",
            en: "Donerci Sabir",
            tr: "Dönerci Sabır",
            ar: "دونرجي صابر"
        },
        cuisine: {
            fa: "فست فود ترکی",
            en: "Turkish Fast Food",
            tr: "Türk Fast Food",
            ar: "وجبات سريعة تركية"
        },
        address: {
            fa: "فاتح، استانبول",
            en: "Fatih, Istanbul",
            tr: "Fatih, İstanbul",
            ar: "فاتح، إسطنبول"
        },
        coordinates: {
            lat: 41.0160,
            lng: 28.9400
        },
        priceRange: {
            fa: "اقتصادی (۱۵-۴۰ لیر)",
            en: "Economical (15-40 TL)",
            tr: "Ekonomik (15-40 TL)",
            ar: "اقتصادي (١٥-٤٠ ليرة)"
        },
        openingHours: {
            fa: "۱۱:۰۰ صبح تا ۳:۰۰ شب",
            en: "11:00 AM - 3:00 AM",
            tr: "11:00 - 03:00",
            ar: "١١:٠٠ صباحًا - ٣:٠٠ صباحًا"
        },
        rating: 4.4,
        reviewCount: 6800,
        specialties: {
            fa: ["دونر گوشت", "چی‌کوفته", "پیده"],
            en: ["Meat Doner", "Cig Kofte", "Pide"],
            tr: ["Et Döner", "Çiğ Köfte", "Pide"],
            ar: ["دونر لحم", "تشي كفتة", "بيض"]
        }
    }
];
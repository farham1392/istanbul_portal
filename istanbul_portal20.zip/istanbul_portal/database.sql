-- ایجاد دیتابیس
CREATE DATABASE IF NOT EXISTS farhamza_istanbul_guide;
USE farhamza_istanbul_guide;

-- جدول کاربران
CREATE TABLE users (
    id INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(50) UNIQUE NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    full_name VARCHAR(100),
    phone VARCHAR(20),
    avatar_url VARCHAR(255),
    language VARCHAR(10) DEFAULT 'fa',
    theme VARCHAR(10) DEFAULT 'light',
    role ENUM('user', 'admin') DEFAULT 'user',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- جدول مکان‌های تاریخی
CREATE TABLE historical_places (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name_fa VARCHAR(200),
    name_en VARCHAR(200),
    name_tr VARCHAR(200),
    name_ar VARCHAR(200),
    description_fa TEXT,
    description_en TEXT,
    description_tr TEXT,
    description_ar TEXT,
    image_url VARCHAR(500),
    category VARCHAR(50),
    rating DECIMAL(3,2),
    entrance_fee DECIMAL(10,2),
    currency VARCHAR(10) DEFAULT 'TRY',
    location VARCHAR(300),
    opening_hours VARCHAR(100),
    latitude DECIMAL(10,8),
    longitude DECIMAL(11,8),
    best_time_fa VARCHAR(200),
    best_time_en VARCHAR(200),
    best_time_tr VARCHAR(200),
    best_time_ar VARCHAR(200),
    transportation_fa VARCHAR(500),
    transportation_en VARCHAR(500),
    transportation_tr VARCHAR(500),
    transportation_ar VARCHAR(500),
    website VARCHAR(200),
    contact VARCHAR(100),
    tips_fa TEXT,
    tips_en TEXT,
    tips_tr TEXT,
    tips_ar TEXT,
    featured BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- جدول هتل‌ها
CREATE TABLE hotels (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name_fa VARCHAR(200),
    name_en VARCHAR(200),
    name_tr VARCHAR(200),
    name_ar VARCHAR(200),
    description_fa TEXT,
    description_en TEXT,
    description_tr TEXT,
    description_ar TEXT,
    image_url VARCHAR(500),
    stars INT,
    rating DECIMAL(3,2),
    price_per_night DECIMAL(10,2),
    currency VARCHAR(10) DEFAULT 'TRY',
    location VARCHAR(300),
    amenities TEXT,
    website VARCHAR(200),
    contact VARCHAR(100),
    latitude DECIMAL(10,8),
    longitude DECIMAL(11,8),
    featured BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- جدول رستوران‌ها
CREATE TABLE restaurants (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name_fa VARCHAR(200),
    name_en VARCHAR(200),
    name_tr VARCHAR(200),
    name_ar VARCHAR(200),
    description_fa TEXT,
    description_en TEXT,
    description_tr TEXT,
    description_ar TEXT,
    image_url VARCHAR(500),
    cuisine_type VARCHAR(100),
    rating DECIMAL(3,2),
    price_range VARCHAR(50),
    location VARCHAR(300),
    opening_hours VARCHAR(100),
    website VARCHAR(200),
    contact VARCHAR(100),
    latitude DECIMAL(10,8),
    longitude DECIMAL(11,8),
    featured BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- جدول تجربه‌ها
CREATE TABLE experiences (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name_fa VARCHAR(200),
    name_en VARCHAR(200),
    name_tr VARCHAR(200),
    name_ar VARCHAR(200),
    description_fa TEXT,
    description_en TEXT,
    description_tr TEXT,
    description_ar TEXT,
    image_url VARCHAR(500),
    category VARCHAR(100),
    duration VARCHAR(50),
    group_size VARCHAR(50),
    price DECIMAL(10,2),
    currency VARCHAR(10) DEFAULT 'TRY',
    location VARCHAR(300),
    includes TEXT,
    website VARCHAR(200),
    contact VARCHAR(100),
    featured BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- جدول علاقه‌مندی‌های کاربران
CREATE TABLE user_favorites (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT,
    place_id INT,
    place_type ENUM('historical_place', 'hotel', 'restaurant', 'experience'),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- جدول نقد و بررسی‌ها
CREATE TABLE reviews (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT,
    place_id INT,
    place_type ENUM('historical_place', 'hotel', 'restaurant', 'experience'),
    rating DECIMAL(3,2),
    comment TEXT,
    language VARCHAR(10),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- جدول عضویت در خبرنامه
CREATE TABLE newsletter_subscribers (
    id INT PRIMARY KEY AUTO_INCREMENT,
    email VARCHAR(100) UNIQUE NOT NULL,
    language VARCHAR(10) DEFAULT 'fa',
    subscribed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- جدول تماس‌ها
CREATE TABLE contacts (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100),
    email VARCHAR(100),
    subject VARCHAR(200),
    message TEXT,
    language VARCHAR(10),
    status ENUM('pending', 'read', 'replied') DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- درج داده‌های نمونه
INSERT INTO historical_places (name_fa, name_en, name_tr, description_fa, description_en, description_tr, image_url, category, rating, entrance_fee, location, opening_hours, latitude, longitude, featured) VALUES
('ایاصوفیه', 'Hagia Sophia', 'Ayasofya', 'یک کلیسای جامع پاتریارکی مسیحی ارتدوکس یونانی سابق، بعداً یک مسجد امپراتوری عثمانی و اکنون یک موزه در استانبول، ترکیه.', 'A former Greek Orthodox Christian patriarchal cathedral, later an Ottoman imperial mosque and now a museum in Istanbul, Turkey.', 'İstanbul\'da bulunan, eski bir Ortodoks patrik katedrali, daha sonra Osmanlı camii ve şu anda müze olan tarihi yapı.', 'assets/visit-hagia-sophia-museum.jpg', 'museum', 4.9, 100, 'Sultanahmet, Fatih', '09:00 - 19:00', 41.0086, 28.9802, 1),
('مسجد آبی', 'Blue Mosque', 'Sultanahmet Camii', 'یک مسجد تاریخی معروف برای کاشی‌های آبی که دیوارهای طراحی داخلی را احاطه کرده‌اند.', 'A historic mosque known for its blue tiles surrounding the walls of interior design.', 'İç tasarımının duvarlarını çevreleyen mavi çinileriyle ünlü tarihi bir cami.', 'assets/blue-mosque.jpg', 'mosque', 4.8, 0, 'Sultanahmet, Fatih', '08:30 - 18:30', 41.0055, 28.9774, 1),
('کاخ توپکاپی', 'Topkapi Palace', 'Topkapı Sarayı', 'یک موزه بزرگ که به مدت ۴۰۰ سال اقامتگاه اصلی سلاطین عثمانی بود.', 'A large museum that served as the main residence of Ottoman sultans for 400 years.', 'Osmanlı sultanlarının 400 yıl boyunca ana ikametgahı olarak hizmet veren büyük bir müze.', 'assets/topkapi-palace.jpg', 'museum', 4.7, 150, 'Cankurtaran, Fatih', '09:00 - 18:00', 41.0116, 28.9831, 1);

-- کاربر ادمین پیش‌فرض
INSERT INTO users (username, email, password_hash, full_name, role) VALUES
('admin', 'admin@istanbulguide.com', '$2y$10$YourHashedPasswordHere', 'Administrator', 'admin');
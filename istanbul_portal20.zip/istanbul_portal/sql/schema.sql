-- بانک اطلاعاتی
CREATE DATABASE IF NOT EXISTS istanbul_guide CHARACTER SET utf8mb4 COLLATE utf8mb4_persian_ci;
USE istanbul_guide;

-- جدول کاربران
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    full_name VARCHAR(100),
    avatar_url VARCHAR(500),
    language VARCHAR(10) DEFAULT 'fa',
    theme VARCHAR(10) DEFAULT 'light',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- جدول مکان‌های گردشگری
CREATE TABLE places (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name_fa VARCHAR(200) NOT NULL,
    name_en VARCHAR(200),
    name_tr VARCHAR(200),
    name_ar VARCHAR(200),
    description_fa TEXT,
    description_en TEXT,
    description_tr TEXT,
    description_ar TEXT,
    category VARCHAR(50),
    district_fa VARCHAR(100),
    district_en VARCHAR(100),
    lat DECIMAL(10, 8),
    lng DECIMAL(11, 8),
    rating DECIMAL(2,1) DEFAULT 0.0,
    price_range VARCHAR(20),
    image_url VARCHAR(500),
    opening_hours_fa VARCHAR(200),
    best_time_fa VARCHAR(200),
    duration_fa VARCHAR(50),
    review_count INT DEFAULT 0,
    website_url VARCHAR(500),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    is_active BOOLEAN DEFAULT TRUE
);

-- جدول تگ‌های مکان‌ها
CREATE TABLE place_tags (
    id INT AUTO_INCREMENT PRIMARY KEY,
    place_id INT,
    tag_fa VARCHAR(50),
    tag_en VARCHAR(50),
    FOREIGN KEY (place_id) REFERENCES places(id) ON DELETE CASCADE
);

-- جدول هتل‌ها
CREATE TABLE hotels (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(200) NOT NULL,
    description TEXT,
    stars INT,
    rating DECIMAL(2,1),
    price_per_night DECIMAL(10,2),
    image_url VARCHAR(500),
    district_fa VARCHAR(100),
    lat DECIMAL(10, 8),
    lng DECIMAL(11, 8),
    amenities JSON,
    contact_phone VARCHAR(20),
    contact_email VARCHAR(100),
    website_url VARCHAR(500),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- جدول علاقه‌مندی‌های کاربران
CREATE TABLE user_favorites (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    place_id INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (place_id) REFERENCES places(id) ON DELETE CASCADE,
    UNIQUE KEY unique_favorite (user_id, place_id)
);

-- جدول رزروها
CREATE TABLE bookings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    hotel_id INT,
    check_in DATE NOT NULL,
    check_out DATE NOT NULL,
    guests INT DEFAULT 1,
    rooms INT DEFAULT 1,
    total_price DECIMAL(10,2),
    status ENUM('pending', 'confirmed', 'cancelled') DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (hotel_id) REFERENCES hotels(id)
);

-- جدول برنامه‌های سفر
CREATE TABLE itineraries (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    title VARCHAR(200),
    days INT,
    interests JSON,
    budget_range VARCHAR(50),
    generated_itinerary JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
);

-- جدول روزهای برنامه سفر
CREATE TABLE itinerary_days (
    id INT AUTO_INCREMENT PRIMARY KEY,
    itinerary_id INT,
    day_number INT,
    activities JSON,
    FOREIGN KEY (itinerary_id) REFERENCES itineraries(id) ON DELETE CASCADE
);

-- جدول اشتراک‌ها در خبرنامه
CREATE TABLE newsletter_subscriptions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(100) UNIQUE NOT NULL,
    subscribed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    is_active BOOLEAN DEFAULT TRUE
);
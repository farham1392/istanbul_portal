<?php
// Istanbul Guide Portal - About Project Page (Multilingual)
session_start();

// تنظیمات چندزبانه
$default_language = 'fa';
$supported_languages = ['tr', 'fa', 'en', 'ar'];

// تنظیم زبان بر اساس پارامتر GET یا سشن
if (isset($_GET['lang']) && in_array($_GET['lang'], $supported_languages)) {
    $_SESSION['lang'] = $_GET['lang'];
    $current_lang = $_GET['lang'];
} elseif (isset($_SESSION['lang']) && in_array($_SESSION['lang'], $supported_languages)) {
    $current_lang = $_SESSION['lang'];
} else {
    $current_lang = $default_language;
    $_SESSION['lang'] = $default_language;
}

// دیکشنری ترجمه‌ها
$translations = [
    'tr' => [
        'page_title' => 'Proje Hakkında | İstanbul Rehberi',
        'page_description' => 'İstanbul turizm rehberi projesinin tanıtımı - teknoloji ve güzelliğin birleşimi',
        'welcome_title' => 'İstanbul Rehberi',
        'welcome_subtitle' => 'İstanbul\'un güzelliklerini keşfetmek için küresel bir proje',
        'tagline1' => 'İleri teknoloji',
        'tagline2' => 'Güzel tasarım',
        'tagline3' => 'Küresel seviye',
        'vision_title' => 'Proje Vizyonu',
        'vision_text1' => 'İstanbul Rehberi projesi, güzel İstanbul şehri için kapsamlı, akıllı ve etkileşimli bir rehber oluşturmayı amaçlamaktadır. Seyahatin sadece yerleri görmekten daha fazlası olması ve <em>unutulmaz bir deneyim</em> haline gelmesi gerektiğine inanıyoruz.',
        'vision_text2' => '<span style="color: var(--turkey-red); font-weight: 700;">İleri teknoloji</span>, <span style="color: var(--turkey-red); font-weight: 700;">küresel seviye UI/UX tasarımı</span> ve <span style="color: var(--turkey-red); font-weight: 700;">doğru yerel bilgiler</span> kombinasyonuyla, sadece bir seyahat rehberi değil, aynı zamanda İstanbul\'un kültürünün ve tarihinin en derin katmanlarını keşfetmek için akıllı bir yol arkadaşı olan bir platform inşa ettik.',
        'features_title' => 'Temel Özellikler',
        'feature1_title' => 'Akıllı Etkileşimli Harita',
        'feature1_desc' => 'İlgi alanlarınıza göre önerilerde bulunan ve optimal rotaları hesaplayan bir harita.',
        'feature2_title' => 'Akıllı AI Asistanı',
        'feature2_desc' => '7/24 sorularınızı yanıtlayan ve kişiselleştirilmiş öneriler sunan bir asistan.',
        'feature3_title' => '360° Sanal Tur',
        'feature3_desc' => 'Seyahatinizden önce yerleri sanal ve tam teşekküllü olarak deneyimleyin.',
        'feature4_title' => 'Seyahat Planlayıcı',
        'feature4_desc' => 'Bütçenize ve ilgi alanlarınıza göre tamamen kişiselleştirilmiş seyahat planı.',
        'feature5_title' => 'Çok Dilli',
        'feature5_desc' => 'Türkçe, İngilizce, Farsça ve Arapça dil desteği.',
        'feature6_title' => 'Duyarlı Tasarım',
        'feature6_desc' => 'Mobil cihazlardan masaüstüne kadar tüm cihazlarda harika kullanıcı deneyimi.',
        'timeline_title' => 'Proje Zaman Çizelgesi',
        'timeline1_date' => 'Şubat 2026',
        'timeline1_title' => 'Fikir Başlangıcı',
        'timeline1_desc' => 'İstanbul Rehberi projesinin ilk fikri oluştu. Amaç Farsça konuşan turistler için kapsamlı bir platform oluşturmaktı.',
        'timeline2_date' => 'Şubat 2026',
        'timeline2_title' => 'Araştırma ve Geliştirme',
        'timeline2_desc' => 'Turistlerin ihtiyaçları hakkında kapsamlı araştırma ve İstanbul\'un turistik yerleri hakkında tam bilgi toplama.',
        'timeline3_date' => 'Şubat 2026',
        'timeline3_title' => 'UI/UX Tasarımı',
        'timeline3_desc' => 'Türk kültüründen ve İstanbul mimarisinden ilham alan modern kullanıcı arayüzü tasarımı.',
        'timeline4_date' => 'Şubat 2026',
        'timeline4_title' => 'Teknik Geliştirme',
        'timeline4_desc' => 'En yeni web teknolojilerini kullanarak tam backend ve frontend uygulaması.',
        'timeline5_date' => 'Şubat 2026',
        'timeline5_title' => 'İlk Sürüm Lansmanı',
        'timeline5_desc' => 'Projenin genel lansmanı ve gerçek kullanıcılardan geri bildirim toplamaya başlama.',
        'stats_title' => 'Proje İstatistikleri',
        'stat1_label' => 'Tarihi Yer',
        'stat2_label' => 'Otel ve Konaklama',
        'stat3_label' => 'Restoran ve Kafe',
        'stat4_label' => 'Kullanıcı Memnuniyeti',
        'stat5_label' => 'Destek',
        'stat6_label' => 'Desteklenen Dil',
        'tech_title' => 'Kullanılan Teknolojiler',
        'tech_desc' => 'Bu proje, hızlı, güvenli ve kullanıcı dostu bir deneyim sunmak için en yeni ve en iyi web teknolojileri kullanılarak geliştirilmiştir.',
        'team_title' => 'Geliştirme Ekibi',
        'team_desc' => 'Bu projeyi fikirden gerçeğe dönüştürmek için birlikte çalışan tutkulu uzmanlardan oluşan bir ekip.',
        'team1_name' => 'Nergis Heydarpour',
        'team1_role' => 'Backend Geliştiricisi',
        'team1_desc' => 'Arka uç ve ön uç geliştirme',
        'team2_name' => 'Arya Ebrahimi',
        'team2_role' => 'UI Tasarımcısı',
        'team2_desc' => 'Arka uç ve ön uç geliştirme',
        'team3_name' => 'Amirali Asadzadeh',
        'team3_role' => 'Araştırma ve İçerik Üretimi',
        'team3_desc' => 'Arka uç ve ön uç geliştirme',
        'team4_name' => 'Farham Zamani',
        'team4_role' => 'Akıllı Asistan Geliştiricisi',
        'team4_desc' => 'Arka uç ve ön uç geliştirme',
        'cta_title' => 'İstanbul\'u keşfetmeye hazır mısınız?',
        'cta_desc' => 'İstanbul Rehberi ile hemen seyahatinize başlayın ve İstanbul\'da farklı bir deneyim yaşayın.',
        'cta_btn1' => 'Seyahate Başla',
        'cta_btn2' => 'Bize Ulaşın',
        'footer_about' => 'İstanbul\'un akıllı ve kapsamlı turizm rehberi. İleri teknoloji ve doğru yerel bilgilerin birleşimi.',
        'footer_links_title' => 'Faydalı Bağlantılar',
        'footer_link1' => 'Ana Sayfa',
        'footer_link2' => 'Turistik Yerler',
        'footer_link3' => 'Otel Rezervasyonu',
        'footer_link4' => 'Tur ve Deneyimler',
        'footer_link5' => 'Seyahat Planlayıcı',
        'footer_contact_title' => 'Bize Ulaşın',
        'footer_newsletter_title' => 'Bülten',
        'footer_newsletter_desc' => 'En son güncellemeleri ve indirimleri almak için bültenimize abone olun.',
        'footer_placeholder' => 'E-posta adresiniz',
        'copyright' => 'Tüm hakları saklıdır.',
        'copyright_note' => 'Bu proje bir demo projesidir ve gerçek İstanbul rehberliği ile bağlantılı değildir.',
        'back_button' => 'Ana Sayfaya Dön',
        'change_language' => 'Dili Değiştir',
        'email' => 'info@istanbulguide.com',
        'phone' => '021-12345678',
        'address' => 'İstanbul, Türkiye',
    ],
    'fa' => [
        'page_title' => 'درباره پروژه | Istanbul Guide',
        'page_description' => 'معرفی پروژه راهنمای گردشگری استانبول - ترکیبی از فناوری و زیبایی',
        'welcome_title' => 'Istanbul Guide',
        'welcome_subtitle' => 'پروژه‌ای در سطح جهانی برای کشف زیبایی‌های استانبول',
        'tagline1' => 'فناوری پیشرفته',
        'tagline2' => 'طراحی زیبا',
        'tagline3' => 'سطح جهانی',
        'vision_title' => 'چشم‌انداز پروژه',
        'vision_text1' => 'پروژه <strong>Istanbul Guide</strong> با هدف ایجاد یک راهنمای جامع، هوشمند و تعاملی برای شهر زیبای استانبول طراحی شده است. ما بر این باوریم که سفر باید فراتر از دیدن مکان‌ها باشد و باید به یک <em>تجربه فراموش‌نشدنی</em> تبدیل شود.',
        'vision_text2' => 'با ترکیب <span style="color: var(--turkey-red); font-weight: 700;">فناوری‌های پیشرفته</span>، <span style="color: var(--turkey-red); font-weight: 700;">طراحی UI/UX سطح جهانی</span> و <span style="color: var(--turkey-red); font-weight: 700;">اطلاعات دقیق محلی</span>، ما پلتفرمی ساختیم که نه تنها راهنمای سفر است، بلکه یک همراه هوشمند برای کشف عمیق‌ترین لایه‌های فرهنگ و تاریخ استانبول می‌باشد.',
        'features_title' => 'ویژگی‌های کلیدی',
        'feature1_title' => 'نقشه هوشمند تعاملی',
        'feature1_desc' => 'نقشه‌ای که بر اساس علایق شما پیشنهاد می‌دهد و مسیرهای بهینه را محاسبه می‌کند.',
        'feature2_title' => 'دستیار هوشمند AI',
        'feature2_desc' => 'دستیاری که ۲۴ ساعته به سوالات شما پاسخ می‌دهد و پیشنهادات شخصی ارائه می‌کند.',
        'feature3_title' => 'تور مجازی ۳۶۰ درجه',
        'feature3_desc' => 'قبل از سفر، مکان‌ها را به صورت مجازی و تمام‌عیار تجربه کنید.',
        'feature4_title' => 'برنامه‌ریز سفر',
        'feature4_desc' => 'برنامه سفر کاملاً شخصی‌سازی شده بر اساس بودجه و علایق شما.',
        'feature5_title' => 'چند زبانه',
        'feature5_desc' => 'پشتیبانی از زبان‌های فارسی، انگلیسی، ترکی و عربی.',
        'feature6_title' => 'طراحی ریسپانسیو',
        'feature6_desc' => 'تجربه کاربری عالی در تمام دستگاه‌ها از موبایل تا دسکتاپ.',
        'timeline_title' => 'خط زمانی پروژه',
        'timeline1_date' => 'فوریه 2026',
        'timeline1_title' => 'شروع ایده',
        'timeline1_desc' => 'ایده اولیه پروژه Istanbul Guide شکل گرفت. هدف ایجاد یک پلتفرم کامل برای گردشگران فارسی‌زبان بود.',
        'timeline2_date' => 'فوریه 2026',
        'timeline2_title' => 'تحقیق و توسعه',
        'timeline2_desc' => 'تحقیقات گسترده درباره نیازهای گردشگران و جمع‌آوری اطلاعات کامل از جاذبه‌های استانبول.',
        'timeline3_date' => 'فوریه 2026',
        'timeline3_title' => 'طراحی UI/UX',
        'timeline3_desc' => 'طراحی رابط کاربری مدرن با الهام از فرهنگ ترکی و معماری استانبول.',
        'timeline4_date' => 'فوریه 2026',
        'timeline4_title' => 'توسعه فنی',
        'timeline4_desc' => 'پیاده‌سازی کامل بک‌اند و فرانت‌اند با استفاده از جدیدترین تکنولوژی‌های وب.',
        'timeline5_date' => 'فوریه 2026',
        'timeline5_title' => 'راه‌اندازی نسخه اول',
        'timeline5_desc' => 'راه‌اندازی عمومی پروژه و شروع جمع‌آوری بازخورد از کاربران واقعی.',
        'stats_title' => 'آمار پروژه',
        'stat1_label' => 'جاذبه تاریخی',
        'stat2_label' => 'هتل و اقامتگاه',
        'stat3_label' => 'رستوران و کافه',
        'stat4_label' => 'رضایت کاربران',
        'stat5_label' => 'پشتیبانی',
        'stat6_label' => 'زبان پشتیبانی',
        'tech_title' => 'تکنولوژی‌های استفاده شده',
        'tech_desc' => 'این پروژه با استفاده از جدیدترین و بهترین تکنولوژی‌های وب توسعه یافته است تا تجربه‌ای سریع، امن و کاربرپسند ارائه دهد.',
        'team_title' => 'تیم توسعه',
        'team_desc' => 'تیمی از متخصصان با اشتیاق که با همکاری یکدیگر این پروژه را از ایده به واقعیت تبدیل کردند.',
        'team1_name' => 'نرگس حیدرپور',
        'team1_role' => 'توسعه‌دهنده بک‌اند',
        'team1_desc' => ' توسعه بک‌اند و فرانت اند',
        'team2_name' => 'آریا ابراهیمی',
        'team2_role' => 'طراح رابط کاربری',
        'team2_desc' => ' توسعه بک‌اند و فرانت اند',
        'team3_name' => 'امیرعلی اسدزاده',
        'team3_role' => 'تحقیق و تولید محتوا',
        'team3_desc' => ' توسعه بک‌اند و فرانت اند',
        'team4_name' => 'فرهام زمانی',
        'team4_role' => 'توسعه دستیار هوشمند',
        'team4_desc' => ' توسعه بک‌اند و فرانت اند',
        'cta_title' => 'آماده کشف استانبول هستید؟',
        'cta_desc' => 'همین حالا سفر خود را با Istanbul Guide آغاز کنید و تجربه‌ای متفاوت از استانبول داشته باشید.',
        'cta_btn1' => 'شروع سفر',
        'cta_btn2' => 'تماس با ما',
        'footer_about' => 'راهنمای هوشمند و جامع گردشگری استانبول. ترکیبی از فناوری پیشرفته و اطلاعات دقیق محلی.',
        'footer_links_title' => 'لینک‌های مفید',
        'footer_link1' => 'صفحه اصلی',
        'footer_link2' => 'جاذبه‌های گردشگری',
        'footer_link3' => 'رزرو هتل',
        'footer_link4' => 'تور و تجربه‌ها',
        'footer_link5' => 'برنامه‌ریز سفر',
        'footer_contact_title' => 'تماس با ما',
        'footer_newsletter_title' => 'خبرنامه',
        'footer_newsletter_desc' => 'برای دریافت جدیدترین به‌روزرسانی‌ها و تخفیف‌ها در خبرنامه ما عضو شوید.',
        'footer_placeholder' => 'ایمیل شما',
        'copyright' => 'تمامی حقوق محفوظ است.',
        'copyright_note' => 'این پروژه یک پروژه نمایشی است و با استانبول‌گردی واقعی مرتبط نمی‌باشد.',
        'back_button' => 'بازگشت به صفحه اصلی',
        'change_language' => 'تغییر زبان',
        'email' => 'info@istanbulguide.com',
        'phone' => '۰۲۱-۱۲۳۴۵۶۷۸',
        'address' => 'استانبول، ترکیه',
    ],
    'en' => [
        'page_title' => 'About Project | Istanbul Guide',
        'page_description' => 'Introduction of Istanbul tourism guide project - combination of technology and beauty',
        'welcome_title' => 'Istanbul Guide',
        'welcome_subtitle' => 'A global project to discover the beauties of Istanbul',
        'tagline1' => 'Advanced Technology',
        'tagline2' => 'Beautiful Design',
        'tagline3' => 'Global Level',
        'vision_title' => 'Project Vision',
        'vision_text1' => 'The <strong>Istanbul Guide</strong> project is designed to create a comprehensive, intelligent and interactive guide for the beautiful city of Istanbul. We believe that travel should be more than just seeing places and should become an <em>unforgettable experience</em>.',
        'vision_text2' => 'By combining <span style="color: var(--turkey-red); font-weight: 700;">advanced technologies</span>, <span style="color: var(--turkey-red); font-weight: 700;">global level UI/UX design</span> and <span style="color: var(--turkey-red); font-weight: 700;">accurate local information</span>, we built a platform that is not only a travel guide, but also an intelligent companion for discovering the deepest layers of Istanbul\'s culture and history.',
        'features_title' => 'Key Features',
        'feature1_title' => 'Smart Interactive Map',
        'feature1_desc' => 'A map that suggests based on your interests and calculates optimal routes.',
        'feature2_title' => 'Smart AI Assistant',
        'feature2_desc' => 'An assistant that answers your questions 24/7 and provides personalized suggestions.',
        'feature3_title' => '360° Virtual Tour',
        'feature3_desc' => 'Experience places virtually and fully before your trip.',
        'feature4_title' => 'Travel Planner',
        'feature4_desc' => 'Completely personalized travel plan based on your budget and interests.',
        'feature5_title' => 'Multilingual',
        'feature5_desc' => 'Support for Turkish, English, Persian and Arabic languages.',
        'feature6_title' => 'Responsive Design',
        'feature6_desc' => 'Great user experience on all devices from mobile to desktop.',
        'timeline_title' => 'Project Timeline',
        'timeline1_date' => 'February 2026',
        'timeline1_title' => 'Idea Start',
        'timeline1_desc' => 'The initial idea of the Istanbul Guide project was formed. The goal was to create a comprehensive platform for Persian-speaking tourists.',
        'timeline2_date' => 'February 2026',
        'timeline2_title' => 'Research and Development',
        'timeline2_desc' => 'Comprehensive research about tourists\' needs and gathering complete information about Istanbul\'s attractions.',
        'timeline3_date' => 'February 2026',
        'timeline3_title' => 'UI/UX Design',
        'timeline3_desc' => 'Modern user interface design inspired by Turkish culture and Istanbul architecture.',
        'timeline4_date' => 'February 2026',
        'timeline4_title' => 'Technical Development',
        'timeline4_desc' => 'Complete backend and frontend implementation using the latest web technologies.',
        'timeline5_date' => 'February 2026',
        'timeline5_title' => 'First Version Launch',
        'timeline5_desc' => 'Public launch of the project and start collecting feedback from real users.',
        'stats_title' => 'Project Statistics',
        'stat1_label' => 'Historical Attractions',
        'stat2_label' => 'Hotels & Accommodations',
        'stat3_label' => 'Restaurants & Cafes',
        'stat4_label' => 'User Satisfaction',
        'stat5_label' => 'Support',
        'stat6_label' => 'Supported Languages',
        'tech_title' => 'Technologies Used',
        'tech_desc' => 'This project is developed using the latest and best web technologies to provide a fast, secure and user-friendly experience.',
        'team_title' => 'Development Team',
        'team_desc' => 'A team of passionate professionals who worked together to turn this project from idea to reality.',
        'team1_name' => 'Nergis Heydarpour',
        'team1_role' => 'backend and front end Developer',
        'team1_desc' => 'Backend and frontend development',
        'team2_name' => 'Arya Ebrahimi',
        'team2_role' => 'backend and front end Developer',
        'team2_desc' => 'Backend and frontend development',
        'team3_name' => 'Amirali Asadzadeh',
        'team3_role' => 'backend and front end Developer',
        'team3_desc' => 'Backend and frontend development',
        'team4_name' => 'Farham Zamani',
        'team4_role' => 'backend and front end Developer',
        'team4_desc' => 'Backend and frontend development',
        'cta_title' => 'Ready to discover Istanbul?',
        'cta_desc' => 'Start your journey with Istanbul Guide now and have a different experience in Istanbul.',
        'cta_btn1' => 'Start Journey',
        'cta_btn2' => 'Contact Us',
        'footer_about' => 'Smart and comprehensive tourism guide of Istanbul. Combination of advanced technology and accurate local information.',
        'footer_links_title' => 'Useful Links',
        'footer_link1' => 'Home Page',
        'footer_link2' => 'Tourist Attractions',
        'footer_link3' => 'Hotel Booking',
        'footer_link4' => 'Tours & Experiences',
        'footer_link5' => 'Travel Planner',
        'footer_contact_title' => 'Contact Us',
        'footer_newsletter_title' => 'Newsletter',
        'footer_newsletter_desc' => 'Subscribe to our newsletter to receive the latest updates and discounts.',
        'footer_placeholder' => 'Your Email',
        'copyright' => 'All rights reserved.',
        'copyright_note' => 'This project is a demo project and is not related to real Istanbul guiding.',
        'back_button' => 'Back to Home',
        'change_language' => 'Change Language',
        'email' => 'info@istanbulguide.com',
        'phone' => '021-12345678',
        'address' => 'Istanbul, Turkey',
    ],
    'ar' => [
        'page_title' => 'حول المشروع | دليل إسطنبول',
        'page_description' => 'مقدمة مشروع دليل سياحة إسطنبول - مزيج من التكنولوجيا والجمال',
        'welcome_title' => 'دليل إسطنبول',
        'welcome_subtitle' => 'مشروع عالمي لاكتشاف جماليات إسطنبول',
        'tagline1' => 'تكنولوجيا متقدمة',
        'tagline2' => 'تصميم جميل',
        'tagline3' => 'مستوى عالمي',
        'vision_title' => 'رؤية المشروع',
        'vision_text1' => 'تم تصميم مشروع <strong>دليل إسطنبول</strong> لإنشاء دليل شامل وذكي وتفاعلي لمدينة إسطنبول الجميلة. نحن نؤمن أن السفر يجب أن يكون أكثر من مجرد رؤية الأماكن ويجب أن يصبح <em>تجربة لا تنسى</em>.',
        'vision_text2' => 'من خلال الجمع بين <span style="color: var(--turkey-red); font-weight: 700;">التكنولوجيا المتقدمة</span> و<span style="color: var(--turkey-red); font-weight: 700;">تصميم واجهة المستخدم وتجربة المستخدم على مستوى عالمي</span> و<span style="color: var(--turkey-red); font-weight: 700;">المعلومات المحلية الدقيقة</span>، أنشأنا منصة ليست فقط دليل سفر، بل أيضًا رفيق ذكي لاكتشاف أعمق طبقات ثقافة وتاريخ إسطنبول.',
        'features_title' => 'الميزات الرئيسية',
        'feature1_title' => 'خريطة تفاعلية ذكية',
        'feature1_desc' => 'خريطة تقترح بناءً على اهتماماتك وتحسب المسارات المثلى.',
        'feature2_title' => 'مساعد ذكي بالذكاء الاصطناعي',
        'feature2_desc' => 'مساعد يجيب على أسئلتك على مدار الساعة ويقدم اقتراحات مخصصة.',
        'feature3_title' => 'جولة افتراضية 360 درجة',
        'feature3_desc' => 'اختبر الأماكن افتراضيًا وبشكل كامل قبل رحلتك.',
        'feature4_title' => 'مخطط الرحلات',
        'feature4_desc' => 'خطة سفر مخصصة بالكامل بناءً على ميزانيتك واهتماماتك.',
        'feature5_title' => 'متعدد اللغات',
        'feature5_desc' => 'دعم اللغات التركية والإنجليزية والفارسية والعربية.',
        'feature6_title' => 'تصميم متجاوب',
        'feature6_desc' => 'تجربة مستخدم رائعة على جميع الأجهزة من الجوال إلى سطح المكتب.',
        'timeline_title' => 'الجدول الزمني للمشروع',
        'timeline1_date' => 'فبراير 2026',
        'timeline1_title' => 'بداية الفكرة',
        'timeline1_desc' => 'تم تشكيل الفكرة الأولية لمشروع دليل إسطنبول. كان الهدف إنشاء منصة شاملة للسياح الناطقين بالفارسية.',
        'timeline2_date' => 'فبراير 2026',
        'timeline2_title' => 'البحث والتطوير',
        'timeline2_desc' => 'بحث شامل حول احتياجات السياح وجمع معلومات كاملة عن معالم إسطنبول السياحية.',
        'timeline3_date' => 'فبراير 2026',
        'timeline3_title' => 'تصميم واجهة المستخدم',
        'timeline3_desc' => 'تصميم واجهة مستخدم حديثة مستوحاة من الثقافة التركية وهندسة إسطنبول.',
        'timeline4_date' => 'فبراير 2026',
        'timeline4_title' => 'التطوير الفني',
        'timeline4_desc' => 'تنفيذ كامل للواجهة الخلفية والأمامية باستخدام أحدث تقنيات الويب.',
        'timeline5_date' => 'فبراير 2026',
        'timeline5_title' => 'إطلاق النسخة الأولى',
        'timeline5_desc' => 'الإطلاق العام للمشروع وبدء جمع التعليقات من المستخدمين الحقيقيين.',
        'stats_title' => 'إحصائيات المشروع',
        'stat1_label' => 'معالم تاريخية',
        'stat2_label' => 'فنادق وإقامة',
        'stat3_label' => 'مطاعم ومقاهي',
        'stat4_label' => 'رضا المستخدمين',
        'stat5_label' => 'الدعم',
        'stat6_label' => 'اللغات المدعومة',
        'tech_title' => 'التقنيات المستخدمة',
        'tech_desc' => 'تم تطوير هذا المشروع باستخدام أحدث وأفضل تقنيات الويب لتقديم تجربة سريعة وآمنة وسهلة الاستخدام.',
        'team_title' => 'فريق التطوير',
        'team_desc' => 'فريق من المحترفين المتحمسين الذين عملوا معًا لتحويل هذا المشروع من فكرة إلى واقع.',
        'team1_name' => 'نرجس حيدر بور',
        'team1_role' => 'مطور الواجهة الخلفية',
        'team1_desc' => 'مسؤول عن تطوير الواجهة الخلفية وهندسة المشروع العامة.',
        'team2_name' => 'آرية إبراهيمي',
        'team2_role' => 'مصمم واجهة المستخدم',
        'team2_desc' => 'تصميم تجربة المستخدم وواجهة مستخدم جميلة.',
        'team3_name' => 'أميرعلي أسد زاده',
        'team3_role' => 'البحث وإنتاج المحتوى',
        'team3_desc' => 'جمع المعلومات عن المعالم السياحية والتحقق منها.',
        'team4_name' => 'فرهام زماني',
        'team4_role' => 'مطور المساعد الذكي',
        'team4_desc' => 'تنفيذ وتدريب نماذج الذكاء الاصطناعي.',
        'cta_title' => 'مستعد لاكتشاف إسطنبول؟',
        'cta_desc' => 'ابدأ رحلتك مع دليل إسطنبول الآن وحظ بتجربة مختلفة في إسطنبول.',
        'cta_btn1' => 'ابدأ الرحلة',
        'cta_btn2' => 'اتصل بنا',
        'footer_about' => 'دليل سياحة إسطنبول الذكي والشامل. مزيج من التكنولوجيا المتقدمة والمعلومات المحلية الدقيقة.',
        'footer_links_title' => 'روابط مفيدة',
        'footer_link1' => 'الصفحة الرئيسية',
        'footer_link2' => 'المعالم السياحية',
        'footer_link3' => 'حجز الفندق',
        'footer_link4' => 'الجولات والتجارب',
        'footer_link5' => 'مخطط الرحلات',
        'footer_contact_title' => 'اتصل بنا',
        'footer_newsletter_title' => 'النشرة الإخبارية',
        'footer_newsletter_desc' => 'اشترك في نشرتنا الإخبارية لتلقي أحدث التحديثات والخصومات.',
        'footer_placeholder' => 'بريدك الإلكتروني',
        'copyright' => 'جميع الحقوق محفوظة.',
        'copyright_note' => 'هذا المشروع هو مشروع تجريبي ولا يرتبط بدليل إسطنبول الحقيقي.',
        'back_button' => 'العودة إلى الرئيسية',
        'change_language' => 'تغيير اللغة',
        'email' => 'info@istanbulguide.com',
        'phone' => '021-12345678',
        'address' => 'إسطنبول، تركيا',
    ]
];

// تابع ترجمه
function t($key) {
    global $translations, $current_lang;
    return isset($translations[$current_lang][$key]) ? $translations[$current_lang][$key] : $translations['en'][$key];
}

// تنظیم جهت صفحه بر اساس زبان
$direction = ($current_lang == 'fa' || $current_lang == 'ar') ? 'rtl' : 'ltr';
$text_align = ($current_lang == 'fa' || $current_lang == 'ar') ? 'right' : 'left';

$current_theme = $_SESSION['theme'] ?? 'light';
$base_url = 'https://farhamzamani.com/istanbul/istanbul portal/istanbul_portal/';

// رنگ‌های پرچم ترکیه
$turkey_red = '#E30A17';
$turkey_white = '#FFFFFF';
$turkey_crescent = '#DC143C';
?>

<!DOCTYPE html>
<html lang="<?php echo $current_lang; ?>" dir="<?php echo $direction; ?>" data-base-url="<?php echo $base_url; ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    
    <title><?php echo t('page_title'); ?></title>
    <meta name="description" content="<?php echo t('page_description'); ?>">
    <meta name="keywords" content="Istanbul, tourism, technology, project, about us">
    
    <!-- Open Graph Meta Tags -->
    <meta property="og:title" content="<?php echo t('page_title'); ?>">
    <meta property="og:description" content="<?php echo t('page_description'); ?>">
    <meta property="og:image" content="<?php echo $base_url; ?>assets/about-banner.jpg">
    <meta property="og:url" content="<?php echo $base_url; ?>about.php">
    
    <!-- Favicon -->
    <link rel="icon" type="image/png" href="assets/download.png">
    
    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Vazirmatn:wght@300;400;500;600;700&family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    
    <!-- Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- Bootstrap 5.3 -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Animate.css -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css">
    
    <style>
        :root {
            --turkey-red: <?php echo $turkey_red; ?>;
            --turkey-white: <?php echo $turkey_white; ?>;
            --turkey-crescent: <?php echo $turkey_crescent; ?>;
            --gradient-turkey: linear-gradient(135deg, <?php echo $turkey_red; ?> 0%, #B00808 100%);
            --gradient-light: linear-gradient(135deg, #ffffff 0%, #f8f9fa 100%);
            --gradient-crescent: linear-gradient(45deg, #DC143C 0%, #E30A17 100%);
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: <?php echo ($current_lang == 'fa' || $current_lang == 'ar') ? "'Vazirmatn', sans-serif" : "'Inter', sans-serif"; ?>;
            background: var(--gradient-light);
            color: #333;
            line-height: 1.8;
            min-height: 100vh;
            position: relative;
            overflow-x: hidden;
        }
        
        /* پس‌زمینه المان‌های پرچم ترکیه */
        .turkey-background {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: -1;
            opacity: 0.05;
            background-image: 
                radial-gradient(circle at 70% 30%, var(--turkey-red) 2px, transparent 3px),
                radial-gradient(circle at 30% 70%, var(--turkey-red) 2px, transparent 3px);
            background-size: 50px 50px;
        }
        
        .crescent-star {
            position: absolute;
            width: 300px;
            height: 300px;
            background: radial-gradient(circle at 70% 50%, transparent 60px, var(--turkey-white) 61px),
                        radial-gradient(circle at 55% 50%, var(--turkey-white) 70px, transparent 71px);
            opacity: 0.1;
            z-index: -1;
        }
        
        .crescent-star:nth-child(1) {
            top: -150px;
            <?php echo ($direction == 'rtl') ? 'left: -150px;' : 'right: -150px;'; ?>
        }
        
        .crescent-star:nth-child(2) {
            bottom: -150px;
            <?php echo ($direction == 'rtl') ? 'right: -150px;' : 'left: -150px;'; ?>
            transform: rotate(180deg);
        }
        
        /* دکمه بازگشت */
        .back-nav {
            position: absolute;
            top: 30px;
            <?php echo ($direction == 'rtl') ? 'right: 30px;' : 'left: 30px'; ?>;
            z-index: 10;
        }
        
        .back-btn {
            background: rgba(255,255,255,0.2);
            color: white;
            border: none;
            padding: 12px 25px;
            border-radius: 25px;
            text-decoration: none;
            display: flex;
            align-items: center;
            gap: 10px;
            backdrop-filter: blur(10px);
            transition: all 0.3s ease;
            font-weight: 600;
        }
        
        .back-btn:hover {
            background: rgba(255,255,255,0.3);
            transform: translateX(<?php echo $direction == 'rtl' ? '-5px' : '5px'; ?>);
        }
        
        /* دکمه زبان */
        .language-switcher {
            position: absolute;
            top: 30px;
            <?php echo ($direction == 'rtl') ? 'left: 30px;' : 'right: 30px'; ?>;
            z-index: 10;
        }
        
        .language-btn {
            background: rgba(255,255,255,0.2);
            color: white;
            border: none;
            padding: 12px 25px;
            border-radius: 25px;
            text-decoration: none;
            display: flex;
            align-items: center;
            gap: 10px;
            backdrop-filter: blur(10px);
            transition: all 0.3s ease;
            font-weight: 600;
            cursor: pointer;
        }
        
        .language-btn:hover {
            background: rgba(255,255,255,0.3);
        }
        
        .language-dropdown {
            position: absolute;
            top: 100%;
            <?php echo ($direction == 'rtl') ? 'right: 0;' : 'left: 0'; ?>;
            background: white;
            border-radius: 15px;
            box-shadow: 0 20px 50px rgba(227, 10, 23, 0.2);
            min-width: 150px;
            display: none;
            overflow: hidden;
            z-index: 1000;
            border: 2px solid var(--turkey-red);
        }
        
        .language-switcher:hover .language-dropdown {
            display: block;
        }
        
        .language-dropdown a {
            display: block;
            padding: 12px 20px;
            text-decoration: none;
            color: #333;
            transition: all 0.3s ease;
            border-bottom: 1px solid #f1f1f1;
            text-align: <?php echo $direction == 'rtl' ? 'right' : 'left'; ?>;
        }
        
        .language-dropdown a:hover {
            background: var(--turkey-red);
            color: white;
        }
        
        /* Header */
        .about-header {
            background: var(--gradient-turkey);
            color: white;
            padding: 80px 20px 60px;
            text-align: center;
            position: relative;
            overflow: hidden;
            border-bottom-<?php echo ($direction == 'rtl') ? 'left' : 'right'; ?>-radius: 50px;
            border-bottom-<?php echo ($direction == 'rtl') ? 'right' : 'left'; ?>-radius: 50px;
            box-shadow: 0 10px 30px rgba(227, 10, 23, 0.3);
        }
        
        .about-header::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100" preserveAspectRatio="none"><path d="M0,0 L100,0 L100,100 Z" fill="rgba(255,255,255,0.1)"/></svg>');
            background-size: cover;
        }
        
        .logo-container {
            position: relative;
            z-index: 1;
        }
        
        .about-logo {
            width: 120px;
            height: 120px;
            background: white;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 25px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.3);
            animation: logoFloat 3s ease-in-out infinite;
        }
        
        @keyframes logoFloat {
            0%, 100% { transform: translateY(0); }
            50% { transform: translateY(-15px); }
        }
        
        .about-logo i {
            font-size: 60px;
            background: var(--gradient-turkey);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }
        
        .about-header h1 {
            font-size: 3.2rem;
            font-weight: 800;
            margin-bottom: 15px;
            text-shadow: 0 3px 10px rgba(0,0,0,0.2);
            animation: fadeInDown 1s ease;
        }
        
        .about-header p {
            font-size: 1.2rem;
            opacity: 0.9;
            max-width: 600px;
            margin: 0 auto;
            animation: fadeInUp 1s ease 0.3s both;
        }
        
        .about-tagline {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 15px;
            margin-top: 30px;
            animation: fadeIn 1s ease 0.6s both;
            flex-wrap: wrap;
        }
        
        .about-tagline span {
            background: rgba(255,255,255,0.2);
            padding: 8px 20px;
            border-radius: 25px;
            backdrop-filter: blur(10px);
        }
        
        /* Main Content */
        .about-content {
            max-width: 1200px;
            margin: 0 auto;
            padding: 60px 20px;
        }
        
        /* Vision Section */
        .vision-section {
            background: white;
            border-radius: 30px;
            padding: 50px;
            margin-bottom: 60px;
            box-shadow: 0 15px 40px rgba(227, 10, 23, 0.1);
            border: 2px solid var(--turkey-red);
            position: relative;
            overflow: hidden;
            animation: fadeIn 1s ease;
            text-align: <?php echo $text_align; ?>;
        }
        
        .vision-section::before {
            content: '';
            position: absolute;
            top: 0;
            <?php echo ($direction == 'rtl') ? 'right: 0;' : 'left: 0'; ?>;
            width: 150px;
            height: 150px;
            background: var(--gradient-turkey);
            border-bottom-<?php echo ($direction == 'rtl') ? 'left' : 'right'; ?>-radius: 100%;
            opacity: 0.1;
        }
        
        .section-title {
            color: var(--turkey-red);
            font-size: 2.5rem;
            margin-bottom: 30px;
            position: relative;
            padding-bottom: 15px;
            text-align: <?php echo $text_align; ?>;
        }
        
        .section-title::after {
            content: '';
            position: absolute;
            bottom: 0;
            <?php echo ($direction == 'rtl') ? 'right: 0;' : 'left: 0'; ?>;
            width: 100px;
            height: 4px;
            background: var(--gradient-crescent);
            border-radius: 2px;
        }
        
        .vision-text {
            font-size: 1.1rem;
            color: #555;
            margin-bottom: 30px;
            line-height: 1.9;
            text-align: <?php echo $text_align; ?>;
        }
        
        /* Features Grid */
        .features-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 30px;
            margin: 50px 0;
        }
        
        .feature-card {
            background: white;
            border-radius: 20px;
            padding: 40px 30px;
            text-align: center;
            transition: all 0.3s ease;
            border: 2px solid transparent;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            position: relative;
            overflow: hidden;
        }
        
        .feature-card:hover {
            transform: translateY(-10px);
            border-color: var(--turkey-red);
            box-shadow: 0 20px 40px rgba(227, 10, 23, 0.15);
        }
        
        .feature-card::before {
            content: '';
            position: absolute;
            top: 0;
            <?php echo ($direction == 'rtl') ? 'right: 0;' : 'left: 0'; ?>;
            width: 100%;
            height: 5px;
            background: var(--gradient-turkey);
        }
        
        .feature-icon {
            width: 80px;
            height: 80px;
            background: var(--gradient-turkey);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 25px;
            color: white;
            font-size: 2rem;
        }
        
        .feature-card h3 {
            color: var(--turkey-red);
            margin-bottom: 15px;
            font-size: 1.5rem;
        }
        
        /* Timeline */
        .timeline-section {
            position: relative;
            padding: 50px 0;
            margin: 60px 0;
        }
        
        .timeline-section::before {
            content: '';
            position: absolute;
            top: 0;
            <?php echo ($direction == 'rtl') ? 'right: 50%;' : 'left: 50%;'; ?>
            transform: translateX(<?php echo $direction == 'rtl' ? '50%' : '-50%'; ?>);
            width: 3px;
            height: 100%;
            background: var(--gradient-turkey);
        }
        
        .timeline-item {
            position: relative;
            margin-bottom: 50px;
            width: 45%;
            animation: fadeInRight 1s ease;
        }
        
        .timeline-item:nth-child(odd) {
            <?php echo ($direction == 'rtl') ? 'margin-right: auto; margin-left: 0;' : 'margin-left: auto; margin-right: 0;'; ?>
        }
        
        .timeline-item:nth-child(even) {
            <?php echo ($direction == 'rtl') ? 'margin-right: 0; margin-left: auto;' : 'margin-left: 0; margin-right: auto;'; ?>
            animation: fadeInLeft 1s ease;
        }
        
        .timeline-dot {
            position: absolute;
            top: 0;
            width: 20px;
            height: 20px;
            background: var(--gradient-turkey);
            border-radius: 50%;
            border: 4px solid white;
            box-shadow: 0 0 0 3px var(--turkey-red);
        }
        
        .timeline-item:nth-child(odd) .timeline-dot {
            <?php echo ($direction == 'rtl') ? 'left: calc(100% + 30px);' : 'right: calc(100% + 30px);'; ?>
        }
        
        .timeline-item:nth-child(even) .timeline-dot {
            <?php echo ($direction == 'rtl') ? 'right: calc(100% + 30px);' : 'left: calc(100% + 30px);'; ?>
        }
        
        .timeline-content {
            background: white;
            padding: 30px;
            border-radius: 20px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            <?php echo ($direction == 'rtl') ? 'border-right' : 'border-left'; ?>: 5px solid var(--turkey-red);
            text-align: <?php echo $text_align; ?>;
        }
        
        .timeline-item:nth-child(even) .timeline-content {
            <?php echo ($direction == 'rtl') ? 'border-right: none; border-left: 5px solid var(--turkey-red);' : 'border-left: none; border-right: 5px solid var(--turkey-red);'; ?>
        }
        
        .timeline-date {
            color: var(--turkey-red);
            font-weight: 700;
            margin-bottom: 10px;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        /* Statistics */
        .stats-section {
            background: var(--gradient-turkey);
            color: white;
            padding: 70px 20px;
            border-radius: 40px;
            margin: 60px 0;
            text-align: center;
            position: relative;
            overflow: hidden;
        }
        
        .stats-section::before {
            content: '';
            position: absolute;
            top: -50%;
            <?php echo ($direction == 'rtl') ? 'left: -50%;' : 'right: -50%;'; ?>
            width: 100%;
            height: 200%;
            background: radial-gradient(circle, rgba(255,255,255,0.1) 1px, transparent 1px);
            background-size: 50px 50px;
            transform: rotate(45deg);
        }
        
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 40px;
            position: relative;
            z-index: 1;
        }
        
        .stat-item {
            padding: 30px;
        }
        
        .stat-number {
            font-size: 3.5rem;
            font-weight: 800;
            margin-bottom: 10px;
            text-shadow: 0 3px 10px rgba(0,0,0,0.3);
        }
        
        .stat-label {
            font-size: 1.1rem;
            opacity: 0.9;
        }
        
        /* Team Section */
        .team-section {
            margin: 80px 0;
        }
        
        .team-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 30px;
            margin-top: 40px;
        }
        
        .team-card {
            background: white;
            border-radius: 20px;
            overflow: hidden;
            box-shadow: 0 15px 40px rgba(0,0,0,0.1);
            transition: all 0.3s ease;
            text-align: center;
        }
        
        .team-card:hover {
            transform: translateY(-10px);
            box-shadow: 0 25px 50px rgba(227, 10, 23, 0.15);
        }
        
        .team-avatar {
            width: 150px;
            height: 150px;
            border-radius: 50%;
            margin: 30px auto 20px;
            border: 5px solid var(--turkey-red);
            padding: 5px;
            background: white;
        }
        
        .team-avatar img {
            width: 100%;
            height: 100%;
            border-radius: 50%;
            object-fit: cover;
        }
        
        .team-info {
            padding: 0 25px 30px;
        }
        
        .team-info h4 {
            color: var(--turkey-red);
            margin-bottom: 5px;
            font-size: 1.3rem;
        }
        
        .team-role {
            color: #666;
            margin-bottom: 15px;
            font-style: italic;
        }
        
        /* Technology Stack */
        .tech-stack {
            background: white;
            border-radius: 30px;
            padding: 50px;
            margin: 60px 0;
            box-shadow: 0 15px 40px rgba(227, 10, 23, 0.1);
        }
        
        .tech-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(120px, 1fr));
            gap: 25px;
            margin-top: 40px;
        }
        
        .tech-item {
            text-align: center;
            padding: 25px 15px;
            border-radius: 15px;
            background: #f8f9fa;
            transition: all 0.3s ease;
        }
        
        .tech-item:hover {
            background: var(--gradient-light);
            transform: scale(1.05);
            border: 2px solid var(--turkey-red);
        }
        
        .tech-icon {
            font-size: 2.5rem;
            margin-bottom: 15px;
            color: var(--turkey-red);
        }
        
        /* Call to Action */
        .cta-section {
            text-align: center;
            padding: 80px 20px;
            background: linear-gradient(135deg, rgba(227, 10, 23, 0.1) 0%, rgba(227, 10, 23, 0.05) 100%);
            border-radius: 40px;
            margin: 60px 0;
            position: relative;
            overflow: hidden;
        }
        
        .cta-section::before {
            content: '';
            position: absolute;
            top: -100px;
            <?php echo ($direction == 'rtl') ? 'right: -100px;' : 'left: -100px'; ?>;
            width: 300px;
            height: 300px;
            background: radial-gradient(circle, var(--turkey-red) 0%, transparent 70%);
            opacity: 0.1;
        }
        
        .cta-section::after {
            content: '';
            position: absolute;
            bottom: -100px;
            <?php echo ($direction == 'rtl') ? 'left: -100px;' : 'right: -100px'; ?>;
            width: 300px;
            height: 300px;
            background: radial-gradient(circle, var(--turkey-red) 0%, transparent 70%);
            opacity: 0.1;
        }
        
        .cta-title {
            font-size: 2.8rem;
            color: var(--turkey-red);
            margin-bottom: 20px;
        }
        
        .cta-buttons {
            display: flex;
            gap: 20px;
            justify-content: center;
            margin-top: 40px;
            flex-wrap: wrap;
        }
        
        .cta-btn {
            padding: 18px 40px;
            border-radius: 30px;
            text-decoration: none;
            font-weight: 700;
            font-size: 1.1rem;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            gap: 12px;
            min-width: 200px;
            justify-content: center;
        }
        
        .cta-primary {
            background: var(--gradient-turkey);
            color: white;
            border: none;
        }
        
        .cta-primary:hover {
            transform: translateY(-5px);
            box-shadow: 0 15px 30px rgba(227, 10, 23, 0.3);
        }
        
        .cta-secondary {
            background: white;
            color: var(--turkey-red);
            border: 3px solid var(--turkey-red);
        }
        
        .cta-secondary:hover {
            background: var(--turkey-red);
            color: white;
            transform: translateY(-5px);
        }
        
        /* Footer */
        .about-footer {
            background: #1a1a1a;
            color: white;
            padding: 60px 20px 30px;
            margin-top: 80px;
            position: relative;
            border-top-<?php echo ($direction == 'rtl') ? 'left' : 'right'; ?>-radius: 40px;
            border-top-<?php echo ($direction == 'rtl') ? 'right' : 'left'; ?>-radius: 40px;
        }
        
        .about-footer::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 5px;
            background: var(--gradient-turkey);
        }
        
        .footer-content {
            max-width: 1200px;
            margin: 0 auto;
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 40px;
        }
        
        .footer-col h4 {
            color: var(--turkey-red);
            margin-bottom: 25px;
            font-size: 1.3rem;
        }
        
        .footer-links {
            list-style: none;
            text-align: <?php echo $text_align; ?>;
        }
        
        .footer-links li {
            margin-bottom: 12px;
        }
        
        .footer-links a {
            color: #ccc;
            text-decoration: none;
            transition: all 0.3s ease;
        }
        
        .footer-links a:hover {
            color: white;
            <?php echo ($direction == 'rtl') ? 'padding-right: 10px;' : 'padding-left: 10px;'; ?>
        }
        
        .social-links {
            display: flex;
            gap: 15px;
            margin-top: 20px;
        }
        
        .social-link {
            width: 45px;
            height: 45px;
            background: #333;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            text-decoration: none;
            transition: all 0.3s ease;
        }
        
        .social-link:hover {
            background: var(--turkey-red);
            transform: translateY(-5px);
        }
        
        .copyright {
            text-align: center;
            padding-top: 40px;
            margin-top: 40px;
            border-top: 1px solid #333;
            color: #888;
            font-size: 0.9rem;
        }
        
        /* انیمیشن برای تایپ کردن */
        .typing-animation {
            display: inline-block;
            overflow: hidden;
            white-space: nowrap;
            <?php echo ($direction == 'rtl') ? 'border-left' : 'border-right'; ?>: 3px solid #FFD700;
            animation: typing 3.5s steps(30, end), blink-caret 0.75s step-end infinite;
        }
        
        @keyframes typing {
            from { width: 0 }
            to { width: 100% }
        }
        
        @keyframes blink-caret {
            from, to { border-color: transparent }
            50% { border-color: #FFD700 }
        }
        
        /* Responsive Design */
        @media (max-width: 768px) {
            .about-header h1 {
                font-size: 2.5rem;
            }
            
            .about-header {
                padding: 60px 20px 40px;
            }
            
            .vision-section,
            .tech-stack {
                padding: 30px;
            }
            
            .timeline-section::before {
                <?php echo ($direction == 'rtl') ? 'right: 20px;' : 'left: 20px'; ?>;
            }
            
            .timeline-item {
                width: calc(100% - 50px);
            }
            
            .timeline-item:nth-child(odd) {
                <?php echo ($direction == 'rtl') ? 'margin-right: 50px;' : 'margin-left: 50px;'; ?>
            }
            
            .timeline-item:nth-child(odd) .timeline-dot {
                <?php echo ($direction == 'rtl') ? 'left: auto; right: -45px;' : 'right: auto; left: -45px;'; ?>
            }
            
            .timeline-item:nth-child(even) {
                <?php echo ($direction == 'rtl') ? 'margin-left: 50px;' : 'margin-right: 50px;'; ?>
            }
            
            .timeline-item:nth-child(even) .timeline-dot {
                <?php echo ($direction == 'rtl') ? 'right: auto; left: -45px;' : 'left: auto; right: -45px;'; ?>
            }
            
            .cta-buttons {
                flex-direction: column;
                align-items: center;
            }
            
            .cta-btn {
                width: 100%;
                max-width: 300px;
            }
            
            .back-btn span,
            .language-btn span {
                display: none;
            }
            
            .back-btn,
            .language-btn {
                padding: 12px;
            }
        }
        
        @media (max-width: 480px) {
            .about-header h1 {
                font-size: 2rem;
            }
            
            .section-title {
                font-size: 2rem;
            }
            
            .feature-card {
                padding: 30px 20px;
            }
            
            .stats-grid {
                grid-template-columns: repeat(2, 1fr);
            }
            
            .stat-number {
                font-size: 2.5rem;
            }
        }
        
        /* Animations */
        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }
        
        @keyframes fadeInDown {
            from { opacity: 0; transform: translateY(-30px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        @keyframes fadeInUp {
            from { opacity: 0; transform: translateY(30px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        @keyframes fadeInLeft {
            from { opacity: 0; transform: translateX(<?php echo $direction == 'rtl' ? '30px' : '-30px'; ?>); }
            to { opacity: 1; transform: translateX(0); }
        }
        
        @keyframes fadeInRight {
            from { opacity: 0; transform: translateX(<?php echo $direction == 'rtl' ? '-30px' : '30px'; ?>); }
            to { opacity: 1; transform: translateX(0); }
        }
        
        .animate-on-scroll {
            opacity: 0;
            transform: translateY(30px);
            transition: all 0.8s ease;
        }
        
        .animate-on-scroll.visible {
            opacity: 1;
            transform: translateY(0);
        }
        
        /* حالت تاریک */
        @media (prefers-color-scheme: dark) {
            body {
                background: #121212;
                color: #eee;
            }
            
            .vision-section,
            .feature-card,
            .timeline-content,
            .tech-stack,
            .team-card {
                background: #222;
                color: #eee;
                border-color: #444;
            }
            
            .feature-card:hover,
            .team-card:hover {
                background: #333;
            }
            
            .tech-item {
                background: #333;
                color: #eee;
            }
            
            .tech-item:hover {
                background: #444;
            }
            
            .vision-text,
            .team-role {
                color: #ccc;
            }
            
            .language-dropdown {
                background: #333;
                border-color: #555;
            }
            
            .language-dropdown a {
                color: #ddd;
                border-bottom-color: #444;
            }
            
            .language-dropdown a:hover {
                background: var(--turkey-red);
                color: white;
            }
        }
    </style>
</head>
<body>
    <!-- المان‌های تزئینی پرچم ترکیه -->
    <div class="turkey-background"></div>
    <div class="crescent-star"></div>
    <div class="crescent-star"></div>
    
    <!-- Header Section -->
    <header class="about-header">
        <!-- دکمه بازگشت -->
        <div class="back-nav">
            <a href="<?php echo $base_url; ?>" class="back-btn">
                <?php if($direction == 'rtl'): ?>
                    <i class="fas fa-arrow-right"></i>
                <?php else: ?>
                    <i class="fas fa-arrow-left"></i>
                <?php endif; ?>
                <span><?php echo t('back_button'); ?></span>
            </a>
        </div>
        
        <!-- دکمه زبان -->
        <div class="language-switcher">
            <button class="language-btn">
                <i class="fas fa-globe"></i>
                <span>
                    <?php 
                    $language_names = [
                        'tr' => 'Türkçe',
                        'fa' => 'فارسی',
                        'en' => 'English',
                        'ar' => 'العربية'
                    ];
                    echo $language_names[$current_lang];
                    ?>
                </span>
                <i class="fas fa-chevron-<?php echo $direction == 'rtl' ? 'up' : 'down'; ?>"></i>
            </button>
            <div class="language-dropdown">
                <a href="?lang=tr"><span style="margin-<?php echo $direction == 'rtl' ? 'right' : 'left'; ?>: 8px;">🇹🇷</span> Türkçe</a>
                <a href="?lang=fa"><span style="margin-<?php echo $direction == 'rtl' ? 'right' : 'left'; ?>: 8px;">🇮🇷</span> فارسی</a>
                <a href="?lang=en"><span style="margin-<?php echo $direction == 'rtl' ? 'right' : 'left'; ?>: 8px;">🇬🇧</span> English</a>
                <a href="?lang=ar"><span style="margin-<?php echo $direction == 'rtl' ? 'right' : 'left'; ?>: 8px;">🇸🇦</span> العربية</a>
            </div>
        </div>
        
        <!-- لوگو و عنوان -->
        <div class="logo-container">
            <div class="about-logo">
                <i class="fas fa-mosque"></i>
            </div>
            <h1><?php echo t('welcome_title'); ?></h1>
            <p><?php echo t('welcome_subtitle'); ?></p>
            
            <div class="about-tagline">
                <span><i class="fas fa-star"></i> <?php echo t('tagline1'); ?></span>
                <span><i class="fas fa-heart"></i> <?php echo t('tagline2'); ?></span>
                <span><i class="fas fa-globe"></i> <?php echo t('tagline3'); ?></span>
            </div>
        </div>
    </header>
    
    <!-- Main Content -->
    <main class="about-content">
        <!-- Vision Section -->
        <section class="vision-section animate-on-scroll">
            <h2 class="section-title"><?php echo t('vision_title'); ?></h2>
            <p class="vision-text">
                <?php echo t('vision_text1'); ?>
            </p>
            <p class="vision-text">
                <?php echo t('vision_text2'); ?>
            </p>
        </section>
        
        <!-- Key Features -->
        <section class="animate-on-scroll">
            <h2 class="section-title" style="text-align: center; margin-bottom: 50px;"><?php echo t('features_title'); ?></h2>
            <div class="features-grid">
                <div class="feature-card">
                    <div class="feature-icon">
                        <i class="fas fa-map-marked-alt"></i>
                    </div>
                    <h3><?php echo t('feature1_title'); ?></h3>
                    <p><?php echo t('feature1_desc'); ?></p>
                </div>
                
                <div class="feature-card">
                    <div class="feature-icon">
                        <i class="fas fa-robot"></i>
                    </div>
                    <h3><?php echo t('feature2_title'); ?></h3>
                    <p><?php echo t('feature2_desc'); ?></p>
                </div>
                
                <div class="feature-card">
                    <div class="feature-icon">
                        <i class="fas fa-vr-cardboard"></i>
                    </div>
                    <h3><?php echo t('feature3_title'); ?></h3>
                    <p><?php echo t('feature3_desc'); ?></p>
                </div>
                
                <div class="feature-card">
                    <div class="feature-icon">
                        <i class="fas fa-magic"></i>
                    </div>
                    <h3><?php echo t('feature4_title'); ?></h3>
                    <p><?php echo t('feature4_desc'); ?></p>
                </div>
                
                <div class="feature-card">
                    <div class="feature-icon">
                        <i class="fas fa-language"></i>
                    </div>
                    <h3><?php echo t('feature5_title'); ?></h3>
                    <p><?php echo t('feature5_desc'); ?></p>
                </div>
                
                <div class="feature-card">
                    <div class="feature-icon">
                        <i class="fas fa-mobile-alt"></i>
                    </div>
                    <h3><?php echo t('feature6_title'); ?></h3>
                    <p><?php echo t('feature6_desc'); ?></p>
                </div>
            </div>
        </section>
        
        <!-- Timeline -->
        <section class="timeline-section animate-on-scroll">
            <!--<h2 class="section-title" style="text-align: center; margin-bottom: 60px;"><?php echo t('timeline_title'); ?></h2>-->
            
            <div class="timeline-item">
                <div class="timeline-dot"></div>
                <div class="timeline-content">
                    <div class="timeline-date">
                        <i class="fas fa-calendar-alt"></i>
                        <?php echo t('timeline1_date'); ?>
                    </div>
                    <h3><?php echo t('timeline1_title'); ?></h3>
                    <p><?php echo t('timeline1_desc'); ?></p>
                </div>
            </div>
            
            <div class="timeline-item">
                <div class="timeline-dot"></div>
                <div class="timeline-content">
                    <div class="timeline-date">
                        <i class="fas fa-calendar-alt"></i>
                        <?php echo t('timeline2_date'); ?>
                    </div>
                    <h3><?php echo t('timeline2_title'); ?></h3>
                    <p><?php echo t('timeline2_desc'); ?></p>
                </div>
            </div>
            
            <div class="timeline-item">
                <div class="timeline-dot"></div>
                <div class="timeline-content">
                    <div class="timeline-date">
                        <i class="fas fa-calendar-alt"></i>
                        <?php echo t('timeline3_date'); ?>
                    </div>
                    <h3><?php echo t('timeline3_title'); ?></h3>
                    <p><?php echo t('timeline3_desc'); ?></p>
                </div>
            </div>
            
            <div class="timeline-item">
                <div class="timeline-dot"></div>
                <div class="timeline-content">
                    <div class="timeline-date">
                        <i class="fas fa-calendar-alt"></i>
                        <?php echo t('timeline4_date'); ?>
                    </div>
                    <h3><?php echo t('timeline4_title'); ?></h3>
                    <p><?php echo t('timeline4_desc'); ?></p>
                </div>
            </div>
            
            <div class="timeline-item">
                <div class="timeline-dot"></div>
                <div class="timeline-content">
                    <div class="timeline-date">
                        <i class="fas fa-calendar-alt"></i>
                        <?php echo t('timeline5_date'); ?>
                    </div>
                    <h3><?php echo t('timeline5_title'); ?></h3>
                    <p><?php echo t('timeline5_desc'); ?></p>
                </div>
            </div>
        </section>
        
        <!-- Statistics -->
        <section class="stats-section animate-on-scroll">
            <h2 style="color: white; font-size: 2.5rem; margin-bottom: 50px;"><?php echo t('stats_title'); ?></h2>
            <div class="stats-grid">
                <div class="stat-item">
                    <div class="stat-number">۱۲۵+</div>
                    <div class="stat-label"><?php echo t('stat1_label'); ?></div>
                </div>
                <div class="stat-item">
                    <div class="stat-number">۵۰۰+</div>
                    <div class="stat-label"><?php echo t('stat2_label'); ?></div>
                </div>
                <div class="stat-item">
                    <div class="stat-number">۸۰۰+</div>
                    <div class="stat-label"><?php echo t('stat3_label'); ?></div>
                </div>
                <div class="stat-item">
                    <div class="stat-number">۱۰۰٪</div>
                    <div class="stat-label"><?php echo t('stat4_label'); ?></div>
                </div>
                <div class="stat-item">
                    <div class="stat-number">۲۴/۷</div>
                    <div class="stat-label"><?php echo t('stat5_label'); ?></div>
                </div>
                <div class="stat-item">
                    <div class="stat-number">۵+</div>
                    <div class="stat-label"><?php echo t('stat6_label'); ?></div>
                </div>
            </div>
        </section>
        
        <!-- Technology Stack -->
        <section class="tech-stack animate-on-scroll">
            <h2 class="section-title"><?php echo t('tech_title'); ?></h2>
            <p class="vision-text" style="margin-bottom: 40px;">
                <?php echo t('tech_desc'); ?>
            </p>
            
            <div class="tech-grid">
                <div class="tech-item">
                    <div class="tech-icon">
                        <i class="fab fa-php"></i>
                    </div>
                    <h4>PHP 8.2</h4>
                </div>
                
                <div class="tech-item">
                    <div class="tech-icon">
                        <i class="fab fa-js"></i>
                    </div>
                    <h4>JavaScript ES6+</h4>
                </div>
                
                <div class="tech-item">
                    <div class="tech-icon">
                        <i class="fas fa-database"></i>
                    </div>
                    <h4>MySQL</h4>
                </div>
                
                <div class="tech-item">
                    <div class="tech-icon">
                        <i class="fab fa-html5"></i>
                    </div>
                    <h4>HTML5</h4>
                </div>
                
                <div class="tech-item">
                    <div class="tech-icon">
                        <i class="fab fa-css3-alt"></i>
                    </div>
                    <h4>CSS3</h4>
                </div>
                
                <div class="tech-item">
                    <div class="tech-icon">
                        <i class="fas fa-map"></i>
                    </div>
                    <h4>Leaflet.js</h4>
                </div>
                
                <div class="tech-item">
                    <div class="tech-icon">
                        <i class="fas fa-chart-line"></i>
                    </div>
                    <h4>Chart.js</h4>
                </div>
                
                <div class="tech-item">
                    <div class="tech-icon">
                        <i class="fab fa-bootstrap"></i>
                    </div>
                    <h4>Bootstrap 5</h4>
                </div>
            </div>
        </section>
        
        <!-- Team Section -->
        <section class="team-section animate-on-scroll">
            <h2 class="section-title" style="text-align: center;"><?php echo t('team_title'); ?></h2>
            <p class="vision-text" style="text-align: center; max-width: 800px; margin: 20px auto 50px;">
                <?php echo t('team_desc'); ?>
            </p>
            
            <div class="team-grid">
                <div class="team-card">
                    <div class="team-avatar">
                        <img src="assets/1770752253444.jpg" alt="<?php echo t('team1_name'); ?>">
                    </div>
                    <div class="team-info">
                        <h4><?php echo t('team1_name'); ?></h4>
                        <p class="team-role"><?php echo t('team1_role'); ?></p>
                        <p><?php echo t('team1_desc'); ?></p>
                    </div>
                </div>
                
                <div class="team-card">
                    <div class="team-avatar">
                        <img src="assets/1770726466226.jpg" alt="<?php echo t('team2_name'); ?>">
                    </div>
                    <div class="team-info">
                        <h4><?php echo t('team2_name'); ?></h4>
                        <p class="team-role"><?php echo t('team2_role'); ?></p>
                        <p><?php echo t('team2_desc'); ?></p>
                    </div>
                </div>
                
                <div class="team-card">
                    <div class="team-avatar">
                        <img src="assets/1770721138189.jpg" alt="<?php echo t('team3_name'); ?>">
                    </div>
                    <div class="team-info">
                        <h4><?php echo t('team3_name'); ?></h4>
                        <p class="team-role"><?php echo t('team3_role'); ?></p>
                        <p><?php echo t('team3_desc'); ?></p>
                    </div>
                </div>
                
                <div class="team-card">
                    <div class="team-avatar">
                        <img src="assets/1770760027775.jpg" alt="<?php echo t('team4_name'); ?>">
                    </div>
                    <div class="team-info">
                        <h4><?php echo t('team4_name'); ?></h4>
                        <p class="team-role"><?php echo t('team4_role'); ?></p>
                        <p><?php echo t('team4_desc'); ?></p>
                    </div>
                </div>
            </div>
        </section>
        
        <!-- Call to Action -->
        <section class="cta-section animate-on-scroll">
            <div style="position: relative; z-index: 2;">
                <h2 class="cta-title"><?php echo t('cta_title'); ?></h2>
                <p style="font-size: 1.2rem; max-width: 700px; margin: 0 auto; color: #555;">
                    <?php echo t('cta_desc'); ?>
                </p>
                
                <div class="cta-buttons">
                    <a href="<?php echo $base_url; ?>" class="cta-btn cta-primary">
                        <i class="fas fa-play-circle"></i>
                        <?php echo t('cta_btn1'); ?>
                    </a>
                    <a href="#contact" class="cta-btn cta-secondary">
                        <i class="fas fa-envelope"></i>
                        <?php echo t('cta_btn2'); ?>
                    </a>
                </div>
            </div>
        </section>
    </main>
    
    <!-- Footer -->
    <footer class="about-footer" id="contact">
        <div class="footer-content">
            <div class="footer-col">
                <h4><?php echo t('welcome_title'); ?></h4>
                <p><?php echo t('footer_about'); ?></p>
                
                <div class="social-links">
                    <a href="#" class="social-link">
                        <i class="fab fa-instagram"></i>
                    </a>
                    <a href="#" class="social-link">
                        <i class="fab fa-telegram"></i>
                    </a>
                    <a href="#" class="social-link">
                        <i class="fab fa-twitter"></i>
                    </a>
                    <a href="#" class="social-link">
                        <i class="fab fa-youtube"></i>
                    </a>
                </div>
            </div>
            
            <div class="footer-col">
                <h4><?php echo t('footer_links_title'); ?></h4>
                <ul class="footer-links">
                    <li><a href="<?php echo $base_url; ?>"><?php echo t('footer_link1'); ?></a></li>
                    <li><a href="#discover"><?php echo t('footer_link2'); ?></a></li>
                    <li><a href="#hotels"><?php echo t('footer_link3'); ?></a></li>
                    <li><a href="#experiences"><?php echo t('footer_link4'); ?></a></li>
                    <li><a href="#itinerary"><?php echo t('footer_link5'); ?></a></li>
                </ul>
            </div>
            
            <div class="footer-col">
                <h4><?php echo t('footer_contact_title'); ?></h4>
                <ul class="footer-links">
                    <li><i class="fas fa-envelope"></i> <?php echo t('email'); ?></li>
                    <li><i class="fas fa-phone"></i> <?php echo t('phone'); ?></li>
                    <li><i class="fas fa-map-marker-alt"></i> <?php echo t('address'); ?></li>
                </ul>
            </div>
            
            <div class="footer-col">
                <h4><?php echo t('footer_newsletter_title'); ?></h4>
                <p><?php echo t('footer_newsletter_desc'); ?></p>
                <form id="footerNewsletter" style="margin-top: 20px;">
                    <div class="input-group" style="display: flex; gap: 10px;">
                        <input type="email" placeholder="<?php echo t('footer_placeholder'); ?>" style="flex: 1; padding: 12px; border-radius: 8px; border: none;">
                        <button type="submit" style="background: var(--turkey-red); color: white; border: none; padding: 12px 20px; border-radius: 8px; cursor: pointer;">
                            <i class="fas fa-paper-plane"></i>
                        </button>
                    </div>
                </form>
            </div>
        </div>
        
        <div class="copyright">
            <p>© <?php echo date('Y'); ?> Istanbul Guide. <?php echo t('copyright'); ?></p>
            <p style="margin-top: 10px;"><?php echo t('copyright_note'); ?></p>
        </div>
    </footer>
    
    <!-- JavaScript -->
    <script>
        // انیمیشن اسکرول
        document.addEventListener('DOMContentLoaded', function() {
            const observerOptions = {
                threshold: 0.1,
                rootMargin: '0px 0px -50px 0px'
            };
            
            const observer = new IntersectionObserver((entries) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        entry.target.classList.add('visible');
                    }
                });
            }, observerOptions);
            
            document.querySelectorAll('.animate-on-scroll').forEach((el) => {
                observer.observe(el);
            });
            
            // نمایش پیام خوش‌آمد
            console.log('🌟 Istanbul Guide - <?php echo t('page_title'); ?> 🌟');
            console.log('🌐 Current Language: <?php echo $current_lang; ?>');
            console.log('🎨 Design: <?php echo t('team4_name'); ?>');
            console.log('🚀 Version: 3.0.0');
        });
        
        // فرم خبرنامه
        document.getElementById('footerNewsletter').addEventListener('submit', function(e) {
            e.preventDefault();
            const email = this.querySelector('input[type="email"]').value;
            
            // اینجا می‌توانید API call اضافه کنید
            alert('<?php echo $current_lang == "fa" ? "عضویت در خبرنامه با موفقیت انجام شد!" : ($current_lang == "tr" ? "Bültene başarıyla abone olundu!" : ($current_lang == "ar" ? "تم الاشتراك في النشرة الإخبارية بنجاح!" : "Successfully subscribed to newsletter!")); ?>');
            this.querySelector('input[type="email"]').value = '';
        });
        
        // اسکرول نرم
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function(e) {
                e.preventDefault();
                
                const targetId = this.getAttribute('href');
                if (targetId === '#') return;
                
                const targetElement = document.querySelector(targetId);
                if (targetElement) {
                    window.scrollTo({
                        top: targetElement.offsetTop - 80,
                        behavior: 'smooth'
                    });
                }
            });
        });
        
        // تابع تغییر زبان
        function changeLanguage(lang) {
            console.log('Changing language to:', lang);
            window.location.href = '?lang=' + lang;
        }
        
        // مدیریت دکمه‌های زبان
        document.querySelectorAll('.language-dropdown a').forEach(link => {
            link.addEventListener('click', function(e) {
                e.preventDefault();
                const lang = this.getAttribute('href').split('=')[1];
                changeLanguage(lang);
            });
        });
    </script>
</body>
</html>
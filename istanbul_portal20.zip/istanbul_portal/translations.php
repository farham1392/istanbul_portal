<?php
$translations = [
    'fa' => [
        'about_project' => 'درباره پروژه',
        'back_to_home' => 'بازگشت به خانه',
        'about_description' => 'یک پروژه نمایشی برای راهنمای گردشگری استانبول',
        'multilingual' => 'چندزبانه',
        'multilingual_desc' => 'پشتیبانی از ۴ زبان مختلف',
        'interactive_map' => 'نقشه تعاملی',
        'interactive_map_desc' => 'نقشه‌های زنده با موقعیت‌یابی',
        'ai_assistant' => 'دستیار هوشمند',
        'ai_assistant_desc' => 'پاسخگویی خودکار به سوالات',
        'project_details' => 'جزئیات پروژه',
        'project_full_desc' => 'این پروژه یک راهنمای گردشگری کامل برای شهر استانبول است که با استفاده از تکنولوژی‌های مدرن وب توسعه یافته است. هدف اصلی این پروژه نمایش قابلیت‌های مختلف در توسعه وب و ایجاد یک تجربه کاربری عالی برای گردشگران است.',
        'technologies_used' => 'تکنولوژی‌های استفاده شده',
        'features' => 'ویژگی‌ها',
        'feature1' => 'سیستم چندزبانه کامل',
        'feature2' => 'طراحی واکنش‌گرا',
        'feature3' => 'پنل مدیریت محتوا',
        'feature4' => 'API کامل برای توسعه‌دهندگان',
        'feature5' => 'سیستم جستجوی پیشرفته',
        'feature6' => 'سیستم رزرو آنلاین'
    ],
    'en' => [
        'about_project' => 'About Project',
        'back_to_home' => 'Back to Home',
        'about_description' => 'A demo project for Istanbul travel guide',
        'multilingual' => 'Multilingual',
        'multilingual_desc' => 'Support for 4 different languages',
        'interactive_map' => 'Interactive Map',
        'interactive_map_desc' => 'Live maps with geolocation',
        'ai_assistant' => 'AI Assistant',
        'ai_assistant_desc' => 'Automatic response to questions',
        'project_details' => 'Project Details',
        'project_full_desc' => 'This project is a complete travel guide for Istanbul city, developed using modern web technologies. The main goal of this project is to demonstrate various web development capabilities and create an excellent user experience for tourists.',
        'technologies_used' => 'Technologies Used',
        'features' => 'Features',
        'feature1' => 'Complete multilingual system',
        'feature2' => 'Responsive design',
        'feature3' => 'Content management panel',
        'feature4' => 'Complete API for developers',
        'feature5' => 'Advanced search system',
        'feature6' => 'Online booking system'
    ],
    'tr' => [
        'about_project' => 'Proje Hakkında',
        'back_to_home' => 'Ana Sayfaya Dön',
        'about_description' => 'İstanbul seyahat rehberi için demo proje',
        'multilingual' => 'Çok Dilli',
        'multilingual_desc' => '4 farklı dil desteği',
        'interactive_map' => 'Etkileşimli Harita',
        'interactive_map_desc' => 'Konum bulma özelliği ile canlı haritalar',
        'ai_assistant' => 'AI Asistanı',
        'ai_assistant_desc' => 'Sorulara otomatik yanıt',
        'project_details' => 'Proje Detayları',
        'project_full_desc' => 'Bu proje, modern web teknolojileri kullanılarak geliştirilmiş İstanbul şehri için tam bir seyahat rehberidir. Bu projenin temel amacı, çeşitli web geliştirme yeteneklerini göstermek ve turistler için mükemmel bir kullanıcı deneyimi yaratmaktır.',
        'technologies_used' => 'Kullanılan Teknolojiler',
        'features' => 'Özellikler',
        'feature1' => 'Tam çok dilli sistem',
        'feature2' => 'Duyarlı tasarım',
        'feature3' => 'İçerik yönetim paneli',
        'feature4' => 'Geliştiriciler için tam API',
        'feature5' => 'Gelişmiş arama sistemi',
        'feature6' => 'Online rezervasyon sistemi'
    ],
    'ar' => [
        'about_project' => 'حول المشروع',
        'back_to_home' => 'العودة إلى الرئيسية',
        'about_description' => 'مشروع تجريبي لدليل السفر في إسطنبول',
        'multilingual' => 'متعدد اللغات',
        'multilingual_desc' => 'دعم 4 لغات مختلفة',
        'interactive_map' => 'خريطة تفاعلية',
        'interactive_map_desc' => 'خرائط حية مع تحديد الموقع',
        'ai_assistant' => 'مساعد ذكي',
        'ai_assistant_desc' => 'رد تلقائي على الأسئلة',
        'project_details' => 'تفاصيل المشروع',
        'project_full_desc' => 'هذا المشروع هو دليل سفر كامل لمدينة إسطنبول، تم تطويره باستخدام تقنيات الويب الحديثة. الهدف الرئيسي من هذا المشروع هو إظهار قدرات تطوير الويب المختلفة وإنشاء تجربة مستخدم ممتازة للسياح.',
        'technologies_used' => 'التقنيات المستخدمة',
        'features' => 'المميزات',
        'feature1' => 'نظام متعدد اللغات كامل',
        'feature2' => 'تصميم متجاوب',
        'feature3' => 'لوحة إدارة المحتوى',
        'feature4' => 'واجهة برمجة تطبيقات كاملة للمطورين',
        'feature5' => 'نظام بحث متقدم',
        'feature6' => 'نظام حجز عبر الإنترنت'
    ]
];

function t($key) {
    global $translations, $current_language;
    return $translations[$current_language][$key] ?? $key;
}
?>
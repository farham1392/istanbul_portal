<?php
class DeepSeekAI_Simple {
    private $apiKey;
    private $apiUrl = 'https://api.deepseek.com/v1/chat/completions';
    
    public function __construct($apiKey = null) {
        // اگر API Key مستقیماً داده شده باشد
        if ($apiKey) {
            $this->apiKey = $apiKey;
        } 
        // در غیر این صورت از فایل پیکربندی بخوان
        else {
            $configFile = __DIR__ . '/../config/api_keys.php';
            
            if (file_exists($configFile)) {
                try {
                    $config = require $configFile;
                    
                    if (isset($config['deepseek']['api_key'])) {
                        $this->apiKey = $config['deepseek']['api_key'];
                    } else {
                        throw new Exception('API Key در فایل پیکربندی یافت نشد');
                    }
                } catch (Exception $e) {
                    throw new Exception('خطا در خواندن فایل پیکربندی: ' . $e->getMessage());
                }
            } else {
                throw new Exception('فایل پیکربندی یافت نشد: ' . $configFile);
            }
        }
        
        // بررسی اینکه API Key ست شده باشد
        if (empty($this->apiKey) || $this->apiKey === 'sk-3eb5a3567ceb4e1fb2738e835a89fc55') {
            throw new Exception('لطفاً API Key معتبر DeepSeek را در فایل پیکربندی قرار دهید');
        }
    }
    
    public function chat($message) {
        // پیام سیستم
        $systemMessage = "شما IstanbulAI هستید، یک دستیار هوشمند برای راهنمایی گردشگران در استانبول. به زبان فارسی پاسخ دهید.";
        
        // آماده‌سازی داده‌ها
        $data = [
            'model' => 'deepseek-chat',
            'messages' => [
                [
                    'role' => 'system',
                    'content' => $systemMessage
                ],
                [
                    'role' => 'user',
                    'content' => $message
                ]
            ],
            'temperature' => 0.7,
            'max_tokens' => 1000,
            'stream' => false
        ];
        
        // ارسال درخواست
        return $this->sendRequest($data);
    }
    
    private function sendRequest($data) {
        // هدرها
        $headers = [
            'Content-Type: application/json',
            'Authorization: Bearer ' . $this->apiKey,
            'Accept: application/json'
        ];
        
        // تنظیمات cURL
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $this->apiUrl);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_TIMEOUT, 30); // 30 ثانیه تایم‌اوت
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true); // برای SSL
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);
        
        // برای دیباگ (فعال کردن در صورت نیاز)
        curl_setopt($ch, CURLOPT_VERBOSE, true);
        $verbose = fopen('php://temp', 'w+');
        curl_setopt($ch, CURLOPT_STDERR, $verbose);
        
        // اجرای درخواست
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error = curl_error($ch);
        curl_close($ch);
        
        // بازگرداندن verbose برای دیباگ
        rewind($verbose);
        $verboseLog = stream_get_contents($verbose);
        fclose($verbose);
        
        // لاگ برای دیباگ
        error_log("DeepSeek API Request - HTTP Code: $httpCode");
        error_log("Response: " . substr($response, 0, 500));
        
        if ($error) {
            error_log("cURL Error: " . $error);
            return [
                'success' => false,
                'error' => 'خطای ارتباطی: ' . $error,
                'http_code' => $httpCode
            ];
        }
        
        if ($httpCode !== 200) {
            return [
                'success' => false,
                'error' => "خطای HTTP: $httpCode",
                'response' => $response,
                'http_code' => $httpCode
            ];
        }
        
        // پردازش پاسخ
        $decodedResponse = json_decode($response, true);
        
        if (json_last_error() !== JSON_ERROR_NONE) {
            return [
                'success' => false,
                'error' => 'خطا در پردازش پاسخ JSON: ' . json_last_error_msg(),
                'raw_response' => $response
            ];
        }
        
        if (isset($decodedResponse['choices'][0]['message']['content'])) {
            return [
                'success' => true,
                'response' => $decodedResponse['choices'][0]['message']['content'],
                'full_response' => $decodedResponse
            ];
        } else {
            return [
                'success' => false,
                'error' => 'پاسخ نامعتبر از API',
                'api_response' => $decodedResponse
            ];
        }
    }
}
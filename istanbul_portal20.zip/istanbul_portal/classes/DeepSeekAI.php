<?php
class DeepSeekAI {
    private $apiKey;
    private $apiUrl;
    private $model;
    private $temperature;
    private $maxTokens;
    
    public function __construct() {
        $config = require __DIR__ . '/../config/api_keys.php';
        $deepseekConfig = $config['deepseek'];
        
        $this->apiKey = $deepseekConfig['api_key'];
        $this->apiUrl = $deepseekConfig['api_url'];
        $this->model = $deepseekConfig['model'];
        $this->temperature = $deepseekConfig['temperature'];
        $this->maxTokens = $deepseekConfig['max_tokens'];
    }
    
    /**
     * ارسال درخواست به DeepSeek API
     */
    public function chat($message, $context = [], $userId = null) {
        // آماده کردن پیام‌ها
        $messages = $this->prepareMessages($message, $context);
        
        // داده‌های درخواست
        $requestData = [
            'model' => $this->model,
            'messages' => $messages,
            'temperature' => $this->temperature,
            'max_tokens' => $this->maxTokens,
            'stream' => false
        ];
        
        // ارسال درخواست
        $response = $this->sendRequest($requestData);
        
        // پردازش پاسخ
        if ($response && isset($response['choices'][0]['message']['content'])) {
            $aiResponse = $response['choices'][0]['message']['content'];
            
            // ذخیره مکالمه در دیتابیس
            $this->saveConversation($userId, $message, $aiResponse);
            
            return [
                'success' => true,
                'response' => $aiResponse,
                'tokens_used' => $response['usage']['total_tokens'] ?? 0
            ];
        }
        
        return [
            'success' => false,
            'response' => 'متأسفانه در حال حاضر قادر به پاسخگویی نیستم. لطفاً دوباره تلاش کنید.',
            'error' => 'No response from AI'
        ];
    }
    
    /**
     * آماده‌سازی سیستم و تاریخچه مکالمه
     */
    private function prepareMessages($userMessage, $context = []) {
        $messages = [];
        
        // سیستم پروپت (نقش دستیار)
        $systemPrompt = $this->getSystemPrompt($context);
        $messages[] = [
            'role' => 'system',
            'content' => $systemPrompt
        ];
        
        // اضافه کردن تاریخچه مکالمه
        if (!empty($context['history'])) {
            foreach ($context['history'] as $chat) {
                $messages[] = [
                    'role' => $chat['role'],
                    'content' => $chat['content']
                ];
            }
        }
        
        // پیام کاربر
        $messages[] = [
            'role' => 'user',
            'content' => $userMessage
        ];
        
        return $messages;
    }
    
    /**
     * سیستم پروپت مخصوص راهنمای استانبول
     */
    private function getSystemPrompt($context) {
        $date = date('Y-m-d');
        $time = date('H:i');
        
        $prompt = "شما IstanbulAI هستید، یک دستیار هوشمند تخصصی برای راهنمایی گردشگران در استانبول.
        
        **هویت شما:**
        - نام: IstanbulAI (دستیار استانبول)
        - نقش: راهنمای تخصصی گردشگری استانبول
        - زبان: فارسی (با لحن گرم و دوستانه)
        - شخصیت: مفید، دقیق، صبور و خوش‌برخورد
        
        **تخصص‌های شما:**
        ۱. جاذبه‌های گردشگری استانبول
        ۲. هتل‌ها و اقامت‌گاه‌ها
        ۳. رستوران‌ها و غذاهای ترکی
        ۴. برنامه‌ریزی سفر
        ۵. فرهنگ و آداب معاشرت
        ۶. حمل و نقل شهری
        ۷. خرید و بازارها
        ۸. رویدادها و فستیوال‌ها
        
        **قوانین پاسخگویی:**
        ۱. همیشه پاسخ‌های دقیق و به‌روز بدهید
        ۲. اطلاعات را به صورت ساختاریافته ارائه دهید
        ۳. از اعداد، لیست‌ها و جدول‌ها استفاده کنید
        ۴. برای مکان‌ها آدرس دقیق و ساعت کاری ذکر کنید
        ۵. قیمت‌ها را به لیر ترکی و دلار اعلام کنید
        ۶. نکات ایمنی و احتیاطی را یادآوری کنید
        ۷. از emoji مناسب استفاده کنید (🎯🏨🍽️🗺️)
        ۸. اگر اطلاعاتی را نمی‌دانید، صادقانه بگویید
        
        **اطلاعات زمینه:**
        - تاریخ امروز: {$date}
        - ساعت: {$time}
        - کاربر در صفحه: {$context['current_page'] ?? 'صفحه اصلی'}
        - زبان کاربر: فارسی";
        
        return $prompt;
    }
    
    /**
     * ارسال درخواست به API
     */
    private function sendRequest($data) {
        $headers = [
            'Content-Type: application/json',
            'Authorization: Bearer ' . $this->apiKey
        ];
        
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $this->apiUrl);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);
        
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        if ($httpCode === 200) {
            return json_decode($response, true);
        }
        
        error_log("DeepSeek API Error: HTTP {$httpCode} - " . $response);
        return null;
    }
    
    /**
     * ذخیره مکالمه در دیتابیس
     */
    private function saveConversation($userId, $userMessage, $aiResponse) {
        global $db;
        
        if (!$userId) {
            $userId = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : null;
        }
        
        $data = [
            'user_id' => $userId,
            'session_id' => session_id(),
            'user_message' => $userMessage,
            'ai_response' => $aiResponse,
            'ip_address' => $_SERVER['REMOTE_ADDR'],
            'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? '',
            'created_at' => date('Y-m-d H:i:s')
        ];
        
        try {
            $db->insert('ai_conversations', $data);
        } catch (Exception $e) {
            error_log('Failed to save AI conversation: ' . $e->getMessage());
        }
    }
    
    /**
     * دریافت تاریخچه مکالمه کاربر
     */
    public function getConversationHistory($userId, $limit = 10) {
        global $db;
        
        if (!$userId) {
            $sessionId = session_id();
            return $db->select('ai_conversations', '*', [
                'session_id' => $sessionId,
                'ORDER' => ['created_at' => 'DESC'],
                'LIMIT' => $limit
            ]);
        }
        
        return $db->select('ai_conversations', '*', [
            'user_id' => $userId,
            'ORDER' => ['created_at' => 'DESC'],
            'LIMIT' => $limit
        ]);
    }
    
    /**
     * تحلیل احساسات پیام کاربر
     */
    public function analyzeSentiment($message) {
        $sentimentPrompt = "تحلیل احساسات این پیام را به صورت JSON برگردان:
        {
            \"sentiment\": \"positive/negative/neutral\",
            \"confidence\": 0.0-1.0,
            \"emotions\": [\"خوشحالی\", \"نگرانی\", ...],
            \"urgency\": \"low/medium/high\"
        }
        
        پیام: \"{$message}\"";
        
        $requestData = [
            'model' => $this->model,
            'messages' => [
                ['role' => 'system', 'content' => 'شما یک تحلیل‌گر احساسات هستید.'],
                ['role' => 'user', 'content' => $sentimentPrompt]
            ],
            'temperature' => 0.3,
            'max_tokens' => 500
        ];
        
        $response = $this->sendRequest($requestData);
        
        if ($response && isset($response['choices'][0]['message']['content'])) {
            $content = $response['choices'][0]['message']['content'];
            // استخراج JSON از پاسخ
            if (preg_match('/\{.*\}/s', $content, $matches)) {
                return json_decode($matches[0], true);
            }
        }
        
        return null;
    }
}
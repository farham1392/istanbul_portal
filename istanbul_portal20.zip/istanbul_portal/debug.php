<?php
// فعال کردن نمایش خطاها
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);

echo "=== شروع دیباگ ===<br><br>";

// 1. بررسی وجود کلاس
echo "1. بررسی فایل کلاس: ";
if (file_exists('classes/DeepSeekAI.php')) {
    echo "✅ فایل وجود دارد<br>";
    
    // بررسی سینتکس PHP
    $content = file_get_contents('classes/DeepSeekAI.php');
    if (strpos($content, '<?php') !== false) {
        echo "✅ سینتکس شروع PHP صحیح است<br>";
    } else {
        echo "❌ سینتکس شروع PHP مشکلی دارد<br>";
    }
} else {
    echo "❌ فایل classes/DeepSeekAI.php وجود ندارد<br>";
}

echo "<br>2. بررسی فایل پیکربندی: ";
if (file_exists('config/api_keys.php')) {
    echo "✅ فایل وجود دارد<br>";
    
    // تست خواندن فایل پیکربندی
    try {
        $config = require 'config/api_keys.php';
        if (isset($config['deepseek']['api_key'])) {
            echo "✅ API Key در تنظیمات وجود دارد<br>";
            echo "Key: " . substr($config['deepseek']['api_key'], 0, 10) . "...<br>";
        } else {
            echo "❌ API Key در تنظیمات وجود ندارد<br>";
        }
    } catch (Exception $e) {
        echo "❌ خطا در خواندن فایل پیکربندی: " . $e->getMessage() . "<br>";
    }
} else {
    echo "❌ فایل config/api_keys.php وجود ندارد<br>";
}

echo "<br>3. بررسی دسترسی به اینترنت و cURL: ";
if (function_exists('curl_version')) {
    echo "✅ cURL نصب شده است<br>";
    
    // تست اتصال به اینترنت
    $ch = curl_init('https://api.deepseek.com');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 5);
    $result = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    echo "کد وضعیت API DeepSeek: " . $httpCode . "<br>";
} else {
    echo "❌ cURL نصب نیست<br>";
}

echo "<br>4. بررسی دیتابیس: ";
try {
    // تست اتصال به دیتابیس (اگر نیاز است)
    $pdo = new PDO('mysql:host=localhost;dbname=test', 'username', 'password');
    echo "✅ اتصال به دیتابیس موفقیت‌آمیز<br>";
} catch (PDOException $e) {
    echo "⚠️ اتصال به دیتابیس: " . $e->getMessage() . "<br>";
}

echo "<br>=== پایان دیباگ ===<br>";
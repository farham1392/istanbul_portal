<?php

return [
    'deepseek' => [
        'api_key' => 'sk-3eb5a3567ceb4e1fb2738e835a89fc55',
        'api_url' => 'https://api.deepseek.com/v1/chat/completions',
        'model' => 'deepseek-chat', 
        'temperature' => 0.7,
        'max_tokens' => 2000
    ]
];
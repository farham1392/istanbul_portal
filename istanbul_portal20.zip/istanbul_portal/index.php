<?php
// Istanbul Guide Portal - Main Entry Point
session_start();

// Load translation system
require_once 'includes/Translation.php';

$translation = new Translation();

// Get current language from session or browser
$current_language = $translation->getLanguage();
$is_rtl = $translation->isRTL();

if (isset($_GET['lang'])) {
    $lang = $_GET['lang'];
    $translation->setLanguage($lang);
    // Redirect to remove lang parameter
    header('Location: ' . strtok($_SERVER['REQUEST_URI'], '?'));
    exit;
}

$languages = [
    'fa' => ['name' => 'فارسی', 'flag' => '🇮🇷', 'dir' => 'rtl'],
    'tr' => ['name' => 'Türkçe', 'flag' => '🇹🇷', 'dir' => 'ltr'],
    'en' => ['name' => 'English', 'flag' => '🇬🇧', 'dir' => 'ltr']
];
$_SESSION['language'] = $current_language;

// Initialize translation
$translation->setLanguage($current_language);

$current_theme = $_SESSION['theme'] ?? 'light';
$base_url = 'https://farhamzamani.com/istanbul/istanbul portal/istanbul_portal';
$api_base = $base_url . 'api/';

$turkey_red = '#E30A17';
$turkey_white = '#FFFFFF';
$turkey_crescent = '#DC143C';

// Database configuration
$db_config = [
    'host' => 'localhost',
    'name' => 'farhamza_istanbul_guide',
    'user' => 'farhamza_farham',
    'pass' => 'fz1392@@'
];

$db_connected = false;
try {
    $pdo = new PDO(
        "mysql:host={$db_config['host']};dbname={$db_config['name']};charset=utf8mb4",
        $db_config['user'],
        $db_config['pass']
    );
    $db_connected = true;
} catch(PDOException $e) {
    $db_connected = false;
}

// Get stats
if ($db_connected) {
    $stats = [
        'historical_places' => 125,
        'hotels' => 500,
        'restaurants' => 800,
        'undiscovered_areas' => 39
    ];
} else {
    $stats = [
        'historical_places' => 125,
        'hotels' => 500,
        'restaurants' => 800,
        'undiscovered_areas' => 39
    ];
}

$page_title = $translation->get('page_title');
$page_description = $translation->get('page_description');

$hotel_booking_links = [
    'https://www.booking.com/hotel/tr/hilton-istanbul-bomonti-amp-conference-center.html?aid=304142&label=gen173nr-10CAEoggI46AdIM1gEaDuIAQGYATO4ARfIAQzYAQPoAQH4AQGIAgGoAgG4AqPIrswGwAIB0gIkNTAzY2YxOWItZTAxZi00NTJkLTgzYWQtYzcxOWMyZmQxMTEw2AIB4AIB&sid=9a81fadab57f6e75303436ab54720fed&dest_id=453609&dest_type=hotel&dist=0&group_adults=2&group_children=0&hapos=4&hpos=4&no_rooms=1&req_adults=2&req_children=0&room1=A%2CA&sb_price_type=total&sr_order=popularity&srepoch=1770759249&srpvid=94319799d68a01c5&type=total&ucfs=1&',
    'https://www.booking.com/hotel/tr/four-seasons-istanbul-at-the-bosphorus.html?aid=304142&label=gen173nr-10CAEoggI46AdIM1gEaDuIAQGYATO4ARfIAQzYAQPoAQH4AQGIAgGoAgG4AqPIrswGwAIB0gIkNTAzY2YxOWItZTAxZi00NTJkLTgzYWQtYzcxOWMyZmQxMTEw2AIB4AIB&sid=9a81fadab57f6e75303436ab54720fed&dest_id=453609&dest_type=hotel&dist=0&group_adults=2&group_children=0&hapos=1&hpos=1&no_rooms=1&req_adults=2&req_children=0&room1=A%2CA&sb_price_type=total&sr_order=popularity&srepoch=1770759224&srpvid=94319799d68a01c5&type=total&ucfs=1&',
    'https://www.booking.com/hotel/tr/radisson-blu-istanbul-sisli.html?aid=304142&label=gen173nr-10CAEoggI46AdIM1gEaDuIAQGYATO4ARfIAQzYAQPoAQH4AQGIAgGoAgG4AqPIrswGwAIB0gIkNTAzY2YxOWItZTAxZi00NTJkLTgzYWQtYzcxOWMyZmQxMTEw2AIB4AIB&sid=9a81fadab57f6e75303436ab54720fed&dest_id=453609&dest_type=hotel&dist=0&group_adults=2&group_children=0&hapos=13&hpos=13&no_rooms=1&req_adults=2&req_children=0&room1=A%2CA&sb_price_type=total&sr_order=popularity&srepoch=1770759291&srpvid=94319799d68a01c5&type=total&ucfs=1&'
];

$attraction_files = [
    'galata.php',      // برج گالاتا
    'HagiaSophia.php',  // ایاصوفیه
    'Bigmarket.php'    // بازار بزرگ
];

// لینک‌های فایل‌های PHP برای مجازی تور
$virtual_tour_files = [
    'HagiaSofya.php',      // ایاصوفیه
    'BlueMosque.php',      // مسجد آبی
    'TopkapiPalace.php',   // کاخ توپکاپی
    'Bigmarket.php'        // بازار بزرگ
];

// Check if this is an AI chat request
if (isset($_POST['ai_chat']) && $_POST['ai_chat'] == '1') {
    // Process AI chat request internally
    header('Content-Type: application/json');
    $user_message = isset($_POST['message']) ? trim($_POST['message']) : '';
    
    // AI Knowledge Base - Only uses site data
    $ai_response = processAIChat($user_message, $current_language, $pdo);
    
    echo json_encode([
        'success' => true,
        'response' => $ai_response,
        'timestamp' => date('Y-m-d H:i:s')
    ]);
    exit;
}

// Check API request
$request_uri = $_SERVER['REQUEST_URI'];
$api_request = strpos($request_uri, '/api/') !== false;

if ($api_request) {
    $api_path = str_replace('/istanbul_portal/api/', '', $request_uri);
    $api_file = 'api/' . strtok($api_path, '?') . '.php';
    
    if (file_exists($api_file)) {
        require_once $api_file;
        exit;
    } else {
        http_response_code(404);
        echo json_encode(['error' => 'API endpoint not found']);
        exit;
    }
}

// AI Chat Processing Function with Complete Knowledge Base
function processAIChat($message, $language, $pdo) {
    // Convert message to lowercase for easier matching
    $lower_message = strtolower($message);
    
    // Comprehensive Knowledge Base for Istanbul
    $knowledge_base = [
        'fa' => [
            // تاریخ ترکیه و استانبول
            'history' => [
                'keywords' => ['تاریخ ترکیه', 'تاریخ استانبول', 'بیزانس', 'عثمانی', 'امپراتوری عثمانی', 
                              'کنستانتینوپل', 'قسطنطنیه', 'سلطان محمد فاتح', 'آتاتورک', 'جمهوری ترکیه',
                              'دوره بیزانس', 'روم شرقی', 'سلجوقیان', 'ترکان سلجوقی', 'فتح استانبول'],
                'response' => '📜 **تاریخ جامع استانبول و ترکیه:**
                
**دوره بیزانس (۳۳۰-۱۴۵۳ میلادی):**
• تأسیس: توسط کنستانتین بزرگ در سال ۳۳۰ میلادی
• نام: کنستانتینوپل (پایتخت امپراتوری روم شرقی)
• مهم‌ترین آثار: ایاصوفیا، دیوارهای قسطنطنیه، کاخ بزرگ
• دوره طلایی: زمان ژوستینیان اول (قرن ۶ میلادی)

**دوره عثمانی (۱۴۵۳-۱۹۲۲ میلادی):**
• فتح: توسط سلطان محمد فاتح در ۲۹ می ۱۴۵۳
• پایتخت: استانبول پایتخت امپراتوری عثمانی شد
• توسعه: ساخت مساجد، کاخ‌ها، بازارها و حمام‌ها
• اوج قدرت: قرن ۱۶ تحت حکومت سلیمان قانونی
• مهم‌ترین آثار: کاخ توپکاپی، مسجد سلیمانیه، مسجد آبی

**دوره جمهوری (از ۱۹۲۳):**
• تأسیس: توسط مصطفی کمال آتاتورک در ۲۹ اکتبر ۱۹۲۳
• پایتخت جدید: آنکارا (اما استانبول مرکز فرهنگی ماند)
• مدرنیزاسیون: اصلاحات آتاتورک برای غربی‌سازی
• امروز: بزرگترین شهر ترکیه با ۱۶ میلیون نفر جمعیت

**دوره‌های مهم:**
۱. دوره رومی (۶۶۷ ق.م - ۳۳۰ م)
۲. دوره بیزانسی (۳۳۰-۱۴۵۳)
۳. دوره عثمانی (۱۴۵۳-۱۹۲۲)
۴. دوره جمهوری (۱۹۲۳-اکنون)

**شخصیت‌های کلیدی:**
• سلطان محمد فاتح (فاتح استانبول)
• سلیمان قانونی (درخشان‌ترین دوره عثمانی)
• مصطفی کمال آتاتورک (بنیانگذار ترکیه مدرن)
• روكسانا (همسر محبوب سلیمان قانونی)'
            ],
            
            // محله‌های استانبول
            'neighborhoods' => [
                'keywords' => ['محله', 'محله‌های استانبول', 'سلطان احمد', 'بی‌اوغلو', 'کادیکوی', 
                              'بشیکتاش', 'شیشلی', 'فاتح', 'امین‌انو', 'باغچه‌لی‌اولر', 'سارییر',
                              'اورتاکوی', 'آرناووتکوی', 'چنگلکوی', 'اسکودار', 'بیکوز'],
                'response' => '🏙️ **محله‌های معروف استانبول:**

**منطقه اروپایی:**

**۱. سلطان احمد (Sultanahmet):**
• قلب تاریخی استانبول
• جاذبه‌ها: ایاصوفیا، مسجد آبی، کاخ توپکاپی
• جو: توریستی، تاریخی، پیاده‌روی عالی
• مناسب برای: تاریخ‌دوستان، اولین بازدید

**۲. بی‌اوغلو (Beyoğlu):**
• مرکز فرهنگی و هنری
• خیابان استقلال، برج گالاتا
• رستوران‌ها، کافه‌ها، گالری‌ها
• شب‌زنده‌داری معروف

**۳. بشیکتاش (Beşiktaş):**
• منطقه مدرن و شیک
• کاخ دلما‌باغچه، ورزشگاه اینونو
• زندگی شبانه، کافه‌های لوکس
• دانشگاه‌های معروف

**۴. شیشلی (Şişli):**
• مرکز خرید و کسب‌وکار
• برج تجارت استانبول (İş Kuleleri)
• مراکز خرید نیستانتاسی، جواهر
• زندگی مدرن شهری

**۵. فاتح (Fatih):**
• محله سنتی و مذهبی
• بازار بزرگ، دانشگاه استانبول
• زندگی محلی اصیل
• غذاهای ارزان و خوشمزه

**منطقه آسیایی:**

**۶. کادیکوی (Kadıköy):**
• قلب بخش آسیایی
• بازار محلی کادیکوی
• زندگی دانشجویی پررونق
• کافه‌های باحال، رستوران‌های دریایی

**۷. اسکودار (Üsküdar):**
• تاریخی و مذهبی
• مساجد زیبا، مناظر بسفر
• آرام‌تر از بخش اروپایی
• حمل‌ونقلی به‌روز

**۸. بیکوز (Beykoz):**
• سبز و آرام
• جنگل‌های بلگراد، قلعه آنادولو حصار
• ویلاهای لوکس، رستوران‌های ماهی
• دور از شلوغی شهر

**۹. اوسکودار (Üsküdar):**
• چهره سنتی استانبول
• میدان اوسکودار، مسجد شاهزاده
• حمل‌نقل آبی عالی
• منظره بی‌نظیر از مساجد

**محله‌های خاص:**

**۱۰. اورتاکوی (Ortaköy):**
• کنار پل بسفر
• کافه‌های کنار آب
• غروب خورشید معروف
• بازار دست‌سازها

**۱۱. امین‌انو (Eminönü):**
• تجاری و تاریخی
• بازار ادویه، اسکله‌ها
• ایستگاه تراموا
• خرید عمده

**۱۲. سارییر (Sarıyer):**
• شمالی‌ترین نقطه اروپایی
• روستاهای ماهیگیری
• طبیعت بکر
• رستوران‌های ماهی تازه'
            ],
            
            // رستوران‌ها و غذاها
            'restaurants_food' => [
                'keywords' => ['رستوران', 'غذا', 'غذای ترکی', 'کباب', 'باقلوا', 'دونر', 'صبحانه ترکی',
                              'لاهمجون', 'پیده', 'مزه', 'چی کفتا', 'آدانا کباب', 'کوفته', 'دلمه',
                              'سوپ', 'کونافه', 'لوکوم', 'بورک', 'ساج', 'سیز', 'کله‌پاچه'],
                'response' => '🍽️ **رستوران‌ها و غذاهای معروف استانبول:**

**دسته‌بندی رستوران‌ها:**

**۱. رستوران‌های لوکس:**
• **Mikla**: غذاهای مدرن ترکی - بالای هتل مارمارا
• **Neolokal**: ترکیبی از سنتی و مدرن - کاراکوی
• **Ulus 29**: منظره بسفر - بشیکتاش
• **360 Istanbul**: منظره ۳۶۰ درجه - بی‌اوغلو

**۲. رستوران‌های سنتی:**
• **Çiya Sofrası**: غذاهای محلی نادر - کادیکوی
• **Kanaat Lokantası**: غذاهای خانگی - اوسکودار
• **Hacı Abdullah**: از ۱۸۸۸ فعال - بی‌اوغلو
• **Beyti**: کباب معروف - فلوریا

**۳. رستوران‌های دریایی:**
• **Balıkçı Sabahattin**: ماهی تازه - سلطان احمد
• **Kiyi**: غذای دریایی عالی - تارابیا
• **Sur Balık**: منظره ایاصوفیا - امین‌انو

**۴. رستوران‌های خیابانی:**
• **Kızılkayalar**: همبرگر معروف - تکسیم
• **Bereket Döner**: دونر خوشمزه - بی‌اوغلو
• **Özcan Turşuları**: ترشی‌جات - کادیکوی

**غذاهای معروف ترکی:**

**غذاهای اصلی:**
۱. **کباب‌ها**:
   - آدانا کباب (تند و گوشت چرخ‌کرده)
   - اسکندر کباب (با نان و ماست)
   - چیگ کفتا (کباب گوشت گوساله)
   - شیش کباب (گوشت تکه‌ای)

۲. **غذاهای گوشتی**:
   - کوفته (گلوله‌های گوشت)
   - ساج کباب (روی ساج آهنی)
   - تندور (پخت در تنور گلی)

۳. **غواهای گیاهی**:
   - دلمه (پیچیده در برگ انگور)
   - بورک (لایه‌ای با پنیر یا گوشت)
   - منمن (سبزیجات و گوجه)

**غذاهای دریایی:**
• ماهی سرخ‌کرده (بالیک ایذگارا)
• میگو گریل (کاریدس)
• ماهی کبابی (ماهی آزاد یا لوتی)

**صبحانه ترکی:**
• **صبحانه کامل (kahvaltı)**:
  - پنیرهای مختلف (بیاض، کاشار)
  - زیتون سیاه و سبز
  - عسل، کایماک (خامه غلیظ)
  - سوچوک (سوسیس)، پاستیرما (گوشت خشک)
  - املت (منمن)
  - چای سیاه فراوان

**دسرها و شیرینی‌ها:**
۱. **باقلوا (Baklava)**:
   - بهترین‌ها: گلابوجو، کaraköy Güllüoğlu
   - انواع: پسته‌ای، گردویی، خامه‌ای

۲. **کونافه (Künefe)**:
   - پنیر بین رشته‌های شیرینی
   - سرو گرم با بستنی

۳. **لوکوم (Lokum)**:
   - شیرینی ژله‌ای با پودر قند
   - طعم‌ها: گلاب، پسته، نارگیل

۴. **سوتلاچ (Sütlaç)**:
   - پودینگ برنج
   - سرد یا گرم

**نوشیدنی‌ها:**
• چای ترکی (سیاه، در لیوان لاله‌ای)
• قهوه ترکی (تلخ، با تفاله)
• آیران (دوغ)
• شربت (آلبالو، رز)
• راکی (نوشیدنی الکلی ملی)

**نکات غذا خوردن:**
• غذاخوری‌ها (lokanta) برای غذاهای سنتی
• کافه‌ها (kahve) برای چای و قهوه
• شیرینی‌فروشی‌ها (pastane) برای شیرینی
• پیش غذا (meze) فرهنگ مهمی دارد
• انعام: ۱۰-۱۵% معمول است'
            ],
            
            // فرهنگ و آداب
            'culture_etiquette' => [
                'keywords' => ['فرهنگ ترکیه', 'آداب ترکیه', 'رسوم ترکی', 'مذهب ترکیه', 'تعطیلات ترکیه',
                              'عید فطر', 'عید قربان', 'روز جمهوری', 'نوروز', 'موسیقی ترکی',
                              'رقص ترکی', 'قالی ترکی', 'حمام ترکی', 'چای ترکی'],
                'response' => '🎎 **فرهنگ و آداب ترکیه:**

**مذهب:**
• ۹۹% مسلمان (اکثریت سنی)
• اقلیت‌های مسیحی و یهودی
• مساجد: نماز پنج وقت، جمعه مهم
• رمضان: روزه‌داری، افطاری‌های بزرگ

**تعطیلات رسمی:**
۱. **عید فطر (Ramazan Bayramı)**:
   - ۳ روز جشن پس از رمضان
   - دیدوبازدید، شیرینی، کمک به نیازمندان

۲. **عید قربان (Kurban Bayramı)**:
   - ۴ روز، بزرگ‌ترین عید
   - قربانی کردن گوسفند، تقسیم گوشت

۳. **روز جمهوری (Cumhuriyet Bayramı)**:
   - ۲۹ اکتبر
   - جشن تأسیس جمهوری ترکیه
   - رژه، آتش‌بازی، کنسرت

۴. **روز جوانان و ورزش (۱۹ می)**
۵. **روز پیروزی (۳۰ آگوست)**
۶. **روز کودکان (۲۳ آوریل)**

**آداب معاشرت:**

**سلام کردن:**
• مردان: دست‌دادن محکم
• زنان: معمولاً بوسیدن روی دو گونه
• "سلام" (Merhaba) یا "صلاح" (Selam)
• احترام به بزرگترها مهم است

**مهمان‌نوازی:**
• مهمان "هدیه خدا" محسوب می‌شود
• حتماً چای یا قهوه تعارف می‌کنند
• رد کردن تعارف بی‌ادبی است
• بهترین غذاها برای مهمان

**آداب غذا خوردن:**
• شروع غذا با "بسم‌الله"
• استفاده از قاشق و چنگال
• نان با دست خورده می‌شود
• تعارف زیاد برای غذا
• تشکر از میزبان ضروری

**لباس:**
• شهرهای بزرگ: لباس غربی
• مناطق محافظه‌کار: پوشش محجبه
• مساجد: روسری، دامن بلند
• ساحل: مایو مجاز

**هنر و موسیقی:**
• موسیقی سنتی: سازهای قانون، عود، نِی
• رقص‌ها: سماع (دراویش)، رقص شکم
• صنایع دستی: فرش، سرامیک، نقره
• اپرا و باله: سالن‌های مدرن

**حمام ترکی (Hamam):**
• بخشی از فرهنگ بهداشتی
• سه بخش: سربینه، گرمخانه، خلوت
• ماساژ با کف (kese)
• تجربه ای سنتی و آرامش‌بخش

**نکات مهم:**
• احترام به پرچم و آتاتورک
• سیاست: موضوع حساسی است
• خانواده: کانون اصلی جامعه
• زمان: انعطاف‌پذیرتر از اروپا'
            ],
            
            // حمل و نقل
            'transportation' => [
                'keywords' => ['حمل و نقل', 'مترو استانبول', 'اتوبوس', 'تاکسی', 'تراموا', 'دلموش',
                              'مارمارای', 'متروبوس', 'بستری', 'کارت‌اعتباری', 'ایستینیه', 'قایق', 'واپور'],
                'response' => '🚇 **حمل‌ونقل عمومی استانبول:**

**کارت‌اعتباری (İstanbulkart):**
• کارت هوشمند برای همه وسایل نقلیه
• خرید: کیوسک‌های مخصوص (İstanbulkart bayi)
• هزینه: ۷۰ لیر برای کارت + شارژ
• مزایا: انتقال رایگان در ۲ ساعت

**مترو (Metro):**
• ۱۱ خط فعال، ۱۵۰+ ایستگاه
• ساعت کار: ۶:۰۰ صبح تا ۰۰:۰۰ نیمه‌شب
• خطوط مهم:
  - M1A: فرودگاه آتاتورک - ینی‌کاپی
  - M2: ینی‌کاپی - هاجی‌عثمان
  - Marmaray: زیر بسفر (اروپا-آسیا)

**تراموا (Tramvay):**
• T1: کاباتاش - باغچه‌لی‌اولر
  - ایستگاه‌های مهم: سلطان احمد، بی‌اوغلو
• T4: توپکاپی - مسلت‌چشمه

**اتوبوس (Otobüs):**
• ۸۰۰+ خط، ۱۰۰۰۰+ اتوبوس
• رنگ‌ها:
  - قرمز: خطوط اصلی
  - آبی: اکسپرس
  - سبز: محلی
• متروبوس: خط ویژه بی‌تی

**دلموش (Dolmuş):**
• تاکسی اشتراکی
• مسیرهای ثابت
• ارزان‌تر از تاکسی
• ظرفیت: ۸-۱۰ نفر

**تاکسی (Taksi):**
• رنگ زرد
• تاکسیمتر اجباری
• هزینه شروع: ۴۰ لیر
• برندهای معتبر: BiTaksi, iTaksi (اپلیکیشن)

**قایق و فری (Vapur):**
• ۵۰+ خط دریایی
• بنادر اصلی:
  - اروپا: امین‌انو، بشیکتاش، کاباتاش
  - آسیا: کادیکوی، اوسکودار
• خطوط محبوب:
  - امین‌انو - کادیکوی
  - بشیکتاش - اوسکودار
  - جزایر پرنس (آدالار)

**مارمارای (Marmaray):**
• قطار زیردریایی زیر بسفر
• اروپا (ینی‌کاپی) - آسیا (آیریلیک‌چشمه)
• ۴ دقیقه زیر آب
• اتصال به مترو

**فرودگاه‌ها:**
۱. **فرودگاه استانبول (IST)**:
   - جدید، بزرگترین فرودگاه جهان
   - ۴۰ کیلومتری مرکز شهر
   - انتقال با Havaist اتوبوس یا تاکسی

۲. **فرودگاه صبیحه گوکچن (SAW)**:
   - بخش آسیایی
   - پروازهای داخلی و کم‌پانی‌ها
   - انتقال با Havabüs

**نکات مهم:**
• ساعت اوج: ۷-۹ صبح، ۵-۸ عصر
• زنان: واگن‌های مخصوص در برخی قطارها
• معلولان: دسترسی مناسب در ایستگاه‌های جدید
• دوچرخه: اجازه در مترو و فری'
            ],
            
            // خرید و سوغاتی
            'shopping_souvenirs' => [
                'keywords' => ['خرید', 'سوغاتی', 'بازار بزرگ', 'بازار ادویه', 'مرکز خرید', 'فرش ترکی',
                              'چای ترکی', 'لوکوم', 'ظروف مسی', 'نقره', 'چرم', 'آینه بنایی', 'نازار بونجی',
                              'قهوه ترکی', 'آب‌طلا', 'عروسک', 'سجاده', 'تسبیح'],
                'response' => '🛍️ **خرید و سوغاتی‌های استانبول:**

**بازارهای تاریخی:**

**۱. بازار بزرگ (Kapalı Çarşı):**
• بزرگترین بازار سرپوشیده جهان
• ۶۱ خیابان، ۴۰۰۰ مغازه
• بخش‌های تخصصی:
  - بازار طلا (Kuyumcular)
  - بازار فرش (Halıcılar)
  - بازار چرم (Dericiler)
  - بازار نقره (Gümüşçüler)
• ساعت: ۹-۱۹ (یکشنبه تعطیل)

**۲. بازار ادویه (Mısır Çarşısı):**
• بازار مصری، کنار مسجد جدید
• ادویه، خشکبار، گیاهان دارویی
• لوکوم، شیرینی، پاستیل
• ساعت: ۸-۱۹:۳۰

**۳. بازار آراستا (Arasta Çarşısı):**
• پشت مسجد آبی
• صنایع دستی باکیفیت
• فرش، سرامیک، نقاشی

**مراکز خرید مدرن:**

**۴. ایستینیه پارک (İstinye Park):**
• لوکس‌ترین مرکز خرید
• برندهای بین‌المللی: LV, Gucci, Prada
• رستوران‌های باکلاس

**۵. جواهر (Cevahir):**
• بزرگترین مرکز خرید اروپا
• ۳۴۰ مغازه، سینما، بولینگ
• بخش آسیایی: کاپیتول (Capitol)

**۶. نیستانتاسی (Nişantaşı):**
• منطقه خرید لوکس
• خیابان آبراه ایستیکلال
• بوتیک‌های طراحان ترکی

**سوغاتی‌های معروف:**

**۱. فرش و گلیم (Halı, Kilim):**
• مناطق تولید: کایسری، قونیه
• نشان‌اصالت: "Hereke" برای فرش ابریشمی
• قیمت: از ۱۰۰ دلار به بالا

**۲. لوکوم (Turkish Delight):**
• برندهای معروف: Hacı Bekir, Hafız Mustafa
• طعم‌ها: پسته‌ای، رز، نارگیل
• بسته‌بندی جعبه‌ای

**۳. چای ترکی (Çay):**
• از منطقه دریای سیاه
• برندها: Doğuş, Çaykur
• قوری دوطبقه (çaydanlık)

**۴. قهوه ترکی (Kahve):**
• برند: Kurukahveci Mehmet Efendi
• آسیاب شده ریز
• همراه قهوه‌جوش مسی

**۵. ظروف مسی و نقره:**
• بازار بزرگ، بازار ادویه
• قابلمه، سینی، گلدان
• حکاکی دستی

**۶. آینه بنایی (Evil Eye - Nazar Boncuğu):**
• محافظ در برابر چشم زخم
• آبی با دایره‌های سفید و زرد
• گردنبند، دست‌بند، تزئینات

**۷. محصولات چرم:**
• کیف، کفش، کت
• منطقه لال‌لی (Laleli) معروف است

**۸. میناکاری (Çini):**
• کاشی و ظروف سرامیکی
• طرح‌های سنتی
• از شهر ایزنیک

**نکات خرید:**
• چانه‌زنی: در بازارها معمول است
• کارت اعتباری: در مراکز خرید پذیرفته
• پاسپورت: برای تخفیف معاف از مالیات
• حمل: خدمات پست به خارج'
            ],
            
            // آب و هوا و بهترین زمان سفر
            'weather_besttime' => [
                'keywords' => ['آب و هوا', 'بهترین زمان سفر', 'فصل استانبول', 'تابستان استانبول', 'زمستان استانبول',
                              'بهار استانبول', 'پاییز استانبول', 'دما', 'باران', 'برف', 'رطوبت', 'اقلیم'],
                'response' => '🌤️ **آب‌وهوا و بهترین زمان سفر به استانبول:**

**اقلیم استانبول:**
• نیمه‌گرمسیری مرطوب
• تابستان‌ها گرم و مرطوب
• زمستان‌ها سرد و بارانی
• دو قاره: اروپا (ملایم‌تر)، آسیا (شرجی‌تر)

**فصل‌های سال:**

**بهار (مارس - می):**
• **دما**: ۱۰°C تا ۲۰°C
• **ویژگی**: معتدل، گل‌ها شکوفا
• **لباس**: سبک، ژاکت برای شب
• **مزایا**: خلوت، قیمت مناسب
• **مناسبت‌ها**: روز کودکان (۲۳ آوریل)

**تابستان (ژوئن - آگوست):**
• **دما**: ۲۰°C تا ۳۰°C (گاهی تا ۳۵°C)
• **ویژگی**: گرم، مرطوب، شلوغ
• **لباس**: سبک، کلاه، کرم ضدآفتاب
• **مزایا**: روزهای طولانی، فستیوال‌ها
• **نکته**: هتل‌ها گران، رزرو زودتر

**پاییز (سپتامبر - نوامبر):**
• **دما**: ۱۵°C تا ۲۵°C
• **ویژگی**: خنک، رنگ‌های پاییزی
• **لباس**: لایه‌ای
• **مزایا**: بهترین فصل برای بازدید
• **مناسبت‌ها**: روز جمهوری (۲۹ اکتبر)

**زمستان (دسامبر - فوریه):**
• **دما**: ۵°C تا ۱۰°C
• **ویژگی**: سرد، بارانی، گاهی برف
• **لباس**: کت گرم، چتر، چکمه
• **مزایا**: خلوت‌ترین فصل، قیمت پایین
• **مناسبت‌ها**: سال نو، خرید حراجی

**میانگین ماهانه:**
• ژانویه: ۶°C، ۱۰ روز بارانی
• آوریل: ۱۳°C، ۸ روز بارانی
• ژوئیه: ۲۴°C، ۳ روز بارانی
• اکتبر: ۱۷°C، ۹ روز بارانی

**بهترین زمان برای فعالیت‌ها:**

**تاریخ‌بازان**: بهار و پاییز (پیاده‌روی راحت)
**عکاسان**: پاییز (رنگ‌ها) و زمستان (برف روی مساجد)
**خریداران**: ژانویه و جولای (حراجی‌های فصلی)
**علاقه‌مندان به غذا**: تمام سال (هر فصل غذای خاصی دارد)

**فستیوال‌های مهم:**
• فستیوال بین‌المللی فیلم (فوریه)
• فستیوال موسیقی (ژوئن-جولای)
• فستیوال خرید (ژوئن)
• فستیوال قهوه (اکتبر)

**نکات آب‌وهوایی:**
• همیشه چتر همراه داشته باشید
• لایه‌ای لباس بپوشید
• صبح‌ها مه ممکن است باشد
• تابستان: هیدراته بمانید
• زمستان: مساجد سرد هستند'
            ],
            
            // امنیت و نکات سفر
            'safety_tips' => [
                'keywords' => ['امنیت', 'ایمنی', 'نکات سفر', 'کلاهبرداری', 'سرقت', 'پلیس', 'اورژانس',
                              'بیمه', 'پزشک', 'داروخانه', 'آب آشامیدنی', 'ولتاژ', 'اینترنت', 'زبان'],
                'response' => '🛡️ **امنیت و نکات سفر به استانبول:**

**سطح امنیت کلی:**
• استانبول شهری امن برای توریست‌ها
• نرخ جرم: پایین‌تر از بسیاری کلان‌شهرهای اروپایی
• پلیس توریستی: انگلیسی صحبت می‌کنند

**نکات امنیتی:**

**۱. جلوگیری از سرقت:**
• کیف و وسایل ارزشمند جلو چشمتان باشد
• در شلوغی (تکسیم، بازار بزرگ) مراقب باشید
• پاسپورت در هتل بگذارید، کپی همراه داشته باشید
• از کیف پول جلوگیری استفاده کنید

**۲. کلاهبرداری‌های رایج:**
• کفش‌شویان: کفش‌تان را برمی‌دارند و پول می‌خواهند
• رستوران‌های بدون منو: قیمت‌ها را بپرسید
• تاکسی‌های غیرقانونی: فقط تاکسی زرد سوار شوید
• "دوست جدید": مراقب پیشنهادات غیرمنتظره باشید

**۳. در خیابان:**
• از ATM داخل بانک‌ها استفاده کنید
• پول نقد زیاد همراه نداشته باشید
• نقشه آفلاین داشته باشید
• مناطق کم‌نور شب‌ها را پرهیز کنید

**شماره‌های اضطراری:**
• پلیس: ۱۵۵
• آمبولانس: ۱۱۲
• آتش‌نشانی: ۱۱۰
• توریست پلیس: ۰۲۱۲ ۵۲۷ ۴۵ ۰۳

**سلامت و بهداشت:**

**آب آشامیدنی:**
• آب لوله‌کشی قابل شرب است اما...
• بهتر است آب بطری بنوشید
• قیمت: ۲-۵ لیر برای ۱.۵ لیتر

**داروخانه (Eczane):**
• علامت "E" بزرگ قرمز
• داروخانه‌های نوبتی (Nöbetçi): شب‌ها باز
• داروهای بدون نسخه محدود است

**بیمارستان‌های معتبر:**
• آمریکایی (Amerikan Hastanesi): نیستانتاسی
• آلمانی (Alman Hastanesi): تکسیم
• آچی‌بادم (Acıbadem): کادیکوی

**اینترنت و ارتباطات:**

**Wi-Fi:**
• هتل‌ها، کافه‌ها، مراکز خرید
• رایگان اما سرعت متغیر
• اپراتورها: Turkcell, Vodafone, Türk Telekom

**سیم کارت توریستی:**
• فرودگاه‌ها و مراکز شهر
• مدارک: پاسپورت
• قیمت: از ۱۰۰ لیر

**زبان:**
• ترکی استانبولی (رسمی)
• انگلیسی: مناطق توریستی
• عبارات مفید:
  - Merhaba (سلام)
  - Teşekkür ederim (متشکرم)
  - Lütfen (لطفاً)
  - Yardım! (کمک!)

**برق:**
• ولتاژ: ۲۲۰ ولت
• پریز: نوع C/E (دو شاخه گرد)
• مبدل: مورد نیاز برای آمریکایی‌ها

**ساعات کاری:**
• بانک‌ها: ۹-۱۷ (شنبه نصف روز)
• مغازه‌ها: ۹-۱۹ (یکشنبه بازارها تعطیل)
• رستوران‌ها: تا دیروقت

**نکات نهایی:**
• احترام به فرهنگ محلی
• عکس‌برداری در مساجد با اجازه
• کفش در خانه درآورید
• از میزبان تشکر کنید (Çok teşekkür ederim)'
            ],
            
            // پاسخ‌های پیش‌فرض
            'default' => 'سوال جالبی پرسیدید! متأسفم، در حال حاضر نمی‌توانم به این سوال خاص پاسخ دهم. لطفاً موضوع خود را دقیق‌تر بیان کنید یا از بخش‌های زیر بپرسید:

• تاریخ ترکیه و استانبول
• محله‌های استانبول
• رستوران‌ها و غذاهای ترکی
• فرهنگ و آداب ترکیه
• حمل‌ونقل عمومی
• خرید و سوغاتی
• آب‌وهوا و بهترین زمان سفر
• امنیت و نکات سفر

یا از جستجوی پیشرفته در سایت استفاده کنید. 🇹🇷'
        ],
        
        'en' => [
            'history' => [
                'keywords' => ['history of turkey', 'history of istanbul', 'byzantine', 'ottoman', 'ottoman empire',
                              'constantinople', 'sultan mehmed ii', 'ataturk', 'republic of turkey', 'byzantium',
                              'eastern roman', 'seljuk', 'conquest of istanbul', 'fall of constantinople'],
                'response' => '📜 **Complete History of Istanbul and Turkey:**

**Byzantine Period (330-1453 AD):**
• Foundation: By Constantine the Great in 330 AD
• Name: Constantinople (Capital of Eastern Roman Empire)
• Most Important Monuments: Hagia Sophia, Walls of Constantinople, Great Palace
• Golden Age: During Justinian I (6th century)

**Ottoman Period (1453-1922 AD):**
• Conquest: By Sultan Mehmed II on May 29, 1453
• Capital: Istanbul became the capital of Ottoman Empire
• Development: Construction of mosques, palaces, markets, and baths
• Peak Power: 16th century under Suleiman the Magnificent
• Important Monuments: Topkapi Palace, Suleymaniye Mosque, Blue Mosque

**Republican Period (1923-Present):**
• Foundation: By Mustafa Kemal Atatürk on October 29, 1923
• New Capital: Ankara (but Istanbul remained cultural center)
• Modernization: Atatürk\'s reforms for westernization
• Today: Largest city in Turkey with 16 million population

**Major Periods:**
1. Roman Period (667 BC - 330 AD)
2. Byzantine Period (330-1453)
3. Ottoman Period (1453-1922)
4. Republican Period (1923-Present)

**Key Figures:**
• Sultan Mehmed II (Conqueror of Istanbul)
• Suleiman the Magnificent (Most brilliant period of Ottomans)
• Mustafa Kemal Atatürk (Founder of modern Turkey)
• Roxelana (Beloved wife of Suleiman)'
            ],
            
            'neighborhoods' => [
                'keywords' => ['neighborhood', 'districts of istanbul', 'sultanahmet', 'beyoglu', 'kadikoy',
                              'besiktas', 'sisli', 'fatih', 'eminonu', 'bagcilar', 'sariyer',
                              'ortakoy', 'arnavutkoy', 'cengelkoy', 'uskudar', 'beykoz'],
                'response' => '🏙️ **Famous Neighborhoods of Istanbul:**

**European Side:**

**1. Sultanahmet:**
• Historical heart of Istanbul
• Attractions: Hagia Sophia, Blue Mosque, Topkapi Palace
• Atmosphere: Touristic, historical, excellent for walking
• Best for: History lovers, first-time visitors

**2. Beyoğlu:**
• Cultural and artistic center
• Istiklal Street, Galata Tower
• Restaurants, cafes, galleries
• Famous nightlife

**3. Beşiktaş:**
• Modern and chic district
• Dolmabahçe Palace, Inonu Stadium
• Nightlife, luxury cafes
• Prestigious universities

**4. Şişli:**
• Shopping and business center
• Istanbul Trade Towers (İş Kuleleri)
• Shopping malls: Nişantaşı, Cevahir
• Modern urban life

**5. Fatih:**
• Traditional and religious district
• Grand Bazaar, Istanbul University
• Authentic local life
• Cheap and delicious food

**Asian Side:**

**6. Kadıköy:**
• Heart of Asian side
• Kadıköy local market
• Vibrant student life
• Cool cafes, seafood restaurants

**7. Üsküdar:**
• Historical and religious
• Beautiful mosques, Bosphorus views
• Calmer than European side
• Modern transportation

**8. Beykoz:**
• Green and peaceful
• Belgrade Forests, Anadolu Hisarı Fortress
• Luxury villas, fish restaurants
• Away from city crowds

**9. Üsküdar:**
• Traditional face of Istanbul
• Üsküdar Square, Şehzade Mosque
• Excellent water transportation
• Amazing view of mosques

**Special Neighborhoods:**

**10. Ortaköy:**
• Next to Bosphorus Bridge
• Waterside cafes
• Famous sunset views
• Handmade crafts market

**11. Eminönü:**
• Commercial and historical
• Spice Bazaar, piers
• Tram station
• Wholesale shopping

**12. Sarıyer:**
• Northernmost European point
• Fishing villages
• Untouched nature
• Fresh fish restaurants'
            ],
            
            'restaurants_food' => [
                'keywords' => ['restaurant', 'food', 'turkish food', 'kebab', 'baklava', 'doner', 'turkish breakfast',
                              'lahmacun', 'pide', 'meze', 'çiğ köfte', 'adana kebab', 'köfte', 'dolma',
                              'soup', 'künefe', 'lokum', 'börek', 'saç', 'ciz', 'kelle paça'],
                'response' => '🍽️ **Famous Restaurants and Foods of Istanbul:**

**Restaurant Categories:**

**1. Luxury Restaurants:**
• **Mikla**: Modern Turkish cuisine - Top of Marmara Hotel
• **Neolokal**: Traditional and modern fusion - Karaköy
• **Ulus 29**: Bosphorus view - Beşiktaş
• **360 Istanbul**: 360-degree view - Beyoğlu

**2. Traditional Restaurants:**
• **Çiya Sofrası**: Rare local dishes - Kadıköy
• **Kanaat Lokantası**: Homemade food - Üsküdar
• **Hacı Abdullah**: Active since 1888 - Beyoğlu
• **Beyti**: Famous kebab - Florya

**3. Seafood Restaurants:**
• **Balıkçı Sabahattin**: Fresh fish - Sultanahmet
• **Kiyi**: Excellent seafood - Tarabya
• **Sur Balık**: Hagia Sophia view - Eminönü

**4. Street Food:**
• **Kızılkayalar**: Famous hamburger - Taksim
• **Bereket Döner**: Tasty doner - Beyoğlu
• **Özcan Turşuları**: Pickles - Kadıköy

**Famous Turkish Foods:**

**Main Dishes:**
1. **Kebabs**:
   - Adana Kebab (spicy minced meat)
   - İskender Kebab (with bread and yogurt)
   - Çiğ Köfte (raw meatballs)
   - Şiş Kebab (meat pieces)

2. **Meat Dishes**:
   - Köfte (meatballs)
   - Saç Kebab (on iron plate)
   - Tandır (cooked in clay oven)

3. **Vegetarian Dishes**:
   - Dolma (stuffed grape leaves)
   - Börek (layered pastry with cheese or meat)
   - Menemen (vegetables and tomato)

**Seafood:**
• Fried fish (Balık ızgara)
• Grilled shrimp (Karides)
• Grilled fish (Salmon or sea bass)

**Turkish Breakfast:**
• **Full breakfast (kahvaltı)**:
  - Various cheeses (beyaz, kaşar)
  - Black and green olives
  - Honey, kaymak (thick cream)
  - Sucuk (sausage), pastırma (dried meat)
  - Omelette (menemen)
  - Plenty of black tea

**Desserts and Sweets:**
1. **Baklava**:
   - Best places: Güllüoğlu, Karaköy Güllüoğlu
   - Types: pistachio, walnut, cream

2. **Künefe**:
   - Cheese between sweet strings
   - Served hot with ice cream

3. **Lokum (Turkish Delight)**:
   - Jelly sweet with powdered sugar
   - Flavors: rose, pistachio, coconut

4. **Sütlaç**:
   - Rice pudding
   - Cold or hot

**Drinks:**
• Turkish tea (black, in tulip glass)
• Turkish coffee (bitter, with grounds)
• Ayran (yogurt drink)
• Sherbet (cherry, rose)
• Rakı (national alcoholic drink)

**Dining Tips:**
• Lokanta for traditional foods
• Kahve for tea and coffee
• Pastane for sweets
• Meze is an important culture
• Tip: 10-15% is usual'
            ],
            
            'culture_etiquette' => [
                'keywords' => ['turkish culture', 'turkish etiquette', 'turkish traditions', 'religion turkey', 'turkey holidays',
                              'eid al-fitr', 'eid al-adha', 'republic day', 'nowruz', 'turkish music',
                              'turkish dance', 'turkish carpet', 'turkish bath', 'turkish tea'],
                'response' => '🎎 **Turkish Culture and Etiquette:**

**Religion:**
• 99% Muslim (Sunni majority)
• Christian and Jewish minorities
• Mosques: Five daily prayers, Friday important
• Ramadan: Fasting, large iftar meals

**Official Holidays:**
1. **Eid al-Fitr (Ramazan Bayramı)**:
   - 3-day celebration after Ramadan
   - Visiting, sweets, helping the needy

2. **Eid al-Adha (Kurban Bayramı)**:
   - 4 days, biggest holiday
   - Sacrificing sheep, distributing meat

3. **Republic Day (Cumhuriyet Bayramı)**:
   - October 29
   - Celebration of Turkish Republic foundation
   - Parades, fireworks, concerts

4. **Youth and Sports Day (May 19)**
5. **Victory Day (August 30)**
6. **Children\'s Day (April 23)**

**Social Etiquette:**

**Greeting:**
• Men: Firm handshake
• Women: Usually kissing on both cheeks
• "Merhaba" or "Selam"
• Respect for elders is important

**Hospitality:**
• Guest is considered "God\'s gift"
• Tea or coffee is always offered
• Refusing hospitality is rude
• Best foods for guests

**Dining Etiquette:**
• Start meal with "Bismillah"
• Use spoon and fork
• Bread eaten with hands
• Lots of food offers
• Thanking host is essential

**Clothing:**
• Big cities: Western clothing
• Conservative areas: Headscarf
• Mosques: Headscarf, long skirt
• Beach: Swimwear allowed

**Art and Music:**
• Traditional music: Kanun, oud, ney instruments
• Dances: Sema (whirling dervishes), belly dance
• Handicrafts: Carpets, ceramics, silver
• Opera and ballet: Modern halls

**Turkish Bath (Hamam):**
• Part of hygiene culture
• Three sections: cold room, hot room, private
• Foam massage (kese)
• Traditional relaxing experience

**Important Notes:**
• Respect for flag and Atatürk
• Politics: Sensitive topic
• Family: Core of society
• Time: More flexible than Europe'
            ],
            
            'transportation' => [
                'keywords' => ['transportation', 'istanbul metro', 'bus', 'taxi', 'tram', 'dolmuş',
                              'marmaray', 'metrobus', 'card', 'boat', 'ferry', 'vapur'],
                'response' => '🚇 **Istanbul Public Transportation:**

**Smart Card (İstanbulkart):**
• Smart card for all vehicles
• Purchase: Special kiosks (İstanbulkart bayi)
• Cost: 70 TL for card + charge
• Benefits: Free transfer within 2 hours

**Metro:**
• 11 active lines, 150+ stations
• Hours: 6:00 AM to 12:00 midnight
• Important lines:
  - M1A: Atatürk Airport - Yenikapı
  - M2: Yenikapı - Hacıosman
  - Marmaray: Under Bosphorus (Europe-Asia)

**Tram:**
• T1: Kabataş - Bağcılar
  - Important stations: Sultanahmet, Beyoğlu
• T4: Topkapı - Mescitçeşme

**Bus:**
• 800+ lines, 10,000+ buses
• Colors:
  - Red: Main lines
  - Blue: Express
  - Green: Local
• Metrobus: BRT line

**Dolmuş:**
• Shared taxi
• Fixed routes
• Cheaper than taxi
• Capacity: 8-10 people

**Taxi:**
• Yellow color
• Mandatory taximeter
• Starting fee: 40 TL
• Reliable brands: BiTaksi, iTaksi (apps)

**Boat and Ferry:**
• 50+ sea lines
• Main ports:
  - Europe: Eminönü, Beşiktaş, Kabataş
  - Asia: Kadıköy, Üsküdar
• Popular lines:
  - Eminönü - Kadıköy
  - Beşiktaş - Üsküdar
  - Princes\' Islands (Adalar)

**Marmaray:**
• Submarine train under Bosphorus
• Europe (Yenikapı) - Asia (Ayrılıkçeşme)
• 4 minutes under water
• Connection to metro

**Airports:**
1. **Istanbul Airport (IST)**:
   - New, world\'s largest airport
   - 40 km from city center
   - Transfer with Havaist bus or taxi

2. **Sabiha Gökçen Airport (SAW)**:
   - Asian side
   - Domestic and low-cost flights
   - Transfer with Havabüs

**Important Tips:**
• Rush hour: 7-9 AM, 5-8 PM
• Women: Special wagons in some trains
• Disabled: Good access in new stations
• Bicycle: Allowed on metro and ferry'
            ],
            
            'shopping_souvenirs' => [
                'keywords' => ['shopping', 'souvenirs', 'grand bazaar', 'spice bazaar', 'shopping mall', 'turkish carpet',
                              'turkish tea', 'lokum', 'copperware', 'silver', 'leather', 'evil eye', 'nazar boncuğu',
                              'turkish coffee', 'gold water', 'doll', 'prayer rug', 'prayer beads'],
                'response' => '🛍️ **Shopping and Souvenirs in Istanbul:**

**Historical Markets:**

**1. Grand Bazaar (Kapalı Çarşı):**
• World\'s largest covered market
• 61 streets, 4000 shops
• Specialized sections:
  - Gold market (Kuyumcular)
  - Carpet market (Halıcılar)
  - Leather market (Dericiler)
  - Silver market (Gümüşçüler)
• Hours: 9-19 (closed Sunday)

**2. Spice Bazaar (Mısır Çarşısı):**
• Egyptian market, next to New Mosque
• Spices, dried fruits, medicinal herbs
• Lokum, sweets, pastilles
• Hours: 8-19:30

**3. Arasta Bazaar:**
• Behind Blue Mosque
• Quality handicrafts
• Carpets, ceramics, paintings

**Modern Shopping Malls:**

**4. İstinye Park:**
• Most luxurious shopping center
• International brands: LV, Gucci, Prada
• Classy restaurants

**5. Cevahir:**
• Europe\'s largest shopping center
• 340 shops, cinema, bowling
• Asian side: Capitol

**6. Nişantaşı:**
• Luxury shopping district
• Abdi İpekçi Street
• Turkish designer boutiques

**Famous Souvenirs:**

**1. Carpet and Kilim (Halı, Kilim):**
• Production areas: Kayseri, Konya
• Authenticity mark: "Hereke" for silk carpets
• Price: From $100 and up

**2. Turkish Delight (Lokum):**
• Famous brands: Hacı Bekir, Hafız Mustafa
• Flavors: pistachio, rose, coconut
• Box packaging

**3. Turkish Tea (Çay):**
• From Black Sea region
• Brands: Doğuş, Çaykur
• Two-storey teapot (çaydanlık)

**4. Turkish Coffee (Kahve):**
• Brand: Kurukahveci Mehmet Efendi
• Finely ground
• With copper coffee pot

**5. Copper and Silverware:**
• Grand Bazaar, Spice Bazaar
• Pots, trays, vases
• Hand engraving

**6. Evil Eye (Nazar Boncuğu):**
• Protection against evil eye
• Blue with white and yellow circles
• Necklace, bracelet, decorations

**7. Leather Products:**
• Bag, shoes, jacket
• Laleli area is famous

**8. Miniature (Çini):**
• Tile and ceramic ware
• Traditional patterns
• From İznik city

**Shopping Tips:**
• Bargaining: Common in markets
• Credit card: Accepted in malls
• Passport: For tax-free discount
• Shipping: Postal services abroad'
            ],
            
            'weather_besttime' => [
                'keywords' => ['weather', 'best time to visit', 'istanbul seasons', 'summer istanbul', 'winter istanbul',
                              'spring istanbul', 'autumn istanbul', 'temperature', 'rain', 'snow', 'humidity', 'climate'],
                'response' => '🌤️ **Weather and Best Time to Visit Istanbul:**

**Istanbul Climate:**
• Humid subtropical
• Hot and humid summers
• Cold and rainy winters
• Two continents: Europe (milder), Asia (more humid)

**Seasons:**

**Spring (March - May):**
• **Temperature**: 10°C to 20°C
• **Characteristics**: Mild, flowers blooming
• **Clothing**: Light, jacket for night
• **Advantages**: Less crowded, good prices
• **Events**: Children\'s Day (April 23)

**Summer (June - August):**
• **Temperature**: 20°C to 30°C (sometimes up to 35°C)
• **Characteristics**: Hot, humid, crowded
• **Clothing**: Light, hat, sunscreen
• **Advantages**: Long days, festivals
• **Note**: Hotels expensive, early booking

**Autumn (September - November):**
• **Temperature**: 15°C to 25°C
• **Characteristics**: Cool, autumn colors
• **Clothing**: Layered
• **Advantages**: Best season for visiting
• **Events**: Republic Day (October 29)

**Winter (December - February):**
• **Temperature**: 5°C to 10°C
• **Characteristics**: Cold, rainy, sometimes snow
• **Clothing**: Warm coat, umbrella, boots
• **Advantages**: Least crowded season, low prices
• **Events**: New Year, shopping sales

**Monthly Averages:**
• January: 6°C, 10 rainy days
• April: 13°C, 8 rainy days
• July: 24°C, 3 rainy days
• October: 17°C, 9 rainy days

**Best Time for Activities:**

**History lovers**: Spring and autumn (comfortable walking)
**Photographers**: Autumn (colors) and winter (snow on mosques)
**Shoppers**: January and July (seasonal sales)
**Food enthusiasts**: All year (each season has special food)

**Important Festivals:**
• International Film Festival (February)
• Music Festival (June-July)
• Shopping Festival (June)
• Coffee Festival (October)

**Weather Tips:**
• Always carry umbrella
• Wear layered clothing
• Morning fog possible
• Summer: Stay hydrated
• Winter: Mosques are cold'
            ],
            
            'safety_tips' => [
                'keywords' => ['safety', 'security', 'travel tips', 'scams', 'theft', 'police', 'emergency',
                              'insurance', 'doctor', 'pharmacy', 'drinking water', 'voltage', 'internet', 'language'],
                'response' => '🛡️ **Safety and Travel Tips for Istanbul:**

**Overall Safety Level:**
• Istanbul is safe city for tourists
• Crime rate: Lower than many European metropolises
• Tourist police: Speak English

**Safety Tips:**

**1. Preventing Theft:**
• Keep bags and valuables in front of you
• Be careful in crowded places (Taksim, Grand Bazaar)
• Leave passport in hotel, carry copy
• Use anti-theft wallet

**2. Common Scams:**
• Shoe shiners: Take your shoes and ask money
• Restaurants without menu: Ask prices
• Illegal taxis: Only take yellow taxis
• "New friend": Be careful of unexpected offers

**3. On the Street:**
• Use ATMs inside banks
• Don\'t carry much cash
• Have offline map
• Avoid poorly lit areas at night

**Emergency Numbers:**
• Police: 155
• Ambulance: 112
• Fire: 110
• Tourist Police: 0212 527 45 03

**Health and Hygiene:**

**Drinking Water:**
• Tap water is drinkable but...
• Better to drink bottled water
• Price: 2-5 TL for 1.5 liter

**Pharmacy (Eczane):**
• Big red "E" sign
• On-duty pharmacies (Nöbetçi): Open at night
• Over-the-counter medicines limited

**Reliable Hospitals:**
• American Hospital (Amerikan Hastanesi): Nişantaşı
• German Hospital (Alman Hastanesi): Taksim
• Acıbadem: Kadıköy

**Internet and Communication:**

**Wi-Fi:**
• Hotels, cafes, shopping centers
• Free but variable speed
• Operators: Turkcell, Vodafone, Türk Telekom

**Tourist SIM Card:**
• Airports and city centers
• Documents: Passport
• Price: From 100 TL

**Language:**
• Turkish (official)
• English: Tourist areas
• Useful phrases:
  - Merhaba (Hello)
  - Teşekkür ederim (Thank you)
  - Lütfen (Please)
  - Yardım! (Help!)

**Electricity:**
• Voltage: 220V
• Plug: Type C/E (two round pins)
• Adapter: Needed for Americans

**Working Hours:**
• Banks: 9-17 (Saturday half day)
• Shops: 9-19 (Sunday markets closed)
• Restaurants: Until late

**Final Tips:**
• Respect local culture
• Photography in mosques with permission
• Take off shoes in homes
• Thank your host (Çok teşekkür ederim)'
            ],
            
            'default' => 'Interesting question! Unfortunately, I cannot answer this specific question right now. Please be more specific or ask about:

• History of Turkey and Istanbul
• Neighborhoods of Istanbul
• Turkish restaurants and food
• Culture and etiquette
• Public transportation
• Shopping and souvenirs
• Weather and best time to visit
• Safety and travel tips

Or use the advanced search feature on our website. 🇹🇷'
        ],
        
        'tr' => [
            'history' => [
                'keywords' => ['türkiye tarihi', 'istanbul tarihi', 'bizans', 'osmanlı', 'osmanlı imparatorluğu',
                              'konstantinopolis', 'sultan mehmed fatih', 'ataturk', 'türkiye cumhuriyeti',
                              'doğu roma', 'selçuklu', 'istanbul\'un fethi', 'konstantiniyye'],
                'response' => '📜 **İstanbul ve Türkiye\'nin Kapsamlı Tarihi:**

**Bizans Dönemi (MS 330-1453):**
• Kuruluş: Büyük Konstantin tarafından MS 330\'da
• İsim: Konstantinopolis (Doğu Roma İmparatorluğu başkenti)
• En Önemli Eserler: Ayasofya, Konstantinopolis Surları, Büyük Saray
• Altın Çağ: I. Justinianus dönemi (6. yüzyıl)

**Osmanlı Dönemi (1453-1922):**
• Fetih: Sultan II. Mehmed tarafından 29 Mayıs 1453\'te
• Başkent: İstanbul Osmanlı İmparatorluğu\'nun başkenti oldu
• Gelişme: Camiler, saraylar, çarşılar ve hamamlar inşa edildi
• Zirve Dönemi: Kanuni Sultan Süleyman dönemi (16. yüzyıl)
• Önemli Eserler: Topkapı Sarayı, Süleymaniye Camii, Sultanahmet Camii

**Cumhuriyet Dönemi (1923-Günümüz):**
• Kuruluş: Mustafa Kemal Atatürk tarafından 29 Ekim 1923\'te
• Yeni Başkent: Ankara (ama İstanbul kültürel merkez olarak kaldı)
• Modernleşme: Atatürk\'ün batılılaşma reformları
• Bugün: 16 milyon nüfusla Türkiye\'nin en büyük şehri

**Önemli Dönemler:**
1. Roma Dönemi (MÖ 667 - MS 330)
2. Bizans Dönemi (330-1453)
3. Osmanlı Dönemi (1453-1922)
4. Cumhuriyet Dönemi (1923-Günümüz)

**Önemli Şahsiyetler:**
• Fatih Sultan Mehmed (İstanbul\'un Fatihi)
• Kanuni Sultan Süleyman (Osmanlı\'nın en parlak dönemi)
• Mustafa Kemal Atatürk (Modern Türkiye\'nin kurucusu)
• Hürrem Sultan (Kanuni\'nin sevgili eşi)'
            ],
            
            'neighborhoods' => [
                'keywords' => ['mahalle', 'istanbul\'un semtleri', 'sultanahmet', 'beyoğlu', 'kadıköy',
                              'beşiktaş', 'şişli', 'fatih', 'eminönü', 'bağcılar', 'sarıyer',
                              'ortaköy', 'arnavutköy', 'çengelköy', 'üsküdar', 'beykoz'],
                'response' => '🏙️ **İstanbul\'un Ünlü Semtleri:**

**Avrupa Yakası:**

**1. Sultanahmet:**
• İstanbul\'un tarihi kalbi
• Gezilecek yerler: Ayasofya, Sultanahmet Camii, Topkapı Sarayı
• Atmosfer: Turistik, tarihi, yürüyüş için mükemmel
• En iyi: Tarih severler, ilk kez gelenler

**2. Beyoğlu:**
• Kültür ve sanat merkezi
• İstiklal Caddesi, Galata Kulesi
• Restoranlar, kafeler, galeriler
• Ünlü gece hayatı

**3. Beşiktaş:**
• Modern ve şık semt
• Dolmabahçe Sarayı, İnönü Stadyumu
• Gece hayatı, lüks kafeler
• Prestijli üniversiteler

**4. Şişli:**
• Alışveriş ve iş merkezi
• İş Kuleleri
• Alışveriş merkezleri: Nişantaşı, Cevahir
• Modern şehir hayatı

**5. Fatih:**
• Geleneksel ve dini semt
• Kapalı Çarşı, İstanbul Üniversitesi
• Otantik yerel hayat
• Ucuz ve lezzetli yemekler

**Asya Yakası:**

**6. Kadıköy:**
• Asya yakasının kalbi
• Kadıköy pazarı
• Canlı öğrenci hayatı
• Havalı kafeler, deniz ürünleri restoranları

**7. Üsküdar:**
• Tarihi ve dini
• Güzel camiler, Boğaz manzaraları
• Avrupa yakasından daha sakin
• Modern ulaşım

**8. Beykoz:**
• Yeşil ve huzurlu
• Belgrad Ormanları, Anadolu Hisarı
• Lüks villalar, balık restoranları
• Şehir kalabalığından uzak

**9. Üsküdar:**
• İstanbul\'un geleneksel yüzü
• Üsküdar Meydanı, Şehzade Camii
• Mükemmel deniz ulaşımı
• Camilerin muhteşem manzarası

**Özel Semtler:**

**10. Ortaköy:**
• Boğaz Köprüsü yanında
• Sahil kafeleri
• Ünlü gün batımı manzaraları
• El yapımı ürünler pazarı

**11. Eminönü:**
• Ticari ve tarihi
• Mısır Çarşısı, iskeleler
• Tramvay istasyonu
• Toptan alışveriş

**12. Sarıyer:**
• Avrupa yakasının en kuzey noktası
• Balıkçı köyleri
• Bakir doğa
• Taze balık restoranları'
            ],
            
            'restaurants_food' => [
                'keywords' => ['restoran', 'yemek', 'türk mutfağı', 'kebap', 'baklava', 'döner', 'türk kahvaltısı',
                              'lahmacun', 'pide', 'meze', 'çiğ köfte', 'adana kebap', 'köfte', 'dolma',
                              'çorba', 'künefe', 'lokum', 'börek', 'saç', 'ciz', 'kelle paça'],
                'response' => '🍽️ **İstanbul\'un Ünlü Restoranları ve Yemekleri:**

**Restoran Kategorileri:**

**1. Lüks Restoranlar:**
• **Mikla**: Modern Türk mutfağı - Marmara Hotel üstü
• **Neolokal**: Geleneksel ve modern füzyon - Karaköy
• **Ulus 29**: Boğaz manzarası - Beşiktaş
• **360 Istanbul**: 360 derece manzara - Beyoğlu

**2. Geleneksel Restoranlar:**
• **Çiya Sofrası**: Nadir yerel yemekler - Kadıköy
• **Kanaat Lokantası**: Ev yemeği - Üsküdar
• **Hacı Abdullah**: 1888\'den beri aktif - Beyoğlu
• **Beyti**: Ünlü kebap - Florya

**3. Deniz Ürünleri Restoranları:**
• **Balıkçı Sabahattin**: Taze balık - Sultanahmet
• **Kiyi**: Mükemmel deniz ürünleri - Tarabya
• **Sur Balık**: Ayasofya manzarası - Eminönü

**4. Sokak Lezzetleri:**
• **Kızılkayalar**: Ünlü hamburger - Taksim
• **Bereket Döner**: Lezzetli döner - Beyoğlu
• **Özcan Turşuları**: Turşular - Kadıköy

**Ünlü Türk Yemekleri:**

**Ana Yemekler:**
1. **Kebaplar**:
   - Adana Kebap (acılı kıyma)
   - İskender Kebap (ekmek ve yoğurtla)
   - Çiğ Köfte (çiğ köfte)
   - Şiş Kebap (et parçaları)

2. **Et Yemekleri**:
   - Köfte (köfteler)
   - Saç Kebap (sac üzerinde)
   - Tandır (toprak fırında pişirme)

3. **Vejetaryen Yemekleri**:
   - Dolma (asma yaprağı sarma)
   - Börek (peynirli veya etli katmer)
   - Menemen (sebze ve domates)

**Deniz Ürünleri:**
• Izgara balık (Balık ızgara)
• Izgara karides (Karides)
• Izgara balık (Somon veya levrek)

**Türk Kahvaltısı:**
• **Tam kahvaltı (kahvaltı)**:
  - Çeşitli peynirler (beyaz, kaşar)
  - Siyah ve yeşil zeytin
  - Bal, kaymak (yoğun krema)
  - Sucuk (sosis), pastırma (kuru et)
  - Omlet (menemen)
  - Bolca siyah çay

**Tatlılar:**
1. **Baklava**:
   - En iyileri: Güllüoğlu, Karaköy Güllüoğlu
   - Çeşitler: antep fıstıklı, cevizli, kremalı

2. **Künefe**:
   - Peynirli tatlı telleri
   - Sıcak servis dondurmayla

3. **Lokum**:
   - Pudra şekerli jelatinli tatlı
   - Aromalar: gül, antep fıstığı, hindistan cevizi

4. **Sütlaç**:
   - Pirinç tatlısı
   - Soğuk veya sıcak

**İçecekler:**
• Türk çayı (siyah, lale bardakta)
• Türk kahvesi (acı, telveli)
• Ayran (yoğurt içeceği)
• Şerbet (vişne, gül)
• Rakı (ulusal alkollü içki)

**Yemek İpuçları:**
• Lokanta geleneksel yemekler için
• Kahve çay ve kahve için
• Pastane tatlılar için
• Meze önemli bir kültür
• Bahşiş: %10-15 normaldir'
            ],
            
            'culture_etiquette' => [
                'keywords' => ['türk kültürü', 'türk görgü kuralları', 'türk gelenekleri', 'türkiye dini', 'türkiye bayramları',
                              'ramazan bayramı', 'kurban bayramı', 'cumhuriyet bayramı', 'nevruz', 'türk müziği',
                              'türk dansı', 'türk halısı', 'türk hamamı', 'türk çayı'],
                'response' => '🎎 **Türk Kültürü ve Görgü Kuralları:**

**Din:**
• %99 Müslüman (Sünni çoğunluk)
• Hristiyan ve Yahudi azınlıklar
• Camiler: Beş vakit namaz, cuma önemli
• Ramazan: Oruç, büyük iftar yemekleri

**Resmi Tatiller:**
1. **Ramazan Bayramı**:
   - Ramazan sonrası 3 günlük kutlama
   - Ziyaret, tatlılar, ihtiyaç sahiplerine yardım

2. **Kurban Bayramı**:
   - 4 gün, en büyük bayram
   - Koyun kurban etme, et dağıtma

3. **Cumhuriyet Bayramı**:
   - 29 Ekim
   - Türkiye Cumhuriyeti\'nin kuruluş kutlaması
   - Geçit törenleri, havai fişek, konserler

4. **Gençlik ve Spor Bayramı (19 Mayıs)**
5. **Zafer Bayramı (30 Ağustos)**
6. **Çocuk Bayramı (23 Nisan)**

**Sosyal Görgü Kuralları:**

**Selamlama:**
• Erkekler: Sıkı el sıkışma
• Kadınlar: Genellikle iki yanaktan öpüşme
• "Merhaba" ya da "Selam"
• Büyüklere saygı önemlidir

**Misafirperverlik:**
• Misafir "Tanrı misafiri" sayılır
• Mutlaka çay veya kahve ikram edilir
• İkramı reddetmek kabalıktır
• En iyi yemekler misafire

**Yemek Görgü Kuralları:**
• Yemeğe "Bismillah" ile başlanır
• Kaşık ve çatal kullanılır
• Ekmek elle yenir
• Bol yemek teklifi
• Ev sahibine teşekkür şart

**Kıyafet:**
• Büyük şehirler: Batı kıyafetleri
• Muhafazakar bölgeler: Başörtüsü
• Camiler: Başörtüsü, uzun etek
• Plaj: Mayo serbest

**Sanat ve Müzik:**
• Geleneksel müzik: Kanun, ud, ney enstrümanları
• Danslar: Sema (semazen), göbek dansı
• El sanatları: Halı, seramik, gümüş
• Opera ve bale: Modern salonlar

**Türk Hamamı:**
• Hijyen kültürünün parçası
• Üç bölüm: soğukluk, sıcaklık, özel
• Köpük masajı (kese)
• Geleneksel rahatlatıcı deneyim

**Önemli Notlar:**
• Bayrak ve Atatürk\'e saygı
• Politika: Hassas konu
• Aile: Toplumun temeli
• Zaman: Avrupa\'dan daha esnek'
            ],
            
            'transportation' => [
                'keywords' => ['ulaşım', 'istanbul metro', 'otobüs', 'taksi', 'tramvay', 'dolmuş',
                              'marmaray', 'metrobüs', 'kart', 'vapur', 'feribot', 'deniz otobüsü'],
                'response' => '🚇 **İstanbul Toplu Taşıma:**

**Akıllı Kart (İstanbulkart):**
• Tüm araçlar için akıllı kart
• Satın alma: Özel kiosklar (İstanbulkart bayi)
• Maliyet: Kart için 70 TL + şarj
• Avantajlar: 2 saat içinde ücretsiz aktarma

**Metro:**
• 11 aktif hat, 150+ istasyon
• Saatler: 06:00 - 00:00
• Önemli hatlar:
  - M1A: Atatürk Havalimanı - Yenikapı
  - M2: Yenikapı - Hacıosman
  - Marmaray: Boğaz altı (Avrupa-Asya)

**Tramvay:**
• T1: Kabataş - Bağcılar
  - Önemli istasyonlar: Sultanahmet, Beyoğlu
• T4: Topkapı - Mescitçeşme

**Otobüs:**
• 800+ hat, 10.000+ otobüs
• Renkler:
  - Kırmızı: Ana hatlar
  - Mavi: Ekspres
  - Yeşil: Yerel
• Metrobüs: BRT hattı

**Dolmuş:**
• Paylaşımlı taksi
• Sabit güzergahlar
• Taksiden daha ucuz
• Kapasite: 8-10 kişi

**Taksi:**
• Sarı renk
• Zorunlu taksimetre
• Başlangıç ücreti: 40 TL
• Güvenilir markalar: BiTaksi, iTaksi (uygulamalar)

**Vapur ve Feribot:**
• 50+ deniz hattı
• Ana iskeleler:
  - Avrupa: Eminönü, Beşiktaş, Kabataş
  - Asya: Kadıköy, Üsküdar
• Popüler hatlar:
  - Eminönü - Kadıköy
  - Beşiktaş - Üsküdar
  - Prens Adaları (Adalar)

**Marmaray:**
• Boğaz altı treni
• Avrupa (Yenikapı) - Asya (Ayrılıkçeşme)
• 4 dakika su altı
• Metro bağlantısı

**Havalimanları:**
1. **İstanbul Havalimanı (IST)**:
   - Yeni, dünyanın en büyük havalimanı
   - Şehir merkezine 40 km
   - Transfer: Havaist otobüs veya taksi

2. **Sabiha Gökçen Havalimanı (SAW)**:
   - Anadolu yakası
   - İç ve düşük maliyetli uçuşlar
   - Transfer: Havabüs

**Önemli İpuçları:**
• Yoğun saatler: 07-09, 17-20
• Kadınlar: Bazı trenlerde özel vagonlar
• Engelliler: Yeni istasyonlarda iyi erişim
• Bisiklet: Metro ve vapurda izinli'
            ],
            
            'shopping_souvenirs' => [
                'keywords' => ['alışveriş', 'hediyelik', 'kapalı çarşı', 'mısır çarşısı', 'alışveriş merkezi', 'türk halısı',
                              'türk çayı', 'lokum', 'bakır eşya', 'gümüş', 'deri', 'nazar boncuğu', 'türk kahvesi',
                              'altın suyu', 'oyuncak bebek', 'seccade', 'tesbih'],
                'response' => '🛍️ **İstanbul\'da Alışveriş ve Hediyelik Eşyalar:**

**Tarihi Çarşılar:**

**1. Kapalı Çarşı:**
• Dünyanın en büyük kapalı çarşısı
• 61 sokak, 4000 dükkan
• Uzmanlaşmış bölümler:
  - Kuyumcular (Altın pazarı)
  - Halıcılar (Halı pazarı)
  - Dericiler (Deri pazarı)
  - Gümüşçüler (Gümüş pazarı)
• Saatler: 9-19 (Pazar kapalı)

**2. Mısır Çarşısı:**
• Mısır çarşısı, Yeni Camii yanı
• Baharatlar, kuruyemişler, şifalı bitkiler
• Lokum, tatlılar, pastiller
• Saatler: 8-19:30

**3. Arasta Çarşısı:**
• Sultanahmet Camii arkası
• Kaliteli el işleri
• Halılar, seramikler, resimler

**Modern Alışveriş Merkezleri:**

**4. İstinye Park:**
• En lüks alışveriş merkezi
• Uluslararası markalar: LV, Gucci, Prada
• Şık restoranlar

**5. Cevahir:**
• Avrupa\'nın en büyük alışveriş merkezi
• 340 mağaza, sinema, bowling
• Anadolu yakası: Capitol

**6. Nişantaşı:**
• Lüks alışveriş bölgesi
• Abdi İpekçi Caddesi
• Türk tasarımcı butikleri

**Ünlü Hediyelik Eşyalar:**

**1. Halı ve Kilim:**
• Üretim bölgeleri: Kayseri, Konya
• Orijinallik işareti: İpek halılar için "Hereke"
• Fiyat: 100$ ve üzeri

**2. Türk Lokumu:**
• Ünlü markalar: Hacı Bekir, Hafız Mustafa
• Aromalar: antep fıstıklı, güllü, hindistan cevizli
• Kutu paketleme

**3. Türk Çayı:**
• Karadeniz bölgesinden
• Markalar: Doğuş, Çaykur
• İki katlı çaydanlık

**4. Türk Kahvesi:**
• Marka: Kurukahveci Mehmet Efendi
• İnce öğütülmüş
• Bakır cezve ile

**5. Bakır ve Gümüş Eşyalar:**
• Kapalı Çarşı, Mısır Çarşısı
• Tencere, tepsiler, vazolar
• El oymacılığı

**6. Nazar Boncuğu:**
• Kem göze karşı koruma
• Mavi, beyaz ve sarı daireler
• Kolye, bileklik, süslemeler

**7. Deri Ürünleri:**
• Çanta, ayakkabı, ceket
• Laleli bölgesi ünlü

**8. Çini:**
• Çini ve seramik eşyalar
• Geleneksel desenler
• İznik şehrinden

**Alışveriş İpuçları:**
• Pazarlık: Çarşılarda yaygın
• Kredi kartı: AVM\'lerde kabul edilir
• Pasaport: Vergi indirimi için
• Kargo: Yurtdışına posta hizmetleri'
            ],
            
            'weather_besttime' => [
                'keywords' => ['hava durumu', 'en iyi seyahat zamanı', 'istanbul mevsimleri', 'istanbul yaz', 'istanbul kış',
                              'istanbul bahar', 'istanbul sonbahar', 'sıcaklık', 'yağmur', 'kar', 'nem', 'iklim'],
                'response' => '🌤️ **İstanbul Hava Durumu ve En İyi Seyahat Zamanı:**

**İstanbul İklimi:**
• Nemli subtropikal
• Sıcak ve nemli yazlar
• Soğuk ve yağmurlu kışlar
• İki kıta: Avrupa (daha ılıman), Asya (daha nemli)

**Mevsimler:**

**İlkbahar (Mart - Mayıs):**
• **Sıcaklık**: 10°C - 20°C
• **Özellikler**: Ilıman, çiçekler açıyor
• **Giyim**: Hafif, gece için ceket
• **Avantajlar**: Kalabalık değil, iyi fiyatlar
• **Etkinlikler**: Çocuk Bayramı (23 Nisan)

**Yaz (Haziran - Ağustos):**
• **Sıcaklık**: 20°C - 30°C (bazen 35°C\'ye kadar)
• **Özellikler**: Sıcak, nemli, kalabalık
• **Giyim**: Hafif, şapka, güneş kremi
• **Avantajlar**: Uzun günler, festivaller
• **Not**: Oteller pahalı, erken rezervasyon

**Sonbahar (Eylül - Kasım):**
• **Sıcaklık**: 15°C - 25°C
• **Özellikler**: Serin, sonbahar renkleri
• **Giyim**: Kat kat
• **Avantajlar**: Ziyaret için en iyi mevsim
• **Etkinlikler**: Cumhuriyet Bayramı (29 Ekim)

**Kış (Aralık - Şubat):**
• **Sıcaklık**: 5°C - 10°C
• **Özellikler**: Soğuk, yağmurlu, bazen kar
• **Giyim**: Sıcak mont, şemsiye, bot
• **Avantajlar**: En az kalabalık mevsim, düşük fiyatlar
• **Etkinlikler**: Yılbaşı, alışveriş indirimleri

**Aylık Ortalamalar:**
• Ocak: 6°C, 10 yağmurlu gün
• Nisan: 13°C, 8 yağmurlu gün
• Temmuz: 24°C, 3 yağmurlu gün
• Ekim: 17°C, 9 yağmurlu gün

**Aktiviteler için En İyi Zaman:**

**Tarih severler**: İlkbahar ve sonbahar (rahat yürüyüş)
**Fotoğrafçılar**: Sonbahar (renkler) ve kış (camilerde kar)
**Alışverişçiler**: Ocak ve Temmuz (sezon indirimleri)
**Yemek meraklıları**: Tüm yıl (her mevsim özel yemek var)

**Önemli Festivaller:**
• Uluslararası Film Festivali (Şubat)
• Müzik Festivali (Haziran-Temmuz)
• Alışveriş Festivali (Haziran)
• Kahve Festivali (Ekim)

**Hava Durumu İpuçları:**
• Her zaman şemsiye taşıyın
• Kat kat giyinin
• Sabah sisi olabilir
• Yaz: Su için
• Kış: Camiler soğuk'
            ],
            
            'safety_tips' => [
                'keywords' => ['güvenlik', 'emniyet', 'seyahat ipuçları', 'dolandırıcılık', 'hırsızlık', 'polis', 'acil',
                              'sigorta', 'doktor', 'eczane', 'içme suyu', 'voltaj', 'internet', 'dil'],
                'response' => '🛡️ **İstanbul\'da Güvenlik ve Seyahat İpuçları:**

**Genel Güvenlik Düzeyi:**
• İstanbul turistler için güvenli şehir
• Suç oranı: Birçok Avrupa metropolünden düşük
• Turist polisi: İngilizce konuşur

**Güvenlik İpuçları:**

**1. Hırsızlığı Önleme:**
• Çanta ve değerli eşyaları önünüzde tutun
• Kalabalık yerlerde (Taksim, Kapalı Çarşı) dikkatli olun
• Pasaportu otelde bırakın, fotokopi taşıyın
• Anti-hırsızlık cüzdan kullanın

**2. Yaygın Dolandırıcılıklar:**
• Ayakkabı boyacıları: Ayakkabınızı alır ve para ister
• Menüsüz restoranlar: Fiyatları sorun
• Yasa dışı taksiler: Sadece sarı taksiye binin
• "Yeni arkadaş": Beklenmedik tekliflere dikkat edin

**3. Sokakta:**
• Bankaların içindeki ATM\'leri kullanın
• Çok nakit taşımayın
• Çevrimdışı harita bulundurun
• Geceleri kötü aydınlatılmış alanlardan kaçının

**Acil Durum Numaraları:**
• Polis: 155
• Ambulans: 112
• İtfaiye: 110
• Turist Polisi: 0212 527 45 03

**Sağlık ve Hijyen:**

**İçme Suyu:**
• Musluk suyu içilebilir ama...
• Şişe su içmek daha iyidir
• Fiyat: 1,5 litre için 2-5 TL

**Eczane:**
• Büyük kırmızı "E" işareti
• Nöbetçi eczaneler: Geceleri açık
• Reçetesiz ilaçlar sınırlı

**Güvenilir Hastaneler:**
• Amerikan Hastanesi: Nişantaşı
• Alman Hastanesi: Taksim
• Acıbadem: Kadıköy

**İnternet ve İletişim:**

**Wi-Fi:**
• Oteller, kafeler, alışveriş merkezleri
• Ücretsiz ama değişken hız
• Operatörler: Turkcell, Vodafone, Türk Telekom

**Turist SIM Kartı:**
• Havalimanları ve şehir merkezleri
• Belgeler: Pasaport
• Fiyat: 100 TL\'den başlar

**Dil:**
• Türkçe (resmi)
• İngilizce: Turistik bölgeler
• Yararlı ifadeler:
  - Merhaba (Hello)
  - Teşekkür ederim (Thank you)
  - Lütfen (Please)
  - Yardım! (Help!)

**Elektrik:**
• Voltaj: 220V
• Priz: Tip C/E (iki yuvarlak pin)
• Adaptör: Amerikalılar için gerekli

**Çalışma Saatleri:**
• Bankalar: 9-17 (Cumartesi yarım gün)
• Dükkanlar: 9-19 (Pazar çarşılar kapalı)
• Restoranlar: Geç saatlere kadar

**Son İpuçları:**
• Yerel kültüre saygı gösterin
• Camilerde fotoğraf izinle
• Evlerde ayakkabı çıkarın
• Ev sahibinize teşekkür edin (Çok teşekkür ederim)'
            ],
            
            'default' => 'İlginç bir soru sordunuz! Maalesef şu anda bu spesifik soruyu cevaplayamam. Lütfen konunuzu daha net belirtin veya şunları sorun:

• Türkiye ve İstanbul tarihi
• İstanbul\'un semtleri
• Türk restoranları ve yemekleri
• Kültür ve görgü kuralları
• Toplu taşıma
• Alışveriş ve hediyelik eşyalar
• Hava durumu ve en iyi seyahat zamanı
• Güvenlik ve seyahat ipuçları

Veya web sitemizdeki gelişmiş arama özelliğini kullanın. 🇹🇷'
        ]
    ];
    
    // Get responses for current language
    $responses = isset($knowledge_base[$language]) ? $knowledge_base[$language] : $knowledge_base['fa'];
    
    // Check each category
    foreach ($responses as $category => $data) {
        if ($category === 'default') continue;
        
        foreach ($data['keywords'] as $keyword) {
            if (stripos($lower_message, $keyword) !== false) {
                return $data['response'];
            }
        }
    }
    
    // Check for specific place names
    $specific_places = [
        'fa' => [
            'ایاصوفیه' => 'ایاصوفیه یکی از شگفتی‌های معماری جهان است. ابتدا کلیسا، سپس مسجد و اکنون موزه. ساخت آن در سال ۵۳۷ میلادی به پایان رسید. گنبد اصلی ۵۵ متر ارتفاع دارد. موزاییک‌های بیزانسی آن بسیار معروف هستند. ساعت بازدید: ۹-۱۹ (دوشنه تعطیل). هزینه: ۱۰۰ لیر.',
            'مسجد آبی' => 'مسجد سلطان احمد (مسجد آبی) بین سال‌های ۱۶۰۹-۱۶۱۶ ساخته شد. نام آبی از کاشی‌های آبی رنگ داخلی گرفته شده. ۶ مناره دارد که در زمان ساخت بی‌نظیر بود. ورود رایگان است اما باید پوشش مناسب داشته باشید.',
            'کاخ توپکاپی' => 'کاخ توپکاپی اقامتگاه اصلی سلاطین عثمانی برای ۴۰۰ سال. دارای ۴ حیاط، حرمسرا، آشپزخانه‌های بزرگ و خزانه. جواهرات مشهور از جمله الماس ۸۶ قیراطی قاشقچی. ساعت: ۹-۱۸ (سه‌شنبه تعطیل). هزینه: ۱۵۰ لیر.',
            'برج گالاتا' => 'برج گالاتا در سال ۱۳۴۸ ساخته شد. ارتفاع ۶۷ متر، ۹ طبقه. منظره ۳۶۰ درجه از استانبول. رستوران و کافه در طبقات بالا. هزینه: ۱۷۵ لیر. ساعت: ۸:۳۰-۲۲:۰۰.',
            'بازار بزرگ' => 'بازار بزرگ (Kapalı Çarşı) در سال ۱۴۶۱ تأسیس شد. ۶۱ خیابان، ۴۰۰۰ مغازه. بزرگترین بازار سرپوشیده جهان. بخش‌های مختلف: طلا، فرش، چرم، نقره. ساعت: ۹-۱۹ (یکشنبه تعطیل).'
        ],
        'en' => [
            'hagia sophia' => 'Hagia Sophia is one of the architectural wonders of the world. First a church, then a mosque, now a museum. Completed in 537 AD. Main dome is 55 meters high. Byzantine mosaics are famous. Hours: 9-19 (closed Monday). Fee: 100 TL.',
            'blue mosque' => 'Sultan Ahmed Mosque (Blue Mosque) built between 1609-1616. Blue name comes from blue tiles inside. Has 6 minarets which was unique when built. Free entry but dress code required.',
            'topkapi palace' => 'Topkapi Palace was main residence of Ottoman sultans for 400 years. Has 4 courtyards, harem, large kitchens and treasury. Famous jewels including 86-carat Spoonmaker\'s Diamond. Hours: 9-18 (closed Tuesday). Fee: 150 TL.',
            'galata tower' => 'Galata Tower built in 1348. Height 67 meters, 9 floors. 360-degree view of Istanbul. Restaurant and cafe on upper floors. Fee: 175 TL. Hours: 8:30-22:00.',
            'grand bazaar' => 'Grand Bazaar (Kapalı Çarşı) established in 1461. 61 streets, 4000 shops. World\'s largest covered market. Sections: gold, carpets, leather, silver. Hours: 9-19 (closed Sunday).'
        ],
        'tr' => [
            'ayasofya' => 'Ayasofya dünyanın mimari harikalarından biridir. Önce kilise, sonra cami, şimdi müze. MS 537\'de tamamlandı. Ana kubbe 55 metre yüksekliğinde. Bizans mozaikleri ünlüdür. Saatler: 9-19 (Pazartesi kapalı). Ücret: 100 TL.',
            'sultanahmet camii' => 'Sultanahmet Camii (Mavi Cami) 1609-1616 yılları arasında inşa edildi. Mavi ismi içindeki mavi çinilerden gelir. 6 minaresi vardır ki inşa edildiğinde benzersizdi. Ücretsiz giriş ama kıyafet kuralları var.',
            'topkapı sarayı' => 'Topkapı Sarayı 400 yıl boyunca Osmanlı sultanlarının ana ikametgâhıydı. 4 avlu, harem, büyük mutfaklar ve hazine odaları var. 86 karatlık Kaşıkçı Elması dahil ünlü mücevherler. Saatler: 9-18 (Salı kapalı). Ücret: 150 TL.',
            'galata kulesi' => 'Galata Kulesi 1348\'de inşa edildi. Yükseklik 67 metre, 9 kat. İstanbul\'un 360 derece manzarası. Üst katlarda restoran ve kafe. Ücret: 175 TL. Saatler: 8:30-22:00.',
            'kapalı çarşı' => 'Kapalı Çarşı 1461\'de kuruldu. 61 sokak, 4000 dükkan. Dünyanın en büyük kapalı çarşısı. Bölümler: altın, halı, deri, gümüş. Saatler: 9-19 (Pazar kapalı).'
        ]
    ];
    
    $places = isset($specific_places[$language]) ? $specific_places[$language] : $specific_places['fa'];
    foreach ($places as $place => $info) {
        if (stripos($lower_message, $place) !== false) {
            return $info;
        }
    }
    
    // Default response
    return $responses['default'];
}

// ======================== آرایه چندزبانه منو با ترجمه کامل ========================
$multi_lang_content = [
    'nav' => [
        'fa' => [
            // 'home' => 'خانه',
            // 'discover' => 'کشف‌کنید',
            // 'accommodation' => 'اقامت',
            // 'experiences' => 'تجربه‌ها',
            // 'itinerary' => 'برنامه سفر',
            // 'map' => 'نقشه',
            // 'router' => 'مسیریاب',
            'about' => 'درباره پروژه',
            'login' => 'ورود / ثبت‌نام'
        ],
        'tr' => [
            // 'home' => 'Ana Sayfa',
            // 'discover' => 'Keşfedin',
            // 'accommodation' => 'Konaklama',
            // 'experiences' => 'Deneyimler',
            // 'itinerary' => 'Seyahat Planı',
            // 'map' => 'Harita',
            // 'router' => 'Rota Bulucu',
            'about' => 'Proje Hakkında',
            'login' => 'Giriş / Kayıt'
        ],
        'en' => [
            // 'home' => 'Home',
            // 'discover' => 'Discover',
            // 'accommodation' => 'Accommodation',
            // 'experiences' => 'Experiences',
            // 'itinerary' => 'Itinerary',
            // 'map' => 'Map',
            // 'router' => 'Route Finder',
            'about' => 'About Project',
            'login' => 'Login / Register'
        ]
    ],
    'hero' => [
        'fa' => [
            'title1' => 'جادوی بی‌پایان استانبول 🇹🇷',
            'subtitle1' => 'جایی که شرق و غرب در هم می‌آمیزند',
            'cta1' => 'کشف استانبول',
            'title2' => 'تجربه تاریخی بی‌نظیر',
            'subtitle2' => 'از بیزانس تا امپراتوری عثمانی',
            'cta2' => 'مشاهده جاذبه‌ها',
            'title3' => 'طعم‌های فراموش‌نشدنی',
            'subtitle3' => 'از غذاهای خیابانی تا رستوران‌های ستاره‌دار',
            'cta3' => 'کشف رستوران‌ها'
        ],
        'tr' => [
            'title1' => 'İstanbul\'un Sonsuz Büyüsü 🇹🇷',
            'subtitle1' => 'Doğu ve Batının Buluştuğu Yer',
            'cta1' => 'İstanbul\'u Keşfet',
            'title2' => 'Eşsiz Tarihi Deneyim',
            'subtitle2' => 'Bizans\'tan Osmanlı İmparatorluğu\'na',
            'cta2' => 'Görülecek Yerleri Gör',
            'title3' => 'Unutulmaz Lezzetler',
            'subtitle3' => 'Sokak Yemeklerinden Yıldızlı Restoranlara',
            'cta3' => 'Restoranları Keşfet'
        ],
        'en' => [
            'title1' => 'Endless Magic of Istanbul 🇹🇷',
            'subtitle1' => 'Where East Meets West',
            'cta1' => 'Discover Istanbul',
            'title2' => 'Unique Historical Experience',
            'subtitle2' => 'From Byzantium to Ottoman Empire',
            'cta2' => 'View Attractions',
            'title3' => 'Unforgettable Flavors',
            'subtitle3' => 'From Street Food to Starred Restaurants',
            'cta3' => 'Discover Restaurants'
        ]
    ],
    'stats' => [
        'fa' => [
            'historical' => 'جاذبه تاریخی',
            'hotels' => 'هتل و اقامتگاه',
            'restaurants' => 'رستوران و کافه',
            'undiscovered' => 'منطقه کشف‌نشده'
        ],
        'tr' => [
            'historical' => 'Tarihi Yer',
            'hotels' => 'Otel ve Konaklama',
            'restaurants' => 'Restoran ve Kafe',
            'undiscovered' => 'Keşfedilmemiş Alan'
        ],
        'en' => [
            'historical' => 'Historical Places',
            'hotels' => 'Hotels & Accommodation',
            'restaurants' => 'Restaurants & Cafes',
            'undiscovered' => 'Undiscovered Areas'
        ]
    ],
    'sections' => [
        'fa' => [
            'discover_title' => 'جاذبه‌های برتر استانبول',
            'discover_sub' => 'معروف‌ترین و دیدنی‌ترین مکان‌های شهر را کشف کنید',
            'view_all' => 'مشاهده همه',
            'categories_title' => 'بر اساس علاقه‌تان کشف کنید',
            'categories_sub' => 'دسته‌بندی‌های محبوب برای سفر شما',
            'hotels_title' => 'اقامت‌گاه‌های منتخب',
            'hotels_sub' => 'بهترین هتل‌ها، ویلاها و اقامتگاه‌های محلی',
            'experiences_title' => 'تجربه‌های ویژه استانبول',
            'experiences_sub' => 'کارهایی که فقط در استانبول می‌توانید انجام دهید',
            'virtual_title' => 'تور مجازی ۳۶۰ درجه',
            'virtual_sub' => 'قبل از سفر از خانه دیدن کنید',
            'planner_title' => 'برنامه‌ریز سفر هوشمند',
            'planner_sub' => 'برنامه سفری شخصی‌سازی شده بر اساس علاقه شما'
        ],
        'tr' => [
            'discover_title' => 'İstanbul\'un En İyi Yerleri',
            'discover_sub' => 'Şehrin en ünlü ve görülmeye değer yerlerini keşfedin',
            'view_all' => 'Tümünü Gör',
            'categories_title' => 'İlginize Göre Keşfedin',
            'categories_sub' => 'Seyahatiniz için popüler kategoriler',
            'hotels_title' => 'Seçkin Konaklama Yerleri',
            'hotels_sub' => 'En iyi oteller, villalar ve yerel konaklamalar',
            'experiences_title' => 'İstanbul\'a Özel Deneyimler',
            'experiences_sub' => 'Sadece İstanbul\'da yapabileceğiniz şeyler',
            'virtual_title' => '360 Derece Sanal Tur',
            'virtual_sub' => 'Seyahatinizden önce evden ziyaret edin',
            'planner_title' => 'Akıllı Seyahat Planlayıcı',
            'planner_sub' => 'İlginize göre kişiselleştirilmiş seyahat planı'
        ],
        'en' => [
            'discover_title' => 'Top Attractions of Istanbul',
            'discover_sub' => 'Discover the most famous and worth seeing places of the city',
            'view_all' => 'View All',
            'categories_title' => 'Discover According to Your Interest',
            'categories_sub' => 'Popular categories for your trip',
            'hotels_title' => 'Selected Accommodations',
            'hotels_sub' => 'Best hotels, villas and local accommodations',
            'experiences_title' => 'Special Istanbul Experiences',
            'experiences_sub' => 'Things you can only do in Istanbul',
            'virtual_title' => '360 Degree Virtual Tour',
            'virtual_sub' => 'Visit from home before your trip',
            'planner_title' => 'Smart Travel Planner',
            'planner_sub' => 'Personalized travel plan according to your interest'
        ]
    ]
];

$lang_menu = [
    'fa' => ['name' => 'فارسی', 'flag' => '🇮🇷'],
    'tr' => ['name' => 'Türkçe', 'flag' => '🇹🇷'],
    'en' => ['name' => 'English', 'flag' => '🇬🇧']
];
?>
<!DOCTYPE html>
<html lang="<?php echo $current_language; ?>" dir="<?php echo $is_rtl ? 'rtl' : 'ltr'; ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    
    <title><?php echo $page_title; ?></title>
    <meta name="description" content="<?php echo $page_description; ?>">
    
    <!-- Open Graph Meta Tags -->
    <meta property="og:title" content="<?php echo $page_title; ?>">
    <meta property="og:description" content="<?php echo $page_description; ?>">
    <meta property="og:image" content="<?php echo $base_url; ?>assets/download.png">
    <meta property="og:url" content="<?php echo $base_url; ?>">
    <meta property="og:type" content="website">
    
    <!-- Favicon -->
    <link rel="icon" type="image/png" href="assets/download.png">
    
    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Vazirmatn:wght@300;400;500;600;700;800&family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    
    <!-- Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- Bootstrap 5.3 -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <style>
    
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

:root {
    --turkey-red: #E30A17;
    --turkey-white: #FFFFFF;
    --turkey-crescent: #DC143C;
    --gradient-turkey: linear-gradient(135deg, #E30A17 0%, #B00808 100%);
    --gradient-light: linear-gradient(135deg, #ffffff 0%, #f8f9fa 100%);
    --gradient-crescent: linear-gradient(45deg, #DC143C 0%, #E30A17 100%);
    --shadow-red: 0 10px 30px rgba(227, 10, 23, 0.15);
    --shadow-heavy: 0 20px 50px rgba(227, 10, 23, 0.2);
    --shadow-light: 0 5px 15px rgba(0, 0, 0, 0.05);
    --border-radius: 20px;
    --transition: all 0.3s ease;
}

body {
    font-family: 'Vazirmatn', 'Inter', sans-serif;
    line-height: 1.6;
    color: #333;
    background-color: #fff;
    overflow-x: hidden;
    transition: var(--transition);
}

body[data-theme="dark"] {
    background-color: #1a1a1a;
    color: #f0f0f0;
}

[dir="rtl"] {
    text-align: right;
}

[dir="ltr"] {
    text-align: left;
}

/* تایپوگرافی */
h1, h2, h3, h4, h5, h6 {
    font-weight: 800;
    line-height: 1.2;
    margin-bottom: 1rem;
    color: var(--turkey-red);
}

h1 {
    font-size: 3.5rem;
}

h2 {
    font-size: 2.5rem;
    position: relative;
    display: inline-block;
}

h2::after {
    content: '';
    position: absolute;
    bottom: -10px;
    right: 0;
    width: 100px;
    height: 4px;
    background: var(--turkey-red);
    border-radius: 2px;
}

[dir="rtl"] h2::after {
    right: 0;
    left: auto;
}

[dir="ltr"] h2::after {
    left: 0;
    right: auto;
}

h3 {
    font-size: 1.8rem;
}

h4 {
    font-size: 1.5rem;
}

p {
    margin-bottom: 1rem;
    font-size: 1.1rem;
    line-height: 1.8;
}

a {
    color: var(--turkey-red);
    text-decoration: none;
    transition: var(--transition);
}

a:hover {
    color: #B00808;
}

/* Preloader */
#preloader {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: var(--turkey-white);
    z-index: 99999;
    display: flex;
    justify-content: center;
    align-items: center;
    transition: opacity 0.5s ease;
}

.turkey-loader {
    position: relative;
    width: 100px;
    height: 100px;
}

.crescent-loader {
    position: absolute;
    width: 80px;
    height: 80px;
    border: 8px solid transparent;
    border-top-color: var(--turkey-red);
    border-radius: 50%;
    animation: spin 1.5s linear infinite;
}

.crescent-loader::before {
    content: '';
    position: absolute;
    top: -8px;
    left: 15px;
    width: 50px;
    height: 50px;
    background: var(--turkey-white);
    border-radius: 50%;
}

.star-loader {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    color: var(--turkey-red);
    font-size: 30px;
    animation: pulse 1s ease-in-out infinite;
}

@keyframes spin {
    0% { transform: rotate(0deg); }
    100% { transform: rotate(360deg); }
}

@keyframes pulse {
    0%, 100% { opacity: 1; transform: translate(-50%, -50%) scale(1); }
    50% { opacity: 0.5; transform: translate(-50%, -50%) scale(1.2); }
}

/* المان‌های تزئینی پرچم ترکیه */
.turkey-elements {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    pointer-events: none;
    z-index: -1;
    overflow: hidden;
}

.crescent-star-bg {
    position: absolute;
    width: 400px;
    height: 400px;
    background: radial-gradient(circle at 70% 50%, transparent 100px, var(--turkey-red) 101px),
                radial-gradient(circle at 55% 50%, var(--turkey-red) 120px, transparent 121px);
    opacity: 0.05;
    border-radius: 50%;
}

.crescent-star-bg:nth-child(1) {
    top: -200px;
    right: -200px;
}

.crescent-star-bg:nth-child(2) {
    bottom: -200px;
    left: -200px;
    transform: rotate(180deg);
}

/* Custom scrollbar */
::-webkit-scrollbar {
    width: 10px;
}

::-webkit-scrollbar-track {
    background: #f1f1f1;
}

::-webkit-scrollbar-thumb {
    background: var(--turkey-red);
    border-radius: 5px;
}

::-webkit-scrollbar-thumb:hover {
    background: #B00808;
}

/* دکمه منوی موبایل */
.mobile-menu-toggle {
    display: none;
    width: 45px;
    height: 45px;
    border-radius: 50%;
    background: #f8f9fa;
    border: 2px solid #e9ecef;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    transition: var(--transition);
    color: #555;
    font-size: 1.2rem;
}

body[data-theme="dark"] .mobile-menu-toggle {
    background: #333;
    border-color: #444;
    color: #f0f0f0;
}

.mobile-menu-toggle:hover {
    background: var(--turkey-red);
    color: var(--turkey-white);
    border-color: var(--turkey-red);
}

/* Navigation - NEW DESIGN */
.floating-nav {
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    transform: none;
    background: rgba(255, 255, 255, 0.95);
    backdrop-filter: blur(20px);
    border-radius: 10;
    padding: 12px 25px;
    box-shadow: var(--shadow-red);
    border: 2px solid var(--turkey-red);
    z-index: 1000;
    width: 100%;
    transition: var(--transition);
    display: flex;
    justify-content: space-between;
    align-items: center;
    border-left: none;
    border-right: none;
    border-top: none;
}

body[data-theme="dark"] .floating-nav {
    background: rgba(40, 40, 40, 0.95);
    border-color: #ff4d4d;
}

.floating-nav:hover {
    box-shadow: var(--shadow-heavy);
    transform: none;
}

.brand-container {
    display: flex;
    align-items: center;
    gap: 12px;
}

.brand-logo {
    display: flex;
    align-items: center;
    text-decoration: none;
    color: var(--turkey-red);
    font-weight: 800;
    font-size: 1.6rem;
    transition: var(--transition);
}

.brand-logo:hover {
    transform: scale(1.05);
}

.logo-icon {
    width: 40px;
    height: 40px;
    background: var(--turkey-red);
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    margin-left: 10px;
    color: var(--turkey-white);
    font-size: 1.3rem;
}

[dir="rtl"] .logo-icon {
    margin-left: 0;
    margin-right: 10px;
}

.logo-text {
    font-family: 'Vazirmatn', sans-serif;
    display: flex;
    align-items: center;
    gap: 5px;
}

.logo-accent {
    color: #333;
    font-weight: 600;
}

body[data-theme="dark"] .logo-accent {
    color: #f0f0f0;
}

.main-nav {
    display: flex;
    align-items: center;
    gap: 25px;
}

.nav-links {
    display: flex;
    gap: 20px;
    align-items: center;
}

.nav-item {
    position: relative;
}

.nav-link {
    display: flex;
    align-items: center;
    gap: 8px;
    text-decoration: none;
    color: #555;
    font-weight: 600;
    font-size: 0.95rem;
    padding: 8px 16px;
    border-radius: 20px;
    transition: var(--transition);
    white-space: nowrap;
}

body[data-theme="dark"] .nav-link {
    color: #ccc;
}

.nav-link i {
    font-size: 1rem;
    color: var(--turkey-red);
}

.nav-link:hover, .nav-link.active {
    background: var(--turkey-red);
    color: var(--turkey-white);
}

.nav-link:hover i, .nav-link.active i {
    color: var(--turkey-white);
}

.nav-link.active::after {
    content: '';
    position: absolute;
    bottom: -8px;
    left: 50%;
    transform: translateX(-50%);
    width: 6px;
    height: 6px;
    background: var(--turkey-red);
    border-radius: 50%;
}


.nav-actions {
    display: flex;
    align-items: center;
    gap: 15px;
}


.language-selector {
    display: flex;
    gap: 8px;
}

.lang-btn {
    display: flex;
    align-items: center;
    gap: 6px;
    padding: 8px 15px;
    background: #f8f9fa;
    border: 2px solid #e9ecef;
    border-radius: 20px;
    cursor: pointer;
    transition: var(--transition);
    font-weight: 600;
    font-size: 0.85rem;
    color: #555;
    white-space: nowrap;
}

body[data-theme="dark"] .lang-btn {
    background: #333;
    border-color: #444;
    color: #ccc;
}

.lang-btn.active {
    background: var(--turkey-red);
    color: var(--turkey-white);
    border-color: var(--turkey-red);
}

.lang-btn:hover:not(.active) {
    background: #e9ecef;
    border-color: var(--turkey-red);
}

body[data-theme="dark"] .lang-btn:hover:not(.active) {
    background: #444;
}

.lang-btn .flag {
    font-size: 1.1rem;
}


.theme-toggle, .search-toggle {
    width: 40px;
    height: 40px;
    border-radius: 50%;
    background: #f8f9fa;
    border: 2px solid #e9ecef;
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    transition: var(--transition);
    color: #555;
    font-size: 1rem;
}

body[data-theme="dark"] .theme-toggle,
body[data-theme="dark"] .search-toggle {
    background: #333;
    border-color: #444;
    color: #f0f0f0;
}

.theme-toggle:hover, .search-toggle:hover {
    background: var(--turkey-red);
    color: var(--turkey-white);
    border-color: var(--turkey-red);
    transform: rotate(15deg);
}

.about-btn, .login-btn {
    padding: 10px 20px;
    border-radius: 20px;
    background: var(--turkey-red);
    color: var(--turkey-white);
    border: none;
    display: flex;
    align-items: center;
    gap: 8px;
    font-weight: 600;
    font-size: 0.9rem;
    text-decoration: none;
    transition: var(--transition);
    white-space: nowrap;
}

.about-btn:hover, .login-btn:hover {
    transform: translateY(-2px);
    box-shadow: 0 5px 15px rgba(227, 10, 23, 0.3);
}

.login-btn {
    background: transparent;
    color: var(--turkey-red);
    border: 2px solid var(--turkey-red);
}

.login-btn:hover {
    background: var(--turkey-red);
    color: var(--turkey-white);
}


.user-menu {
    position: relative;
}

.user-avatar {
    width: 40px;
    height: 40px;
    border-radius: 50%;
    background: #f8f9fa;
    border: 2px solid #e9ecef;
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    transition: var(--transition);
    color: #555;
    font-size: 1.2rem;
}

body[data-theme="dark"] .user-avatar {
    background: #333;
    border-color: #444;
    color: #f0f0f0;
}

.user-avatar:hover {
    background: var(--turkey-red);
    color: var(--turkey-white);
    border-color: var(--turkey-red);
}

.user-dropdown {
    position: absolute;
    top: 100%;
    right: 0;
    background: var(--turkey-white);
    border-radius: 15px;
    box-shadow: var(--shadow-red);
    min-width: 200px;
    display: none;
    overflow: hidden;
    z-index: 1000;
    border: 2px solid var(--turkey-red);
    margin-top: 10px;
}

body[data-theme="dark"] .user-dropdown {
    background: #333;
    color: #f0f0f0;
    border-color: #ff4d4d;
}

.user-menu:hover .user-dropdown {
    display: block;
}

.user-dropdown a {
    display: block;
    padding: 12px 20px;
    text-decoration: none;
    color: #333;
    transition: var(--transition);
    border-bottom: 1px solid #f1f1f1;
    display: flex;
    align-items: center;
    gap: 10px;
}

body[data-theme="dark"] .user-dropdown a {
    color: #f0f0f0;
    border-bottom-color: #444;
}

.user-dropdown a:hover {
    background: var(--turkey-red);
    color: var(--turkey-white);
}

.user-dropdown .dropdown-divider {
    height: 1px;
    background: #f1f1f1;
    margin: 5px 0;
}

body[data-theme="dark"] .user-dropdown .dropdown-divider {
    background: #444;
}

/* Hero Section */
.hero-section {
    position: relative;
    height: 100vh;
    min-height: 700px;
    overflow: hidden;
    background: var(--turkey-red);
    margin-top: 0;
}

.hero-background {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
}

.hero-slider .slide {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background-size: cover;
    background-position: center;
    opacity: 0;
    transition: opacity 1s ease;
    display: flex;
    align-items: center;
    justify-content: center;
}

.hero-slider .slide.active {
    opacity: 1;
}

.slide-content {
    text-align: center;
    color: var(--turkey-white);
    padding: 0 20px;
    max-width: 800px;
    z-index: 2;
    background: rgba(227, 10, 23, 0.8);
    padding: 50px;
    border-radius: 30px;
    backdrop-filter: blur(10px);
    border: 3px solid var(--turkey-white);
    box-shadow: var(--shadow-heavy);
}

.hero-title {
    font-size: 4rem;
    font-weight: 800;
    margin-bottom: 20px;
    text-shadow: 0 3px 10px rgba(0,0,0,0.3);
    background: linear-gradient(to right, #ffffff, #ffe6e6);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
}

.hero-subtitle {
    font-size: 1.5rem;
    margin-bottom: 40px;
    opacity: 0.9;
}

.hero-cta {
    display: inline-flex;
    align-items: center;
    gap: 15px;
    background: var(--turkey-white);
    color: var(--turkey-red);
    padding: 18px 40px;
    border-radius: 30px;
    text-decoration: none;
    font-weight: 700;
    font-size: 1.2rem;
    transition: var(--transition);
    box-shadow: 0 10px 30px rgba(0,0,0,0.2);
}

.hero-cta:hover {
    background: var(--turkey-red);
    color: var(--turkey-white);
    transform: translateY(-5px) scale(1.05);
    box-shadow: 0 15px 40px rgba(227, 10, 23, 0.4);
}

[dir="rtl"] .hero-cta i {
    transform: rotate(180deg);
    margin-right: 10px;
    margin-left: 0;
}

[dir="ltr"] .hero-cta i {
    margin-left: 10px;
    margin-right: 0;
}

.hero-controls {
    position: absolute;
    bottom: 50px;
    right: 50%;
    transform: translateX(50%);
    display: flex;
    align-items: center;
    gap: 30px;
}

.hero-prev, .hero-next {
    width: 60px;
    height: 60px;
    border-radius: 50%;
    background: rgba(255,255,255,0.9);
    border: 2px solid var(--turkey-red);
    color: var(--turkey-red);
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    transition: var(--transition);
    font-size: 1.2rem;
}

.hero-prev:hover, .hero-next:hover {
    background: var(--turkey-red);
    color: var(--turkey-white);
    transform: scale(1.1);
}

.hero-dots {
    display: flex;
    gap: 15px;
}

.hero-dots .dot {
    width: 15px;
    height: 15px;
    border-radius: 50%;
    background: rgba(255,255,255,0.5);
    cursor: pointer;
    transition: var(--transition);
}

.hero-dots .dot.active {
    background: var(--turkey-white);
    transform: scale(1.3);
}

/* Quick Stats */
.quick-stats {
    position: relative;
    margin-top: -80px;
    z-index: 100;
    padding: 0 20px;
}

.stats-container {
    max-width: 1200px;
    margin: 0 auto;
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
    gap: 25px;
}

.stat-item {
    background: var(--turkey-white);
    padding: 35px 25px;
    border-radius: var(--border-radius);
    display: flex;
    align-items: center;
    gap: 25px;
    box-shadow: var(--shadow-red);
    border: 2px solid #f1f1f1;
    transition: var(--transition);
    position: relative;
    overflow: hidden;
}

body[data-theme="dark"] .stat-item {
    background: #333;
    border-color: #444;
}

.stat-item::before {
    content: '';
    position: absolute;
    top: 0;
    right: 0;
    width: 100%;
    height: 5px;
    background: var(--turkey-red);
}

.stat-item:hover {
    transform: translateY(-10px);
    box-shadow: var(--shadow-heavy);
    border-color: var(--turkey-red);
}

.stat-icon {
    width: 80px;
    height: 80px;
    background: var(--turkey-red);
    border-radius: 20px;
    display: flex;
    align-items: center;
    justify-content: center;
    color: var(--turkey-white);
    font-size: 2rem;
    flex-shrink: 0;
}

.stat-info h3 {
    font-size: 2.5rem;
    color: var(--turkey-red);
    margin-bottom: 5px;
    font-weight: 800;
}

.stat-info p {
    color: #666;
    font-size: 1.1rem;
    font-weight: 600;
}

body[data-theme="dark"] .stat-info p {
    color: #ccc;
}

/* Main Content */
.main-content {
    padding: 80px 20px;
    max-width: 1400px;
    margin: 0 auto;
}

.section {
    margin-bottom: 100px;
}

.section-header {
    text-align: center;
    margin-bottom: 50px;
    position: relative;
}

.section-header h2 {
    font-size: 3rem;
    color: var(--turkey-red);
    margin-bottom: 15px;
    font-weight: 800;
    position: relative;
    display: inline-block;
}

.section-header h2::after {
    content: '';
    position: absolute;
    bottom: -10px;
    right: 50%;
    transform: translateX(50%);
    width: 100px;
    height: 5px;
    background: var(--turkey-red);
    border-radius: 3px;
}

.section-header p {
    font-size: 1.2rem;
    color: #666;
    max-width: 600px;
    margin: 0 auto;
}

body[data-theme="dark"] .section-header p {
    color: #ccc;
}

.view-all {
    display: inline-flex;
    align-items: center;
    gap: 10px;
    color: var(--turkey-red);
    text-decoration: none;
    font-weight: 600;
    padding: 12px 25px;
    border: 2px solid var(--turkey-red);
    border-radius: 25px;
    transition: var(--transition);
    margin-top: 20px;
}

.view-all:hover {
    background: var(--turkey-red);
    color: var(--turkey-white);
    transform: translateX(-10px);
}

[dir="rtl"] .view-all:hover {
    transform: translateX(10px);
}

[dir="rtl"] .view-all i {
    transform: rotate(180deg);
    margin-right: 10px;
    margin-left: 0;
}

[dir="ltr"] .view-all i {
    margin-left: 10px;
    margin-right: 0;
}

/* Places Grid */
.places-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
    gap: 30px;
}

.place-card {
    background: var(--turkey-white);
    border-radius: var(--border-radius);
    overflow: hidden;
    box-shadow: var(--shadow-red);
    transition: var(--transition);
    border: 2px solid #f1f1f1;
}

body[data-theme="dark"] .place-card {
    background: #333;
    border-color: #444;
}

.place-card:hover {
    transform: translateY(-15px);
    box-shadow: var(--shadow-heavy);
    border-color: var(--turkey-red);
}

.place-image {
    height: 250px;
    background-size: cover;
    background-position: center;
    position: relative;
}

.place-badge {
    position: absolute;
    top: 20px;
    right: 20px;
    background: var(--turkey-red);
    color: var(--turkey-white);
    padding: 8px 20px;
    border-radius: 20px;
    font-weight: 600;
    font-size: 0.9rem;
}

.place-content {
    padding: 25px;
}

.place-title {
    font-size: 1.5rem;
    color: #333;
    margin-bottom: 10px;
    font-weight: 700;
}

body[data-theme="dark"] .place-title {
    color: #f0f0f0;
}

.place-description {
    color: #666;
    margin-bottom: 20px;
    line-height: 1.6;
}

body[data-theme="dark"] .place-description {
    color: #ccc;
}

.place-meta {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 20px;
}

.place-rating {
    display: flex;
    align-items: center;
    gap: 5px;
    color: #FFD700;
    font-weight: 600;
}

.place-price {
    background: #f8f9fa;
    padding: 8px 20px;
    border-radius: 20px;
    color: var(--turkey-red);
    font-weight: 700;
}

body[data-theme="dark"] .place-price {
    background: #444;
}

.place-actions {
    display: flex;
    gap: 10px;
}

.place-actions .action-btn {
    width: 45px;
    height: 45px;
    border-radius: 50%;
    background: #f8f9fa;
    border: 2px solid #e9ecef;
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    transition: var(--transition);
    color: #555;
    text-decoration: none;
}

body[data-theme="dark"] .place-actions .action-btn {
    background: #444;
    border-color: #555;
    color: #ccc;
}

.place-actions .action-btn:hover {
    background: var(--turkey-red);
    color: var(--turkey-white);
    border-color: var(--turkey-red);
}

/* Categories Grid */
.categories-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 25px;
}

.category-card {
    background: var(--turkey-white);
    padding: 40px 25px;
    border-radius: var(--border-radius);
    text-decoration: none;
    text-align: center;
    box-shadow: var(--shadow-red);
    transition: var(--transition);
    border: 2px solid transparent;
    position: relative;
    overflow: hidden;
}

body[data-theme="dark"] .category-card {
    background: #333;
}

.category-card::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 5px;
    background: var(--turkey-red);
}

.category-card:hover {
    transform: translateY(-10px) scale(1.05);
    box-shadow: var(--shadow-heavy);
    border-color: var(--turkey-red);
}

.category-icon {
    width: 80px;
    height: 80px;
    background: var(--turkey-red);
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 0 auto 25px;
    color: var(--turkey-white);
    font-size: 2rem;
}

.category-card h3 {
    color: var(--turkey-red);
    margin-bottom: 10px;
    font-size: 1.5rem;
}

.category-card p {
    color: var(--turkey-red);
    font-weight: 600;
    font-size: 1.1rem;
}

/* Hotels Grid */
.hotels-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(350px, 1fr));
    gap: 30px;
}

.hotel-card {
    background: var(--turkey-white);
    border-radius: var(--border-radius);
    overflow: hidden;
    box-shadow: var(--shadow-red);
    transition: var(--transition);
    border: 2px solid #f1f1f1;
}

body[data-theme="dark"] .hotel-card {
    background: #333;
    border-color: #444;
}

.hotel-card:hover {
    transform: translateY(-15px);
    box-shadow: var(--shadow-heavy);
    border-color: var(--turkey-red);
}

.hotel-image {
    height: 250px;
    background-size: cover;
    background-position: center;
    position: relative;
}

.hotel-badge {
    position: absolute;
    top: 20px;
    right: 20px;
    background: var(--turkey-red);
    color: var(--turkey-white);
    padding: 8px 20px;
    border-radius: 20px;
    font-weight: 600;
}

.hotel-content {
    padding: 25px;
}

.hotel-title {
    font-size: 1.5rem;
    color: #333;
    margin-bottom: 10px;
    font-weight: 700;
}

body[data-theme="dark"] .hotel-title {
    color: #f0f0f0;
}

.hotel-stars {
    color: #FFD700;
    margin-bottom: 15px;
    font-size: 1.2rem;
}

.hotel-price {
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.price-amount {
    font-size: 1.8rem;
    color: var(--turkey-red);
    font-weight: 800;
}

.book-btn {
    background: var(--turkey-red);
    color: var(--turkey-white);
    border: none;
    padding: 12px 30px;
    border-radius: 25px;
    font-weight: 600;
    cursor: pointer;
    transition: var(--transition);
    text-decoration: none;
    display: inline-flex;
    align-items: center;
    justify-content: center;
}

.book-btn:hover {
    transform: translateY(-3px);
    box-shadow: 0 10px 25px rgba(227, 10, 23, 0.3);
    background: #B00808;
}

/* Experiences Slider */
.experiences-slider {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
    gap: 30px;
}

.experience-card {
    background: var(--turkey-white);
    border-radius: var(--border-radius);
    overflow: hidden;
    box-shadow: var(--shadow-red);
    transition: var(--transition);
    border: 2px solid #f1f1f1;
}

body[data-theme="dark"] .experience-card {
    background: #333;
    border-color: #444;
}

.experience-card:hover {
    transform: translateY(-15px);
    box-shadow: var(--shadow-heavy);
    border-color: var(--turkey-red);
}

.exp-image {
    height: 200px;
    background-size: cover;
    background-position: center;
    position: relative;
}

.exp-badge {
    position: absolute;
    top: 20px;
    right: 20px;
    background: var(--turkey-red);
    color: var(--turkey-white);
    padding: 8px 20px;
    border-radius: 20px;
    font-weight: 600;
}

.exp-content {
    padding: 25px;
}

.exp-content h3 {
    font-size: 1.5rem;
    color: #333;
    margin-bottom: 10px;
    font-weight: 700;
}

body[data-theme="dark"] .exp-content h3 {
    color: #f0f0f0;
}

.exp-content p {
    color: #666;
    margin-bottom: 20px;
    line-height: 1.6;
}

body[data-theme="dark"] .exp-content p {
    color: #ccc;
}

.exp-meta {
    display: flex;
    justify-content: space-between;
    align-items: center;
    color: #777;
    font-size: 0.9rem;
}

body[data-theme="dark"] .exp-meta {
    color: #aaa;
}

.exp-price {
    background: #f8f9fa;
    padding: 8px 20px;
    border-radius: 20px;
    color: var(--turkey-red);
    font-weight: 700;
}

body[data-theme="dark"] .exp-price {
    background: #444;
}

/* Virtual Tour */
.virtual-container {
    background: var(--turkey-white);
    border-radius: 30px;
    overflow: hidden;
    box-shadow: var(--shadow-red);
    border: 2px solid #f1f1f1;
}

body[data-theme="dark"] .virtual-container {
    background: #333;
    border-color: #444;
}

.virtual-viewer {
    height: 500px;
    background: #f8f9fa;
}

body[data-theme="dark"] .virtual-viewer {
    background: #222;
}

.virtual-controls {
    padding: 30px;
    background: var(--turkey-white);
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
    gap: 30px;
}

body[data-theme="dark"] .virtual-controls {
    background: #333;
}

.place-buttons {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
    gap: 15px;
    margin-top: 20px;
}

.place-btn {
    background: #f8f9fa;
    border: 2px solid #e9ecef;
    padding: 15px;
    border-radius: 20px;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 10px;
    cursor: pointer;
    transition: var(--transition);
    font-weight: 600;
    color: #555;
    text-decoration: none;
}

body[data-theme="dark"] .place-btn {
    background: #444;
    border-color: #555;
    color: #ccc;
}

.place-btn:hover, .place-btn.active {
    background: var(--turkey-red);
    color: var(--turkey-white);
    border-color: var(--turkey-red);
}

.virtual-actions {
    display: flex;
    gap: 15px;
    margin-top: 20px;
    flex-wrap: wrap;
}

.action-btn {
    background: #f8f9fa;
    border: 2px solid #e9ecef;
    padding: 12px 25px;
    border-radius: 20px;
    display: flex;
    align-items: center;
    gap: 10px;
    cursor: pointer;
    transition: var(--transition);
    font-weight: 600;
    color: #555;
    text-decoration: none;
}

body[data-theme="dark"] .action-btn {
    background: #444;
    border-color: #555;
    color: #ccc;
}

.action-btn:hover {
    background: var(--turkey-red);
    color: var(--turkey-white);
    border-color: var(--turkey-red);
    transform: translateY(-3px);
}

/* ========== بخش برنامه‌ریز سفر (کاملاً بازطراحی شده) ========== */
.planner-container {
    background: var(--turkey-white);
    border-radius: 30px;
    padding: 50px;
    box-shadow: var(--shadow-red);
    border: 2px solid #f1f1f1;
}

body[data-theme="dark"] .planner-container {
    background: #333;
    border-color: #444;
}

.planner-steps {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 30px;
    margin-bottom: 50px;
}

.step {
    display: flex;
    align-items: center;
    gap: 20px;
    padding: 25px;
    background: #f8f9fa;
    border-radius: 20px;
    transition: var(--transition);
    border: 2px solid transparent;
}

body[data-theme="dark"] .step {
    background: #444;
}

.step:hover, .step.active {
    border-color: var(--turkey-red);
    background: var(--turkey-white);
    box-shadow: 0 10px 30px rgba(227, 10, 23, 0.1);
}

body[data-theme="dark"] .step:hover,
body[data-theme="dark"] .step.active {
    background: #555;
}

.step-number {
    width: 60px;
    height: 60px;
    background: var(--turkey-red);
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    color: var(--turkey-white);
    font-size: 1.8rem;
    font-weight: 800;
    flex-shrink: 0;
}

.step-content h3 {
    color: #333;
    margin-bottom: 5px;
    font-size: 1.3rem;
}

body[data-theme="dark"] .step-content h3 {
    color: #f0f0f0;
}

.step-content p {
    color: #666;
}

body[data-theme="dark"] .step-content p {
    color: #ccc;
}

.planner-form {
    background: #f8f9fa;
    padding: 40px;
    border-radius: 25px;
    margin-bottom: 40px;
}

body[data-theme="dark"] .planner-form {
    background: #444;
}

.form-group {
    margin-bottom: 30px;
}

.form-group label {
    display: block;
    margin-bottom: 15px;
    color: #333;
    font-weight: 600;
    font-size: 1.1rem;
}

body[data-theme="dark"] .form-group label {
    color: #f0f0f0;
}

.day-selector {
    display: flex;
    gap: 15px;
    flex-wrap: wrap;
}

.day-btn {
    padding: 15px 30px;
    background: var(--turkey-white);
    border: 2px solid #e9ecef;
    border-radius: 20px;
    cursor: pointer;
    transition: var(--transition);
    font-weight: 600;
    color: #555;
}

body[data-theme="dark"] .day-btn {
    background: #333;
    border-color: #444;
    color: #ccc;
}

.day-btn:hover, .day-btn.active {
    background: var(--turkey-red);
    color: var(--turkey-white);
    border-color: var(--turkey-red);
}

.interest-tags {
    display: flex;
    gap: 15px;
    flex-wrap: wrap;
}

.interest-tag {
    padding: 12px 25px;
    background: var(--turkey-white);
    border: 2px solid #e9ecef;
    border-radius: 25px;
    cursor: pointer;
    transition: var(--transition);
    font-weight: 600;
    color: #555;
}

body[data-theme="dark"] .interest-tag {
    background: #333;
    border-color: #444;
    color: #ccc;
}

.interest-tag:hover {
    background: var(--turkey-red);
    color: var(--turkey-white);
    border-color: var(--turkey-red);
}

.interest-tag.active {
    background: var(--turkey-red);
    color: var(--turkey-white);
    border-color: var(--turkey-red);
}

.budget-slider {
    max-width: 500px;
}

.budget-labels {
    display: flex;
    justify-content: space-between;
    margin-bottom: 15px;
    color: #666;
    font-weight: 600;
}

body[data-theme="dark"] .budget-labels {
    color: #ccc;
}

.budget-range {
    width: 100%;
    height: 10px;
    border-radius: 5px;
    background: #e9ecef;
    outline: none;
    -webkit-appearance: none;
}

body[data-theme="dark"] .budget-range {
    background: #555;
}

.budget-range::-webkit-slider-thumb {
    -webkit-appearance: none;
    width: 25px;
    height: 25px;
    border-radius: 50%;
    background: var(--turkey-red);
    cursor: pointer;
    border: 3px solid var(--turkey-white);
    box-shadow: 0 3px 10px rgba(0,0,0,0.2);
}

.generate-itinerary {
    background: var(--turkey-red);
    color: var(--turkey-white);
    border: none;
    padding: 18px 40px;
    border-radius: 30px;
    font-weight: 700;
    font-size: 1.1rem;
    cursor: pointer;
    transition: var(--transition);
    display: flex;
    align-items: center;
    gap: 15px;
    margin: 0 auto;
}

.generate-itinerary:hover {
    transform: translateY(-5px) scale(1.05);
    box-shadow: 0 15px 40px rgba(227, 10, 23, 0.3);
    background: #B00808;
}

/* ========== استایل‌های پیش‌نمایش برنامه ========== */
.planner-preview {
    background: var(--turkey-white);
    padding: 40px;
    border-radius: 25px;
    border: 2px solid var(--turkey-red);
    margin-top: 30px;
}

body[data-theme="dark"] .planner-preview {
    background: #444;
}

.itinerary-content {
    max-height: 600px;
    overflow-y: auto;
    padding: 10px;
}

.itinerary-day {
    background: rgba(227, 10, 23, 0.05);
    border-radius: 15px;
    padding: 20px;
    margin-bottom: 20px;
    border-left: 5px solid var(--turkey-red);
}

body[data-theme="dark"] .itinerary-day {
    background: rgba(255, 255, 255, 0.05);
}

.itinerary-day h4 {
    color: var(--turkey-red);
    margin-bottom: 15px;
    font-size: 1.3rem;
    display: flex;
    align-items: center;
    gap: 10px;
}

.activity-list {
    list-style: none;
    padding: 0;
}

.activity-list li {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 12px 15px;
    border-bottom: 1px solid rgba(227, 10, 23, 0.1);
    flex-wrap: wrap;
    gap: 10px;
}

.activity-time {
    background: var(--turkey-red);
    color: white;
    padding: 5px 12px;
    border-radius: 20px;
    font-size: 0.8rem;
    font-weight: bold;
}

.activity-name {
    flex: 2;
    min-width: 150px;
    font-weight: 600;
}

.activity-duration, .activity-price {
    font-size: 0.9rem;
    opacity: 0.9;
}

.day-summary {
    margin-top: 15px;
    padding-top: 15px;
    border-top: 1px dashed rgba(227, 10, 23, 0.3);
    display: flex;
    justify-content: space-between;
    font-weight: bold;
    flex-wrap: wrap;
}

.empty-state {
    text-align: center;
    padding: 40px 20px;
    color: #888;
}

/* Newsletter */
.newsletter-section {
    background: var(--turkey-red);
    color: var(--turkey-white);
    padding: 80px 20px;
    border-radius: 40px;
    text-align: center;
    margin-top: 80px;
    position: relative;
    overflow: hidden;
}

.newsletter-section::before {
    content: '';
    position: absolute;
    top: -100px;
    right: -100px;
    width: 300px;
    height: 300px;
    background: radial-gradient(circle, rgba(255,255,255,0.1) 0%, transparent 70%);
}

.newsletter-container {
    max-width: 800px;
    margin: 0 auto;
    position: relative;
    z-index: 1;
}

.newsletter-content h2 {
    font-size: 3rem;
    margin-bottom: 20px;
    font-weight: 800;
}

.newsletter-content p {
    font-size: 1.2rem;
    opacity: 0.9;
    margin-bottom: 40px;
}

.newsletter-form .input-group {
    display: flex;
    max-width: 500px;
    margin: 0 auto;
    gap: 15px;
}

.newsletter-form input {
    flex: 1;
    padding: 18px 25px;
    border: none;
    border-radius: 30px;
    font-size: 1.1rem;
    outline: none;
}

.subscribe-btn {
    background: var(--turkey-white);
    color: var(--turkey-red);
    border: none;
    padding: 18px 40px;
    border-radius: 30px;
    font-weight: 700;
    cursor: pointer;
    transition: var(--transition);
    display: flex;
    align-items: center;
    gap: 10px;
}

.subscribe-btn:hover {
    background: #f8f9fa;
    transform: translateY(-3px);
}

.privacy-note {
    margin-top: 20px;
    opacity: 0.8;
}

.privacy-note a {
    color: var(--turkey-white);
    text-decoration: underline;
}

/* AI Assistant */
.ai-assistant {
    position: fixed;
    bottom: 30px;
    left: 30px;
    width: 350px;
    background: var(--turkey-white);
    border-radius: 25px;
    box-shadow: var(--shadow-heavy);
    border: 2px solid var(--turkey-red);
    z-index: 1000;
    overflow: hidden;
    display: none;
}

body[data-theme="dark"] .ai-assistant {
    background: #333;
    border-color: #ff4d4d;
}

.assistant-header {
    background: var(--turkey-red);
    color: var(--turkey-white);
    padding: 20px;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.assistant-info {
    display: flex;
    align-items: center;
    gap: 15px;
}

.assistant-avatar {
    width: 50px;
    height: 50px;
    background: var(--turkey-white);
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    color: var(--turkey-red);
    font-size: 1.5rem;
}

.assistant-text h4 {
    margin-bottom: 5px;
    font-size: 1.2rem;
}

.assistant-text p {
    opacity: 0.9;
    font-size: 0.9rem;
}

.assistant-actions {
    display: flex;
    gap: 10px;
}

.minimize-btn, .close-btn {
    width: 35px;
    height: 35px;
    border-radius: 50%;
    background: rgba(255,255,255,0.2);
    border: none;
    color: var(--turkey-white);
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    transition: var(--transition);
}

.minimize-btn:hover, .close-btn:hover {
    background: rgba(255,255,255,0.3);
}

.assistant-chat {
    height: 400px;
    display: flex;
    flex-direction: column;
}

.chat-messages {
    flex: 1;
    padding: 20px;
    overflow-y: auto;
    display: flex;
    flex-direction: column;
    gap: 15px;
}

.message {
    display: flex;
    max-width: 85%;
}

.message.user {
    align-self: flex-end;
}

.message.user .message-content {
    background: var(--turkey-red);
    color: var(--turkey-white);
    padding: 12px 18px;
    border-radius: 20px 20px 5px 20px;
    border: 1px solid var(--turkey-red);
}

.message.ai .message-content {
    background: #f8f9fa;
    color: #333;
    padding: 12px 18px;
    border-radius: 20px 20px 20px 5px;
    border: 1px solid #e9ecef;
}

body[data-theme="dark"] .message.ai .message-content {
    background: #444;
    color: #f0f0f0;
    border-color: #555;
}

.chat-input {
    padding: 20px;
    border-top: 1px solid #e9ecef;
    display: flex;
    gap: 15px;
}

body[data-theme="dark"] .chat-input {
    border-top-color: #555;
}

.chat-input input {
    flex: 1;
    padding: 15px;
    border: 2px solid #e9ecef;
    border-radius: 25px;
    outline: none;
    font-size: 1rem;
}

body[data-theme="dark"] .chat-input input {
    background: #444;
    border-color: #555;
    color: #f0f0f0;
}

.send-btn {
    width: 50px;
    height: 50px;
    border-radius: 50%;
    background: var(--turkey-red);
    color: var(--turkey-white);
    border: none;
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    transition: var(--transition);
}

.send-btn:hover {
    transform: scale(1.1);
    box-shadow: 0 5px 15px rgba(227, 10, 23, 0.3);
}

/* Footer */
.main-footer {
    background: #1a1a1a;
    color: var(--turkey-white);
    padding: 80px 20px 40px;
    position: relative;
    border-top-left-radius: 50px;
    border-top-right-radius: 50px;
}

.main-footer::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 5px;
    background: var(--turkey-red);
}

.footer-container {
    max-width: 1400px;
    margin: 0 auto;
}

.footer-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
    gap: 40px;
    margin-bottom: 60px;
}

.footer-logo {
    display: flex;
    align-items: center;
    gap: 15px;
    margin-bottom: 25px;
    color: var(--turkey-white);
    font-size: 1.8rem;
    font-weight: 800;
}

.footer-description {
    color: #aaa;
    line-height: 1.8;
    margin-bottom: 25px;
}

.social-links {
    display: flex;
    gap: 15px;
}

.social-link {
    width: 45px;
    height: 45px;
    background: #333;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    color: var(--turkey-white);
    text-decoration: none;
    transition: var(--transition);
}

.social-link:hover {
    background: var(--turkey-red);
    transform: translateY(-5px);
}

.footer-col h3 {
    color: var(--turkey-red);
    margin-bottom: 25px;
    font-size: 1.5rem;
}

.footer-links {
    list-style: none;
}

.footer-links li {
    margin-bottom: 15px;
}

.footer-links a {
    color: #ccc;
    text-decoration: none;
    transition: var(--transition);
    display: flex;
    align-items: center;
    gap: 10px;
}

.footer-links a:hover {
    color: var(--turkey-white);
    padding-right: 10px;
}

[dir="ltr"] .footer-links a:hover {
    padding-right: 0;
    padding-left: 10px;
}

.app-download {
    display: flex;
    flex-direction: column;
    gap: 15px;
}

.app-store-btn, .play-store-btn {
    background: #333;
    color: var(--turkey-white);
    padding: 15px 20px;
    border-radius: 15px;
    text-decoration: none;
    display: flex;
    align-items: center;
    gap: 15px;
    transition: var(--transition);
}

.app-store-btn:hover, .play-store-btn:hover {
    background: var(--turkey-red);
    transform: translateY(-5px);
}

.footer-bottom {
    padding-top: 40px;
    border-top: 1px solid #333;
    display: flex;
    justify-content: space-between;
    align-items: center;
    flex-wrap: wrap;
    gap: 20px;
}

.copyright p {
    color: #888;
    margin-bottom: 5px;
}

.footer-legal {
    display: flex;
    gap: 20px;
}

.footer-legal a {
    color: #aaa;
    text-decoration: none;
    transition: var(--transition);
}

.footer-legal a:hover {
    color: var(--turkey-red);
}

/* AI Assistant Toggle Button */
.ai-assistant-toggle {
    position: fixed;
    bottom: 30px;
    left: 30px;
    width: 60px;
    height: 60px;
    background: var(--turkey-red);
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    color: var(--turkey-white);
    font-size: 24px;
    cursor: pointer;
    z-index: 999;
    box-shadow: 0 5px 15px rgba(227, 10, 23, 0.3);
    transition: var(--transition);
}

.ai-assistant-toggle:hover {
    transform: scale(1.1);
    box-shadow: 0 8px 20px rgba(227, 10, 23, 0.4);
}

[dir="rtl"] .ai-assistant-toggle {
    left: auto;
    right: 30px;
}

[dir="rtl"] .ai-assistant {
    left: auto;
    right: 30px;
}

/* ===== مودال جستجو (اضافه شده) ===== */
.search-modal {
    display: none;
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0,0,0,0.8);
    z-index: 2000;
    align-items: center;
    justify-content: center;
    backdrop-filter: blur(10px);
}

.search-modal.active {
    display: flex;
}

.search-modal-content {
    width: 90%;
    max-width: 700px;
    max-height: 80vh;
    background: var(--turkey-white);
    border-radius: 30px;
    box-shadow: var(--shadow-heavy);
    overflow: hidden;
    border: 3px solid var(--turkey-red);
}

body[data-theme="dark"] .search-modal-content {
    background: #333;
}

.search-header {
    background: var(--turkey-red);
    color: var(--turkey-white);
    padding: 20px 25px;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.search-header h3 {
    margin: 0;
    font-size: 1.6rem;
    color: white;
}

.close-search {
    width: 40px;
    height: 40px;
    border-radius: 50%;
    background: rgba(255,255,255,0.2);
    border: none;
    color: white;
    font-size: 1.2rem;
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    transition: var(--transition);
}

.close-search:hover {
    background: rgba(255,255,255,0.3);
}

.search-body {
    padding: 25px;
}

.search-input-group {
    display: flex;
    gap: 15px;
    margin-bottom: 25px;
}

.search-input-group input {
    flex: 1;
    padding: 18px 25px;
    border: 2px solid #e9ecef;
    border-radius: 30px;
    font-size: 1.1rem;
    outline: none;
    background: #f8f9fa;
}

body[data-theme="dark"] .search-input-group input {
    background: #444;
    border-color: #555;
    color: #f0f0f0;
}

.voice-search-btn,
.clear-search-btn {
    width: 55px;
    height: 55px;
    border-radius: 50%;
    background: var(--turkey-red);
    color: white;
    border: none;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.3rem;
    cursor: pointer;
    transition: var(--transition);
}

.voice-search-btn:hover,
.clear-search-btn:hover {
    transform: scale(1.1);
    box-shadow: 0 5px 15px rgba(227,10,23,0.3);
}

.clear-search-btn {
    background: #6c757d;
}

.voice-search-btn.listening {
    background: #28a745;
    animation: pulse 1s infinite;
}

.search-stats {
    font-size: 0.95rem;
    color: #666;
    margin-bottom: 15px;
    padding: 0 5px;
}

body[data-theme="dark"] .search-stats {
    color: #ccc;
}

.search-results {
    max-height: 400px;
    overflow-y: auto;
    padding-right: 5px;
}

.result-item {
    display: flex;
    align-items: center;
    gap: 20px;
    padding: 15px;
    background: #f8f9fa;
    border-radius: 15px;
    margin-bottom: 10px;
    transition: var(--transition);
    border: 1px solid transparent;
}

body[data-theme="dark"] .result-item {
    background: #444;
}

.result-item:hover {
    border-color: var(--turkey-red);
    transform: translateX(5px);
    background: rgba(227,10,23,0.05);
}

.result-icon {
    width: 50px;
    height: 50px;
    background: var(--turkey-red);
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
    font-size: 1.3rem;
    flex-shrink: 0;
}

.result-details {
    flex: 1;
}

.result-title {
    font-size: 1.2rem;
    font-weight: 700;
    color: #333;
    margin-bottom: 5px;
}

body[data-theme="dark"] .result-title {
    color: #f0f0f0;
}

.result-type {
    display: inline-block;
    padding: 4px 12px;
    background: rgba(227,10,23,0.1);
    color: var(--turkey-red);
    border-radius: 20px;
    font-size: 0.8rem;
    font-weight: 600;
}

.result-price {
    font-weight: 700;
    color: var(--turkey-red);
}

.no-results {
    text-align: center;
    padding: 50px 20px;
    color: #888;
    font-size: 1.2rem;
}

.no-results i {
    font-size: 3rem;
    margin-bottom: 20px;
    color: #ccc;
}

/* Animations */
@keyframes float {
    0%, 100% { transform: translateY(0); }
    50% { transform: translateY(-20px); }
}

.float-animation {
    animation: float 3s ease-in-out infinite;
}

.loading-content {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    padding: 50px;
}

/* Responsive Design */
@media (max-width: 1200px) {
    .floating-nav {
        width: 97%;
    }
    
    .hero-title {
        font-size: 3.5rem;
    }
    
    .nav-links {
        gap: 15px;
    }
    
    .nav-link {
        padding: 6px 12px;
        font-size: 0.9rem;
    }
}

@media (max-width: 992px) {
    .floating-nav {
        flex-direction: column;
        gap: 15px;
        padding: 15px;
        top: 10px;
    }
    
    .main-nav {
        width: 100%;
        justify-content: space-between;
    }
    
    .nav-links {
        display: none;
    }
    
    .mobile-menu-toggle {
        display: flex;
    }
    
    .mobile-nav {
        position: fixed;
        top: 80px;
        left: 0;
        width: 100%;
        background: var(--turkey-white);
        padding: 20px;
        box-shadow: var(--shadow-heavy);
        z-index: 999;
        display: none;
        border-top: 2px solid var(--turkey-red);
    }
    
    body[data-theme="dark"] .mobile-nav {
        background: #333;
    }
    
    .mobile-nav.active {
        display: block;
    }
    
    .mobile-nav-links {
        display: flex;
        flex-direction: column;
        gap: 15px;
    }
    
    .mobile-nav-link {
        display: flex;
        align-items: center;
        gap: 10px;
        padding: 12px 20px;
        background: #f8f9fa;
        border-radius: 15px;
        text-decoration: none;
        color: #333;
        font-weight: 600;
        transition: var(--transition);
    }
    
    body[data-theme="dark"] .mobile-nav-link {
        background: #444;
        color: #f0f0f0;
    }
    
    .mobile-nav-link:hover {
        background: var(--turkey-red);
        color: var(--turkey-white);
    }
    
    .hero-title {
        font-size: 3rem;
    }
    
    .section-header h2 {
        font-size: 2.5rem;
    }
    
    .footer-grid {
        grid-template-columns: repeat(2, 1fr);
    }
    
    .nav-actions {
        gap: 10px;
    }
    
    .about-btn span, .login-btn span {
        display: none;
    }
    
    .about-btn, .login-btn {
        width: 40px;
        height: 40px;
        padding: 0;
        justify-content: center;
    }
    
    .lang-btn .lang-name {
        display: none;
    }
    
    .lang-btn {
        padding: 8px 12px;
    }
}

@media (max-width: 768px) {
    .floating-nav {
        top: 10px;
        padding: 12px 15px;
    }
    
    .brand-logo .logo-text {
        font-size: 1.4rem;
    }
    
    .hero-title {
        font-size: 2.5rem;
    }
    
    .hero-subtitle {
        font-size: 1.2rem;
    }
    
    .stats-container {
        grid-template-columns: repeat(2, 1fr);
    }
    
    .section-header h2 {
        font-size: 2rem;
    }
    
    .places-grid, .hotels-grid, .categories-grid {
        grid-template-columns: 1fr;
    }
    
    .planner-container {
        padding: 30px 20px;
    }
    
    .newsletter-content h2 {
        font-size: 2.5rem;
    }
    
    .ai-assistant {
        width: calc(100% - 40px);
        left: 20px;
        bottom: 20px;
    }
    
    [dir="rtl"] .ai-assistant {
        left: auto;
        right: 20px;
    }
    
    .footer-grid {
        grid-template-columns: 1fr;
    }
    
    .footer-bottom {
        flex-direction: column;
        text-align: center;
    }
    
    .nav-actions {
        gap: 8px;
    }
    
    .theme-toggle, .search-toggle {
        width: 35px;
        height: 35px;
        font-size: 0.9rem;
    }
}

@media (max-width: 576px) {
    .brand-logo .logo-text {
        font-size: 1.2rem;
    }
    
    .logo-icon {
        width: 35px;
        height: 35px;
        font-size: 1.1rem;
    }
    
    .hero-title {
        font-size: 2rem;
    }
    
    .hero-cta {
        padding: 15px 30px;
        font-size: 1rem;
    }
    
    .stats-container {
        grid-template-columns: 1fr;
    }
    
    .stat-item {
        padding: 25px 20px;
    }
    
    .newsletter-form .input-group {
        flex-direction: column;
    }
    
    .subscribe-btn {
        justify-content: center;
    }
    
    .ai-assistant-toggle {
        width: 50px;
        height: 50px;
        font-size: 20px;
        bottom: 20px;
        left: 20px;
    }
    
    [dir="rtl"] .ai-assistant-toggle {
        left: auto;
        right: 20px;
    }
    
    .floating-nav {
        padding: 10px;
    }
    
    .nav-actions {
        gap: 5px;
    }
    
    .lang-btn {
        padding: 6px 10px;
    }
    
    .about-btn, .login-btn {
        width: 35px;
        height: 35px;
    }
}

/* Utility Classes */
.text-center {
    text-align: center;
}

.text-right {
    text-align: right;
}

.text-left {
    text-align: left;
}

.mt-1 { margin-top: 1rem; }
.mt-2 { margin-top: 2rem; }
.mt-3 { margin-top: 3rem; }
.mt-4 { margin-top: 4rem; }
.mt-5 { margin-top: 5rem; }

.mb-1 { margin-bottom: 1rem; }
.mb-2 { margin-bottom: 2rem; }
.mb-3 { margin-bottom: 3rem; }
.mb-4 { margin-bottom: 4rem; }
.mb-5 { margin-bottom: 5rem; }

.p-1 { padding: 1rem; }
.p-2 { padding: 2rem; }
.p-3 { padding: 3rem; }
.p-4 { padding: 4rem; }
.p-5 { padding: 5rem; }
</style>
</head>
<body data-theme="<?php echo $current_theme; ?>" data-lang="<?php echo $current_language; ?>">
    
    <!-- Preloader -->
    <div id="preloader">
        <div class="turkey-loader">
            <div class="crescent-loader"></div>
            <div class="star-loader">★</div>
        </div>
    </div>

    <!-- Floating Navigation -->
    <nav class="floating-nav">
        <div class="mobile-menu-toggle" id="mobileMenuToggle">
            <i class="fas fa-bars"></i>
        </div>
        
        <div class="brand-container">
            <a href="<?php echo $base_url; ?>" class="brand-logo">
                <div class="logo-icon">
                    <i class="fas fa-mosque"></i>
                </div>
                <span class="logo-text">Istanbul<span class="logo-accent">Guide</span></span>
            </a>
        </div>
        
        <div class="main-nav">
            <div class="nav-links">
                <div class="nav-item">
                    <a href="#home" class="nav-link active">
                        <i class="fas fa-home"></i>
                        <span><?php echo $multi_lang_content['nav'][$current_language]['home']; ?></span>
                    </a>
                </div>
                <div class="nav-item">
                    <a href="map.php" class="nav-link">
                        <i class="fas fa-map"></i>
                        <span><?php echo $multi_lang_content['nav'][$current_language]['map']; ?></span>
                    </a>
                </div>
                <div class="nav-item">
                    <a href="route-finder-ultimate.html" class="nav-link">
                        <i class="fas fa-directions"></i>
                        <span><?php echo $multi_lang_content['nav'][$current_language]['router']; ?></span>
                    </a>
                </div>
                <div class="nav-item">
                    <a href="#discover" class="nav-link">
                        <i class="fas fa-compass"></i>
                        <span><?php echo $multi_lang_content['nav'][$current_language]['discover']; ?></span>
                    </a>
                </div>
                <div class="nav-item">
                    <a href="#hotels" class="nav-link">
                        <i class="fas fa-hotel"></i>
                        <span><?php echo $multi_lang_content['nav'][$current_language]['accommodation']; ?></span>
                    </a>
                </div>
                <div class="nav-item">
                    <a href="#experiences" class="nav-link">
                        <i class="fas fa-map-marked-alt"></i>
                        <span><?php echo $multi_lang_content['nav'][$current_language]['experiences']; ?></span>
                    </a>
                </div>
                <div class="nav-item">
                    <a href="#itinerary" class="nav-link">
                        <i class="fas fa-route"></i>
                        <span><?php echo $multi_lang_content['nav'][$current_language]['itinerary']; ?></span>
                    </a>
                </div>
            </div>
            
            <div class="nav-actions">
                <a href="about.php" class="about-btn">
                    <i class="fas fa-info-circle"></i>
                    <span><?php echo $multi_lang_content['nav'][$current_language]['about']; ?></span>
                </a>
                
                <?php if (!isset($_SESSION['user_id'])): ?>
                <a href="login.php" class="login-btn">
                    <i class="fas fa-sign-in-alt"></i>
                    <span><?php echo $multi_lang_content['nav'][$current_language]['login']; ?></span>
                </a>
                <?php else: ?>
                <div class="user-menu">
                    <div class="user-avatar">
                        <i class="fas fa-user-circle"></i>
                    </div>
                    <div class="user-dropdown">
                        <a href="profile.php"><i class="fas fa-id-card"></i> <?php echo $current_language == 'fa' ? 'پروفایل' : ($current_language == 'tr' ? 'Profil' : 'Profile'); ?></a>
                        <a href="settings.php"><i class="fas fa-cog"></i> <?php echo $current_language == 'fa' ? 'تنظیمات' : ($current_language == 'tr' ? 'Ayarlar' : 'Settings'); ?></a>
                        <div class="dropdown-divider"></div>
                        <a href="logout.php"><i class="fas fa-sign-out-alt"></i> <?php echo $current_language == 'fa' ? 'خروج' : ($current_language == 'tr' ? 'Çıkış' : 'Logout'); ?></a>
                    </div>
                </div>
                <?php endif; ?>
                
                <div class="language-selector">
                    <?php foreach($lang_menu as $code => $lang): ?>
                        <?php if($code != $current_language): ?>
                            <button class="lang-btn" onclick="changeLanguage('<?php echo $code; ?>')">
                                <span class="flag"><?php echo $lang['flag']; ?></span>
                                <span class="lang-name"><?php echo $lang['name']; ?></span>
                            </button>
                        <?php else: ?>
                            <button class="lang-btn active">
                                <span class="flag"><?php echo $lang['flag']; ?></span>
                                <span class="lang-name"><?php echo $lang['name']; ?></span>
                            </button>
                        <?php endif; ?>
                    <?php endforeach; ?>
                </div>
                
                <button class="theme-toggle" id="themeToggle">
                    <i class="fas fa-moon"></i>
                </button>
                
                <button class="search-toggle" id="searchToggle">
                    <i class="fas fa-search"></i>
                </button>
            </div>
        </div>
    </nav>

    <!-- Mobile Navigation -->
    <div class="mobile-nav" id="mobileNav">
        <div class="mobile-nav-links">
            <a href="#home" class="mobile-nav-link"><i class="fas fa-home"></i> <?php echo $multi_lang_content['nav'][$current_language]['home']; ?></a>
            <a href="#discover" class="mobile-nav-link"><i class="fas fa-compass"></i> <?php echo $multi_lang_content['nav'][$current_language]['discover']; ?></a>
            <a href="#hotels" class="mobile-nav-link"><i class="fas fa-hotel"></i> <?php echo $multi_lang_content['nav'][$current_language]['accommodation']; ?></a>
            <a href="#experiences" class="mobile-nav-link"><i class="fas fa-map-marked-alt"></i> <?php echo $multi_lang_content['nav'][$current_language]['experiences']; ?></a>
            <a href="#itinerary" class="mobile-nav-link"><i class="fas fa-route"></i> <?php echo $multi_lang_content['nav'][$current_language]['itinerary']; ?></a>
            <a href="map.php" class="mobile-nav-link"><i class="fas fa-map"></i> <?php echo $multi_lang_content['nav'][$current_language]['map']; ?></a>
            <a href="route-finder-ultimate.html" class="mobile-nav-link"><i class="fas fa-directions"></i> <?php echo $multi_lang_content['nav'][$current_language]['router']; ?></a>
            <a href="about.php" class="mobile-nav-link"><i class="fas fa-info-circle"></i> <?php echo $multi_lang_content['nav'][$current_language]['about']; ?></a>
            <?php if (!isset($_SESSION['user_id'])): ?>
                <a href="login.php" class="mobile-nav-link"><i class="fas fa-sign-in-alt"></i> <?php echo $multi_lang_content['nav'][$current_language]['login']; ?></a>
            <?php endif; ?>
        </div>
    </div>

    <!-- Hero Section -->
    <section class="hero-section" id="home">
        <div class="hero-background">
            <div class="hero-slider">
                <div class="slide active" style="background-image: linear-gradient(rgba(227, 10, 23, 0.3), rgba(176, 8, 8, 0.3)), url('assets/6-2-istanbul-Galata-Tower.webp');">
                    <div class="slide-content">
                        <h1 class="hero-title"><?php echo $multi_lang_content['hero'][$current_language]['title1']; ?></h1>
                        <p class="hero-subtitle"><?php echo $multi_lang_content['hero'][$current_language]['subtitle1']; ?></p>
                        <a href="#discover" class="hero-cta">
                            <span><?php echo $multi_lang_content['hero'][$current_language]['cta1']; ?></span>
                            <i class="fas fa-arrow-left"></i>
                        </a>
                    </div>
                </div>
                <div class="slide" style="background-image: linear-gradient(rgba(227, 10, 23, 0.3), rgba(176, 8, 8, 0.3)), url('assets/visit-hagia-sophia-museum.jpg');">
                    <div class="slide-content">
                        <h1 class="hero-title"><?php echo $multi_lang_content['hero'][$current_language]['title2']; ?></h1>
                        <p class="hero-subtitle"><?php echo $multi_lang_content['hero'][$current_language]['subtitle2']; ?></p>
                        <a href="#discover" class="hero-cta">
                            <span><?php echo $multi_lang_content['hero'][$current_language]['cta2']; ?></span>
                            <i class="fas fa-arrow-left"></i>
                        </a>
                    </div>
                </div>
                <div class="slide" style="background-image: linear-gradient(rgba(227, 10, 23, 0.3), rgba(176, 8, 8, 0.3)), url('assets/istanbul-doner-kebab.jpg');">
                    <div class="slide-content">
                        <h1 class="hero-title"><?php echo $multi_lang_content['hero'][$current_language]['title3']; ?></h1>
                        <p class="hero-subtitle"><?php echo $multi_lang_content['hero'][$current_language]['subtitle3']; ?></p>
                        <a href="#experiences" class="hero-cta">
                            <span><?php echo $multi_lang_content['hero'][$current_language]['cta3']; ?></span>
                            <i class="fas fa-arrow-left"></i>
                        </a>
                    </div>
                </div>
            </div>
            <div class="hero-controls">
                <button class="hero-prev"><i class="fas fa-chevron-right"></i></button>
                <div class="hero-dots">
                    <span class="dot active"></span>
                    <span class="dot"></span>
                    <span class="dot"></span>
                </div>
                <button class="hero-next"><i class="fas fa-chevron-left"></i></button>
            </div>
        </div>
    </section>

    <!-- Quick Stats -->
    <div class="quick-stats">
        <div class="stats-container">
            <div class="stat-item float-animation">
                <div class="stat-icon">
                    <i class="fas fa-landmark"></i>
                </div>
                <div class="stat-info">
                    <h3><?php echo $stats['historical_places']; ?>+</h3>
                    <p><?php echo $multi_lang_content['stats'][$current_language]['historical']; ?></p>
                </div>
            </div>
            <div class="stat-item float-animation" style="animation-delay: 0.2s">
                <div class="stat-icon">
                    <i class="fas fa-hotel"></i>
                </div>
                <div class="stat-info">
                    <h3><?php echo $stats['hotels']; ?>+</h3>
                    <p><?php echo $multi_lang_content['stats'][$current_language]['hotels']; ?></p>
                </div>
            </div>
            <div class="stat-item float-animation" style="animation-delay: 0.4s">
                <div class="stat-icon">
                    <i class="fas fa-utensils"></i>
                </div>
                <div class="stat-info">
                    <h3><?php echo $stats['restaurants']; ?>+</h3>
                    <p><?php echo $multi_lang_content['stats'][$current_language]['restaurants']; ?></p>
                </div>
            </div>
            <div class="stat-item float-animation" style="animation-delay: 0.6s">
                <div class="stat-icon">
                    <i class="fas fa-map-marked-alt"></i>
                </div>
                <div class="stat-info">
                    <h3><?php echo $stats['undiscovered_areas']; ?></h3>
                    <p><?php echo $multi_lang_content['stats'][$current_language]['undiscovered']; ?></p>
                </div>
            </div>
        </div>
    </div>

    <!-- Main Content -->
    <main class="main-content">
        <!-- Discover Section -->
        <section class="section discover-section" id="discover">
            <div class="section-header">
                <div class="header-title">
                    <h2><?php echo $multi_lang_content['sections'][$current_language]['discover_title']; ?></h2>
                    <p><?php echo $multi_lang_content['sections'][$current_language]['discover_sub']; ?></p>
                </div>
                <a href="javascript:void(0)" class="view-all" onclick="loadAllPlaces()">
                    <?php echo $multi_lang_content['sections'][$current_language]['view_all']; ?>
                    <i class="fas fa-arrow-left"></i>
                </a>
            </div>
            
            <div class="places-grid" id="placesGrid">
                <div class="loading-content">
                    <div class="turkey-loader" style="width: 60px; height: 60px;">
                        <div class="crescent-loader" style="width: 50px; height: 50px; border-width: 4px;"></div>
                        <div class="star-loader" style="font-size: 20px;">★</div>
                    </div>
                    <p style="margin-top: 20px; color: red; font-weight: 600;">
                        <?php 
                        $loading_text = [
                            'fa' => 'در حال بارگذاری مکان‌ها...',
                            'tr' => 'Yerler yükleniyor...',
                            'en' => 'Loading places...'
                        ];
                        echo $loading_text[$current_language] ?? 'Loading...';
                        ?>
                    </p>
                </div>
            </div>
        </section>

        <!-- Featured Categories -->
        <section class="section categories-section">
            <div class="section-header">
                <h2><?php echo $multi_lang_content['sections'][$current_language]['categories_title']; ?></h2>
                <p><?php echo $multi_lang_content['sections'][$current_language]['categories_sub']; ?></p>
            </div>
            
            <div class="categories-grid">
                <?php
                $categories = [
                    'fa' => [
                        ['icon' => 'fas fa-landmark', 'title' => 'تاریخی', 'count' => '۴۵ مکان'],
                        ['icon' => 'fas fa-camera', 'title' => 'عکاسی', 'count' => '۳۲ مکان'],
                        ['icon' => 'fas fa-utensils', 'title' => 'غذا', 'count' => '۸۹ مکان'],
                        ['icon' => 'fas fa-shopping-bag', 'title' => 'خرید', 'count' => '۶۷ مکان'],
                        ['icon' => 'fas fa-water', 'title' => 'دریایی', 'count' => '۲۳ مکان'],
                        ['icon' => 'fas fa-moon', 'title' => 'شب‌زنده‌داری', 'count' => '۳۴ مکان']
                    ],
                    'tr' => [
                        ['icon' => 'fas fa-landmark', 'title' => 'Tarihi', 'count' => '45 Yer'],
                        ['icon' => 'fas fa-camera', 'title' => 'Fotoğraf', 'count' => '32 Yer'],
                        ['icon' => 'fas fa-utensils', 'title' => 'Yemek', 'count' => '89 Yer'],
                        ['icon' => 'fas fa-shopping-bag', 'title' => 'Alışveriş', 'count' => '67 Yer'],
                        ['icon' => 'fas fa-water', 'title' => 'Deniz', 'count' => '23 Yer'],
                        ['icon' => 'fas fa-moon', 'title' => 'Gece Hayatı', 'count' => '34 Yer']
                    ],
                    'en' => [
                        ['icon' => 'fas fa-landmark', 'title' => 'Historical', 'count' => '45 Places'],
                        ['icon' => 'fas fa-camera', 'title' => 'Photography', 'count' => '32 Places'],
                        ['icon' => 'fas fa-utensils', 'title' => 'Food', 'count' => '89 Places'],
                        ['icon' => 'fas fa-shopping-bag', 'title' => 'Shopping', 'count' => '67 Places'],
                        ['icon' => 'fas fa-water', 'title' => 'Sea', 'count' => '23 Places'],
                        ['icon' => 'fas fa-moon', 'title' => 'Nightlife', 'count' => '34 Places']
                    ]
                ];
                
                $current_categories = $categories[$current_language] ?? $categories['fa'];
                
                foreach ($current_categories as $category): ?>
                <a href="javascript:void(0)" class="category-card" style="background: linear-gradient(135deg, #FFB3B3 0%, #FF9E9E 100%);" onclick="filterByCategory('<?php echo strtolower($category['title']); ?>')">
                    <div class="category-icon">
                        <i class="<?php echo $category['icon']; ?>"></i>
                    </div>
                    <h3><?php echo $category['title']; ?></h3>
                    <p><?php echo $category['count']; ?></p>
                </a>
                <?php endforeach; ?>
            </div>
        </section>

        <!-- Hotels Section -->
        <section class="section hotels-section" id="hotels">
            <div class="section-header">
                <div class="header-title">
                    <h2><?php echo $multi_lang_content['sections'][$current_language]['hotels_title']; ?></h2>
                    <p><?php echo $multi_lang_content['sections'][$current_language]['hotels_sub']; ?></p>
                </div>
                <a href="javascript:void(0)" class="view-all" onclick="loadAllHotels()">
                    <?php echo $multi_lang_content['sections'][$current_language]['view_all']; ?>
                    <i class="fas fa-arrow-left"></i>
                </a>
            </div>
            
            <div class="hotels-grid" id="hotelsGrid">
                <?php
                $hotels = [
                    'fa' => [
                        ['name' => 'هیلتون استانبول', 'rating' => '۴.۹★', 'price' => '۲۵۰۰ لیر'],
                        ['name' => 'هتل چهار فصل', 'rating' => '۴.۷★', 'price' => '۳۵۰۰ لیر'],
                        ['name' => 'هتل رادیسون', 'rating' => '۴.۵★', 'price' => '۱۸۰۰ لیر']
                    ],
                    'tr' => [
                        ['name' => 'Hilton İstanbul', 'rating' => '۴.۹★', 'price' => '۲۵۰۰ TL'],
                        ['name' => 'Four Seasons Hotel', 'rating' => '۴.۷★', 'price' => '۳۵۰۰ TL'],
                        ['name' => 'Radisson Hotel', 'rating' => '۴.۵★', 'price' => '۱۸۰۰ TL']
                    ],
                    'en' => [
                        ['name' => 'Hilton Istanbul', 'rating' => '۴.۹★', 'price' => '۲۵۰۰ TL'],
                        ['name' => 'Four Seasons Hotel', 'rating' => '۴.۷★', 'price' => '۳۵۰۰ TL'],
                        ['name' => 'Radisson Hotel', 'rating' => '۴.۵★', 'price' => '۱۸۰۰ TL']
                    ]
                ];
                
                $current_hotels = $hotels[$current_language] ?? $hotels['fa'];
                $book_text = [
                    'fa' => 'رزرو آنلاین',
                    'tr' => 'Online Rezervasyon',
                    'en' => 'Online Booking'
                ];
                
                foreach ($current_hotels as $index => $hotel): 
                    $images = ['assets/hilton bomonti.webp', 'https://images.unsplash.com/photo-1512918728675-ed5a9ecdebfd?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80', 'https://images.unsplash.com/photo-1584132967334-10e028bd69f7?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80'];
                ?>
                <div class="hotel-card">
                    <div class="hotel-image" style="background-image: url('<?php echo $images[$index]; ?>')">
                        <span class="hotel-badge"><?php echo $hotel['rating']; ?></span>
                    </div>
                    <div class="hotel-content">
                        <h3 class="hotel-title"><?php echo $hotel['name']; ?></h3>
                        <div class="hotel-stars">★★★★★</div>
                        <div class="hotel-price">
                            <div class="price-amount"><?php echo $hotel['price']; ?></div>
                            <a href="<?php echo $hotel_booking_links[$index]; ?>" target="_blank" class="book-btn"><?php echo $book_text[$current_language]; ?></a>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </section>

        <!-- Experiences Section -->
        <section class="section experiences-section" id="experiences">
            <div class="section-header">
                <h2><?php echo $multi_lang_content['sections'][$current_language]['experiences_title']; ?></h2>
                <p><?php echo $multi_lang_content['sections'][$current_language]['experiences_sub']; ?></p>
            </div>
            
            <div class="experiences-slider">
                <?php
                $experiences = [
                    'fa' => [
                        ['title' => 'تور دریایی بسفر', 'desc' => 'گشت‌زنی بین قاره‌ای بین اروپا و آسیا', 'price' => 'از ۱۵۰ لیر'],
                        ['title' => 'کلاس آشپزی ترکی', 'desc' => 'یادگیری پخت کباب و باقلوا از سرآشپز محلی', 'price' => 'از ۳۰۰ لیر'],
                        ['title' => 'تور مخفی استانبول', 'desc' => 'کشف محله‌های مخفی و داستان‌های ناگفته', 'price' => 'از ۴۵۰ لیر'],
                        ['title' => 'هلیکوپترتور استانبول', 'desc' => 'دید هوایی از شهر روی دو قاره', 'price' => 'از ۲۵۰۰ لیر']
                    ],
                    'tr' => [
                        ['title' => 'Boğaz Turu', 'desc' => 'Avrupa ve Asya arasında kıtalararası gezi', 'price' => '150 TL\'den'],
                        ['title' => 'Türk Mutfağı Dersi', 'desc' => 'Yerel şeften kebap ve baklava pişirmeyi öğrenin', 'price' => '300 TL\'den'],
                        ['title' => 'Gizli İstanbul Turu', 'desc' => 'Gizli mahalleler ve anlatılmamış hikayeleri keşfedin', 'price' => '450 TL\'den'],
                        ['title' => 'Helikopter Turu', 'desc' => 'İki kıta üzerindeki şehrin havadan görünümü', 'price' => '۲۵۰۰ TL\'den']
                    ],
                    'en' => [
                        ['title' => 'Bosphorus Cruise Tour', 'desc' => 'Intercontinental cruising between Europe and Asia', 'price' => 'From 150 TL'],
                        ['title' => 'Turkish Cooking Class', 'desc' => 'Learn to cook kebab and baklava from local chef', 'price' => 'From 300 TL'],
                        ['title' => 'Hidden Istanbul Tour', 'desc' => 'Discover hidden neighborhoods and untold stories', 'price' => 'From 450 TL'],
                        ['title' => 'Helicopter Tour Istanbul', 'desc' => 'Aerial view of the city on two continents', 'price' => 'From 2500 TL']
                    ]
                ];
                
                $current_experiences = $experiences[$current_language] ?? $experiences['fa'];
                $exp_images = ['download.jpg', 'download (1).jpg', 'public.avif', 'download (2).jpg'];
                $badges = ['پرطرفدار', 'جدید', 'انحصاری', 'لوکس'];
                $badges_tr = ['Popüler', 'Yeni', 'Özel', 'Lüks'];
                $badges_en = ['Popular', 'New', 'Exclusive', 'Luxury'];
                
                $current_badges = $current_language == 'tr' ? $badges_tr : ($current_language == 'en' ? $badges_en : $badges);
                
                foreach ($current_experiences as $index => $exp): ?>
                <div class="experience-card">
                    <div class="exp-image" style="background-image: url('assets/<?php echo $exp_images[$index]; ?>');">
                        <span class="exp-badge"><?php echo $current_badges[$index]; ?></span>
                    </div>
                    <div class="exp-content">
                        <h3><?php echo $exp['title']; ?></h3>
                        <p><?php echo $exp['desc']; ?></p>
                        <div class="exp-meta">
                            <?php if($current_language == 'fa'): ?>
                                <span><i class="fas fa-clock"></i> <?php echo $index == 3 ? '۱ ساعت' : ($index == 0 ? '۳ ساعت' : ($index == 1 ? '۴ ساعت' : '۶ ساعت')); ?></span>
                                <span><i class="fas fa-user-friends"></i> <?php echo $index == 3 ? '۴ نفر' : ($index == 1 ? 'خصوصی' : ($index == 2 ? 'گروه کوچک' : 'گروهی')); ?></span>
                            <?php elseif($current_language == 'tr'): ?>
                                <span><i class="fas fa-clock"></i> <?php echo $index == 3 ? '۱ saat' : ($index == 0 ? '۳ saat' : ($index == 1 ? '۴ saat' : '۶ saat')); ?></span>
                                <span><i class="fas fa-user-friends"></i> <?php echo $index == 3 ? '۴ kişi' : ($index == 1 ? 'Özel' : ($index == 2 ? 'Küçük grup' : 'Grup')); ?></span>
                            <?php else: ?>
                                <span><i class="fas fa-clock"></i> <?php echo $index == 3 ? '1 hour' : ($index == 0 ? '3 hours' : ($index == 1 ? '4 hours' : '6 hours')); ?></span>
                                <span><i class="fas fa-user-friends"></i> <?php echo $index == 3 ? '4 people' : ($index == 1 ? 'Private' : ($index == 2 ? 'Small group' : 'Group')); ?></span>
                            <?php endif; ?>
                            <span class="exp-price"><?php echo $exp['price']; ?></span>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </section>

        <!-- Virtual Tour -->
        <section class="section virtual-section">
            <div class="section-header">
                <h2><?php echo $multi_lang_content['sections'][$current_language]['virtual_title']; ?></h2>
                <p><?php echo $multi_lang_content['sections'][$current_language]['virtual_sub']; ?></p>
            </div>
            
            <div class="virtual-container">
                <div class="virtual-viewer" id="virtualViewer">
                    <iframe width="100%" height="100%" src="https://www.airpano.com/embed.php?3D=mosques-istanbul-turkey" frameborder="0" marginheight="0" marginwidth="0" scrolling="no" framespacing="0" allowfullscreen> </iframe>
                </div>
            </div>
        </section>

        <!-- Planner Section -->
        <section class="section planner-section" id="itinerary">
            <div class="section-header">
                <h2><?php echo $multi_lang_content['sections'][$current_language]['planner_title']; ?></h2>
                <p><?php echo $multi_lang_content['sections'][$current_language]['planner_sub']; ?></p>
            </div>

            <div class="planner-container">
                <div class="planner-steps">
                    <?php
                    $steps = [
                        'fa' => ['مدت سفر', 'علاقه‌مندی‌ها', 'بودجه', 'برنامه نهایی'],
                        'tr' => ['Seyahat Süresi', 'İlgi Alanları', 'Bütçe', 'Son Plan'],
                        'en' => ['Trip Duration', 'Interests', 'Budget', 'Final Plan']
                    ];
                    $current_steps = $steps[$current_language];
                    foreach ($current_steps as $index => $step): ?>
                        <div class="step <?php echo $index == 0 ? 'active' : ''; ?>">
                            <div class="step-number"><?php echo $index + 1; ?></div>
                            <div class="step-content">
                                <h3><?php echo $step; ?></h3>
                                <p>
                                    <?php
                                    if ($index == 0) {
                                        echo $current_language == 'fa' ? 'چند روز در استانبول هستید؟' : ($current_language == 'tr' ? 'İstanbul\'da kaç gün kalacaksınız?' : 'How many days in Istanbul?');
                                    } elseif ($index == 1) {
                                        echo $current_language == 'fa' ? 'چه چیزی برای شما مهم است؟' : ($current_language == 'tr' ? 'Sizin için ne önemli?' : 'What is important for you?');
                                    } elseif ($index == 2) {
                                        echo $current_language == 'fa' ? 'محدوده هزینه‌ای شما چقدر است؟' : ($current_language == 'tr' ? 'Harcama aralığınız nedir?' : 'What is your spending range?');
                                    } else {
                                        echo $current_language == 'fa' ? 'برنامه سفری شخصی شما' : ($current_language == 'tr' ? 'Kişisel seyahat planınız' : 'Your personal travel plan');
                                    }
                                    ?>
                                </p>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>

                <div class="planner-form">
                    <div class="form-group">
                        <label><?php echo $current_language == 'fa' ? 'تعداد روزهای سفر:' : ($current_language == 'tr' ? 'Seyahat Gün Sayısı:' : 'Number of Travel Days:'); ?></label>
                        <div class="day-selector">
                            <button class="day-btn active" data-days="1"><?php echo $current_language == 'fa' ? '۱ روز' : ($current_language == 'tr' ? '1 gün' : '1 day'); ?></button>
                            <button class="day-btn" data-days="3"><?php echo $current_language == 'fa' ? '۳ روز' : ($current_language == 'tr' ? '3 gün' : '3 days'); ?></button>
                            <button class="day-btn" data-days="5"><?php echo $current_language == 'fa' ? '۵ روز' : ($current_language == 'tr' ? '5 gün' : '5 days'); ?></button>
                            <button class="day-btn" data-days="7"><?php echo $current_language == 'fa' ? '۷ روز' : ($current_language == 'tr' ? '7 gün' : '7 days'); ?></button>
                        </div>
                    </div>

                    <div class="form-group">
                        <label><?php echo $current_language == 'fa' ? 'علاقه‌مندی‌های شما:' : ($current_language == 'tr' ? 'İlgi Alanlarınız:' : 'Your Interests:'); ?></label>
                        <div class="interest-tags">
                            <?php
                            $interests = [
                                'fa' => ['تاریخی', 'غذا', 'خرید', 'عکاسی', 'طبیعت', 'ماجراجویی', 'آرامش', 'خانوادگی'],
                                'tr' => ['Tarihi', 'Yemek', 'Alışveriş', 'Fotoğraf', 'Doğa', 'Macera', 'Rahatlık', 'Aile'],
                                'en' => ['Historical', 'Food', 'Shopping', 'Photography', 'Nature', 'Adventure', 'Relaxation', 'Family']
                            ];
                            $current_interests = $interests[$current_language];
                            foreach ($current_interests as $interest): ?>
                                <span class="interest-tag"><?php echo $interest; ?></span>
                            <?php endforeach; ?>
                        </div>
                    </div>

                    <div class="form-group">
                        <label><?php echo $current_language == 'fa' ? 'بودجه روزانه:' : ($current_language == 'tr' ? 'Günlük Bütçe:' : 'Daily Budget:'); ?></label>
                        <div class="budget-slider">
                            <div class="budget-labels">
                                <span><?php echo $current_language == 'fa' ? 'اقتصادی' : ($current_language == 'tr' ? 'Ekonomik' : 'Economy'); ?></span>
                                <span><?php echo $current_language == 'fa' ? 'متوسط' : ($current_language == 'tr' ? 'Orta' : 'Medium'); ?></span>
                                <span><?php echo $current_language == 'fa' ? 'لوکس' : ($current_language == 'tr' ? 'Lüks' : 'Luxury'); ?></span>
                            </div>
                            <input type="range" min="0" max="100" value="50" class="budget-range">
                        </div>
                    </div>

                    <button class="generate-itinerary">
                        <i class="fas fa-magic"></i>
                        <?php echo $current_language == 'fa' ? 'تولید برنامه سفر' : ($current_language == 'tr' ? 'Seyahat Planı Oluştur' : 'Generate Travel Plan'); ?>
                    </button>
                </div>

                <div class="planner-preview" id="itineraryPreview">
                    <h3 id="previewTitle">
                        <?php echo $current_language == 'fa' ? 'پیش‌نمایش برنامه سفر:' : ($current_language == 'tr' ? 'Seyahat Planı Önizlemesi:' : 'Travel Plan Preview:'); ?>
                    </h3>
                    <div id="itineraryContent" class="itinerary-content">
                        <div class="empty-state">
                            <i class="fas fa-map-marked-alt" style="font-size: 3rem; color: #ccc; margin-bottom: 20px;"></i>
                            <p><?php echo $current_language == 'fa' ? 'لطفاً تعداد روزها، علایق و بودجه خود را انتخاب کنید و روی «تولید برنامه سفر» کلیک کنید.' : ($current_language == 'tr' ? 'Lütfen gün sayısı, ilgi alanları ve bütçenizi seçin ve «Seyahat Planı Oluştur» düğmesine tıklayın.' : 'Please select the number of days, your interests and budget, then click «Generate Travel Plan».'); ?></p>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- Newsletter -->
        <section class="newsletter-section">
            <div class="newsletter-container">
                <div class="newsletter-content">
                    <h2>
                        <?php 
                        $newsletter_title = [
                            'fa' => 'آماده کشف استانبول هستید؟ 🇹🇷',
                            'tr' => 'İstanbul\'u Keşfetmeye Hazır mısınız? 🇹🇷',
                            'en' => 'Ready to Discover Istanbul? 🇹🇷'
                        ];
                        echo $newsletter_title[$current_language];
                        ?>
                    </h2>
                    <p>
                        <?php 
                        $newsletter_desc = [
                            'fa' => 'با خبرنامه ما، جدیدترین راهنمای سفر، تخفیف‌ها و تجربه‌های خاص را دریافت کنید',
                            'tr' => 'Bültenimizle en yeni seyahat rehberleri, indirimler ve özel deneyimler alın',
                            'en' => 'With our newsletter, get the latest travel guides, discounts and special experiences'
                        ];
                        echo $newsletter_desc[$current_language];
                        ?>
                    </p>
                </div>
                <div class="newsletter-form">
                    <form id="newsletterForm" onsubmit="subscribeNewsletter(event)">
                        <div class="input-group">
                            <input type="email" id="newsletterEmail" 
                                   placeholder="<?php 
                                   $email_placeholder = [
                                       'fa' => 'ایمیل خود را وارد کنید',
                                       'tr' => 'E-postanızı girin',
                                       'en' => 'Enter your email'
                                   ];
                                   echo $email_placeholder[$current_language];
                                   ?>" required>
                            <button type="submit" class="subscribe-btn">
                                <span>
                                    <?php 
                                    $subscribe_text = [
                                        'fa' => 'عضویت',
                                        'tr' => 'Abone Ol',
                                        'en' => 'Subscribe'
                                    ];
                                    echo $subscribe_text[$current_language];
                                    ?>
                                </span>
                                <i class="fas fa-paper-plane"></i>
                            </button>
                        </div>
                        <p class="privacy-note">
                            <?php 
                            $privacy_text = [
                                'fa' => 'با عضویت، <a href="#">حریم خصوصی</a> را می‌پذیرید',
                                'tr' => 'Abone olarak <a href="#">Gizlilik</a> politikasını kabul edersiniz',
                                'en' => 'By subscribing, you accept the <a href="#">Privacy</a> policy'
                            ];
                            echo $privacy_text[$current_language];
                            ?>
                        </p>
                    </form>
                </div>
            </div>
        </section>
    </main>

    <!-- AI Assistant -->
    <div class="ai-assistant" id="aiAssistant">
        <div class="assistant-header">
            <div class="assistant-info">
                <div class="assistant-avatar">
                    <i class="fas fa-robot"></i>
                </div>
                <div class="assistant-text">
                    <h4>
                        <?php 
                        $ai_title = [
                            'fa' => 'دستیار هوشمند استانبول 🇹🇷',
                            'tr' => 'İstanbul Akıllı Asistanı 🇹🇷',
                            'en' => 'Istanbul Smart Assistant 🇹🇷'
                        ];
                        echo $ai_title[$current_language];
                        ?>
                    </h4>
                    <p>
                        <?php 
                        $ai_status = [
                            'fa' => 'آنلاین • پاسخ بر اساس اطلاعات سایت',
                            'tr' => 'Çevrimiçi • Site bilgilerine göre yanıt',
                            'en' => 'Online • Responses based on site information'
                        ];
                        echo $ai_status[$current_language];
                        ?>
                    </p>
                </div>
            </div>
            <div class="assistant-actions">
                <button class="minimize-btn">
                    <i class="fas fa-minus"></i>
                </button>
                <button class="close-btn">
                    <i class="fas fa-times"></i>
                </button>
            </div>
        </div>
        
        <div class="assistant-chat">
            <div class="chat-messages" id="chatMessages">
            </div>
            
            <div class="chat-input">
                <input type="text" id="chatInput" 
                       placeholder="<?php 
                       $chat_placeholder = [
                           'fa' => 'سوال خود را بپرسید...',
                           'tr' => 'Sorunuzu sorun...',
                           'en' => 'Ask your question...'
                       ];
                       echo $chat_placeholder[$current_language];
                       ?>">
                <button class="send-btn" id="sendMessage">
                    <i class="fas fa-paper-plane"></i>
                </button>
            </div>
        </div>
    </div>

    <!-- Search Modal -->
    <div class="search-modal" id="searchModal">
        <div class="search-modal-content">
            <div class="search-header">
                <h3>
                    <i class="fas fa-search" style="margin-left: 10px;"></i>
                    <?php 
                    $search_title = [
                        'fa' => 'جستجوی استانبول',
                        'tr' => 'İstanbul Arama',
                        'en' => 'Istanbul Search'
                    ];
                    echo $search_title[$current_language];
                    ?>
                </h3>
                <button class="close-search" id="closeSearchBtn">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            <div class="search-body">
                <div class="search-input-group">
                    <input type="text" id="searchInput" 
                           placeholder="<?php 
                           $search_placeholder = [
                               'fa' => 'مکان، رستوران، هتل، ... را جستجو کنید',
                               'tr' => 'Yer, restoran, otel, ... arayın',
                               'en' => 'Search places, restaurants, hotels, ...'
                           ];
                           echo $search_placeholder[$current_language];
                           ?>" autocomplete="off">
                    <button class="voice-search-btn" id="voiceSearchBtn" title="<?php echo $current_language == 'fa' ? 'جستجوی صوتی' : ($current_language == 'tr' ? 'Sesli arama' : 'Voice search'); ?>">
                        <i class="fas fa-microphone"></i>
                    </button>
                    <button class="clear-search-btn" id="clearSearchBtn" style="<?php echo $current_language == 'fa' ? 'margin-right: 10px;' : 'margin-left: 10px;'; ?>">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
                <div class="search-stats" id="searchStats">
                    <?php 
                    $initial_stats = [
                        'fa' => 'برای شروع جستجو تایپ کنید یا از دکمه میکروفون استفاده کنید',
                        'tr' => 'Aramaya başlamak için yazın veya mikrofon düğmesini kullanın',
                        'en' => 'Type to start search or use the microphone button'
                    ];
                    echo $initial_stats[$current_language];
                    ?>
                </div>
                <div class="search-results" id="searchResults">
                </div>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer class="main-footer">
        <div class="footer-container">
            <div class="footer-grid">
                <div class="footer-col">
                    <div class="footer-logo">
                        <div class="logo-icon">
                            <i class="fas fa-mosque"></i>
                        </div>
                        <span class="logo-text">Istanbul<span class="logo-accent">Guide</span></span>
                    </div>
                    <p class="footer-description">
                        <?php 
                        $footer_desc = [
                            'fa' => 'راهنمای کامل و جامع برای کشف استانبول، شهر روی دو قاره. ما بهترین تجربه سفر را برای شما فراهم می‌کنیم.',
                            'tr' => 'İki kıta üzerindeki şehir İstanbul\'u keşfetmek için kapsamlı rehber. Size en iyi seyahat deneyimini sunuyoruz.',
                            'en' => 'Comprehensive guide to discover Istanbul, the city on two continents. We provide you with the best travel experience.'
                        ];
                        echo $footer_desc[$current_language];
                        ?>
                    </p>
                    <div class="social-links">
                        <a href="#" class="social-link"><i class="fab fa-instagram"></i></a>
                        <a href="#" class="social-link"><i class="fab fa-telegram"></i></a>
                        <a href="#" class="social-link"><i class="fab fa-twitter"></i></a>
                        <a href="#" class="social-link"><i class="fab fa-youtube"></i></a>
                        <a href="#" class="social-link"><i class="fab fa-tiktok"></i></a>
                    </div>
                </div>
                
                <div class="footer-col">
                    <h3><?php echo $current_language == 'fa' ? 'کشف کنید' : ($current_language == 'tr' ? 'Keşfedin' : 'Discover'); ?></h3>
                    <ul class="footer-links">
                        <?php
                        $discover_links = [
                            'fa' => ['جاذبه‌ها', 'هتل‌ها', 'رستوران‌ها', 'تورهای روزانه', 'تجربه‌های خاص', 'فعالیت‌های رایگان'],
                            'tr' => ['Gezi Yerleri', 'Oteller', 'Restoranlar', 'Günlük Turlar', 'Özel Deneyimler', 'Ücretsiz Aktiviteler'],
                            'en' => ['Attractions', 'Hotels', 'Restaurants', 'Daily Tours', 'Special Experiences', 'Free Activities']
                        ];
                        $current_discover = $discover_links[$current_language];
                        foreach ($current_discover as $link): ?>
                        <li><a href="javascript:void(0)"><?php echo $link; ?></a></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
                
                <div class="footer-col">
                    <h3><?php echo $current_language == 'fa' ? 'راهنماها' : ($current_language == 'tr' ? 'Rehberler' : 'Guides'); ?></h3>
                    <ul class="footer-links">
                        <?php
                        $guides_links = [
                            'fa' => ['نقشه مترو', 'راهنمای غذا', 'فرهنگ و آداب', 'هزینه‌های سفر', 'آب و هوا', 'واژگان مفید ترکی'],
                            'tr' => ['Metro Haritası', 'Yemek Rehberi', 'Kültür ve Görgü', 'Seyahat Masrafları', 'Hava Durumu', 'Yararlı Türkçe Kelimeler'],
                            'en' => ['Metro Map', 'Food Guide', 'Culture & Etiquette', 'Travel Costs', 'Weather', 'Useful Turkish Words']
                        ];
                        $current_guides = $guides_links[$current_language];
                        foreach ($current_guides as $link): ?>
                        <li><a href="javascript:void(0)"><?php echo $link; ?></a></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
                
                <div class="footer-col">
                    <h3><?php echo $current_language == 'fa' ? 'پشتیبانی' : ($current_language == 'tr' ? 'Destek' : 'Support'); ?></h3>
                    <ul class="footer-links">
                        <?php
                        $support_links = [
                            'fa' => ['سوالات متداول', 'تماس با ما', 'شرایط استفاده', 'حریم خصوصی', 'همکاری با ما', 'فرصت‌های شغلی'],
                            'tr' => ['SSS', 'İletişim', 'Kullanım Şartları', 'Gizlilik', 'Bizimle Çalışın', 'Kariyer Fırsatları'],
                            'en' => ['FAQ', 'Contact Us', 'Terms of Use', 'Privacy', 'Partnership', 'Career Opportunities']
                        ];
                        $current_support = $support_links[$current_language];
                        foreach ($current_support as $link): ?>
                        <li><a href="javascript:void(0)"><?php echo $link; ?></a></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
                
                <div class="footer-col">
                    <h3><?php echo $current_language == 'fa' ? 'اپلیکیشن موبایل' : ($current_language == 'tr' ? 'Mobil Uygulama' : 'Mobile App'); ?></h3>
                    <p>
                        <?php 
                        $app_desc = [
                            'fa' => 'راهنمای استانبول را در جیب خود داشته باشید',
                            'tr' => 'İstanbul rehberini cebinizde taşıyın',
                            'en' => 'Carry Istanbul guide in your pocket'
                        ];
                        echo $app_desc[$current_language];
                        ?>
                    </p>
                    <div class="app-download">
                        <a href="#" class="app-store-btn">
                            <i class="fab fa-apple"></i>
                            <div>
                                <span><?php echo $current_language == 'fa' ? 'دانلود از' : ($current_language == 'tr' ? 'İndir' : 'Download from'); ?></span>
                                <strong>App Store</strong>
                            </div>
                        </a>
                        <a href="#" class="play-store-btn">
                            <i class="fab fa-google-play"></i>
                            <div>
                                <span><?php echo $current_language == 'fa' ? 'دانلود از' : ($current_language == 'tr' ? 'İndir' : 'Download from'); ?></span>
                                <strong>Google Play</strong>
                            </div>
                        </a>
                    </div>
                </div>
            </div>
            
            <div class="footer-bottom">
                <div class="copyright">
                    <p>© <?php echo date('Y'); ?> Istanbul Guide 🇹🇷. 
                        <?php 
                        $rights_text = [
                            'fa' => 'تمامی حقوق محفوظ است.',
                            'tr' => 'Tüm hakları saklıdır.',
                            'en' => 'All rights reserved.'
                        ];
                        echo $rights_text[$current_language];
                        ?>
                    </p>
                    <p>
                        <?php 
                        $demo_text = [
                            'fa' => 'این پروژه یک پروژه نمایشی است و با استانبول‌گردی واقعی مرتبط نمی‌باشد.',
                            'tr' => 'Bu proje gösterim amaçlıdır ve gerçek İstanbul gezileriyle ilgili değildir.',
                            'en' => 'This project is for demonstration purposes and is not related to real Istanbul tours.'
                        ];
                        echo $demo_text[$current_language];
                        ?>
                    </p>
                </div>
                <div class="footer-legal">
                    <?php
                    $legal_links = [
                        'fa' => ['حریم خصوصی', 'شرایط استفاده', 'تنظیمات کوکی'],
                        'tr' => ['Gizlilik', 'Kullanım Şartları', 'Çerez Ayarları'],
                        'en' => ['Privacy', 'Terms of Use', 'Cookie Settings']
                    ];
                    $current_legal = $legal_links[$current_language];
                    foreach ($current_legal as $link): ?>
                    <a href="javascript:void(0)"><?php echo $link; ?></a>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </footer>

    <!-- پخش خودکار آهنگ پس از ورود -->
    <?php if (isset($_SESSION['user_id']) && !isset($_SESSION['song_played'])): ?>
        <audio id="welcomeSong" autoplay loop>
            <source src="assets/Ibrahim Tatlises - Dom Dom Kursunu.mp3" type="audio/mpeg">
            <!--مرورگر شما از پخش صدا پشتیبانی نمی‌کند.-->
        </audio>
        <script>
            document.addEventListener('DOMContentLoaded', function() {
                var song = document.getElementById('welcomeSong');
                song.play().catch(function(error) {
                    console.log('Autoplay blocked, will try after user interaction.');
                    document.body.addEventListener('click', function once() {
                        song.play();
                        document.body.removeEventListener('click', once);
                    }, { once: true });
                });
            });
        </script>
        <?php $_SESSION['song_played'] = true; ?>
    <?php endif; ?>

    <!-- JavaScript Libraries -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    
    <script>
        // ======================== CONSTANTS & GLOBAL DATA ========================
        const CONFIG = {
            baseUrl: '<?php echo $base_url; ?>',
            apiBase: '<?php echo $api_base; ?>',
            language: '<?php echo $current_language; ?>',
            theme: '<?php echo $current_theme; ?>',
            dbConnected: <?php echo $db_connected ? 'true' : 'false'; ?>,
            turkeyRed: '<?php echo $turkey_red; ?>',
            turkeyWhite: '<?php echo $turkey_white; ?>'
        };

        // ---------- پایگاه داده داخلی جاذبه‌ها (با ۱۰ جاذبه اصلی) ----------
        const attractionsDB = {
            historical: [
                { name: { fa: 'ایاصوفیه', tr: 'Ayasofya', en: 'Hagia Sophia' }, area: 'sultanahmet', duration: 2, price: 100, priority: 10, type: 'museum' },
                { name: { fa: 'مسجد آبی', tr: 'Sultanahmet Camii', en: 'Blue Mosque' }, area: 'sultanahmet', duration: 1.5, price: 0, priority: 9, type: 'mosque' },
                { name: { fa: 'کاخ توپکاپی', tr: 'Topkapı Sarayı', en: 'Topkapi Palace' }, area: 'sultanahmet', duration: 3, price: 150, priority: 10, type: 'palace' },
                { name: { fa: 'برج گالاتا', tr: 'Galata Kulesi', en: 'Galata Tower' }, area: 'beyoglu', duration: 1.5, price: 175, priority: 8, type: 'tower' },
                { name: { fa: 'مخزن باسیلیکا', tr: 'Yerebatan Sarnıcı', en: 'Basilica Cistern' }, area: 'sultanahmet', duration: 1, price: 100, priority: 7, type: 'historical' },
                { name: { fa: 'مسجد سلیمانیه', tr: 'Süleymaniye Camii', en: 'Suleymaniye Mosque' }, area: 'fatih', duration: 1.5, price: 0, priority: 9, type: 'mosque' },
                { name: { fa: 'کاخ دلمه‌باغچه', tr: 'Dolmabahçe Sarayı', en: 'Dolmabahçe Palace' }, area: 'besiktas', duration: 2, price: 150, priority: 8, type: 'palace' },
                { name: { fa: 'رستوران هاتای ', tr:'Hatay restoranısi', en: 'Hatay restaurant' }, area: 'fatih', duration: 1.5, price: 100, priority: 7, type: 'museum' },
                { name: { fa: 'کاخ بیلربیی', tr: 'Beylerbeyi Sarayı', en: 'Beylerbeyi Palace' }, area: 'uskudar', duration: 1.5, price: 100, priority: 7, type: 'palace' },
                { name: { fa: 'مسجد اورتاکوی', tr: 'Ortaköy Camii', en: 'Ortaköy Mosque' }, area: 'besiktas', duration: 0.75, price: 0, priority: 8, type: 'mosque' }
            ],
            food: [
                { name: { fa: 'چیا صفراسی', tr: 'Çiya Sofrası', en: 'Çiya Sofrası' }, area: 'kadikoy', duration: 1.5, price: 150, priority: 9, type: 'restaurant' },
                { name: { fa: 'میکلا', tr: 'Mikla', en: 'Mikla' }, area: 'beyoglu', duration: 2, price: 600, priority: 8, type: 'restaurant' },
                { name: { fa: 'بالیقچی صباح الدین', tr: 'Balıkçı Sabahattin', en: 'Balıkçı Sabahattin' }, area: 'sultanahmet', duration: 1.5, price: 200, priority: 8, type: 'seafood' },
                { name: { fa: 'حاجی عبدالله', tr: 'Hacı Abdullah', en: 'Hacı Abdullah' }, area: 'beyoglu', duration: 1.5, price: 150, priority: 7, type: 'restaurant' },
                { name: { fa: 'کاراکوی گولو اوغلو', tr: 'Karaköy Güllüoğlu', en: 'Karaköy Güllüoğlu' }, area: 'karakoy', duration: 0.75, price: 50, priority: 9, type: 'baklava' },
                { name: { fa: 'وفا بوزاجیسی', tr: 'Vefa Bozacısı', en: 'Vefa Bozacısı' }, area: 'fatih', duration: 0.5, price: 20, priority: 7, type: 'drink' }
            ],
            shopping: [
                { name: { fa: 'بازار بزرگ', tr: 'Kapalı Çarşı', en: 'Grand Bazaar' }, area: 'fatih', duration: 3, price: 0, priority: 10, type: 'bazaar' },
                { name: { fa: 'بازار ادویه', tr: 'Mısır Çarşısı', en: 'Spice Bazaar' }, area: 'eminonu', duration: 1.5, price: 0, priority: 8, type: 'bazaar' },
                { name: { fa: 'ایشتینیه پارک', tr: 'İstinye Park', en: 'İstinye Park' }, area: 'sisli', duration: 2, price: 0, priority: 7, type: 'mall' },
                { name: { fa: 'نیشانتاشی', tr: 'Nişantaşı', en: 'Nişantaşı' }, area: 'sisli', duration: 2, price: 0, priority: 6, type: 'shopping' }
            ],
            photography: [
                { name: { fa: 'منظره برج گالاتا', tr: 'Galata Kulesi Manzarası', en: 'Galata Tower View' }, area: 'beyoglu', duration: 1, price: 175, priority: 9, type: 'viewpoint' },
                { name: { fa: 'غروب اورتاکوی', tr: 'Ortaköy Gün Batımı', en: 'Ortaköy Sunset' }, area: 'besiktas', duration: 1, price: 0, priority: 10, type: 'viewpoint' },
                { name: { fa: 'خیابان استقلال', tr: 'İstiklal Caddesi', en: 'Istiklal Street' }, area: 'beyoglu', duration: 1.5, price: 0, priority: 8, type: 'street' },
                { name: { fa: 'محله بالات', tr: 'Balat', en: 'Balat' }, area: 'fatih', duration: 1.5, price: 0, priority: 8, type: 'neighborhood' }
            ],
            nature: [
                { name: { fa: 'جنگل بلگراد', tr: 'Belgrad Ormanı', en: 'Belgrade Forest' }, area: 'sariyer', duration: 3, price: 0, priority: 9, type: 'forest' },
                { name: { fa: 'جزایر پرنس', tr: 'Prens Adaları', en: 'Princes\' Islands' }, area: 'adalar', duration: 5, price: 100, priority: 10, type: 'island' },
                { name: { fa: 'ساحل کادیکوی', tr: 'Kadıköy Sahili', en: 'Kadıköy Coast' }, area: 'kadikoy', duration: 1, price: 0, priority: 7, type: 'coast' }
            ],
            adventure: [
                { name: { fa: 'تور قایق بسفر', tr: 'Boğaz Turu', en: 'Bosphorus Boat Tour' }, area: 'eminonu', duration: 2, price: 150, priority: 9, type: 'boat' },
                { name: { fa: 'پارک ماجراجویی', tr: 'Macera Parkı', en: 'Adventure Park' }, area: 'sariyer', duration: 3, price: 100, priority: 6, type: 'adventure' }
            ],
            relaxation: [
                { name: { fa: 'حمام ترکی', tr: 'Türk Hamamı', en: 'Turkish Bath' }, area: 'fatih', duration: 2, price: 300, priority: 9, type: 'hamam' },
                { name: { fa: 'کافه روی آب', tr: 'Sahil Kafe', en: 'Seaside Cafe' }, area: 'besiktas', duration: 1.5, price: 50, priority: 8, type: 'cafe' },
                { name: { fa: 'پارک گولهانه', tr: 'Gülhane Parkı', en: 'Gülhane Park' }, area: 'sultanahmet', duration: 1, price: 0, priority: 7, type: 'park' }
            ],
            family: [
                { name: { fa: 'موزه اسباب‌بازی', tr: 'Oyuncak Müzesi', en: 'Toy Museum' }, area: 'kadikoy', duration: 1.5, price: 50, priority: 8, type: 'museum' },
                { name: { fa: 'مینیاتورک', tr: 'Miniatürk', en: 'Miniatürk' }, area: 'sisli', duration: 2, price: 50, priority: 8, type: 'park' },
                { name: { fa: 'آکواریوم', tr: 'Akvaryum', en: 'Aquarium' }, area: 'beylikduzu', duration: 2, price: 150, priority: 8, type: 'aquarium' }
            ]
        };

        // ---------- تابع تبدیل علایق به کلید دیتابیس ----------
        function getInterestKey(text, lang) {
            const map = {
                'fa': { 'تاریخی': 'historical', 'غذا': 'food', 'خرید': 'shopping', 'عکاسی': 'photography', 'طبیعت': 'nature', 'ماجراجویی': 'adventure', 'آرامش': 'relaxation', 'خانوادگی': 'family' },
                'tr': { 'Tarihi': 'historical', 'Yemek': 'food', 'Alışveriş': 'shopping', 'Fotoğraf': 'photography', 'Doğa': 'nature', 'Macera': 'adventure', 'Rahatlık': 'relaxation', 'Aile': 'family' },
                'en': { 'Historical': 'historical', 'Food': 'food', 'Shopping': 'shopping', 'Photography': 'photography', 'Nature': 'nature', 'Adventure': 'adventure', 'Relaxation': 'relaxation', 'Family': 'family' }
            };
            return map[lang]?.[text] || null;
        }
        
        

        // ======================== جستجوی سراسری ========================
        function performSearch(query) {
            const searchInput = document.getElementById('searchInput');
            const searchStats = document.getElementById('searchStats');
            const searchResults = document.getElementById('searchResults');
            
            if (!query || query.trim() === '') {
                searchStats.innerHTML = '<?php 
                    $empty_search = [
                        'fa' => 'برای شروع جستجو تایپ کنید یا از دکمه میکروفون استفاده کنید',
                        'tr' => 'Aramaya başlamak için yazın veya mikrofon düğmesini kullanın',
                        'en' => 'Type to start search or use the microphone button'
                    ];
                    echo $empty_search[$current_language];
                ?>';
                searchResults.innerHTML = '';
                return;
            }

            const lang = CONFIG.language;
            const lowerQuery = query.toLowerCase();
            let results = [];

            for (let category in attractionsDB) {
                attractionsDB[category].forEach(item => {
                    const nameInLang = item.name[lang] || item.name.en;
                    const nameLower = nameInLang.toLowerCase();
                    if (nameLower.includes(lowerQuery)) {
                        results.push({
                            title: nameInLang,
                            type: item.type,
                            price: item.price,
                            area: item.area,
                            icon: getIconForType(item.type)
                        });
                    }
                });
            }

            const hotelsData = {
                'fa': ['هیلتون استانبول', 'هتل چهار فصل', 'هتل رادیسون'],
                'tr': ['Hilton İstanbul', 'Four Seasons Hotel', 'Radisson Hotel'],
                'en': ['Hilton Istanbul', 'Four Seasons Hotel', 'Radisson Hotel']
            };
            hotelsData[lang].forEach(hotel => {
                if (hotel.toLowerCase().includes(lowerQuery)) {
                    results.push({
                        title: hotel,
                        type: 'hotel',
                        price: lang === 'fa' ? 'از ۱۸۰۰ لیر' : 'from 1800 TL',
                        icon: 'fas fa-hotel'
                    });
                }
            });

            const expData = {
                'fa': ['تور دریایی بسفر', 'کلاس آشپزی ترکی', 'تور مخفی استانبول', 'هلیکوپترتور استانبول'],
                'tr': ['Boğaz Turu', 'Türk Mutfağı Dersi', 'Gizli İstanbul Turu', 'Helikopter Turu'],
                'en': ['Bosphorus Cruise Tour', 'Turkish Cooking Class', 'Hidden Istanbul Tour', 'Helicopter Tour Istanbul']
            };
            expData[lang].forEach(exp => {
                if (exp.toLowerCase().includes(lowerQuery)) {
                    results.push({
                        title: exp,
                        type: 'experience',
                        price: lang === 'fa' ? 'از ۱۵۰ لیر' : 'from 150 TL',
                        icon: 'fas fa-map-marked-alt'
                    });
                }
            });

            results = results.filter((v, i, a) => a.findIndex(t => t.title === v.title) === i);
            
            searchStats.innerHTML = results.length + ' <?php 
                $result_text = [
                    'fa' => 'نتیجه یافت شد',
                    'tr' => 'sonuç bulundu',
                    'en' => 'results found'
                ];
                echo $result_text[$current_language];
            ?>';

            if (results.length === 0) {
                searchResults.innerHTML = `
                    <div class="no-results">
                        <i class="fas fa-search"></i>
                        <p><?php 
                            $no_result = [
                                'fa' => 'نتیجه‌ای برای جستجوی شما یافت نشد',
                                'tr' => 'Aramanızla eşleşen sonuç bulunamadı',
                                'en' => 'No results found for your search'
                            ];
                            echo $no_result[$current_language];
                        ?></p>
                    </div>
                `;
            } else {
                let html = '';
                results.slice(0, 10).forEach(res => {
                    const priceText = res.price ? (res.price + (typeof res.price === 'number' ? ' TL' : '')) : 'رایگان';
                    html += `
                        <div class="result-item" onclick="selectSearchResult('${res.title}')">
                            <div class="result-icon">
                                <i class="${res.icon}"></i>
                            </div>
                            <div class="result-details">
                                <div class="result-title">${res.title}</div>
                                <span class="result-type">${res.type}</span>
                                <span class="result-price" style="margin-right: 10px;">💰 ${priceText}</span>
                            </div>
                        </div>
                    `;
                });
                searchResults.innerHTML = html;
            }
        }

        function selectSearchResult(title) {
            alert('شما انتخاب کردید: ' + title);
        }

        function getIconForType(type) {
            const icons = {
                'museum': 'fas fa-landmark',
                'mosque': 'fas fa-mosque',
                'palace': 'fas fa-chess-queen',
                'tower': 'fas fa-chess-rook',
                'historical': 'fas fa-history',
                'restaurant': 'fas fa-utensils',
                'seafood': 'fas fa-fish',
                'baklava': 'fas fa-cake',
                'drink': 'fas fa-coffee',
                'bazaar': 'fas fa-store',
                'mall': 'fas fa-shopping-bag',
                'shopping': 'fas fa-shopping-cart',
                'viewpoint': 'fas fa-camera',
                'street': 'fas fa-road',
                'neighborhood': 'fas fa-city',
                'forest': 'fas fa-tree',
                'island': 'fas fa-water',
                'coast': 'fas fa-umbrella-beach',
                'boat': 'fas fa-ship',
                'adventure': 'fas fa-hiking',
                'hamam': 'fas fa-hot-tub',
                'cafe': 'fas fa-coffee',
                'park': 'fas fa-tree',
                'aquarium': 'fas fa-fish',
                'hotel': 'fas fa-hotel',
                'experience': 'fas fa-map-marked-alt'
            };
            return icons[type] || 'fas fa-map-pin';
        }

        // ======================== جستجوی صوتی ========================
        let recognition = null;
        let isListening = false;

        function initVoiceSearch() {
            if (!('webkitSpeechRecognition' in window) && !('SpeechRecognition' in window)) {
                console.log('Voice search not supported');
                const voiceBtn = document.getElementById('voiceSearchBtn');
                if (voiceBtn) {
                    voiceBtn.style.opacity = '0.5';
                    voiceBtn.title = '<?php 
                        $not_supported = [
                            'fa' => 'مرورگر شما از جستجوی صوتی پشتیبانی نمی‌کند',
                            'tr' => 'Tarayıcınız sesli aramayı desteklemiyor',
                            'en' => 'Your browser does not support voice search'
                        ];
                        echo $not_supported[$current_language];
                    ?>';
                }
                return;
            }

            const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
            recognition = new SpeechRecognition();
            recognition.lang = CONFIG.language === 'fa' ? 'fa-IR' : (CONFIG.language === 'tr' ? 'tr-TR' : 'en-US');
            recognition.continuous = false;
            recognition.interimResults = false;

            recognition.onstart = function() {
                isListening = true;
                const voiceBtn = document.getElementById('voiceSearchBtn');
                voiceBtn.classList.add('listening');
                voiceBtn.innerHTML = '<i class="fas fa-microphone-slash"></i>';
            };

            recognition.onend = function() {
                isListening = false;
                const voiceBtn = document.getElementById('voiceSearchBtn');
                voiceBtn.classList.remove('listening');
                voiceBtn.innerHTML = '<i class="fas fa-microphone"></i>';
            };

            recognition.onresult = function(event) {
                const transcript = event.results[0][0].transcript;
                document.getElementById('searchInput').value = transcript;
                performSearch(transcript);
            };

            recognition.onerror = function(event) {
                console.error('Voice error:', event.error);
                isListening = false;
                const voiceBtn = document.getElementById('voiceSearchBtn');
                voiceBtn.classList.remove('listening');
                voiceBtn.innerHTML = '<i class="fas fa-microphone"></i>';
            };
        }

        function toggleVoiceSearch() {
            if (!recognition) {
                alert('<?php 
                    $not_supported_alert = [
                        'fa' => 'جستجوی صوتی در مرورگر شما پشتیبانی نمی‌شود',
                        'tr' => 'Sesli arama tarayıcınızda desteklenmiyor',
                        'en' => 'Voice search is not supported in your browser'
                    ];
                    echo $not_supported_alert[$current_language];
                ?>');
                return;
            }
            if (isListening) {
                recognition.stop();
            } else {
                recognition.start();
            }
        }

        // ======================== رویدادهای مودال جستجو ========================
        function initSearchModal() {
            const searchToggle = document.getElementById('searchToggle');
            const searchModal = document.getElementById('searchModal');
            const closeSearchBtn = document.getElementById('closeSearchBtn');
            const searchInput = document.getElementById('searchInput');
            const clearSearchBtn = document.getElementById('clearSearchBtn');
            const voiceSearchBtn = document.getElementById('voiceSearchBtn');

            searchToggle.addEventListener('click', function() {
                searchModal.classList.add('active');
                setTimeout(() => searchInput.focus(), 100);
            });

            closeSearchBtn.addEventListener('click', function() {
                searchModal.classList.remove('active');
                if (isListening) recognition.stop();
            });

            searchModal.addEventListener('click', function(e) {
                if (e.target === searchModal) {
                    searchModal.classList.remove('active');
                    if (isListening) recognition.stop();
                }
            });

            let debounceTimer;
            searchInput.addEventListener('input', function(e) {
                clearTimeout(debounceTimer);
                debounceTimer = setTimeout(() => {
                    performSearch(e.target.value);
                }, 300);
            });

            clearSearchBtn.addEventListener('click', function() {
                searchInput.value = '';
                performSearch('');
                searchInput.focus();
            });

            voiceSearchBtn.addEventListener('click', toggleVoiceSearch);
        }

        // ======================== توابع اصلی ========================
        document.addEventListener('DOMContentLoaded', function() {
            console.log('🚀 Istanbul Portal - Three Language Version 🇹🇷');
            console.log('🌐 Current Language:', CONFIG.language);
            
            setTimeout(() => {
                document.getElementById('preloader').style.opacity = '0';
                setTimeout(() => {
                    document.getElementById('preloader').style.display = 'none';
                }, 500);
            }, 2000);
            
            initHeroSlider();
            setTimeout(loadInitialData, 2500);
            setupEventListeners();
            addScrollAnimations();
            initAIAssistant();
            initMobileMenu();
            initTravelPlanner();
            initSearchModal();
            initVoiceSearch();
        });

        function initHeroSlider() {
            const slides = document.querySelectorAll('.hero-slider .slide');
            const dots = document.querySelectorAll('.hero-dots .dot');
            const prevBtn = document.querySelector('.hero-prev');
            const nextBtn = document.querySelector('.hero-next');
            let currentSlide = 0;
            function showSlide(index) {
                slides.forEach(slide => slide.classList.remove('active'));
                dots.forEach(dot => dot.classList.remove('active'));
                slides[index].classList.add('active');
                dots[index].classList.add('active');
                currentSlide = index;
            }
            function nextSlide() {
                let nextIndex = (currentSlide + 1) % slides.length;
                showSlide(nextIndex);
            }
            function prevSlide() {
                let prevIndex = (currentSlide - 1 + slides.length) % slides.length;
                showSlide(prevIndex);
            }
            setInterval(nextSlide, 5000);
            nextBtn.addEventListener('click', nextSlide);
            prevBtn.addEventListener('click', prevSlide);
            dots.forEach((dot, index) => {
                dot.addEventListener('click', () => showSlide(index));
            });
        }

        function initMobileMenu() {
            const mobileToggle = document.getElementById('mobileMenuToggle');
            const mobileNav = document.getElementById('mobileNav');
            if (mobileToggle && mobileNav) {
                mobileToggle.addEventListener('click', () => {
                    mobileNav.classList.toggle('active');
                    mobileToggle.innerHTML = mobileNav.classList.contains('active') 
                        ? '<i class="fas fa-times"></i>' 
                        : '<i class="fas fa-bars"></i>';
                });
                document.addEventListener('click', (e) => {
                    if (!mobileToggle.contains(e.target) && !mobileNav.contains(e.target)) {
                        mobileNav.classList.remove('active');
                        mobileToggle.innerHTML = '<i class="fas fa-bars"></i>';
                    }
                });
                mobileNav.querySelectorAll('.mobile-nav-link').forEach(link => {
                    link.addEventListener('click', () => {
                        mobileNav.classList.remove('active');
                        mobileToggle.innerHTML = '<i class="fas fa-bars"></i>';
                    });
                });
            }
        }

        function setupEventListeners() {
            const themeToggle = document.getElementById('themeToggle');
            if (themeToggle) {
                themeToggle.addEventListener('click', toggleTheme);
            }
            document.querySelectorAll('.nav-link, .mobile-nav-link').forEach(link => {
                link.addEventListener('click', function(e) {
                    const href = this.getAttribute('href');
                    if (href.startsWith('#')) {
                        e.preventDefault();
                        const targetId = href;
                        const targetElement = document.querySelector(targetId);
                        if (targetElement) {
                            window.scrollTo({
                                top: targetElement.offsetTop - 100,
                                behavior: 'smooth'
                            });
                            document.querySelectorAll('.nav-link').forEach(l => l.classList.remove('active'));
                            this.classList.add('active');
                        }
                    }
                });
            });
            const newsletterForm = document.getElementById('newsletterForm');
            if (newsletterForm) {
                newsletterForm.addEventListener('submit', function(e) {
                    e.preventDefault();
                    const email = document.getElementById('newsletterEmail').value;
                    setTimeout(() => {
                        alert(successMessages[CONFIG.language] || successMessages['fa']);
                        newsletterForm.reset();
                    }, 1000);
                });
            }
        }

        function toggleTheme() {
            const currentTheme = document.body.getAttribute('data-theme');
            const newTheme = currentTheme === 'light' ? 'dark' : 'light';
            document.body.setAttribute('data-theme', newTheme);
            const icon = document.querySelector('#themeToggle i');
            icon.className = newTheme === 'dark' ? 'fas fa-sun' : 'fas fa-moon';
            localStorage.setItem('theme', newTheme);
        }

        function loadInitialData() {
            const placesGrid = document.getElementById('placesGrid');
            if (placesGrid) {
                const placesContent = {
                    'fa': [
                        { title: 'برج گالاتا', desc: 'برجی تاریخی در استانبول با منظره‌ای پانوراما از شهر', price: 'رایگان' },
                        { title: 'ایاصوفیه', desc: 'کلیسا، مسجد و اکنون موزه‌ای در استانبول', price: '۱۰۰ لیر' },
                        { title: 'بازار بزرگ', desc: 'یکی از بزرگترین و قدیمی ترین بازارهای سرپوشیده جهان', price: 'رایگان' },
                        { title: 'کاخ توپکاپی', desc: 'اقامتگاه سلاطین عثمانی به مدت ۴۰۰ سال', price: '۱۵۰ لیر' },
                        { title: 'مخزن باسیلیکا', desc: 'مخزن آب زیرزمینی با ستون‌های باستانی', price: '۱۰۰ لیر' },
                        { title: 'مسجد سلیمانیه', desc: 'شاهکار معمار سنان، نمایی زیبا از شاخ طلایی', price: 'رایگان' },
                        { title: 'کاخ دلمه‌باغچه', desc: 'کاخی مجلل در کنار بسفر', price: '۱۵۰ لیر' },
                        { title: 'رستوران هاتای', desc: 'رستوران بیزانسی با موزاییک‌های نفیس', price: '۱۰۰ لیر' },
                        { title: 'رستوران باستا نئو بیسترو', desc: 'رستوران تابستانی عثمانی در ساحل آسیایی', price: '۱۰۰ لیر' },
                        { title: 'مسجد اورتاکوی', desc: 'مسجدی زیبا در کنار پل بسفر', price: 'رایگان' }
                    ],
                    'tr': [
                        { title: 'Galata Kulesi', desc: 'İstanbul\'da şehrin panoramik manzarasına sahip tarihi kule', price: 'Ücretsiz' },
                        { title: 'Ayasofya', desc: 'Önce kilise, sonra cami, şimdi İstanbul\'da müze', price: '100 TL' },
                        { title: 'Kapalı Çarşı', desc: 'Dünyanın en büyük ve en eski kapalı çarşılarından biri', price: 'Ücretsiz' },
                        { title: 'Topkapı Sarayı', desc: 'Osmanlı sultanlarının 400 yıl boyunca ana ikametgâhı', price: '150 TL' },
                        { title: 'Yerebatan Sarnıcı', desc: 'Antik sütunlarla dolu yeraltı su deposu', price: '100 TL' },
                        { title: 'Süleymaniye Camii', desc: 'Mimar Sinan\'ın başyapıtı, Haliç\'e bakan muhteşem manzara', price: 'Ücretsiz' },
                        { title: 'Dolmabahçe Sarayı', desc: 'Boğaz kıyısında gösterişli saray', price: '150 TL' },
                        { title: 'Kariye Müzesi', desc: 'Eşsiz mozaiklerle süslü Bizans kilisesi', price: '100 TL' },
                        { title: 'Beylerbeyi Sarayı', desc: 'Osmanlı\'nın Asya yakasındaki yazlık sarayı', price: '100 TL' },
                        { title: 'Ortaköy Camii', desc: 'Boğaz Köprüsü yanında güzel cami', price: 'Ücretsiz' }
                    ],
                    'en': [
                        { title: 'Galata Tower', desc: 'Historical tower in Istanbul with panoramic view of the city', price: 'Free' },
                        { title: 'Hagia Sophia', desc: 'First a church, then a mosque, now a museum in Istanbul', price: '100 TL' },
                        { title: 'Grand Bazaar', desc: 'One of the largest and oldest covered markets in the world', price: 'Free' },
                        { title: 'Topkapi Palace', desc: 'Main residence of Ottoman sultans for 400 years', price: '150 TL' },
                        { title: 'Basilica Cistern', desc: 'Underground water reservoir with ancient columns', price: '100 TL' },
                        { title: 'Suleymaniye Mosque', desc: 'Masterpiece of architect Sinan, beautiful view of Golden Horn', price: 'Free' },
                        { title: 'Dolmabahce Palace', desc: 'Luxurious palace on the Bosphorus shore', price: '150 TL' },
                        { title: 'Hatay restaurant', desc: 'Hatay restoranı with exquisite mosaics', price: '100 TL' },
                        { title: 'Beylerbeyi Palace', desc: 'Ottoman summer palace on the Asian side', price: '100 TL' },
                        { title: 'Ortakoy Mosque', desc: 'Beautiful mosque next to the Bosphorus Bridge', price: 'Free' }
                    ]
                };
                
                const images = [
                    '6-2-istanbul-Galata-Tower.webp',
                    'visit-hagia-sophia-museum.jpg',
                    'Thumbnail-min.jpg',
                    'topkapi.jpg',
                    'basilica.jpg',
                    'suleymaniye.jpg',
                    'dolmabahce.jpg',
                    'Hatay restaurant.jpg',
                    'Basta Neo Bistro Restaurant.jpg',
                    'ortakoy.jpg'
                ];
                
                const categories = {
                    'fa': ['تاریخی', 'تاریخی', 'خرید', 'تاریخی', 'تاریخی', 'مذهبی', 'تاریخی', 'تاریخی', 'تاریخی', 'مذهبی'],
                    'tr': ['Tarihi', 'Tarihi', 'Alışveriş', 'Tarihi', 'Tarihi', 'Dini', 'Tarihi', 'Tarihi', 'Tarihi', 'Dini'],
                    'en': ['Historical', 'Historical', 'Shopping', 'Historical', 'Historical', 'Religious', 'Historical', 'Historical', 'Historical', 'Religious']
                };
                
                const ratings = ['۴.۷', '۴.۹', '۴.۵', '۴.۸', '۴.۶', '۴.۸', '۴.۷', '۴.۵', '۴.۶', '۴.৭'];
                const placeFiles = [
                    'galata.php', 'HagiaSophia.php', 'Bigmarket.php',
                    'topkapi.php', 'basilica.php', 'suleymaniye.php',
                    'dolmabahce.php', 'chora.php', 'beylerbeyi.php', 'ortakoy.php'
                ];
                
                placesGrid.innerHTML = '';
                const currentPlaces = placesContent[CONFIG.language] || placesContent['fa'];
                currentPlaces.forEach((place, index) => {
                    const placeCard = document.createElement('div');
                    placeCard.className = 'place-card';
                    placeCard.innerHTML = `
                        <div class="place-image" style="background-image: url('assets/${images[index]}')">
                            <span class="place-badge">${categories[CONFIG.language][index]}</span>
                        </div>
                        <div class="place-content">
                            <h3 class="place-title">${place.title}</h3>
                            <p class="place-description">${place.desc}</p>
                            <div class="place-meta">
                                <div class="place-rating">
                                    <i class="fas fa-star"></i>
                                    <span>${ratings[index]}</span>
                                </div>
                                <div class="place-price">${place.price}</div>
                            </div>
                            <div class="place-actions">
                                <button class="action-btn"><i class="fas fa-heart"></i></button>
                                <a href="${placeFiles[index]}" class="action-btn"><i class="fas fa-info-circle"></i></a>
                            </div>
                        </div>
                    `;
                    placesGrid.appendChild(placeCard);
                });
            }
        }

        function addScrollAnimations() {
            const observerOptions = { threshold: 0.1, rootMargin: '0px 0px -50px 0px' };
            const observer = new IntersectionObserver((entries) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        entry.target.classList.add('animate__animated', 'animate__fadeInUp');
                    }
                });
            }, observerOptions);
            document.querySelectorAll('.section').forEach(section => {
                observer.observe(section);
            });
        }

        // ========== موتور برنامه‌ریز سفر هوشمند ==========
        function generateItinerary(days, interests, budgetLevel, lang) {
            const budgetFactor = budgetLevel === 'economy' ? 0.7 : budgetLevel === 'luxury' ? 1.5 : 1.0;
            let selectedAttractions = [];
            interests.forEach(interest => {
                if (attractionsDB[interest]) {
                    let items = attractionsDB[interest].map(item => {
                        const displayName = item.name[lang] || item.name.en;
                        return {
                            ...item,
                            displayName: displayName,
                            score: item.priority * (budgetLevel === 'economy' ? 1 / (item.price + 1) : 1)
                        };
                    });
                    items.sort((a, b) => b.score - a.score);
                    selectedAttractions = selectedAttractions.concat(items.slice(0, 2));
                }
            });
            if (selectedAttractions.length === 0) {
                ['historical', 'food', 'shopping'].forEach(cat => {
                    if (attractionsDB[cat]) {
                        let items = attractionsDB[cat].map(item => ({ ...item, displayName: item.name[lang] || item.name.en }));
                        selectedAttractions = selectedAttractions.concat(items.slice(0, 2));
                    }
                });
            }
            selectedAttractions = selectedAttractions.filter((v, i, a) => 
                a.findIndex(t => t.displayName === v.displayName) === i
            );
            const groupedByArea = {};
            selectedAttractions.forEach(item => {
                if (!groupedByArea[item.area]) groupedByArea[item.area] = [];
                groupedByArea[item.area].push(item);
            });
            const itinerary = [];
            const maxHoursPerDay = 8;
            for (let day = 0; day < days; day++) {
                const dayPlan = {
                    day: day + 1,
                    activities: [],
                    totalCost: 0,
                    totalHours: 0
                };
                const areas = Object.keys(groupedByArea).sort((a, b) => 
                    groupedByArea[b].length - groupedByArea[a].length
                );
                const mainArea = areas[day % areas.length];
                const areaItems = groupedByArea[mainArea] || [];
                let hoursUsed = 0;
                let itemsUsed = [];
                areaItems.forEach(item => {
                    if (hoursUsed + item.duration <= maxHoursPerDay && !itemsUsed.includes(item.displayName)) {
                        dayPlan.activities.push({
                            ...item,
                            time: `${Math.floor(hoursUsed + 9)}:00`
                        });
                        dayPlan.totalCost += item.price * budgetFactor;
                        dayPlan.totalHours += item.duration;
                        hoursUsed += item.duration;
                        itemsUsed.push(item.displayName);
                    }
                });
                if (hoursUsed < maxHoursPerDay) {
                    for (let area of areas) {
                        if (area === mainArea) continue;
                        const otherItems = groupedByArea[area] || [];
                        for (let item of otherItems) {
                            if (hoursUsed + item.duration <= maxHoursPerDay && !itemsUsed.includes(item.displayName)) {
                                dayPlan.activities.push({
                                    ...item,
                                    time: `${Math.floor(hoursUsed + 9)}:00`
                                });
                                dayPlan.totalCost += item.price * budgetFactor;
                                dayPlan.totalHours += item.duration;
                                hoursUsed += item.duration;
                                itemsUsed.push(item.displayName);
                            }
                            if (hoursUsed >= maxHoursPerDay) break;
                        }
                        if (hoursUsed >= maxHoursPerDay) break;
                    }
                }
                const lunchPrice = budgetLevel === 'economy' ? 80 : budgetLevel === 'luxury' ? 300 : 150;
                dayPlan.activities.push({
                    displayName: lang === 'fa' ? 'ناهار (پیشنهاد)' : (lang === 'tr' ? 'Öğle Yemeği (Öneri)' : 'Lunch (Suggestion)'),
                    area: mainArea,
                    duration: 1,
                    price: lunchPrice,
                    type: 'meal',
                    time: '13:00'
                });
                dayPlan.totalCost += lunchPrice;
                dayPlan.totalHours += 1;
                itinerary.push(dayPlan);
            }
            return itinerary;
        }

        function displayItinerary(itinerary, lang) {
            const container = document.getElementById('itineraryContent');
            if (!container) return;
            let html = '';
            itinerary.forEach(day => {
                html += `<div class="itinerary-day">
                    <h4><i class="fas fa-calendar-day"></i> ${lang === 'fa' ? 'روز' : (lang === 'tr' ? 'Gün' : 'Day')} ${day.day}</h4>
                    <ul class="activity-list">`;
                day.activities.forEach(act => {
                    let priceIcon = '';
                    if (act.price > 200) priceIcon = '💰💰💰';
                    else if (act.price > 80) priceIcon = '💰💰';
                    else priceIcon = '💰';
                    html += `<li>
                        <span class="activity-time">${act.time}</span>
                        <span class="activity-name"><strong>${act.displayName}</strong></span>
                        <span class="activity-duration">⏱️ ${act.duration} ${lang === 'fa' ? 'ساعت' : (lang === 'tr' ? 'saat' : 'hr')}</span>
                        <span class="activity-price">${priceIcon} ${Math.round(act.price)} TL</span>
                    </li>`;
                });
                html += `</ul>
                    <div class="day-summary">
                        <span>⏱️ ${lang === 'fa' ? 'مجموع زمان:' : (lang === 'tr' ? 'Toplam süre:' : 'Total time:')} ${day.totalHours} ${lang === 'fa' ? 'ساعت' : (lang === 'tr' ? 'saat' : 'hrs')}</span>
                        <span>💰 ${lang === 'fa' ? 'هزینه تقریبی:' : (lang === 'tr' ? 'Tahmini maliyet:' : 'Estimated cost:')} ${Math.round(day.totalCost)} TL</span>
                    </div>
                </div>`;
            });
            container.innerHTML = html;
        }

        function initTravelPlanner() {
            const generateBtn = document.querySelector('.generate-itinerary');
            if (!generateBtn) return;
            generateBtn.addEventListener('click', function() {
                const lang = CONFIG.language || 'fa';
                const dayBtns = document.querySelectorAll('.day-btn');
                let selectedDays = 3;
                dayBtns.forEach((btn) => {
                    if (btn.classList.contains('active')) {
                        selectedDays = parseInt(btn.dataset.days) || 3;
                    }
                });
                const interestTags = document.querySelectorAll('.interest-tag');
                const selectedInterests = [];
                interestTags.forEach(tag => {
                    if (tag.classList.contains('active')) {
                        const key = getInterestKey(tag.textContent.trim(), lang);
                        if (key) selectedInterests.push(key);
                    }
                });
                const budgetSlider = document.querySelector('.budget-range');
                const budgetValue = parseInt(budgetSlider.value);
                let budgetLevel = 'medium';
                if (budgetValue < 33) budgetLevel = 'economy';
                else if (budgetValue > 66) budgetLevel = 'luxury';
                const itinerary = generateItinerary(selectedDays, selectedInterests, budgetLevel, lang);
                displayItinerary(itinerary, lang);
            });
            document.querySelectorAll('.day-btn').forEach(btn => {
                btn.addEventListener('click', function() {
                    document.querySelectorAll('.day-btn').forEach(b => b.classList.remove('active'));
                    this.classList.add('active');
                });
            });
            document.querySelectorAll('.interest-tag').forEach(tag => {
                tag.addEventListener('click', function() {
                    this.classList.toggle('active');
                });
            });
        }

        // Initialize AI Assistant
        function initAIAssistant() {
            const assistant = document.getElementById('aiAssistant');
            const minimizeBtn = assistant.querySelector('.minimize-btn');
            const closeBtn = assistant.querySelector('.close-btn');
            const sendBtn = document.getElementById('sendMessage');
            const chatInput = document.getElementById('chatInput');
            const chatMessages = document.getElementById('chatMessages');
            
            setTimeout(() => {
                assistant.style.display = 'block';
                addWelcomeMessage();
            }, 5000);
            
            minimizeBtn.addEventListener('click', () => {
                assistant.classList.toggle('minimized');
                const chatContainer = assistant.querySelector('.assistant-chat');
                if (assistant.classList.contains('minimized')) {
                    chatContainer.style.display = 'none';
                    minimizeBtn.innerHTML = '<i class="fas fa-expand"></i>';
                } else {
                    chatContainer.style.display = 'flex';
                    minimizeBtn.innerHTML = '<i class="fas fa-minus"></i>';
                }
            });
            
            closeBtn.addEventListener('click', () => {
                assistant.style.display = 'none';
                setTimeout(() => {
                    assistant.style.display = 'block';
                    addWelcomeMessage();
                }, 3600000);
            });
            
            sendBtn.addEventListener('click', sendMessage);
            chatInput.addEventListener('keypress', (e) => {
                if (e.key === 'Enter') sendMessage();
            });
            
            function addWelcomeMessage() {
                chatMessages.innerHTML = '';
                const welcomeMessages = {
                    'fa': `سلام! من دستیار هوشمند استانبول هستم. می‌توانم در مورد این موضوعات کمک کنم:
        
🎯 **تاریخ ترکیه و استانبول** (بیزانس، عثمانی، جمهوری)
🏙️ **محله‌های استانبول** (سلطان احمد، بی‌اوغلو، کادیکوی، ...)
🍽️ **رستوران‌ها و غذاهای ترکی** (کباب، صبحانه ترکی، دسرها)
🎎 **فرهنگ و آداب** (مذهب، تعطیلات، آداب معاشرت)
🚇 **حمل‌ونقل عمومی** (مترو، تراموا، قایق، تاکسی)
🛍️ **خرید و سوغاتی** (بازار بزرگ، مراکز خرید، صنایع دستی)
🌤️ **آب‌وهوا و بهترین زمان سفر**
🛡️ **امنیت و نکات سفر**
        
یک سوال بپرسید یا از دکمه‌های زیر استفاده کنید:`,
                    'en': `Hello! I am Istanbul AI assistant. I can help with these topics:
        
🎯 **History of Turkey and Istanbul** (Byzantine, Ottoman, Republic)
🏙️ **Neighborhoods of Istanbul** (Sultanahmet, Beyoglu, Kadikoy, ...)
🍽️ **Turkish restaurants and food** (Kebabs, Turkish breakfast, desserts)
🎎 **Culture and etiquette** (Religion, holidays, manners)
🚇 **Public transportation** (Metro, tram, ferry, taxi)
🛍️ **Shopping and souvenirs** (Grand Bazaar, malls, handicrafts)
🌤️ **Weather and best time to visit**
🛡️ **Safety and travel tips**
        
Ask a question or use the buttons below:`,
                    'tr': `Merhaba! Ben İstanbul yapay zeka asistanıyım. Şu konularda yardımcı olabilirim:
        
🎯 **Türkiye ve İstanbul tarihi** (Bizans, Osmanlı, Cumhuriyet)
🏙️ **İstanbul\'un semtleri** (Sultanahmet, Beyoğlu, Kadıköy, ...)
🍽️ **Türk restoranları ve yemekleri** (Kebap, Türk kahvaltısı, tatlılar)
🎎 **Kültür ve görgü kuralları** (Din, tatiller, görgü kuralları)
🚇 **Toplu taşıma** (Metro, tramvay, vapur, taksi)
🛍️ **Alışveriş ve hediyelik eşyalar** (Kapalı Çarşı, alışveriş merkezleri, el işleri)
🌤️ **Hava durumu ve en iyi seyahat zamanı**
🛡️ **Güvenlik ve seyahat ipuçları**
        
Bir soru sorun veya aşağıdaki butonları kullanın:`
                };
                const welcomeMessage = welcomeMessages[CONFIG.language] || welcomeMessages['fa'];
                const welcomeElement = document.createElement('div');
                welcomeElement.className = 'message ai welcome';
                welcomeElement.innerHTML = `<div class="message-content">${welcomeMessage}</div>`;
                chatMessages.appendChild(welcomeElement);
                addQuickSuggestions();
                chatMessages.scrollTop = chatMessages.scrollHeight;
            }
            
            function addQuickSuggestions() {
                const suggestionsContainer = document.createElement('div');
                suggestionsContainer.className = 'quick-suggestions';
                suggestionsContainer.style.cssText = `
                    padding: 15px;
                    display: flex;
                    flex-wrap: wrap;
                    gap: 10px;
                    border-bottom: 1px solid #eee;
                `;
                const suggestions = {
                    'fa': ['تاریخ استانبول', 'محله های معروف', 'رستوران های خوب', 'حمل و نقل', 'خرید سوغاتی', 'آب و هوا'],
                    'en': ['History of Istanbul', 'Popular neighborhoods', 'Good restaurants', 'Transportation', 'Shopping souvenirs', 'Weather'],
                    'tr': ['İstanbul tarihi', 'Popüler semtler', 'İyi restoranlar', 'Ulaşım', 'Alışveriş hediyelik', 'Hava durumu']
                };
                const langSuggestions = suggestions[CONFIG.language] || suggestions['fa'];
                langSuggestions.forEach(suggestion => {
                    const btn = document.createElement('button');
                    btn.textContent = suggestion;
                    btn.className = 'suggestion-btn';
                    btn.style.cssText = `
                        background: #f8f9fa;
                        border: 1px solid #e30a17;
                        border-radius: 20px;
                        padding: 8px 15px;
                        font-size: 12px;
                        cursor: pointer;
                        transition: all 0.3s;
                        color: #333;
                    `;
                    btn.onmouseover = () => btn.style.background = '#e30a17';
                    btn.onmouseout = () => btn.style.background = '#f8f9fa';
                    btn.onclick = () => {
                        chatInput.value = suggestion;
                        sendMessage();
                    };
                    suggestionsContainer.appendChild(btn);
                });
                chatMessages.appendChild(suggestionsContainer);
            }
            
            async function sendMessage() {
                const message = chatInput.value.trim();
                if (!message) return;
                const userMessage = document.createElement('div');
                userMessage.className = 'message user';
                userMessage.innerHTML = `<div class="message-content">${message}</div>`;
                chatMessages.appendChild(userMessage);
                chatInput.value = '';
                chatMessages.scrollTop = chatMessages.scrollHeight;
                const typingIndicator = document.createElement('div');
                typingIndicator.className = 'message ai typing';
                const typingTexts = {
                    'fa': 'در حال پاسخ‌دهی...',
                    'en': 'Responding...',
                    'tr': 'Yanıtlanıyor...'
                };
                typingIndicator.innerHTML = `<div class="message-content"><i class="fas fa-ellipsis-h"></i> ${typingTexts[CONFIG.language]}</div>`;
                chatMessages.appendChild(typingIndicator);
                chatMessages.scrollTop = chatMessages.scrollHeight;
                try {
                    const formData = new FormData();
                    formData.append('ai_chat', '1');
                    formData.append('message', message);
                    const response = await fetch(window.location.href, {
                        method: 'POST',
                        body: formData
                    });
                    const data = await response.json();
                    typingIndicator.remove();
                    const aiResponse = document.createElement('div');
                    aiResponse.className = 'message ai';
                    let formattedResponse = data.response
                        .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
                        .replace(/\n\n/g, '</p><p>')
                        .replace(/\n/g, '<br>');
                    aiResponse.innerHTML = `<div class="message-content"><p>${formattedResponse}</p></div>`;
                    chatMessages.appendChild(aiResponse);
                    setTimeout(() => {
                        if (chatMessages.querySelectorAll('.quick-suggestions').length === 0) {
                            addQuickSuggestions();
                        }
                    }, 100);
                } catch (error) {
                    console.error('AI Error:', error);
                    typingIndicator.remove();
                    const errorResponse = document.createElement('div');
                    errorResponse.className = 'message ai';
                    const errorTexts = {
                        'fa': 'متأسفم، خطایی در ارتباط رخ داد. لطفاً دوباره تلاش کنید یا از بخش جستجوی سایت استفاده کنید.',
                        'en': 'Sorry, a connection error occurred. Please try again or use the site search section.',
                        'tr': 'Üzgünüm, bir bağlantı hatası oluştu. Lütfen tekrar deneyin veya site arama bölümünü kullanın.'
                    };
                    errorResponse.innerHTML = `<div class="message-content">${errorTexts[CONFIG.language]}</div>`;
                    chatMessages.appendChild(errorResponse);
                }
                chatMessages.scrollTop = chatMessages.scrollHeight;
            }
            addWelcomeMessage();
        }

        window.changeLanguage = function(lang) {
            document.getElementById('preloader').style.display = 'flex';
            document.getElementById('preloader').style.opacity = '1';
            window.location.href = '?lang=' + lang;
        };

        window.filterByCategory = function(category) {
            const messages = {
                'fa': `فیلتر بر اساس دسته: ${category}`,
                'en': `Filter by category: ${category}`,
                'tr': `Kategoriye göre filtrele: ${category}`
            };
            alert(messages[CONFIG.language]);
        };

        window.loadAllPlaces = function() {
            const messages = {
                'fa': 'در حال بارگذاری همه مکان‌ها...',
                'en': 'Loading all places...',
                'tr': 'Tüm yerler yükleniyor...'
            };
            alert(messages[CONFIG.language]);
        };

        window.loadAllHotels = function() {
            const messages = {
                'fa': 'در حال بارگذاری همه هتل‌ها...',
                'en': 'Loading all hotels...',
                'tr': 'Tüm oteller yükleniyor...'
            };
            alert(messages[CONFIG.language]);
        };

        window.subscribeNewsletter = function(e) {
            e.preventDefault();
            const email = document.getElementById('newsletterEmail').value;
            const successMessages = {
                'fa': 'عضویت در خبرنامه با موفقیت انجام شد!',
                'en': 'Successfully subscribed to newsletter!',
                'tr': 'Bültene başarıyla abone oldunuz!'
            };
            setTimeout(() => {
                alert(successMessages[CONFIG.language]);
                document.getElementById('newsletterEmail').value = '';
            }, 1000);
        };

        window.logout = function() {
            alert(CONFIG.language === 'fa' ? 'با موفقیت خارج شدید!' : 
                  CONFIG.language === 'tr' ? 'Başarıyla çıkış yapıldı!' : 
                  'Successfully logged out!');
            window.location.href = 'logout.php';
        };
    </script>

    <!-- AI Assistant Toggle Button -->
    <div class="ai-assistant-toggle" id="aiAssistantToggle" style="position: fixed; bottom: 30px; left: 30px; width: 60px; height: 60px; background: red; border-radius: 50%; display: flex; align-items: center; justify-content: center; color: white; font-size: 24px; cursor: pointer; z-index: 999; box-shadow: 0 5px 15px rgba(227, 10, 23, 0.3);">
        <i class="fas fa-robot"></i>
    </div>

    <script>
        const assistantToggle = document.getElementById('aiAssistantToggle');
        const aiAssistant = document.getElementById('aiAssistant');
        if (assistantToggle && aiAssistant) {
            assistantToggle.addEventListener('click', () => {
                if (aiAssistant.style.display === 'block') {
                    aiAssistant.style.display = 'none';
                } else {
                    aiAssistant.style.display = 'block';
                    const chatMessages = document.getElementById('chatMessages');
                    if (chatMessages) {
                        chatMessages.scrollTop = chatMessages.scrollHeight;
                    }
                }
            });
        }
    </script>
</body>
</html>
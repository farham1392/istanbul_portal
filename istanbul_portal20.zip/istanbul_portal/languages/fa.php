<?php
// languages/fa.php
return [
    // متا تگ‌ها
    'page_title' => 'راهنمای گردشگری استانبول | کشف جادوی شهر روی دو قاره',
    'page_description' => 'راهنمای جامع گردشگری استانبول: جاذبه‌ها، هتل‌ها، رستوران‌ها، برنامه‌ریز سفر و تورهای مجازی',
    'site_name' => 'Istanbul Guide',
    
    // نویگیشن
    'nav_home' => 'خانه',
    'nav_discover' => 'کشف‌کنید',
    'nav_hotels' => 'اقامت',
    'nav_experiences' => 'تجربه‌ها',
    'nav_itinerary' => 'برنامه سفر',
    'nav_about' => 'درباره پروژه',
    'nav_login' => 'ورود / ثبت‌نام',
    'nav_profile' => 'پروفایل',
    'nav_favorites' => 'علاقه‌مندی‌ها',
    'nav_saved' => 'ذخیره‌شده‌ها',
    'nav_settings' => 'تنظیمات',
    'nav_logout' => 'خروج',
    
    // هدر هیرو
    'hero_title_1' => 'جادوی بی‌پایان استانبول 🇹🇷',
    'hero_subtitle_1' => 'جایی که شرق و غرب در هم می‌آمیزند',
    'hero_cta_1' => 'کشف استانبول',
    
    'hero_title_2' => 'تجربه تاریخی بی‌نظیر',
    'hero_subtitle_2' => 'از بیزانس تا امپراتوری عثمانی',
    'hero_cta_2' => 'مشاهده جاذبه‌ها',
    
    'hero_title_3' => 'طعم‌های فراموش‌نشدنی',
    'hero_subtitle_3' => 'از غذاهای خیابانی تا رستوران‌های ستاره‌دار',
    'hero_cta_3' => 'کشف رستوران‌ها',
    
    // آمار سریع
    'stat_historical' => 'جاذبه تاریخی',
    'stat_hotels' => 'هتل و اقامتگاه',
    'stat_restaurants' => 'رستوران و کافه',
    'stat_undiscovered' => 'منطقه کشف‌نشده',
    
    // بخش‌ها
    'section_top_attractions' => 'جاذبه‌های برتر استانبول',
    'section_top_attractions_desc' => 'معروف‌ترین و دیدنی‌ترین مکان‌های شهر را کشف کنید',
    'section_view_all' => 'مشاهده همه',
    
    'section_categories' => 'بر اساس علاقه‌تان کشف کنید',
    'section_categories_desc' => 'دسته‌بندی‌های محبوب برای سفر شما',
    
    'section_hotels' => 'اقامت‌گاه‌های منتخب',
    'section_hotels_desc' => 'بهترین هتل‌ها، ویلاها و اقامتگاه‌های محلی',
    
    'section_experiences' => 'تجربه‌های ویژه استانبول',
    'section_experiences_desc' => 'کارهایی که فقط در استانبول می‌توانید انجام دهید',
    
    'section_virtual_tour' => 'تور مجازی ۳۶۰ درجه',
    'section_virtual_tour_desc' => 'قبل از سفر از خانه دیدن کنید',
    
    'section_travel_planner' => 'برنامه‌ریز سفر هوشمند',
    'section_travel_planner_desc' => 'برنامه سفری شخصی‌سازی شده بر اساس علاقه شما',
    
    // دسته‌بندی‌ها
    'category_historical' => 'تاریخی',
    'category_photography' => 'عکاسی',
    'category_food' => 'غذا',
    'category_shopping' => 'خرید',
    'category_sea' => 'دریایی',
    'category_nightlife' => 'شب‌زنده‌داری',
    
    // جاذبه‌ها
    'place_galata_tower' => 'برج گالاتا',
    'place_galata_desc' => 'برجی تاریخی در استانبول با منظره‌ای پانوراما از شهر',
    'place_hagia_sophia' => 'ایاصوفیه',
    'place_hagia_desc' => 'کلیسا، مسجد و اکنون موزه‌ای در استانبول',
    'place_grand_bazaar' => 'بازار بزرگ',
    'place_grand_bazaar_desc' => 'یکی از بزرگترین و قدیمی ترین بازارهای سرپوشیده جهان',
    
    // هتل‌ها
    'hotel_hilton' => 'هیلتون استانبول',
    'hotel_four_seasons' => 'هتل چهار فصل',
    'hotel_radisson' => 'هتل رادیسون',
    'book_online' => 'رزرو آنلاین',
    
    // تجربه‌ها
    'experience_bosphorus' => 'تور دریایی بسفر',
    'experience_bosphorus_desc' => 'گشت‌زنی بین قاره‌ای بین اروپا و آسیا',
    'experience_cooking' => 'کلاس آشپزی ترکی',
    'experience_cooking_desc' => 'یادگیری پخت کباب و باقلوا از سرآشپز محلی',
    'experience_secret_tour' => 'تور مخفی استانبول',
    'experience_secret_tour_desc' => 'کشف محله‌های مخفی و داستان‌های ناگفته',
    'experience_helicopter' => 'هلیکوپترتور استانبول',
    'experience_helicopter_desc' => 'دید هوایی از شهر روی دو قاره',
    
    // تور مجازی
    'virtual_select_place' => 'انتخاب مکان:',
    'virtual_hagia_sophia' => 'ایاصوفیه',
    'virtual_blue_mosque' => 'مسجد آبی',
    'virtual_topkapi' => 'کاخ توپکاپی',
    'virtual_grand_bazaar' => 'بازار بزرگ',
    'virtual_guide' => 'راهنمای تور:',
    'virtual_guide_desc' => 'از موس برای چرخش و اسکرول برای زوم استفاده کنید',
    'virtual_vr_mode' => 'حالت VR',
    'virtual_fullscreen' => 'تمام صفحه',
    'virtual_audio_guide' => 'راهنمای صوتی',
    
    // برنامه‌ریز سفر
    'planner_step_1' => 'مدت سفر',
    'planner_step_1_desc' => 'چند روز در استانبول هستید؟',
    'planner_step_2' => 'علاقه‌مندی‌ها',
    'planner_step_2_desc' => 'چه چیزی برای شما مهم است؟',
    'planner_step_3' => 'بودجه',
    'planner_step_3_desc' => 'محدوده هزینه‌ای شما چقدر است؟',
    'planner_step_4' => 'برنامه نهایی',
    'planner_step_4_desc' => 'برنامه سفری شخصی شما',
    
    'planner_days' => 'تعداد روزهای سفر:',
    'planner_day_1' => '۱ روز',
    'planner_day_3' => '۳ روز',
    'planner_day_5' => '۵ روز',
    'planner_day_7' => '۷ روز',
    
    'planner_interests' => 'علاقه‌مندی‌های شما:',
    'interest_historical' => 'تاریخی',
    'interest_food' => 'غذا',
    'interest_shopping' => 'خرید',
    'interest_photography' => 'عکاسی',
    'interest_nature' => 'طبیعت',
    'interest_adventure' => 'ماجراجویی',
    'interest_relaxation' => 'آرامش',
    'interest_family' => 'خانوادگی',
    
    'planner_budget' => 'بودجه روزانه:',
    'budget_economical' => 'اقتصادی',
    'budget_medium' => 'متوسط',
    'budget_luxury' => 'لوکس',
    
    'generate_itinerary' => 'تولید برنامه سفر',
    'itinerary_preview' => 'پیش‌نمایش برنامه سفر:',
    'itinerary_day_1' => 'روز اول: قلب تاریخی استانبول',
    
    // خبرنامه
    'newsletter_title' => 'آماده کشف استانبول هستید؟ 🇹🇷',
    'newsletter_desc' => 'با خبرنامه ما، جدیدترین راهنمای سفر، تخفیف‌ها و تجربه‌های خاص را دریافت کنید',
    'newsletter_placeholder' => 'ایمیل خود را وارد کنید',
    'newsletter_subscribe' => 'عضویت',
    'newsletter_privacy' => 'با عضویت، <a href="#">حریم خصوصی</a> را می‌پذیرید',
    
    // دستیار هوشمند
    'ai_assistant' => 'دستیار هوشمند استانبول 🇹🇷',
    'ai_status' => 'آنلاین • پاسخ فوری',
    'ai_placeholder' => 'سوال خود را بپرسید...',
    'ai_welcome' => 'سلام! من دستیار هوشمند سفر شما هستم. می‌توانم در مورد جاذبه‌ها، هتل‌ها، رستوران‌ها و برنامه‌ریزی سفر در استانبول کمک کنم.',
    
    // فوتر
    'footer_description' => 'راهنمای کامل و جامع برای کشف استانبول، شهر روی دو قاره. ما بهترین تجربه سفر را برای شما فراهم می‌کنیم.',
    
    'footer_discover' => 'کشف کنید',
    'footer_attractions' => 'جاذبه‌ها',
    'footer_hotels' => 'هتل‌ها',
    'footer_restaurants' => 'رستوران‌ها',
    'footer_tours' => 'تورهای روزانه',
    'footer_experiences' => 'تجربه‌های خاص',
    'footer_free_activities' => 'فعالیت‌های رایگان',
    
    'footer_guides' => 'راهنماها',
    'footer_metro_map' => 'نقشه مترو',
    'footer_food_guide' => 'راهنمای غذا',
    'footer_culture' => 'فرهنگ و آداب',
    'footer_costs' => 'هزینه‌های سفر',
    'footer_weather' => 'آب و هوا',
    'footer_turkish_phrases' => 'واژگان مفید ترکی',
    
    'footer_support' => 'پشتیبانی',
    'footer_faq' => 'سوالات متداول',
    'footer_contact' => 'تماس با ما',
    'footer_terms' => 'شرایط استفاده',
    'footer_privacy' => 'حریم خصوصی',
    'footer_partnership' => 'همکاری با ما',
    'footer_careers' => 'فرصت‌های شغلی',
    
    'footer_app' => 'اپلیکیشن موبایل',
    'footer_app_desc' => 'راهنمای استانبول را در جیب خود داشته باشید',
    'footer_download' => 'دانلود از',
    
    'footer_copyright' => '© :year Istanbul Guide 🇹🇷. تمامی حقوق محفوظ است.',
    'footer_disclaimer' => 'این پروژه یک پروژه نمایشی است و با استانبول‌گردی واقعی مرتبط نمی‌باشد.',
    
    'footer_legal_privacy' => 'حریم خصوصی',
    'footer_legal_terms' => 'شرایط استفاده',
    'footer_legal_cookies' => 'تنظیمات کوکی',
    
    // جستجو
    'search_title' => 'کشف استانبول',
    'search_placeholder' => 'جاذبه‌ها، هتل‌ها، رستوران‌ها یا تجربه‌ها را جستجو کنید...',
    'search_suggestions' => 'پیشنهادهای پرطرفدار:',
    'search_category' => 'دسته‌بندی:',
    'search_all' => 'همه',
    'search_historical' => 'تاریخی',
    'search_museum' => 'موزه',
    'search_mosque' => 'مسجد',
    'search_shopping' => 'خرید',
    'search_food' => 'غذا',
    'search_nature' => 'طبیعت',
    'search_price_range' => 'محدوده قیمت:',
    'search_advanced' => 'جستجوی پیشرفته',
    
    // درباره پروژه
    'about_page_title' => 'درباره پروژه | Istanbul Guide',
    'about_page_desc' => 'معرفی پروژه راهنمای گردشگری استانبول - ترکیبی از فناوری و زیبایی',
    
    'about_vision' => 'چشم‌انداز پروژه',
    'about_vision_text_1' => 'پروژه <strong>Istanbul Guide</strong> با هدف ایجاد یک راهنمای جامع، هوشمند و تعاملی برای شهر زیبای استانبول طراحی شده است. ما بر این باوریم که سفر باید فراتر از دیدن مکان‌ها باشد و باید به یک <em>تجربه فراموش‌نشدنی</em> تبدیل شود.',
    'about_vision_text_2' => 'با ترکیب <span style="color: var(--turkey-red); font-weight: 700;">فناوری‌های پیشرفته</span>، <span style="color: var(--turkey-red); font-weight: 700;">طراحی UI/UX سطح جهانی</span> و <span style="color: var(--turkey-red); font-weight: 700;">اطلاعات دقیق محلی</span>، ما پلتفرمی ساختیم که نه تنها راهنمای سفر است، بلکه یک همراه هوشمند برای کشف عمیق‌ترین لایه‌های فرهنگ و تاریخ استانبول می‌باشد.',
    
    'about_features' => 'ویژگی‌های کلیدی',
    'about_feature_1_title' => 'نقشه هوشمند تعاملی',
    'about_feature_1_desc' => 'نقشه‌ای که بر اساس علایق شما پیشنهاد می‌دهد و مسیرهای بهینه را محاسبه می‌کند.',
    'about_feature_2_title' => 'دستیار هوشمند AI',
    'about_feature_2_desc' => 'دستیاری که ۲۴ ساعته به سوالات شما پاسخ می‌دهد و پیشنهادات شخصی ارائه می‌کند.',
    'about_feature_3_title' => 'تور مجازی ۳۶۰ درجه',
    'about_feature_3_desc' => 'قبل از سفر، مکان‌ها را به صورت مجازی و تمام‌عیار تجربه کنید.',
    'about_feature_4_title' => 'برنامه‌ریز سفر',
    'about_feature_4_desc' => 'برنامه سفر کاملاً شخصی‌سازی شده بر اساس بودجه و علایق شما.',
    'about_feature_5_title' => 'چند زبانه',
    'about_feature_5_desc' => 'پشتیبانی از زبان‌های فارسی، انگلیسی، ترکی و عربی.',
    'about_feature_6_title' => 'طراحی ریسپانسیو',
    'about_feature_6_desc' => 'تجربه کاربری عالی در تمام دستگاه‌ها از موبایل تا دسکتاپ.',
    
    'about_timeline' => 'خط زمانی پروژه',
    'about_timeline_1_date' => 'بهمن ۱۴۰۲',
    'about_timeline_1_title' => 'شروع ایده',
    'about_timeline_1_desc' => 'ایده اولیه پروژه Istanbul Guide شکل گرفت. هدف ایجاد یک پلتفرم کامل برای گردشگران فارسی‌زبان بود.',
    'about_timeline_2_date' => 'اسفند ۱۴۰۲',
    'about_timeline_2_title' => 'تحقیق و توسعه',
    'about_timeline_2_desc' => 'تحقیقات گسترده درباره نیازهای گردشگران و جمع‌آوری اطلاعات کامل از جاذبه‌های استانبول.',
    'about_timeline_3_date' => 'فروردین ۱۴۰۳',
    'about_timeline_3_title' => 'طراحی UI/UX',
    'about_timeline_3_desc' => 'طراحی رابط کاربری مدرن با الهام از فرهنگ ترکی و معماری استانبول.',
    'about_timeline_4_date' => 'اردیبهشت ۱۴۰۳',
    'about_timeline_4_title' => 'توسعه فنی',
    'about_timeline_4_desc' => 'پیاده‌سازی کامل بک‌اند و فرانت‌اند با استفاده از جدیدترین تکنولوژی‌های وب.',
    'about_timeline_5_date' => 'خرداد ۱۴۰۳',
    'about_timeline_5_title' => 'راه‌اندازی نسخه اول',
    'about_timeline_5_desc' => 'راه‌اندازی عمومی پروژه و شروع جمع‌آوری بازخورد از کاربران واقعی.',
    
    'about_stats' => 'آمار پروژه',
    'about_stats_1' => 'جاذبه تاریخی',
    'about_stats_2' => 'هتل و اقامتگاه',
    'about_stats_3' => 'رستوران و کافه',
    'about_stats_4' => 'رضایت کاربران',
    'about_stats_5' => 'پشتیبانی',
    'about_stats_6' => 'زبان پشتیبانی',
    
    'about_tech' => 'تکنولوژی‌های استفاده شده',
    'about_tech_desc' => 'این پروژه با استفاده از جدیدترین و بهترین تکنولوژی‌های وب توسعه یافته است تا تجربه‌ای سریع، امن و کاربرپسند ارائه دهد.',
    
    'about_team' => 'تیم توسعه',
    'about_team_desc' => 'تیمی از متخصصان با اشتیاق که با همکاری یکدیگر این پروژه را از ایده به واقعیت تبدیل کردند.',
    'about_team_member_1' => 'فرهام زمانی',
    'about_team_role_1' => 'توسعه‌دهنده اصلی',
    'about_team_desc_1' => 'مسئول توسعه بک‌اند و معماری کلی پروژه',
    'about_team_member_2' => 'تیم طراحی UI/UX',
    'about_team_role_2' => 'طراحان رابط کاربری',
    'about_team_desc_2' => 'طراحی تجربه کاربری و رابط کاربری زیبا',
    'about_team_member_3' => 'تیم محتوا',
    'about_team_role_3' => 'تحقیق و تولید محتوا',
    'about_team_desc_3' => 'گردآوری و تأیید اطلاعات جاذبه‌های گردشگری',
    'about_team_member_4' => 'تیم هوش مصنوعی',
    'about_team_role_4' => 'توسعه دستیار هوشمند',
    'about_team_desc_4' => 'پیاده‌سازی و آموزش مدل‌های هوش مصنوعی',
    
    'about_cta_title' => 'آماده کشف استانبول هستید؟',
    'about_cta_desc' => 'همین حالا سفر خود را با Istanbul Guide آغاز کنید و تجربه‌ای متفاوت از استانبول داشته باشید.',
    'about_cta_start' => 'شروع سفر',
    'about_cta_contact' => 'تماس با ما',
    
    // دکمه‌ها
    'btn_back' => 'بازگشت به صفحه اصلی',
    'btn_search' => 'جستجو',
    'btn_close' => 'بستن',
    'btn_minimize' => 'کوچک کردن',
    'btn_send' => 'ارسال',
    'btn_login' => 'ورود',
    'btn_signup' => 'ثبت‌نام',
    'btn_save' => 'ذخیره',
    'btn_cancel' => 'لغو',
    'btn_confirm' => 'تایید',
    'btn_learn_more' => 'بیشتر بدانید',
    
    // وضعیت‌ها
    'status_free' => 'رایگان',
    'status_open' => 'باز',
    'status_closed' => 'بسته',
    'status_available' => 'موجود',
    'status_unavailable' => 'ناموجود',
    'status_popular' => 'پرطرفدار',
    'status_new' => 'جدید',
    'status_exclusive' => 'انحصاری',
    'status_luxury' => 'لوکس',
    
    // زمان‌ها
    'time_hour' => 'ساعت',
    'time_day' => 'روز',
    'time_week' => 'هفته',
    'time_month' => 'ماه',
    'time_year' => 'سال',
    'time_now' => 'اکنون',
    'time_today' => 'امروز',
    'time_tomorrow' => 'فردا',
    'time_yesterday' => 'دیروز',
    
    // ارز
    'currency_tl' => 'لیر',
    'currency_usd' => 'دلار',
    'currency_eur' => 'یورو',
    'currency_rial' => 'ریال',
    
    // رتبه‌بندی
    'rating_excellent' => 'عالی',
    'rating_very_good' => 'خیلی خوب',
    'rating_good' => 'خوب',
    'rating_average' => 'متوسط',
    'rating_poor' => 'ضعیف',
    
    // پیام‌ها
    'msg_loading' => 'در حال بارگذاری...',
    'msg_success' => 'عملیات با موفقیت انجام شد',
    'msg_error' => 'خطا در انجام عملیات',
    'msg_no_results' => 'نتیجه‌ای یافت نشد',
    'msg_try_again' => 'دوباره تلاش کنید',
    'msg_coming_soon' => 'به زودی',
    
    // اعتبارسنجی
    'validation_required' => 'این فیلد الزامی است',
    'validation_email' => 'ایمیل معتبر وارد کنید',
    'validation_min_length' => 'حداقل :length کاراکتر وارد کنید',
    'validation_max_length' => 'حداکثر :length کاراکتر مجاز است',
    'validation_match' => 'مقدار با تاییدیه مطابقت ندارد',
    
    // فرم‌ها
    'form_name' => 'نام',
    'form_email' => 'ایمیل',
    'form_password' => 'رمز عبور',
    'form_confirm_password' => 'تایید رمز عبور',
    'form_phone' => 'تلفن',
    'form_message' => 'پیام',
    'form_submit' => 'ارسال',
    'form_reset' => 'بازنشانی',
    'form_optional' => 'اختیاری',
    
    // ماه‌های فارسی
    'month_1' => 'فروردین',
    'month_2' => 'اردیبهشت',
    'month_3' => 'خرداد',
    'month_4' => 'تیر',
    'month_5' => 'مرداد',
    'month_6' => 'شهریور',
    'month_7' => 'مهر',
    'month_8' => 'آبان',
    'month_9' => 'آذر',
    'month_10' => 'دی',
    'month_11' => 'بهمن',
    'month_12' => 'اسفند',
    
    // روزهای هفته
    'day_sat' => 'شنبه',
    'day_sun' => 'یکشنبه',
    'day_mon' => 'دوشنبه',
    'day_tue' => 'سه‌شنبه',
    'day_wed' => 'چهارشنبه',
    'day_thu' => 'پنجشنبه',
    'day_fri' => 'جمعه',
];
<?php
// languages/tr.php
return [
    // Meta etiketleri
    'page_title' => 'İstanbul Turizm Rehberi | İki Kıtadaki Şehrin Büyüsünü Keşfedin',
    'page_description' => 'Kapsamlı İstanbul turizm rehberi: atraksiyonlar, oteller, restoranlar, seyahat planlayıcı ve sanal turlar',
    'site_name' => 'İstanbul Rehberi',
    
    // Navigasyon
    'nav_home' => 'Ana Sayfa',
    'nav_discover' => 'Keşfet',
    'nav_hotels' => 'Konaklama',
    'nav_experiences' => 'Deneyimler',
    'nav_itinerary' => 'Seyahat Planlayıcı',
    'nav_about' => 'Proje Hakkında',
    'nav_login' => 'Giriş / Kayıt',
    'nav_profile' => 'Profil',
    'nav_favorites' => 'Favoriler',
    'nav_saved' => 'Kaydedilenler',
    'nav_settings' => 'Ayarlar',
    'nav_logout' => 'Çıkış',
    
    // Hero Başlık
    'hero_title_1' => 'İstanbul\'un Sonsuz Büyüsü 🇹🇷',
    'hero_subtitle_1' => 'Doğu ve Batı\'nın buluştuğu yer',
    'hero_cta_1' => 'İstanbul\'u Keşfet',
    
    'hero_title_2' => 'Unutulmaz Tarihi Deneyim',
    'hero_subtitle_2' => 'Bizans\'tan Osmanlı İmparatorluğu\'na',
    'hero_cta_2' => 'Atraksiyonları Gör',
    
    'hero_title_3' => 'Unutulmaz Lezzetler',
    'hero_subtitle_3' => 'Sokak yemeklerinden yıldızlı restoranlara',
    'hero_cta_3' => 'Restoranları Keşfet',
    
    // Hızlı İstatistikler
    'stat_historical' => 'Tarihi Atraksiyon',
    'stat_hotels' => 'Otel ve Konaklama',
    'stat_restaurants' => 'Restoran ve Kafe',
    'stat_undiscovered' => 'Keşfedilmemiş Bölge',
    
    // Bölümler
    'section_top_attractions' => 'En İyi İstanbul Atraksiyonları',
    'section_top_attractions_desc' => 'Şehirdeki en ünlü ve görülmeye değer yerleri keşfedin',
    'section_view_all' => 'Tümünü Gör',
    
    'section_categories' => 'İlgi Alanlarınıza Göre Keşfedin',
    'section_categories_desc' => 'Seyahatiniz için popüler kategoriler',
    
    'section_hotels' => 'Seçkin Konaklama Yerleri',
    'section_hotels_desc' => 'En iyi oteller, villalar ve yerel konaklamalar',
    
    'section_experiences' => 'Özel İstanbul Deneyimleri',
    'section_experiences_desc' => 'Sadece İstanbul\'da yapabileceğiniz şeyler',
    
    'section_virtual_tour' => '360° Sanal Tur',
    'section_virtual_tour_desc' => 'Seyahatinizden önce evinizden ziyaret edin',
    
    'section_travel_planner' => 'Akıllı Seyahat Planlayıcı',
    'section_travel_planner_desc' => 'İlgi alanlarınıza göre kişiselleştirilmiş seyahat planı',
    
    // Kategoriler
    'category_historical' => 'Tarihi',
    'category_photography' => 'Fotoğrafçılık',
    'category_food' => 'Yemek',
    'category_shopping' => 'Alışveriş',
    'category_sea' => 'Deniz',
    'category_nightlife' => 'Gece Hayatı',
    
    // Yerler
    'place_galata_tower' => 'Galata Kulesi',
    'place_galata_desc' => 'İstanbul\'da panoramik şehir manzarası olan tarihi bir kule',
    'place_hagia_sophia' => 'Ayasofya',
    'place_hagia_desc' => 'İstanbul\'da bir kilise, cami ve şimdi müze',
    'place_grand_bazaar' => 'Kapalı Çarşı',
    'place_grand_bazaar_desc' => 'Dünyanın en büyük ve en eski kapalı çarşılarından biri',
    
    // Oteller
    'hotel_hilton' => 'İstanbul Hilton',
    'hotel_four_seasons' => 'Four Seasons Otel',
    'hotel_radisson' => 'Radisson Otel',
    'book_online' => 'Online Rezervasyon',
    
    // Deneyimler
    'experience_bosphorus' => 'Boğaz Deniz Turu',
    'experience_bosphorus_desc' => 'Avrupa ve Asya arasında kıtalararası gezi',
    'experience_cooking' => 'Türk Mutfağı Kursu',
    'experience_cooking_desc' => 'Yerel bir şeften kebap ve baklava pişirmeyi öğrenin',
    'experience_secret_tour' => 'Gizli İstanbul Turu',
    'experience_secret_tour_desc' => 'Gizli mahalleleri ve anlatılmamış hikayeleri keşfedin',
    'experience_helicopter' => 'İstanbul Helikopter Turu',
    'experience_helicopter_desc' => 'İki kıtadaki şehrin havadan manzarası',
    
    // Sanal Tur
    'virtual_select_place' => 'Yer Seçin:',
    'virtual_hagia_sophia' => 'Ayasofya',
    'virtual_blue_mosque' => 'Sultanahmet Camii',
    'virtual_topkapi' => 'Topkapı Sarayı',
    'virtual_grand_bazaar' => 'Kapalı Çarşı',
    'virtual_guide' => 'Tur Rehberi:',
    'virtual_guide_desc' => 'Döndürmek için fareyi, yakınlaştırmak için kaydırmayı kullanın',
    'virtual_vr_mode' => 'VR Modu',
    'virtual_fullscreen' => 'Tam Ekran',
    'virtual_audio_guide' => 'Sesli Rehber',
    
    // Seyahat Planlayıcı
    'planner_step_1' => 'Seyahat Süresi',
    'planner_step_1_desc' => 'İstanbul\'da kaç gün kalacaksınız?',
    'planner_step_2' => 'İlgi Alanları',
    'planner_step_2_desc' => 'Sizin için ne önemli?',
    'planner_step_3' => 'Bütçe',
    'planner_step_3_desc' => 'Bütçe aralığınız nedir?',
    'planner_step_4' => 'Son Plan',
    'planner_step_4_desc' => 'Kişisel seyahat planınız',
    
    'planner_days' => 'Seyahat Gün Sayısı:',
    'planner_day_1' => '1 Gün',
    'planner_day_3' => '3 Gün',
    'planner_day_5' => '5 Gün',
    'planner_day_7' => '7 Gün',
    
    'planner_interests' => 'İlgi Alanlarınız:',
    'interest_historical' => 'Tarihi',
    'interest_food' => 'Yemek',
    'interest_shopping' => 'Alışveriş',
    'interest_photography' => 'Fotoğrafçılık',
    'interest_nature' => 'Doğa',
    'interest_adventure' => 'Macera',
    'interest_relaxation' => 'Rahatlama',
    'interest_family' => 'Aile',
    
    'planner_budget' => 'Günlük Bütçe:',
    'budget_economical' => 'Ekonomik',
    'budget_medium' => 'Orta',
    'budget_luxury' => 'Lüks',
    
    'generate_itinerary' => 'Seyahat Planı Oluştur',
    'itinerary_preview' => 'Seyahat Planı Önizlemesi:',
    'itinerary_day_1' => '1. Gün: İstanbul\'un Tarihi Kalbi',
    
    // Bülten
    'newsletter_title' => 'İstanbul\'u Keşfetmeye Hazır mısınız? 🇹🇷',
    'newsletter_desc' => 'Bültenimizle en son seyahat rehberleri, indirimler ve özel deneyimleri alın',
    'newsletter_placeholder' => 'E-postanızı girin',
    'newsletter_subscribe' => 'Abone Ol',
    'newsletter_privacy' => 'Abone olarak, <a href="#">Gizlilik Politikası</a>\'nı kabul etmiş olursunuz',
    
    // AI Asistanı
    'ai_assistant' => 'İstanbul Akıllı Asistan 🇹🇷',
    'ai_status' => 'Çevrimiçi • Anında Yanıt',
    'ai_placeholder' => 'Sorunuzu sorun...',
    'ai_welcome' => 'Merhaba! Ben akıllı seyahat asistanınızım. İstanbul\'daki atraksiyonlar, oteller, restoranlar ve seyahat planlaması konusunda yardımcı olabilirim.',
    
    // Footer
    'footer_description' => 'İki kıtadaki şehir İstanbul\'u keşfetmek için eksiksiz ve kapsamlı rehber. Size en iyi seyahat deneyimini sunuyoruz.',
    
    'footer_discover' => 'Keşfedin',
    'footer_attractions' => 'Atraksiyonlar',
    'footer_hotels' => 'Oteller',
    'footer_restaurants' => 'Restoranlar',
    'footer_tours' => 'Günlük Turlar',
    'footer_experiences' => 'Özel Deneyimler',
    'footer_free_activities' => 'Ücretsiz Aktiviteler',
    
    'footer_guides' => 'Rehberler',
    'footer_metro_map' => 'Metro Haritası',
    'footer_food_guide' => 'Yemek Rehberi',
    'footer_culture' => 'Kültür ve Görgü',
    'footer_costs' => 'Seyahat Maliyetleri',
    'footer_weather' => 'Hava Durumu',
    'footer_turkish_phrases' => 'Yararlı Türkçe İfadeler',
    
    'footer_support' => 'Destek',
    'footer_faq' => 'SSS',
    'footer_contact' => 'Bize Ulaşın',
    'footer_terms' => 'Kullanım Şartları',
    'footer_privacy' => 'Gizlilik',
    'footer_partnership' => 'İşbirliği',
    'footer_careers' => 'Kariyer',
    
    'footer_app' => 'Mobil Uygulama',
    'footer_app_desc' => 'İstanbul Rehberi\'ni cebinizde taşıyın',
    'footer_download' => 'İndir',
    
    'footer_copyright' => '© :year İstanbul Rehberi 🇹🇷. Tüm hakları saklıdır.',
    'footer_disclaimer' => 'Bu proje bir demo projesidir ve gerçek İstanbul turizmi ile ilişkili değildir.',
    
    'footer_legal_privacy' => 'Gizlilik',
    'footer_legal_terms' => 'Kullanım Şartları',
    'footer_legal_cookies' => 'Çerez Ayarları',
    
    // Arama
    'search_title' => 'İstanbul\'u Keşfet',
    'search_placeholder' => 'Atraksiyon, otel, restoran veya deneyim ara...',
    'search_suggestions' => 'Popüler Öneriler:',
    'search_category' => 'Kategori:',
    'search_all' => 'Tümü',
    'search_historical' => 'Tarihi',
    'search_museum' => 'Müze',
    'search_mosque' => 'Cami',
    'search_shopping' => 'Alışveriş',
    'search_food' => 'Yemek',
    'search_nature' => 'Doğa',
    'search_price_range' => 'Fiyat Aralığı:',
    'search_advanced' => 'Gelişmiş Arama',
    
    // Proje Hakkında
    'about_page_title' => 'Proje Hakkında | İstanbul Rehberi',
    'about_page_desc' => 'İstanbul Turizm Rehberi Projesi Tanıtımı - Teknoloji ve güzelliğin birleşimi',
    
    'about_vision' => 'Proje Vizyonu',
    'about_vision_text_1' => '<strong>İstanbul Rehberi</strong> projesi, güzel İstanbul şehri için kapsamlı, akıllı ve etkileşimli bir rehber oluşturma amacıyla tasarlanmıştır. Seyahatin sadece yerleri görmekten daha fazlası olması gerektiğine ve <em>unutulmaz bir deneyim</em> haline gelmesi gerektiğine inanıyoruz.',
    'about_vision_text_2' => '<span style="color: var(--turkey-red); font-weight: 700;">Gelişmiş teknolojileri</span>, <span style="color: var(--turkey-red); font-weight: 700;">dünya standartlarında UI/UX tasarımını</span> ve <span style="color: var(--turkey-red); font-weight: 700;">doğru yerel bilgileri</span> birleştirerek, sadece bir seyahat rehberi değil, aynı zamanda İstanbul\'un kültürünün ve tarihinin en derin katmanlarını keşfetmek için akıllı bir yol arkadaşı olan bir platform inşa ettik.',
    
    'about_features' => 'Temel Özellikler',
    'about_feature_1_title' => 'Etkileşimli Akıllı Harita',
    'about_feature_1_desc' => 'İlgi alanlarınıza göre öneriler yapan ve optimal rotaları hesaplayan bir harita.',
    'about_feature_2_title' => 'AI Akıllı Asistan',
    'about_feature_2_desc' => '7/24 sorularınızı yanıtlayan ve kişisel öneriler sunan bir asistan.',
    'about_feature_3_title' => '360° Sanal Tur',
    'about_feature_3_desc' => 'Seyahatinizden önce yerleri sanal ve tam olarak deneyimleyin.',
    'about_feature_4_title' => 'Seyahat Planlayıcı',
    'about_feature_4_desc' => 'Bütçe ve ilgi alanlarına göre tamamen kişiselleştirilmiş seyahat planı.',
    'about_feature_5_title' => 'Çok Dilli',
    'about_feature_5_desc' => 'Farsça, İngilizce, Türkçe ve Arapça dilleri için destek.',
    'about_feature_6_title' => 'Responsive Tasarım',
    'about_feature_6_desc' => 'Mobilden masaüstüne kadar tüm cihazlarda harika kullanıcı deneyimi.',
    
    'about_timeline' => 'Proje Zaman Çizelgesi',
    'about_timeline_1_date' => 'Ocak 2024',
    'about_timeline_1_title' => 'Fikir Başlangıcı',
    'about_timeline_1_desc' => 'İstanbul Rehberi projesinin ilk fikri oluştu. Amaç, Farsça konuşan turistler için eksiksiz bir platform oluşturmaktı.',
    'about_timeline_2_date' => 'Şubat 2024',
    'about_timeline_2_title' => 'Araştırma ve Geliştirme',
    'about_timeline_2_desc' => 'Turist ihtiyaçları hakkında kapsamlı araştırma ve İstanbul atraksiyonlarından eksiksiz bilgi toplama.',
    'about_timeline_3_date' => 'Mart 2024',
    'about_timeline_3_title' => 'UI/UX Tasarım',
    'about_timeline_3_desc' => 'Türk kültüründen ve İstanbul mimarisinden ilham alan modern kullanıcı arayüzü tasarımı.',
    'about_timeline_4_date' => 'Nisan 2024',
    'about_timeline_4_title' => 'Teknik Geliştirme',
    'about_timeline_4_desc' => 'En son web teknolojileri kullanılarak tam backend ve frontend uygulaması.',
    'about_timeline_5_date' => 'Mayıs 2024',
    'about_timeline_5_title' => 'İlk Versiyon Lansmanı',
    'about_timeline_5_desc' => 'Projenin kamuya açık lansmanı ve gerçek kullanıcılardan geri bildirim toplama başlangıcı.',
    
    'about_stats' => 'Proje İstatistikleri',
    'about_stats_1' => 'Tarihi Atraksiyon',
    'about_stats_2' => 'Otel ve Konaklama',
    'about_stats_3' => 'Restoran ve Kafe',
    'about_stats_4' => 'Kullanıcı Memnuniyeti',
    'about_stats_5' => 'Destek',
    'about_stats_6' => 'Desteklenen Diller',
    
    'about_tech' => 'Kullanılan Teknolojiler',
    'about_tech_desc' => 'Bu proje, hızlı, güvenli ve kullanıcı dostu bir deneyim sunmak için en son ve en iyi web teknolojileri kullanılarak geliştirilmiştir.',
    
    'about_team' => 'Geliştirme Ekibi',
    'about_team_desc' => 'Bu projeyi fikirden gerçeğe dönüştürmek için birlikte çalışan tutkulu uzmanlardan oluşan bir ekip.',
    'about_team_member_1' => 'Farham Zamani',
    'about_team_role_1' => 'Baş Geliştirici',
    'about_team_desc_1' => 'Backend geliştirme ve genel proje mimarisinden sorumlu',
    'about_team_member_2' => 'UI/UX Tasarım Ekibi',
    'about_team_role_2' => 'Kullanıcı Arayüzü Tasarımcıları',
    'about_team_desc_2' => 'Kullanıcı deneyimi ve güzel arayüz tasarımı',
    'about_team_member_3' => 'İçerik Ekibi',
    'about_team_role_3' => 'Araştırma ve İçerik Üretimi',
    'about_team_desc_3' => 'Turistik atraksiyon bilgilerinin toplanması ve doğrulanması',
    'about_team_member_4' => 'AI Ekibi',
    'about_team_role_4' => 'Akıllı Asistan Geliştirme',
    'about_team_desc_4' => 'Yapay zeka modellerinin uygulanması ve eğitimi',
    
    'about_cta_title' => 'İstanbul\'u Keşfetmeye Hazır mısınız?',
    'about_cta_desc' => 'Şimdi İstanbul Rehberi ile yolculuğunuza başlayın ve İstanbul\'un farklı bir deneyimini yaşayın.',
    'about_cta_start' => 'Yolculuğa Başla',
    'about_cta_contact' => 'Bize Ulaşın',
    
    // Düğmeler
    'btn_back' => 'Ana Sayfaya Dön',
    'btn_search' => 'Ara',
    'btn_close' => 'Kapat',
    'btn_minimize' => 'Küçült',
    'btn_send' => 'Gönder',
    'btn_login' => 'Giriş',
    'btn_signup' => 'Kayıt',
    'btn_save' => 'Kaydet',
    'btn_cancel' => 'İptal',
    'btn_confirm' => 'Onayla',
    'btn_learn_more' => 'Daha Fazla Bilgi',
    
    // Durumlar
    'status_free' => 'Ücretsiz',
    'status_open' => 'Açık',
    'status_closed' => 'Kapalı',
    'status_available' => 'Mevcut',
    'status_unavailable' => 'Mevcut Değil',
    'status_popular' => 'Popüler',
    'status_new' => 'Yeni',
    'status_exclusive' => 'Özel',
    'status_luxury' => 'Lüks',
    
    // Zamanlar
    'time_hour' => 'saat',
    'time_day' => 'gün',
    'time_week' => 'hafta',
    'time_month' => 'ay',
    'time_year' => 'yıl',
    'time_now' => 'şimdi',
    'time_today' => 'bugün',
    'time_tomorrow' => 'yarın',
    'time_yesterday' => 'dün',
    
    // Para Birimi
    'currency_tl' => 'TL',
    'currency_usd' => 'USD',
    'currency_eur' => 'EUR',
    'currency_rial' => 'Riyal',
    
    // Değerlendirmeler
    'rating_excellent' => 'Mükemmel',
    'rating_very_good' => 'Çok İyi',
    'rating_good' => 'İyi',
    'rating_average' => 'Orta',
    'rating_poor' => 'Zayıf',
    
    // Mesajlar
    'msg_loading' => 'Yükleniyor...',
    'msg_success' => 'İşlem başarıyla tamamlandı',
    'msg_error' => 'İşlemde hata',
    'msg_no_results' => 'Sonuç bulunamadı',
    'msg_try_again' => 'Tekrar deneyin',
    'msg_coming_soon' => 'Çok Yakında',
    
    // Doğrulama
    'validation_required' => 'Bu alan zorunludur',
    'validation_email' => 'Geçerli bir e-posta girin',
    'validation_min_length' => 'En az :length karakter girin',
    'validation_max_length' => 'Maksimum :length karakter izin verilir',
    'validation_match' => 'Değer onayla eşleşmiyor',
    
    // Formlar
    'form_name' => 'Ad',
    'form_email' => 'E-posta',
    'form_password' => 'Şifre',
    'form_confirm_password' => 'Şifreyi Onayla',
    'form_phone' => 'Telefon',
    'form_message' => 'Mesaj',
    'form_submit' => 'Gönder',
    'form_reset' => 'Sıfırla',
    'form_optional' => 'İsteğe Bağlı',
    
    // Aylar
    'month_1' => 'Ocak',
    'month_2' => 'Şubat',
    'month_3' => 'Mart',
    'month_4' => 'Nisan',
    'month_5' => 'Mayıs',
    'month_6' => 'Haziran',
    'month_7' => 'Temmuz',
    'month_8' => 'Ağustos',
    'month_9' => 'Eylül',
    'month_10' => 'Ekim',
    'month_11' => 'Kasım',
    'month_12' => 'Aralık',
    
    // Haftanın Günleri
    'day_sat' => 'Cumartesi',
    'day_sun' => 'Pazar',
    'day_mon' => 'Pazartesi',
    'day_tue' => 'Salı',
    'day_wed' => 'Çarşamba',
    'day_thu' => 'Perşembe',
    'day_fri' => 'Cuma',
];
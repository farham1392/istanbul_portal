<?php
// languages/en.php
return [
    // Meta tags
    'page_title' => 'Istanbul Tourism Guide | Discover the Magic of the City on Two Continents',
    'page_description' => 'Comprehensive Istanbul tourism guide: attractions, hotels, restaurants, travel planner and virtual tours',
    'site_name' => 'Istanbul Guide',
    
    // Navigation
    'nav_home' => 'Home',
    'nav_discover' => 'Discover',
    'nav_hotels' => 'Accommodation',
    'nav_experiences' => 'Experiences',
    'nav_itinerary' => 'Travel Planner',
    'nav_about' => 'About Project',
    'nav_login' => 'Login / Signup',
    'nav_profile' => 'Profile',
    'nav_favorites' => 'Favorites',
    'nav_saved' => 'Saved',
    'nav_settings' => 'Settings',
    'nav_logout' => 'Logout',
    
    // Hero Header
    'hero_title_1' => 'Endless Magic of Istanbul 🇹🇷',
    'hero_subtitle_1' => 'Where East and West converge',
    'hero_cta_1' => 'Discover Istanbul',
    
    'hero_title_2' => 'Unforgettable Historical Experience',
    'hero_subtitle_2' => 'From Byzantium to the Ottoman Empire',
    'hero_cta_2' => 'View Attractions',
    
    'hero_title_3' => 'Unforgettable Flavors',
    'hero_subtitle_3' => 'From street food to starred restaurants',
    'hero_cta_3' => 'Discover Restaurants',
    
    // Quick Stats
    'stat_historical' => 'Historical Attractions',
    'stat_hotels' => 'Hotels & Accommodations',
    'stat_restaurants' => 'Restaurants & Cafes',
    'stat_undiscovered' => 'Undiscovered Areas',
    
    // Sections
    'section_top_attractions' => 'Top Istanbul Attractions',
    'section_top_attractions_desc' => 'Discover the most famous and beautiful places in the city',
    'section_view_all' => 'View All',
    
    'section_categories' => 'Discover by Your Interests',
    'section_categories_desc' => 'Popular categories for your journey',
    
    'section_hotels' => 'Featured Accommodations',
    'section_hotels_desc' => 'Best hotels, villas, and local stays',
    
    'section_experiences' => 'Special Istanbul Experiences',
    'section_experiences_desc' => 'Things you can only do in Istanbul',
    
    'section_virtual_tour' => '360° Virtual Tour',
    'section_virtual_tour_desc' => 'Visit from home before your trip',
    
    'section_travel_planner' => 'Smart Travel Planner',
    'section_travel_planner_desc' => 'Personalized travel plan based on your interests',
    
    // Categories
    'category_historical' => 'Historical',
    'category_photography' => 'Photography',
    'category_food' => 'Food',
    'category_shopping' => 'Shopping',
    'category_sea' => 'Sea',
    'category_nightlife' => 'Nightlife',
    
    // Places
    'place_galata_tower' => 'Galata Tower',
    'place_galata_desc' => 'A historical tower in Istanbul with panoramic city views',
    'place_hagia_sophia' => 'Hagia Sophia',
    'place_hagia_desc' => 'A church, mosque, and now a museum in Istanbul',
    'place_grand_bazaar' => 'Grand Bazaar',
    'place_grand_bazaar_desc' => 'One of the largest and oldest covered markets in the world',
    
    // Hotels
    'hotel_hilton' => 'Istanbul Hilton',
    'hotel_four_seasons' => 'Four Seasons Hotel',
    'hotel_radisson' => 'Radisson Hotel',
    'book_online' => 'Book Online',
    
    // Experiences
    'experience_bosphorus' => 'Bosphorus Sea Tour',
    'experience_bosphorus_desc' => 'Intercontinental cruise between Europe and Asia',
    'experience_cooking' => 'Turkish Cooking Class',
    'experience_cooking_desc' => 'Learn to cook kebab and baklava from a local chef',
    'experience_secret_tour' => 'Secret Istanbul Tour',
    'experience_secret_tour_desc' => 'Discover hidden neighborhoods and untold stories',
    'experience_helicopter' => 'Istanbul Helicopter Tour',
    'experience_helicopter_desc' => 'Aerial view of the city on two continents',
    
    // Virtual Tour
    'virtual_select_place' => 'Select Place:',
    'virtual_hagia_sophia' => 'Hagia Sophia',
    'virtual_blue_mosque' => 'Blue Mosque',
    'virtual_topkapi' => 'Topkapi Palace',
    'virtual_grand_bazaar' => 'Grand Bazaar',
    'virtual_guide' => 'Tour Guide:',
    'virtual_guide_desc' => 'Use mouse to rotate and scroll to zoom',
    'virtual_vr_mode' => 'VR Mode',
    'virtual_fullscreen' => 'Full Screen',
    'virtual_audio_guide' => 'Audio Guide',
    
    // Travel Planner
    'planner_step_1' => 'Travel Duration',
    'planner_step_1_desc' => 'How many days in Istanbul?',
    'planner_step_2' => 'Interests',
    'planner_step_2_desc' => 'What matters to you?',
    'planner_step_3' => 'Budget',
    'planner_step_3_desc' => 'What is your budget range?',
    'planner_step_4' => 'Final Plan',
    'planner_step_4_desc' => 'Your personal travel plan',
    
    'planner_days' => 'Number of Travel Days:',
    'planner_day_1' => '1 Day',
    'planner_day_3' => '3 Days',
    'planner_day_5' => '5 Days',
    'planner_day_7' => '7 Days',
    
    'planner_interests' => 'Your Interests:',
    'interest_historical' => 'Historical',
    'interest_food' => 'Food',
    'interest_shopping' => 'Shopping',
    'interest_photography' => 'Photography',
    'interest_nature' => 'Nature',
    'interest_adventure' => 'Adventure',
    'interest_relaxation' => 'Relaxation',
    'interest_family' => 'Family',
    
    'planner_budget' => 'Daily Budget:',
    'budget_economical' => 'Economical',
    'budget_medium' => 'Medium',
    'budget_luxury' => 'Luxury',
    
    'generate_itinerary' => 'Generate Travel Plan',
    'itinerary_preview' => 'Travel Plan Preview:',
    'itinerary_day_1' => 'Day 1: Historical Heart of Istanbul',
    
    // Newsletter
    'newsletter_title' => 'Ready to Discover Istanbul? 🇹🇷',
    'newsletter_desc' => 'Get the latest travel guides, discounts and special experiences with our newsletter',
    'newsletter_placeholder' => 'Enter your email',
    'newsletter_subscribe' => 'Subscribe',
    'newsletter_privacy' => 'By subscribing, you accept our <a href="#">Privacy Policy</a>',
    
    // AI Assistant
    'ai_assistant' => 'Istanbul Smart Assistant 🇹🇷',
    'ai_status' => 'Online • Instant Response',
    'ai_placeholder' => 'Ask your question...',
    'ai_welcome' => 'Hello! I am your smart travel assistant. I can help with attractions, hotels, restaurants, and travel planning in Istanbul.',
    
    // Footer
    'footer_description' => 'Complete and comprehensive guide to discover Istanbul, the city on two continents. We provide the best travel experience for you.',
    
    'footer_discover' => 'Discover',
    'footer_attractions' => 'Attractions',
    'footer_hotels' => 'Hotels',
    'footer_restaurants' => 'Restaurants',
    'footer_tours' => 'Daily Tours',
    'footer_experiences' => 'Special Experiences',
    'footer_free_activities' => 'Free Activities',
    
    'footer_guides' => 'Guides',
    'footer_metro_map' => 'Metro Map',
    'footer_food_guide' => 'Food Guide',
    'footer_culture' => 'Culture & Etiquette',
    'footer_costs' => 'Travel Costs',
    'footer_weather' => 'Weather',
    'footer_turkish_phrases' => 'Useful Turkish Phrases',
    
    'footer_support' => 'Support',
    'footer_faq' => 'FAQ',
    'footer_contact' => 'Contact Us',
    'footer_terms' => 'Terms of Use',
    'footer_privacy' => 'Privacy',
    'footer_partnership' => 'Partnership',
    'footer_careers' => 'Careers',
    
    'footer_app' => 'Mobile App',
    'footer_app_desc' => 'Have Istanbul Guide in your pocket',
    'footer_download' => 'Download on',
    
    'footer_copyright' => '© :year Istanbul Guide 🇹🇷. All rights reserved.',
    'footer_disclaimer' => 'This project is a demo project and is not related to real Istanbul tourism.',
    
    'footer_legal_privacy' => 'Privacy',
    'footer_legal_terms' => 'Terms of Use',
    'footer_legal_cookies' => 'Cookie Settings',
    
    // Search
    'search_title' => 'Discover Istanbul',
    'search_placeholder' => 'Search attractions, hotels, restaurants or experiences...',
    'search_suggestions' => 'Popular Suggestions:',
    'search_category' => 'Category:',
    'search_all' => 'All',
    'search_historical' => 'Historical',
    'search_museum' => 'Museum',
    'search_mosque' => 'Mosque',
    'search_shopping' => 'Shopping',
    'search_food' => 'Food',
    'search_nature' => 'Nature',
    'search_price_range' => 'Price Range:',
    'search_advanced' => 'Advanced Search',
    
    // About Project
    'about_page_title' => 'About Project | Istanbul Guide',
    'about_page_desc' => 'Introduction to Istanbul Tourism Guide Project - A blend of technology and beauty',
    
    'about_vision' => 'Project Vision',
    'about_vision_text_1' => 'The <strong>Istanbul Guide</strong> project is designed to create a comprehensive, intelligent, and interactive guide for the beautiful city of Istanbul. We believe that travel should be more than just seeing places and should become an <em>unforgettable experience</em>.',
    'about_vision_text_2' => 'By combining <span style="color: var(--turkey-red); font-weight: 700;">advanced technologies</span>, <span style="color: var(--turkey-red); font-weight: 700;">world-class UI/UX design</span>, and <span style="color: var(--turkey-red); font-weight: 700;">accurate local information</span>, we have built a platform that is not only a travel guide but also an intelligent companion for discovering the deepest layers of Istanbul\'s culture and history.',
    
    'about_features' => 'Key Features',
    'about_feature_1_title' => 'Interactive Smart Map',
    'about_feature_1_desc' => 'A map that suggests based on your interests and calculates optimal routes.',
    'about_feature_2_title' => 'AI Smart Assistant',
    'about_feature_2_desc' => 'An assistant that answers your questions 24/7 and provides personal suggestions.',
    'about_feature_3_title' => '360° Virtual Tour',
    'about_feature_3_desc' => 'Experience places virtually and fully before your trip.',
    'about_feature_4_title' => 'Travel Planner',
    'about_feature_4_desc' => 'Fully personalized travel plan based on budget and interests.',
    'about_feature_5_title' => 'Multilingual',
    'about_feature_5_desc' => 'Support for Persian, English, Turkish and Arabic languages.',
    'about_feature_6_title' => 'Responsive Design',
    'about_feature_6_desc' => 'Great user experience on all devices from mobile to desktop.',
    
    'about_timeline' => 'Project Timeline',
    'about_timeline_1_date' => 'January 2024',
    'about_timeline_1_title' => 'Idea Start',
    'about_timeline_1_desc' => 'The initial idea of Istanbul Guide project was formed. The goal was to create a complete platform for Persian-speaking tourists.',
    'about_timeline_2_date' => 'February 2024',
    'about_timeline_2_title' => 'Research & Development',
    'about_timeline_2_desc' => 'Extensive research about tourist needs and comprehensive information collection from Istanbul attractions.',
    'about_timeline_3_date' => 'March 2024',
    'about_timeline_3_title' => 'UI/UX Design',
    'about_timeline_3_desc' => 'Modern user interface design inspired by Turkish culture and Istanbul architecture.',
    'about_timeline_4_date' => 'April 2024',
    'about_timeline_4_title' => 'Technical Development',
    'about_timeline_4_desc' => 'Complete backend and frontend implementation using the latest web technologies.',
    'about_timeline_5_date' => 'May 2024',
    'about_timeline_5_title' => 'First Version Launch',
    'about_timeline_5_desc' => 'Public launch of the project and start collecting feedback from real users.',
    
    'about_stats' => 'Project Statistics',
    'about_stats_1' => 'Historical Attractions',
    'about_stats_2' => 'Hotels & Accommodations',
    'about_stats_3' => 'Restaurants & Cafes',
    'about_stats_4' => 'User Satisfaction',
    'about_stats_5' => 'Support',
    'about_stats_6' => 'Supported Languages',
    
    'about_tech' => 'Technologies Used',
    'about_tech_desc' => 'This project has been developed using the latest and best web technologies to provide a fast, secure and user-friendly experience.',
    
    'about_team' => 'Development Team',
    'about_team_desc' => 'A team of passionate specialists who worked together to turn this project from idea to reality.',
    'about_team_member_1' => 'Farham Zamani',
    'about_team_role_1' => 'Lead Developer',
    'about_team_desc_1' => 'Responsible for backend development and overall project architecture',
    'about_team_member_2' => 'UI/UX Design Team',
    'about_team_role_2' => 'User Interface Designers',
    'about_team_desc_2' => 'User experience and beautiful interface design',
    'about_team_member_3' => 'Content Team',
    'about_team_role_3' => 'Research & Content Production',
    'about_team_desc_3' => 'Collection and verification of tourist attraction information',
    'about_team_member_4' => 'AI Team',
    'about_team_role_4' => 'Smart Assistant Development',
    'about_team_desc_4' => 'Implementation and training of artificial intelligence models',
    
    'about_cta_title' => 'Ready to Discover Istanbul?',
    'about_cta_desc' => 'Start your journey with Istanbul Guide now and have a different experience of Istanbul.',
    'about_cta_start' => 'Start Journey',
    'about_cta_contact' => 'Contact Us',
    
    // Buttons
    'btn_back' => 'Back to Home',
    'btn_search' => 'Search',
    'btn_close' => 'Close',
    'btn_minimize' => 'Minimize',
    'btn_send' => 'Send',
    'btn_login' => 'Login',
    'btn_signup' => 'Signup',
    'btn_save' => 'Save',
    'btn_cancel' => 'Cancel',
    'btn_confirm' => 'Confirm',
    'btn_learn_more' => 'Learn More',
    
    // Statuses
    'status_free' => 'Free',
    'status_open' => 'Open',
    'status_closed' => 'Closed',
    'status_available' => 'Available',
    'status_unavailable' => 'Unavailable',
    'status_popular' => 'Popular',
    'status_new' => 'New',
    'status_exclusive' => 'Exclusive',
    'status_luxury' => 'Luxury',
    
    // Times
    'time_hour' => 'hour',
    'time_day' => 'day',
    'time_week' => 'week',
    'time_month' => 'month',
    'time_year' => 'year',
    'time_now' => 'now',
    'time_today' => 'today',
    'time_tomorrow' => 'tomorrow',
    'time_yesterday' => 'yesterday',
    
    // Currency
    'currency_tl' => 'TL',
    'currency_usd' => 'USD',
    'currency_eur' => 'EUR',
    'currency_rial' => 'Rial',
    
    // Ratings
    'rating_excellent' => 'Excellent',
    'rating_very_good' => 'Very Good',
    'rating_good' => 'Good',
    'rating_average' => 'Average',
    'rating_poor' => 'Poor',
    
    // Messages
    'msg_loading' => 'Loading...',
    'msg_success' => 'Operation completed successfully',
    'msg_error' => 'Error in operation',
    'msg_no_results' => 'No results found',
    'msg_try_again' => 'Try again',
    'msg_coming_soon' => 'Coming soon',
    
    // Validation
    'validation_required' => 'This field is required',
    'validation_email' => 'Enter a valid email',
    'validation_min_length' => 'Enter at least :length characters',
    'validation_max_length' => 'Maximum :length characters allowed',
    'validation_match' => 'Value does not match confirmation',
    
    // Forms
    'form_name' => 'Name',
    'form_email' => 'Email',
    'form_password' => 'Password',
    'form_confirm_password' => 'Confirm Password',
    'form_phone' => 'Phone',
    'form_message' => 'Message',
    'form_submit' => 'Submit',
    'form_reset' => 'Reset',
    'form_optional' => 'Optional',
    
    // Months
    'month_1' => 'January',
    'month_2' => 'February',
    'month_3' => 'March',
    'month_4' => 'April',
    'month_5' => 'May',
    'month_6' => 'June',
    'month_7' => 'July',
    'month_8' => 'August',
    'month_9' => 'September',
    'month_10' => 'October',
    'month_11' => 'November',
    'month_12' => 'December',
    
    // Days of week
    'day_sat' => 'Saturday',
    'day_sun' => 'Sunday',
    'day_mon' => 'Monday',
    'day_tue' => 'Tuesday',
    'day_wed' => 'Wednesday',
    'day_thu' => 'Thursday',
    'day_fri' => 'Friday',
];
-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 06, 2026 at 01:07 PM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 7.4.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `istanbul`
--

-- --------------------------------------------------------

--
-- Table structure for table `favorites`
--

CREATE TABLE `favorites` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `place_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_persian_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hotels`
--

CREATE TABLE `hotels` (
  `id` int(11) NOT NULL,
  `name_fa` varchar(255) COLLATE utf8mb4_persian_ci NOT NULL,
  `name_en` varchar(255) COLLATE utf8mb4_persian_ci DEFAULT NULL,
  `description_fa` text COLLATE utf8mb4_persian_ci DEFAULT NULL,
  `description_en` text COLLATE utf8mb4_persian_ci DEFAULT NULL,
  `stars` int(11) DEFAULT 3,
  `rating` decimal(3,2) DEFAULT 0.00,
  `price_per_night` decimal(10,2) DEFAULT NULL,
  `district_fa` varchar(100) COLLATE utf8mb4_persian_ci DEFAULT NULL,
  `address_fa` text COLLATE utf8mb4_persian_ci DEFAULT NULL,
  `phone` varchar(20) COLLATE utf8mb4_persian_ci DEFAULT NULL,
  `email` varchar(100) COLLATE utf8mb4_persian_ci DEFAULT NULL,
  `amenities` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`amenities`)),
  `image_urls` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`image_urls`)),
  `latitude` decimal(10,8) DEFAULT NULL,
  `longitude` decimal(11,8) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_persian_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hotel_bookings`
--

CREATE TABLE `hotel_bookings` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `hotel_id` int(11) NOT NULL,
  `check_in` date NOT NULL,
  `check_out` date NOT NULL,
  `guests` int(11) DEFAULT 1,
  `rooms` int(11) DEFAULT 1,
  `total_price` decimal(10,2) DEFAULT NULL,
  `status` enum('pending','confirmed','cancelled','completed') COLLATE utf8mb4_persian_ci DEFAULT 'pending',
  `special_requests` text COLLATE utf8mb4_persian_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_persian_ci;

-- --------------------------------------------------------

--
-- Table structure for table `itineraries`
--

CREATE TABLE `itineraries` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `title_fa` varchar(255) COLLATE utf8mb4_persian_ci DEFAULT NULL,
  `title_en` varchar(255) COLLATE utf8mb4_persian_ci DEFAULT NULL,
  `days` int(11) DEFAULT 1,
  `interests` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`interests`)),
  `budget_level` enum('economical','medium','luxury') COLLATE utf8mb4_persian_ci DEFAULT 'medium',
  `itinerary_data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`itinerary_data`)),
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_persian_ci;

-- --------------------------------------------------------

--
-- Table structure for table `places`
--

CREATE TABLE `places` (
  `id` int(11) NOT NULL,
  `name_fa` varchar(255) COLLATE utf8mb4_persian_ci NOT NULL,
  `name_en` varchar(255) COLLATE utf8mb4_persian_ci DEFAULT NULL,
  `description_fa` text COLLATE utf8mb4_persian_ci DEFAULT NULL,
  `description_en` text COLLATE utf8mb4_persian_ci DEFAULT NULL,
  `category` enum('historical','museum','mosque','shopping','food','nature','palace','bazaar') COLLATE utf8mb4_persian_ci DEFAULT NULL,
  `district_fa` varchar(100) COLLATE utf8mb4_persian_ci DEFAULT NULL,
  `district_en` varchar(100) COLLATE utf8mb4_persian_ci DEFAULT NULL,
  `address_fa` text COLLATE utf8mb4_persian_ci DEFAULT NULL,
  `address_en` text COLLATE utf8mb4_persian_ci DEFAULT NULL,
  `latitude` decimal(10,8) DEFAULT NULL,
  `longitude` decimal(11,8) DEFAULT NULL,
  `rating` decimal(3,2) DEFAULT 0.00,
  `price_range` enum('free','low','medium','high') COLLATE utf8mb4_persian_ci DEFAULT NULL,
  `opening_hours_fa` varchar(255) COLLATE utf8mb4_persian_ci DEFAULT NULL,
  `opening_hours_en` varchar(255) COLLATE utf8mb4_persian_ci DEFAULT NULL,
  `best_time_fa` varchar(255) COLLATE utf8mb4_persian_ci DEFAULT NULL,
  `duration_fa` varchar(50) COLLATE utf8mb4_persian_ci DEFAULT NULL,
  `image_url` varchar(500) COLLATE utf8mb4_persian_ci DEFAULT NULL,
  `virtual_tour_images` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`virtual_tour_images`)),
  `tags` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`tags`)),
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_persian_ci;

-- --------------------------------------------------------

--
-- Table structure for table `searches`
--

CREATE TABLE `searches` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `query` text COLLATE utf8mb4_persian_ci DEFAULT NULL,
  `filters` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`filters`)),
  `results_count` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_persian_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) COLLATE utf8mb4_persian_ci NOT NULL,
  `email` varchar(100) COLLATE utf8mb4_persian_ci NOT NULL,
  `password_hash` varchar(255) COLLATE utf8mb4_persian_ci NOT NULL,
  `full_name` varchar(100) COLLATE utf8mb4_persian_ci DEFAULT NULL,
  `phone` varchar(20) COLLATE utf8mb4_persian_ci DEFAULT NULL,
  `avatar_url` varchar(255) COLLATE utf8mb4_persian_ci DEFAULT NULL,
  `language` enum('fa','en','tr','ar') COLLATE utf8mb4_persian_ci DEFAULT 'fa',
  `theme` enum('light','dark') COLLATE utf8mb4_persian_ci DEFAULT 'light',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_persian_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password_hash`, `full_name`, `phone`, `avatar_url`, `language`, `theme`, `created_at`, `updated_at`) VALUES
(1, 'نرگس', 'nargeshydarpoooor@gmail.com', '$2y$10$pY1WJXcX3bX.aYzc.XG3IuQc1kTqwHtX16DwaZ2.AWJqvao/dPvvu', 'حیدرپور', '09109016365', '', 'fa', 'light', '2026-02-06 10:55:20', '2026-02-06 10:55:20'),
(2, 'محمد', 'jalooahmad@gmail.com', '$2y$10$1kSW/rRgd8H2/q1POwt4YeyeQTnJeOJyK.eC6PBEQIQz7CwsnEBSm', 'احمدی', '09123103312', '', 'fa', 'light', '2026-02-06 11:08:27', '2026-02-06 11:08:27'),
(17, 'بتول', 'bjhadarpor@gmail.com', '$2y$10$4brlI34OeHqQGoYGJCuAa.p5vmFtVmVkMB0tgQMtHzajILBe5b2Ri', 'جربان', '09371542461', '', 'fa', 'light', '2026-02-06 11:26:43', '2026-02-06 11:26:43'),
(18, 'زهرا', 'zahraakbari@gmail.com', '$2y$10$FZgt/h3iCrpyfZmz/ovoJuCQmf7IFmevjXoOUWAzaBRq.7Tx5.z4W', 'اکبری', '09104570263', '', 'fa', 'light', '2026-02-06 11:28:59', '2026-02-06 11:28:59'),
(19, 'سینا', 'sinasalhi@gmail.com', '$2y$10$6pU76fvNAfd08YIs25OlUOFUvp3l5bQLS/UQ7A5k9WzIT7OcPC6aK', 'سینا صالحی', '09184562323', '', 'fa', 'light', '2026-02-06 11:40:08', '2026-02-06 11:40:08');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `favorites`
--
ALTER TABLE `favorites`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_favorite` (`user_id`,`place_id`),
  ADD KEY `place_id` (`place_id`);

--
-- Indexes for table `hotels`
--
ALTER TABLE `hotels`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `hotel_bookings`
--
ALTER TABLE `hotel_bookings`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `hotel_id` (`hotel_id`);

--
-- Indexes for table `itineraries`
--
ALTER TABLE `itineraries`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `places`
--
ALTER TABLE `places`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `searches`
--
ALTER TABLE `searches`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `favorites`
--
ALTER TABLE `favorites`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hotels`
--
ALTER TABLE `hotels`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hotel_bookings`
--
ALTER TABLE `hotel_bookings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `itineraries`
--
ALTER TABLE `itineraries`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `places`
--
ALTER TABLE `places`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `searches`
--
ALTER TABLE `searches`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `favorites`
--
ALTER TABLE `favorites`
  ADD CONSTRAINT `favorites_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `favorites_ibfk_2` FOREIGN KEY (`place_id`) REFERENCES `places` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `hotel_bookings`
--
ALTER TABLE `hotel_bookings`
  ADD CONSTRAINT `hotel_bookings_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `hotel_bookings_ibfk_2` FOREIGN KEY (`hotel_id`) REFERENCES `hotels` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `itineraries`
--
ALTER TABLE `itineraries`
  ADD CONSTRAINT `itineraries_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `searches`
--
ALTER TABLE `searches`
  ADD CONSTRAINT `searches_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

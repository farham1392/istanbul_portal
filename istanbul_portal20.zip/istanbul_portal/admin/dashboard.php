<?php
require_once '../includes/functions.php';

// بررسی دسترسی ادمین
session_start();
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: login.php');
    exit;
}

$db = getDB();

// آمار کلی
$stats = [];

// تعداد مکان‌ها
$stmt = $db->query("SELECT COUNT(*) as count FROM places");
$stats['total_places'] = $stmt->fetch(PDO::FETCH_ASSOC)['count'];

// تعداد کاربران
$stmt = $db->query("SELECT COUNT(*) as count FROM users");
$stats['total_users'] = $stmt->fetch(PDO::FETCH_ASSOC)['count'];

// تعداد رزروها
$stmt = $db->query("SELECT COUNT(*) as count FROM bookings");
$stats['total_bookings'] = $stmt->fetch(PDO::FETCH_ASSOC)['count'];

// تعداد برنامه‌های سفر
$stmt = $db->query("SELECT COUNT(*) as count FROM itineraries");
$stats['total_itineraries'] = $stmt->fetch(PDO::FETCH_ASSOC)['count'];

?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>پنل مدیریت - Istanbul Guide</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body {
            background-color: #f8f9fa;
            font-family: 'Vazirmatn', sans-serif;
        }
        
        .sidebar {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            color: white;
        }
        
        .sidebar .nav-link {
            color: rgba(255,255,255,.8);
            padding: 15px 20px;
            border-radius: 10px;
            margin-bottom: 5px;
            transition: all 0.3s;
        }
        
        .sidebar .nav-link:hover,
        .sidebar .nav-link.active {
            background: rgba(255,255,255,.2);
            color: white;
        }
        
        .stat-card {
            border-radius: 15px;
            border: none;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            transition: transform 0.3s;
        }
        
        .stat-card:hover {
            transform: translateY(-5px);
        }
        
        .stat-icon {
            width: 60px;
            height: 60px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-3 col-lg-2 sidebar p-0">
                <div class="p-4">
                    <h4 class="text-center mb-4">
                        <i class="fas fa-mosque"></i>
                        مدیریت استانبول‌گردی
                    </h4>
                    
                    <ul class="nav flex-column">
                        <li class="nav-item">
                            <a class="nav-link active" href="dashboard.php">
                                <i class="fas fa-tachometer-alt me-2"></i>
                                داشبورد
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="places.php">
                                <i class="fas fa-landmark me-2"></i>
                                مکان‌های گردشگری
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="hotels.php">
                                <i class="fas fa-hotel me-2"></i>
                                هتل‌ها
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="bookings.php">
                                <i class="fas fa-calendar-check me-2"></i>
                                رزروها
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="users.php">
                                <i class="fas fa-users me-2"></i>
                                کاربران
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="settings.php">
                                <i class="fas fa-cog me-2"></i>
                                تنظیمات
                            </a>
                        </li>
                        <li class="nav-item mt-4">
                            <a class="nav-link text-danger" href="logout.php">
                                <i class="fas fa-sign-out-alt me-2"></i>
                                خروج
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
            
            <!-- Main Content -->
            <div class="col-md-9 col-lg-10 ms-auto p-4">
                <!-- Header -->
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h3>داشبورد مدیریت</h3>
                    <div class="d-flex align-items-center">
                        <span class="me-3"><?php echo $_SESSION['admin_name'] ?? 'مدیر'; ?></span>
                        <img src="https://ui-avatars.com/api/?name=Admin&background=667eea&color=fff&size=40" 
                             class="rounded-circle" alt="Admin">
                    </div>
                </div>
                
                <!-- Stats Cards -->
                <div class="row mb-4">
                    <div class="col-md-3 mb-3">
                        <div class="card stat-card">
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div>
                                        <h6 class="text-muted">مکان‌های گردشگری</h6>
                                        <h3><?php echo $stats['total_places']; ?></h3>
                                    </div>
                                    <div class="stat-icon" style="background: #667eea20; color: #667eea;">
                                        <i class="fas fa-landmark"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-md-3 mb-3">
                        <div class="card stat-card">
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div>
                                        <h6 class="text-muted">کاربران</h6>
                                        <h3><?php echo $stats['total_users']; ?></h3>
                                    </div>
                                    <div class="stat-icon" style="background: #10b98120; color: #10b981;">
                                        <i class="fas fa-users"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-md-3 mb-3">
                        <div class="card stat-card">
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div>
                                        <h6 class="text-muted">رزروها</h6>
                                        <h3><?php echo $stats['total_bookings']; ?></h3>
                                    </div>
                                    <div class="stat-icon" style="background: #f59e0b20; color: #f59e0b;">
                                        <i class="fas fa-calendar-check"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-md-3 mb-3">
                        <div class="card stat-card">
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div>
                                        <h6 class="text-muted">برنامه‌های سفر</h6>
                                        <h3><?php echo $stats['total_itineraries']; ?></h3>
                                    </div>
                                    <div class="stat-icon" style="background: #ef444420; color: #ef4444;">
                                        <i class="fas fa-route"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Recent Activity -->
                <div class="row">
                    <div class="col-md-8">
                        <div class="card">
                            <div class="card-header">
                                <h5 class="card-title mb-0">آخرین فعالیت‌ها</h5>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table table-hover">
                                        <thead>
                                            <tr>
                                                <th>تاریخ</th>
                                                <th>کاربر</th>
                                                <th>فعالیت</th>
                                                <th>وضعیت</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                            // دریافت آخرین فعالیت‌ها
                                            $query = "SELECT * FROM (
                                                SELECT created_at as date, username as user, 'ثبت‌نام' as activity, 'موفق' as status FROM users 
                                                UNION ALL
                                                SELECT created_at as date, 'کاربر مهمان' as user, 'ایجاد برنامه سفر' as activity, 'موفق' as status FROM itineraries 
                                                WHERE user_id IS NULL
                                                UNION ALL
                                                SELECT created_at as date, 'کاربر' as user, 'رزرو هتل' as activity, 'در انتظار' as status FROM bookings 
                                                WHERE status = 'pending'
                                            ) as activities 
                                            ORDER BY date DESC 
                                            LIMIT 10";
                                            
                                            $stmt = $db->query($query);
                                            while ($row = $stmt->fetch(PDO::FETCH_ASSOC)):
                                            ?>
                                            <tr>
                                                <td><?php echo date('Y/m/d H:i', strtotime($row['date'])); ?></td>
                                                <td><?php echo $row['user']; ?></td>
                                                <td><?php echo $row['activity']; ?></td>
                                                <td>
                                                    <?php if ($row['status'] == 'موفق'): ?>
                                                        <span class="badge bg-success">موفق</span>
                                                    <?php elseif ($row['status'] == 'در انتظار'): ?>
                                                        <span class="badge bg-warning">در انتظار</span>
                                                    <?php else: ?>
                                                        <span class="badge bg-danger">ناموفق</span>
                                                    <?php endif; ?>
                                                </td>
                                            </tr>
                                            <?php endwhile; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-md-4">
                        <div class="card">
                            <div class="card-header">
                                <h5 class="card-title mb-0">دسته‌بندی‌های محبوب</h5>
                            </div>
                            <div class="card-body">
                                <?php
                                $query = "SELECT category, COUNT(*) as count FROM places 
                                          GROUP BY category 
                                          ORDER BY count DESC 
                                          LIMIT 5";
                                $stmt = $db->query($query);
                                
                                while ($row = $stmt->fetch(PDO::FETCH_ASSOC)):
                                    $categoryInfo = getCategoryInfo($row['category']);
                                ?>
                                <div class="d-flex justify-content-between align-items-center mb-3">
                                    <div class="d-flex align-items-center">
                                        <div class="stat-icon me-3" style="background: <?php echo $categoryInfo['color'] . '20'; ?>; 
                                                                      color: <?php echo $categoryInfo['color']; ?>; 
                                                                      width: 40px; height: 40px; font-size: 16px;">
                                            <i class="<?php echo $categoryInfo['icon']; ?>"></i>
                                        </div>
                                        <div>
                                            <h6 class="mb-0"><?php echo $categoryInfo['name_fa']; ?></h6>
                                            <small class="text-muted"><?php echo $row['count']; ?> مکان</small>
                                        </div>
                                    </div>
                                    <div class="text-muted">
                                        <?php echo round(($row['count'] / $stats['total_places']) * 100); ?>%
                                    </div>
                                </div>
                                <?php endwhile; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // به‌روزرسانی خودکار آمار
        setInterval(() => {
            location.reload();
        }, 300000); // هر 5 دقیقه
    </script>
</body>
</html>
<?php $db = null; ?>
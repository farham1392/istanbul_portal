<?php
require_once '../../includes/functions.php';

if (!isPost()) {
    jsonResponse(['success' => false, 'message' => 'Method not allowed'], 405);
}

$days = getPost('days', 3);
$interests = getPost('interests', []);
$budget = getPost('budget', 'medium');
$userId = getCurrentUser();

// تبدیل interests به آرایه
if (is_string($interests)) {
    $interests = json_decode($interests, true);
}

// ایجاد برنامه سفر هوشمند
$itinerary = generateSmartItinerary($days, $interests, $budget);

// ذخیره در دیتابیس اگر کاربر وارد سیستم باشد
if ($userId) {
    $db = getDB();
    
    $query = "INSERT INTO itineraries (user_id, title, days, interests, budget_range, generated_itinerary) 
              VALUES (:user_id, :title, :days, :interests, :budget_range, :itinerary)";
    $stmt = $db->prepare($query);
    
    $title = "برنامه $days روزه استانبول";
    $interestsJson = json_encode($interests, JSON_UNESCAPED_UNICODE);
    $itineraryJson = json_encode($itinerary, JSON_UNESCAPED_UNICODE);
    
    $stmt->bindParam(':user_id', $userId);
    $stmt->bindParam(':title', $title);
    $stmt->bindParam(':days', $days);
    $stmt->bindParam(':interests', $interestsJson);
    $stmt->bindParam(':budget_range', $budget);
    $stmt->bindParam(':itinerary', $itineraryJson);
    
    $stmt->execute();
    $itineraryId = $db->lastInsertId();
}

jsonResponse([
    'success' => true,
    'data' => [
        'itinerary' => $itinerary,
        'summary' => [
            'days' => $days,
            'interests' => $interests,
            'budget' => $budget,
            'total_activities' => count($itinerary) * 4 // تقریباً 4 فعالیت در روز
        ]
    ]
]);
?>
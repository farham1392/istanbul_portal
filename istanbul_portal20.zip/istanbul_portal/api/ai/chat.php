<?php
session_start();
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = json_decode(file_get_contents('php://input'), true);
    $message = $data['message'] ?? '';
    $language = $data['language'] ?? 'fa';
    
    // نمونه پاسخ‌های از پیش تعریف شده برای نمایش
    $responses = [
        'fa' => [
            'default' => 'سلام! من دستیار هوشمند استانبول هستم. چگونه می‌توانم کمک کنم؟',
            'hotels' => 'بهترین هتل‌های استانبول در مناطق سلطان‌احمد، تکسیم و بشیکتاش قرار دارند. می‌توانم هتل‌های متناسب با بودجه شما را پیشنهاد دهم.',
            'restaurants' => 'استانبول به غذاهای خیابانی معروف است. دونر کباب، باقلوا و ماهی نان از غذاهای معروف هستند.',
            'attractions' => 'ایاصوفیه، کاخ توپکاپی، مسجد آبی و برج گالاتا از معروف‌ترین جاذبه‌ها هستند.',
            'transportation' => 'مترو، تراموا و تاکسی‌های زرد بهترین راه‌های حمل و نقل در استانبول هستند.'
        ],
        'en' => [
            'default' => 'Hello! I am the Istanbul AI assistant. How can I help you?',
            'hotels' => 'The best hotels in Istanbul are located in Sultanahmet, Taksim and Besiktas areas. I can suggest hotels according to your budget.',
            'restaurants' => 'Istanbul is famous for street food. Doner kebab, baklava and fish bread are famous foods.',
            'attractions' => 'Hagia Sophia, Topkapi Palace, Blue Mosque and Galata Tower are the most famous attractions.',
            'transportation' => 'Metro, tram and yellow taxis are the best transportation options in Istanbul.'
        ],
        'tr' => [
            'default' => 'Merhaba! Ben İstanbul AI asistanıyım. Nasıl yardımcı olabilirim?',
            'hotels' => 'İstanbul\'daki en iyi oteller Sultanahmet, Taksim ve Beşiktaş bölgelerinde bulunur. Bütçenize uygun oteller önerebilirim.',
            'restaurants' => 'İstanbul sokak lezzetleriyle ünlüdür. Döner kebap, baklava ve balık ekmek ünlü yemeklerdir.',
            'attractions' => 'Ayasofya, Topkapı Sarayı, Sultanahmet Camii ve Galata Kulesi en ünlü turistik yerlerdir.',
            'transportation' => 'Metro, tramvay ve sarı taksiler İstanbul\'daki en iyi ulaşım seçenekleridir.'
        ]
    ];
    
    // تشخیص موضوع سوال (ساده)
    $response = $responses[$language]['default'];
    
    if (stripos($message, 'hotel') !== false || stripos($message, 'otel') !== false) {
        $response = $responses[$language]['hotels'];
    } elseif (stripos($message, 'restaurant') !== false || stripos($message, 'food') !== false || stripos($message, 'yemek') !== false) {
        $response = $responses[$language]['restaurants'];
    } elseif (stripos($message, 'attraction') !== false || stripos($message, 'place') !== false || stripos($message, 'gezi') !== false) {
        $response = $responses[$language]['attractions'];
    } elseif (stripos($message, 'transport') !== false || stripos($message, 'ulaşım') !== false) {
        $response = $responses[$language]['transportation'];
    }
    
    echo json_encode([
        'success' => true,
        'response' => $response,
        'language' => $language
    ]);
} else {
    echo json_encode([
        'success' => false,
        'message' => 'Invalid request method'
    ]);
}
?>
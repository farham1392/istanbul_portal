<?php
require_once '../../includes/functions.php';

$searchTerm = getQuery('q');
if (!$searchTerm) {
    jsonResponse(['success' => false, 'message' => 'عبارت جستجو الزامی است']);
}

$db = getDB();

$query = "SELECT p.* FROM places p
          LEFT JOIN place_tags pt ON p.id = pt.place_id
          WHERE p.is_active = 1 
          AND (p.name_fa LIKE :search 
               OR p.description_fa LIKE :search 
               OR pt.tag_fa LIKE :search)
          GROUP BY p.id
          ORDER BY p.rating DESC";

$stmt = $db->prepare($query);
$searchTerm = "%" . $searchTerm . "%";
$stmt->bindParam(':search', $searchTerm);
$stmt->execute();

$places = $stmt->fetchAll(PDO::FETCH_ASSOC);

// افزودن اطلاعات اضافی
foreach ($places as &$place) {
    $place['category_info'] = getCategoryInfo($place['category']);
    $place['price_range_text'] = getPriceRangeText($place['price_range']);
}

jsonResponse([
    'success' => true,
    'data' => $places,
    'count' => count($places)
]);
?>
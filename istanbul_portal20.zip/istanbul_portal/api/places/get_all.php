<?php
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');

// Sample data matching your data.js
$places = [
    [
        'id' => 1,
        'name_fa' => 'ایاصوفیه',
        'name_en' => 'Hagia Sophia',
        'description_fa' => 'ایاصوفیه یک شاهکار معماری بیزانس و یکی از بزرگ‌ترین کلیساهای جهان است که بعداً به مسجد تبدیل شد و اکنون موزه است.',
        'category' => 'historical',
        'rating' => 4.8,
        'price_range' => 'medium',
        'image_url' => 'assets/visit-hagia-sophia-museum.jpg',
        'lat' => 41.0086,
        'lng' => 28.9802,
        'review_count' => 12500,
        'tags' => ['تاریخی', 'معماری', 'بیزانس', 'عثمانی']
    ],
    [
        'id' => 2,
        'name_fa' => 'کاخ توپکاپی',
        'name_en' => 'Topkapi Palace',
        'description_fa' => 'کاخ توپکاپی اقامتگاه اصلی سلاطین عثمانی برای بیش از ۴۰۰ سال بوده است.',
        'category' => 'historical',
        'rating' => 4.7,
        'price_range' => 'medium',
        'image_url' => 'assets/download (4).jpg',
        'lat' => 41.0138,
        'lng' => 28.9856,
        'review_count' => 9800,
        'tags' => ['کاخ', 'عثمانی', 'تاریخی', 'موزه']
    ],
    [
        'id' => 3,
        'name_fa' => 'مسجد آبی',
        'name_en' => 'Blue Mosque',
        'description_fa' => 'مسجد سلطان احمد که به مسجد آبی معروف است، به دلیل کاشی‌کاری‌های آبی رنگ داخلی خود مشهور می‌باشد.',
        'category' => 'mosque',
        'rating' => 4.6,
        'price_range' => 'free',
        'image_url' => 'assets/b0.webp',
        'lat' => 41.0054,
        'lng' => 28.9768,
        'review_count' => 11200,
        'tags' => ['مسجد', 'معماری اسلامی', 'تاریخی']
    ]
];

// Get query parameters
$category = $_GET['category'] ?? 'all';
$limit = $_GET['limit'] ?? 12;

// Filter by category
if ($category !== 'all') {
    $places = array_filter($places, function($place) use ($category) {
        return $place['category'] === $category;
    });
    $places = array_values($places);
}

// Apply limit
$places = array_slice($places, 0, $limit);

// Return response
echo json_encode([
    'success' => true,
    'data' => $places,
    'count' => count($places)
], JSON_UNESCAPED_UNICODE);
?>
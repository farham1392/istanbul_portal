<?php
require_once '../../config.php';
require_once '../../includes/Database.php';
require_once '../../includes/Auth.php';
require_once '../../includes/ApiResponse.php';

$db = Database::getInstance();
$auth = new Auth();
$conn = $db->getConnection();

// پارامترهای GET
$page = max(1, intval($_GET['page'] ?? 1));
$perPage = min(50, max(1, intval($_GET['per_page'] ?? 12)));
$offset = ($page - 1) * $perPage;

// فیلترها
$filters = [];
$params = [];

if (!empty($_GET['category'])) {
    $filters[] = "category = :category";
    $params[':category'] = $_GET['category'];
}

if (!empty($_GET['district'])) {
    $filters[] = "district_fa = :district";
    $params[':district'] = $_GET['district'];
}

if (!empty($_GET['price_range'])) {
    $filters[] = "price_range = :price_range";
    $params[':price_range'] = $_GET['price_range'];
}

if (!empty($_GET['min_rating'])) {
    $filters[] = "rating >= :min_rating";
    $params[':min_rating'] = floatval($_GET['min_rating']);
}

if (!empty($_GET['q'])) {
    $filters[] = "(name_fa LIKE :search OR description_fa LIKE :search OR tags LIKE :search)";
    $params[':search'] = '%' . $_GET['q'] . '%';
}

// ساختن شرط WHERE
$whereClause = !empty($filters) ? 'WHERE ' . implode(' AND ', $filters) : '';

// گرفتن تعداد کل
$total = $conn->fetch("SELECT COUNT(*) as total FROM places {$whereClause}", $params)['total'];

// گرفتن داده‌ها
$params[':limit'] = $perPage;
$params[':offset'] = $offset;

$places = $conn->fetchAll(
    "SELECT * FROM places 
     {$whereClause}
     ORDER BY rating DESC, created_at DESC 
     LIMIT :limit OFFSET :offset",
    $params
);

// اضافه کردن وضعیت علاقه‌مندی
$user = $auth->getCurrentUser();
if ($user) {
    foreach ($places as &$place) {
        $is_favorite = $conn->fetch(
            "SELECT COUNT(*) as count FROM favorites WHERE user_id = ? AND place_id = ?",
            [$user['id'], $place['id']]
        )['count'] > 0;
        $place['is_favorite'] = $is_favorite;
    }
}

ApiResponse::paginated($places, $total, $page, $perPage);
?>
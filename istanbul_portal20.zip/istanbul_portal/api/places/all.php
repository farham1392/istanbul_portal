<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

// شبیه‌سازی داده‌ها
$places = [
    [
        'id' => 1,
        'name' => 'Hagia Sophia',
        'description' => 'A former Greek Orthodox Christian patriarchal cathedral, later an Ottoman imperial mosque and now a museum in Istanbul, Turkey.',
        'image_url' => 'assets/visit-hagia-sophia-museum.jpg',
        'category' => 'museum',
        'rating' => 4.9,
        'entrance_fee' => 100,
        'currency' => 'TRY',
        'location' => 'Sultanahmet, Fatih',
        'opening_hours' => '09:00 - 19:00',
        'latitude' => 41.0086,
        'longitude' => 28.9802
    ],
    [
        'id' => 2,
        'name' => 'Blue Mosque',
        'description' => 'A historic mosque known for its blue tiles surrounding the walls of interior design.',
        'image_url' => 'assets/blue-mosque.jpg',
        'category' => 'mosque',
        'rating' => 4.8,
        'entrance_fee' => 0,
        'currency' => 'TRY',
        'location' => 'Sultanahmet, Fatih',
        'opening_hours' => '08:30 - 18:30',
        'latitude' => 41.0055,
        'longitude' => 28.9774
    ],
    [
        'id' => 3,
        'name' => 'Topkapi Palace',
        'description' => 'A large museum that served as the main residence of Ottoman sultans for 400 years.',
        'image_url' => 'assets/topkapi-palace.jpg',
        'category' => 'museum',
        'rating' => 4.7,
        'entrance_fee' => 150,
        'currency' => 'TRY',
        'location' => 'Cankurtaran, Fatih',
        'opening_hours' => '09:00 - 18:00',
        'latitude' => 41.0116,
        'longitude' => 28.9831
    ],
    [
        'id' => 4,
        'name' => 'Galata Tower',
        'description' => 'A medieval stone tower in the Galata quarter of Istanbul, offering panoramic views of the city.',
        'image_url' => 'assets/6-2-istanbul-Galata-Tower.webp',
        'category' => 'historical',
        'rating' => 4.6,
        'entrance_fee' => 75,
        'currency' => 'TRY',
        'location' => 'Beyoğlu',
        'opening_hours' => '08:30 - 23:00',
        'latitude' => 41.0255,
        'longitude' => 28.9742
    ],
    [
        'id' => 5,
        'name' => 'Grand Bazaar',
        'description' => 'One of the largest and oldest covered markets in the world with over 4,000 shops.',
        'image_url' => 'assets/grand-bazaar.jpg',
        'category' => 'shopping',
        'rating' => 4.5,
        'entrance_fee' => 0,
        'currency' => 'TRY',
        'location' => 'Beyazıt, Fatih',
        'opening_hours' => '08:30 - 19:00',
        'latitude' => 41.0108,
        'longitude' => 28.9685
    ],
    [
        'id' => 6,
        'name' => 'Basilica Cistern',
        'description' => 'The largest of several hundred ancient cisterns that lie beneath the city of Istanbul.',
        'image_url' => 'assets/basilica-cistern.jpg',
        'category' => 'historical',
        'rating' => 4.4,
        'entrance_fee' => 50,
        'currency' => 'TRY',
        'location' => 'Sultanahmet, Fatih',
        'opening_hours' => '09:00 - 18:30',
        'latitude' => 41.0083,
        'longitude' => 28.9778
    ]
];

echo json_encode([
    'success' => true,
    'places' => $places,
    'count' => count($places)
]);
?>
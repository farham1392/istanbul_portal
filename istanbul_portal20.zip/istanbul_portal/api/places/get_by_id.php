<?php
require_once '../../includes/functions.php';

$placeId = getQuery('id');
if (!$placeId) {
    jsonResponse(['success' => false, 'message' => 'شناسه مکان الزامی است']);
}

$db = getDB();

$query = "SELECT * FROM places WHERE id = :id AND is_active = 1";
$stmt = $db->prepare($query);
$stmt->bindParam(':id', $placeId);
$stmt->execute();

$place = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$place) {
    jsonResponse(['success' => false, 'message' => 'مکان یافت نشد'], 404);
}

// دریافت تگ‌ها
$tagQuery = "SELECT tag_fa, tag_en FROM place_tags WHERE place_id = :place_id";
$tagStmt = $db->prepare($tagQuery);
$tagStmt->bindParam(':place_id', $placeId);
$tagStmt->execute();
$place['tags'] = $tagStmt->fetchAll(PDO::FETCH_ASSOC);

// اطلاعات دسته‌بندی
$place['category_info'] = getCategoryInfo($place['category']);
$place['price_range_text'] = getPriceRangeText($place['price_range']);
$place['stars_html'] = generateStars($place['rating']);

// مکان‌های مشابه (همان دسته‌بندی)
$similarQuery = "SELECT id, name_fa, image_url, rating, price_range 
                 FROM places 
                 WHERE category = :category 
                 AND id != :id 
                 AND is_active = 1 
                 ORDER BY rating DESC 
                 LIMIT 5";
$similarStmt = $db->prepare($similarQuery);
$similarStmt->bindParam(':category', $place['category']);
$similarStmt->bindParam(':id', $placeId);
$similarStmt->execute();
$place['similar_places'] = $similarStmt->fetchAll(PDO::FETCH_ASSOC);

jsonResponse([
    'success' => true,
    'data' => $place
]);
?>
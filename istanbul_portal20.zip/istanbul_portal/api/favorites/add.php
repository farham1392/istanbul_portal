<?php
require_once '../../includes/functions.php';

$userId = getCurrentUser();
if (!$userId) {
    jsonResponse(['success' => false, 'message' => 'نیاز به ورود به سیستم'], 401);
}

if (!isPost()) {
    jsonResponse(['success' => false, 'message' => 'Method not allowed'], 405);
}

$placeId = getPost('place_id');
if (!$placeId) {
    jsonResponse(['success' => false, 'message' => 'شناسه مکان الزامی است']);
}

$db = getDB();

// بررسی وجود مکان
$placeQuery = "SELECT id FROM places WHERE id = :place_id";
$placeStmt = $db->prepare($placeQuery);
$placeStmt->bindParam(':place_id', $placeId);
$placeStmt->execute();

if (!$placeStmt->fetch()) {
    jsonResponse(['success' => false, 'message' => 'مکان یافت نشد']);
}

// بررسی وجود در علاقه‌مندی‌ها
$checkQuery = "SELECT id FROM user_favorites WHERE user_id = :user_id AND place_id = :place_id";
$checkStmt = $db->prepare($checkQuery);
$checkStmt->bindParam(':user_id', $userId);
$checkStmt->bindParam(':place_id', $placeId);
$checkStmt->execute();

if ($checkStmt->fetch()) {
    jsonResponse(['success' => false, 'message' => 'این مکان قبلاً به علاقه‌مندی‌ها اضافه شده']);
}

// اضافه کردن به علاقه‌مندی‌ها
$insertQuery = "INSERT INTO user_favorites (user_id, place_id) VALUES (:user_id, :place_id)";
$insertStmt = $db->prepare($insertQuery);
$insertStmt->bindParam(':user_id', $userId);
$insertStmt->bindParam(':place_id', $placeId);

if ($insertStmt->execute()) {
    jsonResponse([
        'success' => true,
        'message' => 'به علاقه‌مندی‌ها اضافه شد'
    ]);
} else {
    jsonResponse(['success' => false, 'message' => 'خطا در اضافه کردن به علاقه‌مندی‌ها']);
}
?>
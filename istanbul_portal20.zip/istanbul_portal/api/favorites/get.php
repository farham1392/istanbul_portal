<?php
require_once '../../includes/functions.php';

$userId = getCurrentUser();
if (!$userId) {
    jsonResponse(['success' => false, 'message' => 'نیاز به ورود به سیستم'], 401);
}

$db = getDB();

$query = "SELECT p.* FROM places p
          INNER JOIN user_favorites uf ON p.id = uf.place_id
          WHERE uf.user_id = :user_id
          ORDER BY uf.created_at DESC";

$stmt = $db->prepare($query);
$stmt->bindParam(':user_id', $userId);
$stmt->execute();

$favorites = $stmt->fetchAll(PDO::FETCH_ASSOC);

// افزودن اطلاعات اضافی
foreach ($favorites as &$favorite) {
    $favorite['category_info'] = getCategoryInfo($favorite['category']);
    $favorite['price_range_text'] = getPriceRangeText($favorite['price_range']);
}

jsonResponse([
    'success' => true,
    'data' => $favorites,
    'count' => count($favorites)
]);
?>
<?php
require_once '../../includes/functions.php';

$userId = getCurrentUser();
if (!$userId) {
    jsonResponse(['success' => false, 'message' => 'نیاز به ورود به سیستم'], 401);
}

if (!isPost()) {
    jsonResponse(['success' => false, 'message' => 'Method not allowed'], 405);
}

$placeId = getPost('place_id');
if (!$placeId) {
    jsonResponse(['success' => false, 'message' => 'شناسه مکان الزامی است']);
}

$db = getDB();

$query = "DELETE FROM user_favorites WHERE user_id = :user_id AND place_id = :place_id";
$stmt = $db->prepare($query);
$stmt->bindParam(':user_id', $userId);
$stmt->bindParam(':place_id', $placeId);

if ($stmt->execute()) {
    jsonResponse([
        'success' => true,
        'message' => 'از علاقه‌مندی‌ها حذف شد'
    ]);
} else {
    jsonResponse(['success' => false, 'message' => 'خطا در حذف از علاقه‌مندی‌ها']);
}
?>
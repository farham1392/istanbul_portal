<?php
require_once '../../config.php';
require_once '../../includes/Database.php';
require_once '../../includes/Auth.php';
require_once '../../includes/ApiResponse.php';

$db = Database::getInstance();
$auth = new Auth();
$conn = $db->getConnection();

// بررسی لاگین بودن
if (!$auth->isLoggedIn()) {
    ApiResponse::unauthorized();
}

$user = $auth->getCurrentUser();

// گرفتن علاقه‌مندی‌های کاربر
$favorites = $conn->fetchAll(
    "SELECT p.*, f.created_at as favorited_at 
     FROM favorites f
     JOIN places p ON f.place_id = p.id
     WHERE f.user_id = :user_id
     ORDER BY f.created_at DESC",
    [':user_id' => $user['id']]
);

// اضافه کردن وضعیت علاقه‌مندی
foreach ($favorites as &$favorite) {
    $favorite['is_favorite'] = true;
}

ApiResponse::success($favorites);
?>
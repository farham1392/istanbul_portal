<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = json_decode(file_get_contents('php://input'), true);
    $email = $data['email'] ?? '';
    $language = $data['language'] ?? 'fa';
    
    // اعتبارسنجی ایمیل
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo json_encode([
            'success' => false,
            'message' => 'Invalid email address'
        ]);
        exit;
    }
    
    // ذخیره در فایل (در حالت واقعی باید در دیتابیس ذخیره شود)
    $file = 'newsletter_subscribers.txt';
    $entry = date('Y-m-d H:i:s') . " | " . $email . " | " . $language . PHP_EOL;
    file_put_contents($file, $entry, FILE_APPEND);
    
    // پیام‌های ترجمه شده
    $messages = [
        'fa' => 'عضویت در خبرنامه با موفقیت انجام شد!',
        'en' => 'Successfully subscribed to newsletter!',
        'tr' => 'Bültene başarıyla abone olundu!',
        'ar' => 'تم الاشتراك في النشرة الإخبارية بنجاح!'
    ];
    
    echo json_encode([
        'success' => true,
        'message' => $messages[$language] ?? $messages['en']
    ]);
} else {
    echo json_encode([
        'success' => false,
        'message' => 'Invalid request method'
    ]);
}
?>
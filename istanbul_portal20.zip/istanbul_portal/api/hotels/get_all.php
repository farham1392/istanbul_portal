<?php
require_once '../../includes/functions.php';

$db = getDB();
$limit = getQuery('limit', 20);
$offset = getQuery('offset', 0);
$min_price = getQuery('min_price');
$max_price = getQuery('max_price');
$stars = getQuery('stars');
$district = getQuery('district');

$query = "SELECT * FROM hotels WHERE 1=1";
$params = [];

if ($min_price) {
    $query .= " AND price_per_night >= :min_price";
    $params[':min_price'] = $min_price;
}

if ($max_price) {
    $query .= " AND price_per_night <= :max_price";
    $params[':max_price'] = $max_price;
}

if ($stars) {
    $query .= " AND stars = :stars";
    $params[':stars'] = $stars;
}

if ($district) {
    $query .= " AND district_fa = :district";
    $params[':district'] = $district;
}

$query .= " ORDER BY rating DESC LIMIT :limit OFFSET :offset";

$stmt = $db->prepare($query);

foreach ($params as $key => $value) {
    $stmt->bindValue($key, $value);
}

$stmt->bindValue(':limit', (int)$limit, PDO::PARAM_INT);
$stmt->bindValue(':offset', (int)$offset, PDO::PARAM_INT);
$stmt->execute();

$hotels = $stmt->fetchAll(PDO::FETCH_ASSOC);

// تبدیل JSON amenities به آرایه
foreach ($hotels as &$hotel) {
    $hotel['amenities'] = json_decode($hotel['amenities'], true);
    $hotel['stars_html'] = str_repeat('★', $hotel['stars']);
}

jsonResponse([
    'success' => true,
    'data' => $hotels,
    'count' => count($hotels)
]);
?>
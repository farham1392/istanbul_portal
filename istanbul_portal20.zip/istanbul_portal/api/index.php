<?php
// api/index.php
require_once '../includes/Database.php';
require_once '../includes/Auth.php';
require_once '../includes/ApiResponse.php';
require_once '../includes/helpers.php';

// متد درخواست
$method = $_SERVER['REQUEST_METHOD'];

// مسیر درخواست
$request_uri = $_SERVER['REQUEST_URI'];
$base_path = '/istanbul-guide/api/';
$endpoint = str_replace($base_path, '', $request_uri);
$endpoint = explode('?', $endpoint)[0];
$segments = explode('/', $endpoint);

// گرفتن پارامترهای URL
$resource = $segments[0] ?? '';
$id = $segments[1] ?? null;
$action = $segments[2] ?? null;

// گرفتن بدنه درخواست
$input = json_decode(file_get_contents('php://input'), true) ?? [];

// اتصال به دیتابیس
$db = Database::getInstance();

// ایجاد شیء Auth
$auth = new Auth();

// Route کردن درخواست‌ها
try {
    switch ($resource) {
        case 'auth':
            handle_auth($method, $action, $input, $auth);
            break;
            
        case 'places':
            handle_places($method, $id, $input, $auth, $db);
            break;
            
        case 'hotels':
            handle_hotels($method, $id, $input, $auth, $db);
            break;
            
        case 'favorites':
            handle_favorites($method, $action, $input, $auth, $db);
            break;
            
        case 'itineraries':
            handle_itineraries($method, $id, $input, $auth, $db);
            break;
            
        case 'bookings':
            handle_bookings($method, $input, $auth, $db);
            break;
            
        case 'virtual-tours':
            handle_virtual_tours($method, $input, $db);
            break;
            
        case 'categories':
            handle_categories($db);
            break;
            
        case 'search':
            handle_search($input, $db);
            break;
            
        default:
            ApiResponse::notFound('منبع مورد نظر یافت نشد');
    }
} catch (Exception $e) {
    ApiResponse::error($e->getMessage(), 500);
}

// هندلرهای مختلف
function handle_auth($method, $action, $input, $auth) {
    switch ($method) {
        case 'POST':
            switch ($action) {
                case 'login':
                    if (empty($input['username']) || empty($input['password'])) {
                        ApiResponse::validationError([
                            'username' => 'نام کاربری الزامی است',
                            'password' => 'رمز عبور الزامی است'
                        ]);
                    }
                    
                    try {
                        $user = $auth->login($input['username'], $input['password']);
                        ApiResponse::success($user, 'ورود موفقیت‌آمیز بود');
                    } catch (Exception $e) {
                        ApiResponse::error($e->getMessage(), 401);
                    }
                    break;
                    
                case 'register':
                    $required = ['username', 'email', 'password'];
                    $errors = [];
                    
                    foreach ($required as $field) {
                        if (empty($input[$field])) {
                            $errors[$field] = "فیلد {$field} الزامی است";
                        }
                    }
                    
                    if (!empty($errors)) {
                        ApiResponse::validationError($errors);
                    }
                    
                    try {
                        $user = $auth->register($input);
                        ApiResponse::success($user, 'ثبت‌نام موفقیت‌آمیز بود', 201);
                    } catch (Exception $e) {
                        ApiResponse::error($e->getMessage(), 400);
                    }
                    break;
                    
                case 'logout':
                    $auth->logout();
                    ApiResponse::success(null, 'خروج موفقیت‌آمیز بود');
                    break;
                    
                default:
                    ApiResponse::notFound();
            }
            break;
            
        case 'GET':
            if ($action === 'me') {
                $user = $auth->getCurrentUser();
                if ($user) {
                    ApiResponse::success($user);
                } else {
                    ApiResponse::unauthorized();
                }
            } else {
                ApiResponse::notFound();
            }
            break;
            
        default:
            ApiResponse::error('متد غیرمجاز', 405);
    }
}

function handle_places($method, $id, $input, $auth, $db) {
    $conn = $db->getConnection();
    
    switch ($method) {
        case 'GET':
            if ($id) {
                // گرفتن یک مکان خاص
                $place = $conn->fetch(
                    "SELECT p.*, 
                            COUNT(DISTINCT f.id) as favorite_count,
                            (SELECT AVG(rating) FROM reviews WHERE place_id = p.id) as average_rating
                     FROM places p
                     LEFT JOIN favorites f ON p.id = f.place_id
                     WHERE p.id = :id
                     GROUP BY p.id",
                    [':id' => $id]
                );
                
                if ($place) {
                    // اضافه کردن تصاویر
                    $place['images'] = $conn->fetchAll(
                        "SELECT * FROM place_images WHERE place_id = :id ORDER BY sort_order",
                        [':id' => $id]
                    );
                    
                    // اضافه کردن نظرات
                    $place['reviews'] = $conn->fetchAll(
                        "SELECT r.*, u.username, u.avatar_url 
                         FROM reviews r 
                         JOIN users u ON r.user_id = u.id 
                         WHERE r.place_id = :id 
                         ORDER BY r.created_at DESC 
                         LIMIT 10",
                        [':id' => $id]
                    );
                    
                    // اضافه کردن وضعیت علاقه‌مندی
                    $user = $auth->getCurrentUser();
                    if ($user) {
                        $is_favorite = $conn->count(
                            "SELECT COUNT(*) FROM favorites WHERE user_id = :user_id AND place_id = :place_id",
                            [':user_id' => $user['id'], ':place_id' => $id]
                        ) > 0;
                        $place['is_favorite'] = $is_favorite;
                    }
                    
                    ApiResponse::success($place);
                } else {
                    ApiResponse::notFound();
                }
            } else {
                // گرفتن همه مکان‌ها با فیلتر
                $filters = $_GET;
                $page = intval($filters['page'] ?? 1);
                $perPage = intval($filters['per_page'] ?? 12);
                $offset = ($page - 1) * $perPage;
                
                $where = ['1=1'];
                $params = [];
                
                // فیلتر دسته‌بندی
                if (!empty($filters['category'])) {
                    $where[] = 'p.category = :category';
                    $params[':category'] = $filters['category'];
                }
                
                // فیلتر منطقه
                if (!empty($filters['district'])) {
                    $where[] = 'p.district_fa = :district';
                    $params[':district'] = $filters['district'];
                }
                
                // فیلتر قیمت
                if (!empty($filters['price_range'])) {
                    $where[] = 'p.price_range = :price_range';
                    $params[':price_range'] = $filters['price_range'];
                }
                
                // فیلتر امتیاز
                if (!empty($filters['min_rating'])) {
                    $where[] = 'p.rating >= :min_rating';
                    $params[':min_rating'] = floatval($filters['min_rating']);
                }
                
                // جستجو
                if (!empty($filters['q'])) {
                    $where[] = '(p.name_fa LIKE :search OR p.description_fa LIKE :search OR p.tags LIKE :search)';
                    $params[':search'] = '%' . $filters['q'] . '%';
                }
                
                $whereClause = implode(' AND ', $where);
                
                // گرفتن تعداد کل
                $total = $conn->count(
                    "SELECT COUNT(*) FROM places p WHERE {$whereClause}",
                    $params
                );
                
                // گرفتن داده‌ها
                $places = $conn->fetchAll(
                    "SELECT p.*, 
                            COUNT(DISTINCT f.id) as favorite_count,
                            (SELECT AVG(rating) FROM reviews WHERE place_id = p.id) as average_rating
                     FROM places p
                     LEFT JOIN favorites f ON p.id = f.place_id
                     WHERE {$whereClause}
                     GROUP BY p.id
                     ORDER BY p.created_at DESC
                     LIMIT :limit OFFSET :offset",
                    array_merge($params, [
                        ':limit' => $perPage,
                        ':offset' => $offset
                    ])
                );
                
                // اضافه کردن وضعیت علاقه‌مندی
                $user = $auth->getCurrentUser();
                if ($user) {
                    foreach ($places as &$place) {
                        $is_favorite = $conn->count(
                            "SELECT COUNT(*) FROM favorites WHERE user_id = :user_id AND place_id = :place_id",
                            [':user_id' => $user['id'], ':place_id' => $place['id']]
                        ) > 0;
                        $place['is_favorite'] = $is_favorite;
                    }
                }
                
                ApiResponse::paginated($places, $total, $page, $perPage);
            }
            break;
            
        case 'POST':
            // ایجاد مکان جدید (نیاز به احراز هویت)
            if (!$auth->isLoggedIn()) {
                ApiResponse::unauthorized();
            }
            
            // اعتبارسنجی داده‌ها
            $required = ['name_fa', 'category', 'district_fa'];
            $errors = [];
            
            foreach ($required as $field) {
                if (empty($input[$field])) {
                    $errors[$field] = "فیلد {$field} الزامی است";
                }
            }
            
            if (!empty($errors)) {
                ApiResponse::validationError($errors);
            }
            
            // آماده کردن داده‌ها
            $placeData = [
                'name_fa' => sanitize_input($input['name_fa']),
                'name_en' => sanitize_input($input['name_en'] ?? ''),
                'description_fa' => sanitize_input($input['description_fa'] ?? ''),
                'description_en' => sanitize_input($input['description_en'] ?? ''),
                'category' => sanitize_input($input['category']),
                'district_fa' => sanitize_input($input['district_fa']),
                'district_en' => sanitize_input($input['district_en'] ?? ''),
                'address_fa' => sanitize_input($input['address_fa'] ?? ''),
                'address_en' => sanitize_input($input['address_en'] ?? ''),
                'latitude' => floatval($input['latitude'] ?? 0),
                'longitude' => floatval($input['longitude'] ?? 0),
                'rating' => floatval($input['rating'] ?? 4.0),
                'price_range' => sanitize_input($input['price_range'] ?? 'medium'),
                'opening_hours_fa' => sanitize_input($input['opening_hours_fa'] ?? ''),
                'duration_fa' => sanitize_input($input['duration_fa'] ?? ''),
                'best_time_fa' => sanitize_input($input['best_time_fa'] ?? ''),
                'image_url' => sanitize_input($input['image_url'] ?? ''),
                'tags' => json_encode($input['tags'] ?? []),
                'created_at' => date('Y-m-d H:i:s')
            ];
            
            try {
                $placeId = $conn->insert('places', $placeData);
                
                // اضافه کردن تصاویر
                if (!empty($input['images'])) {
                    foreach ($input['images'] as $index => $image) {
                        $imageData = [
                            'place_id' => $placeId,
                            'image_url' => sanitize_input($image),
                            'sort_order' => $index,
                            'created_at' => date('Y-m-d H:i:s')
                        ];
                        $conn->insert('place_images', $imageData);
                    }
                }
                
                $place = $conn->fetch(
                    "SELECT * FROM places WHERE id = :id",
                    [':id' => $placeId]
                );
                
                ApiResponse::success($place, 'مکان با موفقیت ایجاد شد', 201);
            } catch (Exception $e) {
                ApiResponse::error('خطا در ایجاد مکان: ' . $e->getMessage(), 500);
            }
            break;
            
        case 'PUT':
        case 'PATCH':
            // آپدیت مکان (نیاز به احراز هویت)
            if (!$auth->isLoggedIn() || !$id) {
                ApiResponse::unauthorized();
            }
            
            // بررسی وجود مکان
            $existing = $conn->fetch(
                "SELECT * FROM places WHERE id = :id",
                [':id' => $id]
            );
            
            if (!$existing) {
                ApiResponse::notFound();
            }
            
            // آپدیت داده‌ها
            $updateData = [];
            $allowedFields = ['name_fa', 'name_en', 'description_fa', 'description_en', 
                            'category', 'district_fa', 'district_en', 'address_fa', 
                            'address_en', 'latitude', 'longitude', 'rating', 
                            'price_range', 'opening_hours_fa', 'duration_fa', 
                            'best_time_fa', 'image_url', 'tags'];
            
            foreach ($allowedFields as $field) {
                if (isset($input[$field])) {
                    if ($field === 'tags' && is_array($input[$field])) {
                        $updateData[$field] = json_encode($input[$field]);
                    } else {
                        $updateData[$field] = sanitize_input($input[$field]);
                    }
                }
            }
            
            if (!empty($updateData)) {
                $conn->update('places', $updateData, 'id = :id', [':id' => $id]);
                
                $updatedPlace = $conn->fetch(
                    "SELECT * FROM places WHERE id = :id",
                    [':id' => $id]
                );
                
                ApiResponse::success($updatedPlace, 'مکان با موفقیت به‌روزرسانی شد');
            } else {
                ApiResponse::error('داده‌ای برای به‌روزرسانی ارسال نشده است', 400);
            }
            break;
            
        case 'DELETE':
            // حذف مکان (نیاز به احراز هویت)
            if (!$auth->isLoggedIn() || !$id) {
                ApiResponse::unauthorized();
            }
            
            // بررسی وجود مکان
            $existing = $conn->fetch(
                "SELECT * FROM places WHERE id = :id",
                [':id' => $id]
            );
            
            if (!$existing) {
                ApiResponse::notFound();
            }
            
            // حذف تصاویر مرتبط
            $conn->delete('place_images', 'place_id = :place_id', [':place_id' => $id]);
            
            // حذف علاقه‌مندی‌ها
            $conn->delete('favorites', 'place_id = :place_id', [':place_id' => $id]);
            
            // حذف نظرات
            $conn->delete('reviews', 'place_id = :place_id', [':place_id' => $id]);
            
            // حذف مکان
            $conn->delete('places', 'id = :id', [':id' => $id]);
            
            ApiResponse::success(null, 'مکان با موفقیت حذف شد');
            break;
            
        default:
            ApiResponse::error('متد غیرمجاز', 405);
    }
}

// هندلرهای دیگر (hotels, favorites, itineraries, bookings, virtual-tours, categories, search)
// به دلیل محدودیت طول، این‌ها را در فایل‌های جداگانه ایجاد می‌کنیم
?>
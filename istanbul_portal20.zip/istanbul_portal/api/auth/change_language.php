<?php
session_start();
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = json_decode(file_get_contents('php://input'), true);
    $language = $data['language'] ?? 'fa';
    
    $_SESSION['language'] = $language;
    
    echo json_encode([
        'success' => true,
        'message' => 'Language changed successfully',
        'language' => $language
    ]);
} else {
    echo json_encode([
        'success' => false,
        'message' => 'Invalid request method'
    ]);
}
?>
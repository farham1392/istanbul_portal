<?php
// api/auth/captcha.php
require_once '../../includes/init.php';

header('Content-Type: text/html; charset=utf-8');

// تولید متن کپچا
$text = substr(str_shuffle('0123456789ABCDEFGHJKLMNPQRSTUVWXYZ'), 0, 6);
$_SESSION['captcha'] = $text;

// ایجاد HTML برای نمایش
echo "<span style='letter-spacing: 5px; font-weight: bold; color: #4F46E5;'>$text</span>";
?>
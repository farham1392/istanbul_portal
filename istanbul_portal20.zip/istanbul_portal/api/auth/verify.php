<?php
// api/auth/verify.php
require_once '../../includes/init.php';

$token = getGet('token', '');

if (empty($token)) {
    redirect('index.php');
}

$userModel = new User();
$verified = $userModel->verify($token);

if ($verified) {
    $_SESSION['verification_success'] = true;
    redirect('verification-success.php');
} else {
    $_SESSION['verification_error'] = true;
    redirect('verification-error.php');
}
?>
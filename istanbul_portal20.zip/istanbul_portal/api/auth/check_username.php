<?php
// api/auth/check_username.php
require_once '../../includes/init.php';

header('Content-Type: application/json; charset=utf-8');

$username = getGet('username', '');

if (empty($username)) {
    jsonResponse(['exists' => false]);
}

$userModel = new User();
$exists = $userModel->exists($username);

jsonResponse(['exists' => $exists]);
?>
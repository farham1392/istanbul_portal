<?php
session_start();
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = json_decode(file_get_contents('php://input'), true);
    $theme = $data['theme'] ?? 'light';
    
    $_SESSION['theme'] = $theme;
    
    echo json_encode([
        'success' => true,
        'message' => 'Theme changed successfully',
        'theme' => $theme
    ]);
} else {
    echo json_encode([
        'success' => false,
        'message' => 'Invalid request method'
    ]);
}
?>
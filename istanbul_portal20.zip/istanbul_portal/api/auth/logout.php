<?php
require_once '../../includes/functions.php';

$userId = getCurrentUser();
if (!$userId) {
    jsonResponse(['success' => false, 'message' => 'Not authenticated'], 401);
}

// در این پیاده‌سازی ساده، فقط پیام موفقیت برمی‌گردانیم
// در نسخه پیشرفته‌تر، توکن را باطل می‌کنیم

jsonResponse([
    'success' => true,
    'message' => 'خروج موفقیت‌آمیز'
]);
?>
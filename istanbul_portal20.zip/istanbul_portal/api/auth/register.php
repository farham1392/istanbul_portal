<?php
// register.php
require_once 'includes/init.php';

$page_title = 'ثبت‌نام در راهنمای استانبول';
$page_description = 'حساب کاربری خود را ایجاد کنید و از تمام امکانات راهنمای استانبول استفاده کنید';

// اگر کاربر لاگین کرده، به صفحه اصلی هدایت شود
if (isLoggedIn()) {
    redirect('index.php');
}

$errors = [];
$success = false;

// بررسی ارسال فرم
if (isPost()) {
    $authController = new AuthController();
    $result = $authController->register($_POST);
    
    if ($result['success']) {
        $success = true;
        $_SESSION['temp_user_id'] = $result['user_id'];
    } else {
        $errors = $result['errors'];
    }
}

// تولید کپچا
$captchaImage = generateCaptcha();
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?></title>
    <meta name="description" content="<?php echo $page_description; ?>">
    
    <!-- Favicon -->
    <link rel="icon" type="image/png" href="assets/favicon.png">
    
    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Vazirmatn:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    
    <!-- Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- Styles -->
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Vazirmatn', sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        
        .auth-container {
            width: 100%;
            max-width: 500px;
        }
        
        .auth-card {
            background: white;
            border-radius: 20px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
            overflow: hidden;
            animation: slideUp 0.5s ease;
        }
        
        @keyframes slideUp {
            from { transform: translateY(20px); opacity: 0; }
            to { transform: translateY(0); opacity: 1; }
        }
        
        .auth-header {
            background: linear-gradient(135deg, #4f46e5 0%, #7c3aed 100%);
            color: white;
            padding: 30px;
            text-align: center;
            position: relative;
            overflow: hidden;
        }
        
        .auth-header::before {
            content: '🗺️';
            position: absolute;
            top: 20px;
            left: 20px;
            font-size: 40px;
            opacity: 0.2;
        }
        
        .auth-header::after {
            content: '🏛️';
            position: absolute;
            bottom: 20px;
            right: 20px;
            font-size: 40px;
            opacity: 0.2;
        }
        
        .auth-header h1 {
            font-size: 28px;
            margin-bottom: 10px;
            position: relative;
            z-index: 1;
        }
        
        .auth-header p {
            opacity: 0.9;
            font-size: 14px;
            position: relative;
            z-index: 1;
        }
        
        .auth-body {
            padding: 30px;
        }
        
        .alert {
            padding: 15px;
            border-radius: 12px;
            margin-bottom: 20px;
            font-size: 14px;
            animation: fadeIn 0.3s ease;
        }
        
        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }
        
        .alert-success {
            background: #d1fae5;
            color: #065f46;
            border: 1px solid #a7f3d0;
        }
        
        .alert-error {
            background: #fee2e2;
            color: #991b1b;
            border: 1px solid #fecaca;
        }
        
        .alert ul {
            padding-right: 20px;
            margin: 10px 0 0 0;
        }
        
        .alert li {
            margin-bottom: 5px;
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
            color: #374151;
            font-size: 14px;
        }
        
        .input-with-icon {
            position: relative;
        }
        
        .input-with-icon i {
            position: absolute;
            right: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: #9ca3af;
        }
        
        .form-control {
            width: 100%;
            padding: 15px 45px 15px 15px;
            border: 2px solid #e5e7eb;
            border-radius: 12px;
            font-size: 16px;
            font-family: 'Vazirmatn', sans-serif;
            transition: all 0.3s;
        }
        
        .form-control:focus {
            border-color: #7c3aed;
            outline: none;
            box-shadow: 0 0 0 3px rgba(124, 58, 237, 0.1);
        }
        
        .form-control.error {
            border-color: #ef4444;
        }
        
        .form-control.success {
            border-color: #10b981;
        }
        
        .password-strength {
            margin-top: 5px;
            height: 5px;
            background: #e5e7eb;
            border-radius: 3px;
            overflow: hidden;
        }
        
        .password-strength-bar {
            height: 100%;
            border-radius: 3px;
            transition: width 0.3s;
        }
        
        .strength-weak {
            background: #ef4444;
            width: 25%;
        }
        
        .strength-medium {
            background: #f59e0b;
            width: 50%;
        }
        
        .strength-strong {
            background: #10b981;
            width: 100%;
        }
        
        .captcha-container {
            display: flex;
            gap: 10px;
            align-items: center;
            margin-bottom: 20px;
        }
        
        .captcha-image {
            flex: 1;
            border: 2px solid #e5e7eb;
            border-radius: 8px;
            padding: 10px;
            text-align: center;
            font-family: monospace;
            font-size: 24px;
            letter-spacing: 5px;
            background: #f9fafb;
            cursor: pointer;
            user-select: none;
        }
        
        .captcha-image:hover {
            background: #f3f4f6;
        }
        
        .captcha-input {
            flex: 2;
        }
        
        .form-options {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 25px;
        }
        
        .terms-agreement {
            display: flex;
            align-items: center;
            gap: 8px;
        }
        
        .terms-agreement input {
            width: 18px;
            height: 18px;
        }
        
        .terms-agreement label {
            font-size: 14px;
            color: #6b7280;
            margin: 0;
        }
        
        .terms-agreement a {
            color: #7c3aed;
            text-decoration: none;
        }
        
        .terms-agreement a:hover {
            text-decoration: underline;
        }
        
        .auth-btn {
            width: 100%;
            padding: 15px;
            background: linear-gradient(135deg, #4f46e5 0%, #7c3aed 100%);
            color: white;
            border: none;
            border-radius: 12px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            font-family: 'Vazirmatn', sans-serif;
            position: relative;
        }
        
        .auth-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 20px rgba(124, 58, 237, 0.3);
        }
        
        .auth-btn:disabled {
            opacity: 0.6;
            cursor: not-allowed;
            transform: none;
            box-shadow: none;
        }
        
        .btn-spinner {
            position: absolute;
            left: 15px;
            top: 50%;
            transform: translateY(-50%);
        }
        
        .divider {
            display: flex;
            align-items: center;
            margin: 30px 0;
            color: #6b7280;
        }
        
        .divider::before,
        .divider::after {
            content: '';
            flex: 1;
            height: 1px;
            background: #e5e7eb;
        }
        
        .divider span {
            padding: 0 15px;
            font-size: 14px;
        }
        
        .social-login {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 15px;
            margin-bottom: 25px;
        }
        
        .social-btn {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            padding: 12px;
            border: 2px solid #e5e7eb;
            border-radius: 12px;
            background: white;
            color: #374151;
            text-decoration: none;
            font-size: 14px;
            transition: all 0.3s;
        }
        
        .social-btn:hover {
            border-color: #7c3aed;
            background: #faf5ff;
        }
        
        .social-btn.google i {
            color: #db4437;
        }
        
        .social-btn.facebook i {
            color: #4267B2;
        }
        
        .auth-footer {
            text-align: center;
            color: #6b7280;
            font-size: 14px;
            margin-top: 25px;
        }
        
        .auth-footer a {
            color: #7c3aed;
            text-decoration: none;
            font-weight: 600;
        }
        
        .auth-footer a:hover {
            text-decoration: underline;
        }
        
        .password-toggle {
            position: absolute;
            left: 15px;
            top: 50%;
            transform: translateY(-50%);
            background: none;
            border: none;
            color: #9ca3af;
            cursor: pointer;
            font-size: 16px;
        }
        
        .progress-steps {
            display: flex;
            justify-content: space-between;
            margin-bottom: 30px;
            position: relative;
        }
        
        .progress-steps::before {
            content: '';
            position: absolute;
            top: 15px;
            right: 0;
            left: 0;
            height: 2px;
            background: #e5e7eb;
            z-index: 1;
        }
        
        .step {
            display: flex;
            flex-direction: column;
            align-items: center;
            position: relative;
            z-index: 2;
        }
        
        .step-number {
            width: 30px;
            height: 30px;
            border-radius: 50%;
            background: #e5e7eb;
            color: #6b7280;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
            margin-bottom: 8px;
            transition: all 0.3s;
        }
        
        .step.active .step-number {
            background: #7c3aed;
            color: white;
        }
        
        .step.completed .step-number {
            background: #10b981;
            color: white;
        }
        
        .step-label {
            font-size: 12px;
            color: #9ca3af;
        }
        
        .step.active .step-label {
            color: #7c3aed;
        }
        
        @media (max-width: 480px) {
            .auth-body {
                padding: 20px;
            }
            
            .social-login {
                grid-template-columns: 1fr;
            }
            
            .captcha-container {
                flex-direction: column;
            }
            
            .form-options {
                flex-direction: column;
                align-items: flex-start;
                gap: 10px;
            }
        }
    </style>
</head>
<body>
    <div class="auth-container">
        <div class="auth-card">
            <div class="auth-header">
                <h1>به جمع استانبول‌گردها بپیوندید</h1>
                <p>حساب کاربری خود را ایجاد کنید و استانبول را متفاوت کشف کنید</p>
            </div>
            
            <div class="auth-body">
                <!-- مراحل ثبت‌نام -->
                <div class="progress-steps">
                    <div class="step <?php echo $success ? 'completed' : 'active'; ?>">
                        <div class="step-number">۱</div>
                        <div class="step-label">اطلاعات حساب</div>
                    </div>
                    <div class="step <?php echo $success ? 'active' : ''; ?>">
                        <div class="step-number">۲</div>
                        <div class="step-label">تأیید ایمیل</div>
                    </div>
                    <div class="step">
                        <div class="step-number">۳</div>
                        <div class="step-label">تکمیل پروفایل</div>
                    </div>
                </div>
                
                <?php if ($success): ?>
                    <div class="alert alert-success">
                        <h3>تبریک! ثبت‌نام شما با موفقیت انجام شد 🎉</h3>
                        <p>لینک تأیید ایمیل به آدرس <strong><?php echo htmlspecialchars($_POST['email'] ?? ''); ?></strong> ارسال شد.</p>
                        <p>لطفاً ایمیل خود را بررسی کنید و روی لینک تأیید کلیک کنید.</p>
                        <div style="margin-top: 20px;">
                            <a href="login.php" style="
                                background: #10b981;
                                color: white;
                                padding: 10px 20px;
                                border-radius: 8px;
                                text-decoration: none;
                                display: inline-block;
                                margin-left: 10px;
                            ">ورود به حساب</a>
                            <a href="resend-verification.php" style="
                                background: #f3f4f6;
                                color: #6b7280;
                                padding: 10px 20px;
                                border-radius: 8px;
                                text-decoration: none;
                                display: inline-block;
                            ">ارسال مجدد ایمیل</a>
                        </div>
                    </div>
                <?php else: ?>
                    <?php if (!empty($errors)): ?>
                        <div class="alert alert-error">
                            <h3>خطا در ثبت‌نام</h3>
                            <ul>
                                <?php foreach ($errors as $error): ?>
                                    <li><?php echo htmlspecialchars($error); ?></li>
                                <?php endforeach; ?>
                            </ul>
                        </div>
                    <?php endif; ?>
                    
                    <form id="registerForm" method="POST" action="">
                        <input type="hidden" name="csrf_token" value="<?php echo CSRF_TOKEN; ?>">
                        
                        <div class="form-group">
                            <label for="full_name">نام و نام خانوادگی</label>
                            <div class="input-with-icon">
                                <i class="fas fa-user"></i>
                                <input type="text" id="full_name" name="full_name" class="form-control" 
                                       value="<?php echo htmlspecialchars($_POST['full_name'] ?? ''); ?>"
                                       placeholder="مثل: محمد رضایی">
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <label for="username">نام کاربری *</label>
                            <div class="input-with-icon">
                                <i class="fas fa-at"></i>
                                <input type="text" id="username" name="username" class="form-control" required
                                       value="<?php echo htmlspecialchars($_POST['username'] ?? ''); ?>"
                                       placeholder="مثل: mrezaei" 
                                       minlength="3" maxlength="30">
                            </div>
                            <small style="color: #6b7280; font-size: 12px; display: block; margin-top: 5px;">
                                فقط حروف انگلیسی، اعداد و زیرخط مجاز است
                            </small>
                        </div>
                        
                        <div class="form-group">
                            <label for="email">ایمیل *</label>
                            <div class="input-with-icon">
                                <i class="fas fa-envelope"></i>
                                <input type="email" id="email" name="email" class="form-control" required
                                       value="<?php echo htmlspecialchars($_POST['email'] ?? ''); ?>"
                                       placeholder="example@email.com">
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <label for="password">رمز عبور *</label>
                            <div class="input-with-icon">
                                <i class="fas fa-lock"></i>
                                <input type="password" id="password" name="password" class="form-control" required
                                       placeholder="حداقل ۶ کاراکتر" minlength="6">
                                <button type="button" class="password-toggle" onclick="togglePassword('password')">
                                    <i class="fas fa-eye"></i>
                                </button>
                            </div>
                            <div class="password-strength">
                                <div class="password-strength-bar" id="passwordStrengthBar"></div>
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <label for="confirm_password">تأیید رمز عبور *</label>
                            <div class="input-with-icon">
                                <i class="fas fa-lock"></i>
                                <input type="password" id="confirm_password" name="confirm_password" class="form-control" required
                                       placeholder="تکرار رمز عبور">
                                <button type="button" class="password-toggle" onclick="togglePassword('confirm_password')">
                                    <i class="fas fa-eye"></i>
                                </button>
                            </div>
                        </div>
                        
                        <div class="captcha-container">
                            <div class="captcha-image" onclick="refreshCaptcha()" title="کلیک برای تغییر">
                                <?php echo $captchaImage; ?>
                            </div>
                            <div class="captcha-input">
                                <input type="text" id="captcha" name="captcha" class="form-control" required
                                       placeholder="کد امنیتی">
                            </div>
                        </div>
                        
                        <div class="form-options">
                            <div class="terms-agreement">
                                <input type="checkbox" id="terms" name="terms" required>
                                <label for="terms">
                                    با <a href="terms.php" target="_blank">شرایط استفاده</a> و 
                                    <a href="privacy.php" target="_blank">حریم خصوصی</a> موافقم
                                </label>
                            </div>
                        </div>
                        
                        <button type="submit" class="auth-btn" id="registerBtn">
                            <span id="btnText">ایجاد حساب کاربری</span>
                            <span id="btnSpinner" class="btn-spinner" style="display: none;">
                                <i class="fas fa-spinner fa-spin"></i>
                            </span>
                        </button>
                    </form>
                    
                    <div class="divider">
                        <span>یا ثبت‌نام با</span>
                    </div>
                    
                    <div class="social-login">
                        <a href="api/auth/google.php" class="social-btn google">
                            <i class="fab fa-google"></i>
                            گوگل
                        </a>
                        <a href="api/auth/facebook.php" class="social-btn facebook">
                            <i class="fab fa-facebook"></i>
                            فیسبوک
                        </a>
                    </div>
                    
                    <div class="auth-footer">
                        قبلاً حساب کاربری دارید؟ 
                        <a href="login.php">وارد شوید</a>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <script>
        // تابع تغییر وضعیت نمایش رمز عبور
        function togglePassword(inputId) {
            const input = document.getElementById(inputId);
            const icon = input.parentElement.querySelector('.password-toggle i');
            
            if (input.type === 'password') {
                input.type = 'text';
                icon.className = 'fas fa-eye-slash';
            } else {
                input.type = 'password';
                icon.className = 'fas fa-eye';
            }
        }
        
        // تابع بروزرسانی کپچا
        function refreshCaptcha() {
            const captchaDiv = document.querySelector('.captcha-image');
            captchaDiv.innerHTML = '<i class="fas fa-spinner fa-spin"></i>';
            
            fetch('api/auth/captcha.php')
                .then(response => response.text())
                .then(data => {
                    captchaDiv.innerHTML = data;
                })
                .catch(error => {
                    console.error('Error refreshing captcha:', error);
                    captchaDiv.innerHTML = 'خطا';
                });
        }
        
        // بررسی قدرت رمز عبور
        document.getElementById('password').addEventListener('input', function(e) {
            const password = e.target.value;
            const strengthBar = document.getElementById('passwordStrengthBar');
            let strength = 0;
            
            if (password.length >= 6) strength++;
            if (password.length >= 8) strength++;
            if (/[A-Z]/.test(password)) strength++;
            if (/[0-9]/.test(password)) strength++;
            if (/[^A-Za-z0-9]/.test(password)) strength++;
            
            // به‌روزرسانی نوار قدرت
            strengthBar.className = 'password-strength-bar';
            if (strength <= 2) {
                strengthBar.className += ' strength-weak';
                strengthBar.style.width = '25%';
            } else if (strength <= 4) {
                strengthBar.className += ' strength-medium';
                strengthBar.style.width = '50%';
            } else {
                strengthBar.className += ' strength-strong';
                strengthBar.style.width = '100%';
            }
        });
        
        // اعتبارسنجی فرم
        document.getElementById('registerForm').addEventListener('submit', function(e) {
            e.preventDefault();
            
            // نمایش اسپینر
            const btn = document.getElementById('registerBtn');
            const btnText = document.getElementById('btnText');
            const btnSpinner = document.getElementById('btnSpinner');
            
            btn.disabled = true;
            btnText.style.display = 'none';
            btnSpinner.style.display = 'inline';
            
            // اعتبارسنجی اضافی
            const password = document.getElementById('password').value;
            const confirmPassword = document.getElementById('confirm_password').value;
            
            if (password !== confirmPassword) {
                alert('رمز عبور و تأیید رمز عبور مطابقت ندارند');
                btn.disabled = false;
                btnText.style.display = 'inline';
                btnSpinner.style.display = 'none';
                return;
            }
            
            // ارسال فرم
            this.submit();
        });
        
        // بررسی نام کاربری در لحظه
        document.getElementById('username').addEventListener('blur', function() {
            const username = this.value.trim();
            if (username.length < 3) return;
            
            fetch(`api/auth/check_username.php?username=${encodeURIComponent(username)}`)
                .then(response => response.json())
                .then(data => {
                    const input = document.getElementById('username');
                    if (data.exists) {
                        input.classList.add('error');
                        input.classList.remove('success');
                        input.setCustomValidity('این نام کاربری قبلاً ثبت شده است');
                    } else {
                        input.classList.remove('error');
                        input.classList.add('success');
                        input.setCustomValidity('');
                    }
                });
        });
        
        // بررسی ایمیل در لحظه
        document.getElementById('email').addEventListener('blur', function() {
            const email = this.value.trim();
            if (!email.includes('@')) return;
            
            fetch(`api/auth/check_email.php?email=${encodeURIComponent(email)}`)
                .then(response => response.json())
                .then(data => {
                    const input = document.getElementById('email');
                    if (data.exists) {
                        input.classList.add('error');
                        input.classList.remove('success');
                        input.setCustomValidity('این ایمیل قبلاً ثبت شده است');
                    } else {
                        input.classList.remove('error');
                        input.classList.add('success');
                        input.setCustomValidity('');
                    }
                });
        });
        
        // صفحه‌بندی خودکار فیلدها
        document.addEventListener('keydown', function(e) {
            if (e.key === 'Enter') {
                const inputs = Array.from(document.querySelectorAll('input'));
                const currentIndex = inputs.indexOf(document.activeElement);
                
                if (currentIndex > -1 && currentIndex < inputs.length - 1) {
                    e.preventDefault();
                    inputs[currentIndex + 1].focus();
                }
            }
        });
    </script>
</body>
</html>
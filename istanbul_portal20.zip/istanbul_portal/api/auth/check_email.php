<?php
// api/auth/check_email.php
require_once '../../includes/init.php';

header('Content-Type: application/json; charset=utf-8');

$email = getGet('email', '');

if (empty($email) || !isValidEmail($email)) {
    jsonResponse(['exists' => false]);
}

$userModel = new User();
$exists = $userModel->exists($email);

jsonResponse(['exists' => $exists]);
?>
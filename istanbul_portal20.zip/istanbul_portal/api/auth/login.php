<?php
require_once '../../includes/functions.php';

if (!isPost()) {
    jsonResponse(['success' => false, 'message' => 'Method not allowed'], 405);
}

$username = getPost('username');
$password = getPost('password');

if (empty($username) || empty($password)) {
    jsonResponse(['success' => false, 'message' => 'نام کاربری و رمز عبور الزامی است']);
}

$db = getDB();

$query = "SELECT id, username, email, password_hash, full_name, avatar_url, language, theme 
          FROM users 
          WHERE username = :username OR email = :username";
$stmt = $db->prepare($query);
$stmt->bindParam(':username', $username);
$stmt->execute();

$user = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$user) {
    jsonResponse(['success' => false, 'message' => 'کاربری با این مشخصات یافت نشد']);
}

if (!verifyPassword($password, $user['password_hash'])) {
    jsonResponse(['success' => false, 'message' => 'رمز عبور اشتباه است']);
}

$token = generateToken($user['id']);

// حذف رمز عبور از اطلاعات کاربر
unset($user['password_hash']);

jsonResponse([
    'success' => true,
    'message' => 'ورود موفقیت‌آمیز',
    'token' => $token,
    'user' => $user
]);
?>
<?php
session_start();
header('Content-Type: application/json');

$data = json_decode(file_get_contents('php://input'), true);
$language = $data['language'] ?? 'fa';

$availableLanguages = ['fa', 'en', 'tr'];
if (in_array($language, $availableLanguages)) {
    $_SESSION['language'] = $language;
    echo json_encode(['success' => true, 'message' => 'Language changed successfully']);
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid language']);
}
?>